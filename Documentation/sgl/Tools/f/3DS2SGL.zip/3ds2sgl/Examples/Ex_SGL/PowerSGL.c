/******************************************************************************
 * Name   : EXAMPLE.C
 *
 * Author : Carlos Sarria
 * Date   : July 1997
 *
 * Copyright : 1997 by VideoLogic Limited. All rights reserved.
  *****************************************************************************/
#include <ddraw.h>
#include <sgl.h>

#include "frontend.h"
#include "Example.h"

#pragma warning (disable : 4244)
#pragma warning (disable : 4056)

#define NAMED_ITEM			TRUE
#define UNAMED_ITEM			FALSE

#define COLOUR		    	TRUE
#define GREY				FALSE

#define SHADOW_LIGHT		TRUE
#define NO_SHADOWS			FALSE

#define SMOOTH_SHADING		TRUE
#define NO_SMOOTH_SHADING	FALSE

#define INVISIBLE			TRUE
#define	VISIBLE			    FALSE

#define	LENS_200MM			16.0f
#define	LENS_50MM			4.0f
#define	LENS_35MM			3.0f
#define	LENS_24MM			2.0f

static sgl_colour 	White   =	{0.8f,0.8f,0.8f};
static sgl_colour 	Black 	=	{0.0f,0.0f,0.0f};
static sgl_colour	DarkGrey=	{0.15f,0.15f,0.15f};


static sgl_intermediate_map BuffTex[5];

static int   logicalDevice, viewport1, finished = 0, Texture[5];
static int   camera1, camTran, Tran3DS[5];
static int   light1,pointLight;
static int   frame = 0;
float XAng = 0.0f, YAng = 0.0, XAng1=0.0f, YAng1=0.0f, TPos = -500.0;

sgl_vector LightDir = {100.0f, -100.0f, 100.0f};

static void SetupTextures (void);
static void SetupLights   (void);
static void SetupAmbient  (void);
static void SetupCameras  (void);
static void SetupGround   (void);
static void Create3D      (void);

/*---------------------------------------------------------------------------------------------------*/
int SetupScene (void)
{
	logicalDevice = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	if (logicalDevice<0) return ERR_CREATE_SCREEN_DEVICE;

	viewport1 = sgl_create_viewport (logicalDevice, 0, 0, 640, 480,100.0f, 0.0f, 580.0f, 480.0f);
   	if (viewport1<0) return ERR_CREATE_VIEWPORT;

 	SetupTextures ();
    SetupLights   ();
    SetupCameras  ();
    SetupAmbient  ();

    SetCursor (NULL);  /* This hides the pointer */
	sgl_qual_texture_filter (sgl_tf_bilinear); /* switch on bilinear filtering */

    Create3D      ();

   return 0;
}

/*-----------------------------------------------------------------------------------------------------*/
void NextFrame()
{
	register i;

    XAng += XAng1;
	YAng += YAng1;

	for (i=0; i<NUM_MESHES; i++){
   	    sgl_modify_transform (Tran3DS[i], TRUE);
        sgl_rotate    (sgl_y_axis, YAng);
        sgl_rotate    (sgl_x_axis, XAng);
	}

    sgl_modify_transform (camTran, TRUE);
    sgl_translate (0.0, 0.0, TPos);

	sgl_render(viewport1, camera1, TRUE);
	frame++;
}
/*-----------------------------------------------------------------------------------------------------*/
void Finish()
{
	if(!finished){
		FreeAllBMPTextures ();
		sgl_delete_device(logicalDevice);
		finished=1;
	}

}
/*-----------------------------------------------------------------------------------------------------*/
void SetupTextures (void)
{
register i;

  for (i=0;i<NumMaterials; i++){
         if (*(MatInfo[i].MatFile) == 0) continue;
         BuffTex[i] = ConvertBMPtoSGL   (MatInfo[i].MatFile, FALSE);
         Texture[i] = sgl_create_texture( sgl_map_16bit, sgl_map_256x256,
						            	FALSE, FALSE, &BuffTex[i],  NULL);
      }
}
/*----------------------------------------------------------------------------------------------------*/
void SetupLights (void)
{
	sgl_create_ambient_light (UNAMED_ITEM, DarkGrey, FALSE);
}
/*-----------------------------------------------------------------------------*/
void SetupAmbient (void)
{
	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
     	sgl_set_background_colour (camera1,Black);
    sgl_to_parent();
}
/*------------------------------------------------------------------------------*/
void SetupCameras (void)
{
	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
     	camTran = sgl_create_transform(TRUE);
		camera1 = sgl_create_camera(LENS_35MM,10.0f,0.0f);

    sgl_to_parent();
}
/*----------------------------------------------------------------------------------------*/
void Create3D(void)
{
register i, j, k;

    /* This function is in Example.h and creates an array of structures with 3D data */
    CreateMeshesArray ();

   for (i=0; i<NUM_MESHES;i++)
   {
	 k = Mesh[i].Material;
   sgl_create_list (UNAMED_ITEM, TRUE, FALSE);
     Tran3DS[i] = sgl_create_transform (TRUE);

       light1 = sgl_create_parallel_light( NAMED_ITEM, White ,LightDir, 0,FALSE);

       sgl_set_ambient        (MatInfo[k].MatAmbient);
       sgl_set_specular       (MatInfo[k].MatSpecular, 0);
       sgl_set_diffuse        (MatInfo[k].MatDiffuse);
	   if (Mesh[i].TexMap==TRUE){
	      sgl_set_texture_map    (Texture[i],FALSE,FALSE);
          sgl_set_texture_effect (TRUE,TRUE,TRUE,FALSE);
	   }
	   if (MatInfo[k].MatTransparency != 0.0f)   sgl_set_opacity (1.0f-MatInfo[k].MatTransparency);

       sgl_create_mesh (UNAMED_ITEM);
       sgl_add_vertices (Mesh[i].NumVertex, (sgl_vector *)Mesh[i].Vertex, (sgl_vector *)Mesh[i].Normals, (sgl_2d_vec *)Mesh[i].UV);
       for (j=0;j<Mesh[i].NumFaces;j++) sgl_add_face (3, (int *)(Mesh[i].Faces+j*3));

   sgl_to_parent ();
   }

}
/*--------------------------- End of File --------------------------------*/

