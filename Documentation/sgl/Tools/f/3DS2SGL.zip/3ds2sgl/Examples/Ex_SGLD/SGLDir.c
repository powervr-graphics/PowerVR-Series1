/*-----------------------------------------------------------------------------
   Name   : EXAMPLE.C
   Author : Carlos Sarria
   Date   : July 1997

   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#include <math.h>
#include <malloc.h>
#include <windows.h>

#include  <ddraw.h>
#include  <sgl.h>

#include "frontend.h"
#include "example.h"   /* This is the file with 3D data */


#pragma warning (disable : 4244) /* Disables float to double conversion warning */

#define PI	3.1416f

int   Device,  Init = TRUE,  frame,  TPos = 280,  UpVert=1;
int   Texture[100], PosX = 10; PosY = 10;
float Shad[255], GroundSh[1000];
float XAng1 = 0.000f,  YAng1 = 0.00f;
float XAng  = -6.3f,  YAng  =-18.85f;

SGLVERTEX  *TempVert[NUM_MESHES];
SGLCONTEXT SGLContext;
sgl_intermediate_map BuffTex[5];
sgl_uint32 GroundCo[1000][3], GCo[1000][3], Logo[50][50][3];

#define RGBColour(r, g, b) ((sgl_uint32) (((sgl_uint32)(r&0x000000FF)<<16) | ((sgl_uint32)(g&0x000000FF) << 8) | (sgl_uint32)(b&0x000000FF)))

void SetupContext   (void);
void SetupTextures  (void);
void InitMeshes     (void);
void DrawAll        (void);
void UpdateVertex   (int Num);
void Shading        (int Num);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */
/*  Inputs          :   None                                                           */
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device                                                         */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
    Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

    sgl_qual_texture_filter (sgl_tf_bilinear);

    SetupTextures ();
	SetupContext  ();

    InitMeshes ();

    SetCursor (NULL);  /* This hides the pointer */

    return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */
/*  Inputs          :   None                                                           */
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContext                                                     */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame()
{
   sgltri_startofframe (&SGLContext);
	 DrawAll ();
   sgltri_render   (&SGLContext);

   frame++;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */
/*  Inputs          :   None                                                           */
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void Finish()
{
  FreeAllBMPTextures ();
  sgl_delete_device(Device);
  Init = FALSE;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  DrawAll                                                         */
/*  Inputs          :  None                                                            */
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, XAng1, YAng1, SGLContext                            */
/*  Description     :  Updates and draws all the meshes in the model.                  */
/*  Note            :  The definition of Mesh[i] struct is in logo.h                   */
/*-------------------------------------------------------------------------------------*/
void DrawAll()
{
register i;
int Mat;

    XAng += XAng1;
	YAng += YAng1;

    for (i=0; i<NUM_MESHES; i++){

		UpdateVertex (i);

		/* Updating texture parameters for each mesh of the model */
	    SGLContext.nTextureName = Texture[Mesh[i].Material];
        SGLContext.u32Flags     = SGLTT_GOURAUD | SGLTT_BILINEAR;

		if (Mesh[i].TexMap == TRUE)  SGLContext.u32Flags |= SGLTT_TEXTURE;  /* Texture Mapping  */

        /* Global Translucent */
        Mat = Mesh[i].Material;
		if (MatInfo[Mat].MatTransparency != 0.0){
           SGLContext.u32Flags |=  SGLTT_GLOBALTRANS ;
           SGLContext.u32GlobalTrans = (sgl_uint32) (255 - MatInfo[Mat].MatTransparency * 255.0);
        }

        /* Drawing triangles... */
        sgltri_triangles (&SGLContext, Mesh[i].NumFaces, (int(*)[3])Mesh[i].Faces, TempVert[i]);
    }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupTextures                                                    */
/*  Inputs          : None                                                             */
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : NumMaterials, Texture, MatInfo                                   */
/*  Description     : Loads BMP files getting the information from MatInfo struct      */
/*-------------------------------------------------------------------------------------*/
void SetupTextures (void)
{
register i;

  for (i=0;i<NumMaterials; i++){
         if (*(MatInfo[i].MatFile) == 0) continue;
         BuffTex[i] = ConvertBMPtoSGL   (MatInfo[i].MatFile, FALSE);
         Texture[i] = sgl_create_texture( sgl_map_16bit, sgl_map_256x256,
						            	FALSE, FALSE, &BuffTex[i],  NULL);
      }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupContext                                                     */
/*  Inputs          : None                                                             */
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : SGLContext                                                       */
/*  Description     : Sets default values for the render context.                      */
/*-------------------------------------------------------------------------------------*/
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 5;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD |SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = ENABLE_SHADOWS;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.RenderRegions        = 0;
    SGLContext.n32MipmapOffset      = 0;
    SGLContext.u32GlobalTrans       = 255;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : InitMeshes                                                       */
/*  Inputs          : None                                                             */
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Shad, Mesh, TempVert, TempNormals                                */
/*  Description     : Sets initials values for meshes managing                         */
/*-------------------------------------------------------------------------------------*/
void InitMeshes (void)
{
register i,j, k=0;

    /* This function is in Example.h and creates an array of structures with 3D data */
    CreateMeshesArray ();

	/* Shad is a 255 values array with information for smooth shading */
    for (i=0; i<120; i++) Shad[k++] = (float)(120-i)/960.0 + 0.2;
    for (i=0; i<110; i++) Shad[k++] = (float) (i+20)/130.0;
    for (i=0; i<25;  i++) Shad[k++] = 1.0f;

	/* Memory allocation for TempVert */
    for (i=0; i<NUM_MESHES; i++) TempVert[i] = (SGLVERTEX *) malloc (Mesh[i].NumVertex*sizeof(SGLVERTEX));

	/* Setting UV values for all the meshes */
    for (j=0; j<NUM_MESHES;j++){
		 Shading (j);  /* setting vertices colour just once */
         for (i=0; i<Mesh[j].NumVertex; i++){
            (TempVert[j]+i)->fUOverW    =  (Mesh[j].TexMap==TRUE) ? *(Mesh[j].UV+i*2+0) : 0;
            (TempVert[j]+i)->fVOverW    =  (Mesh[j].TexMap==TRUE) ? *(Mesh[j].UV+i*2+1) : 0;
       }
    }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : UpdateVertex                                                     */
/*  Inputs          : Num (the mesh in the model)                                      */
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : XAng, YAng                                                       */
/*  Description     : Turns vertices around two axes.                                  */
/*-------------------------------------------------------------------------------------*/
void UpdateVertex (int Num)
{
sgl_vector Temp;
int i, j=0, k=0, l=0;
float x, y, z, CosX, SinX, CosY, SinY, CamZ, CamFocus = 500.0f;

CosX = cos(XAng); SinX = sin(XAng);
CosY = cos(YAng); SinY = sin(YAng);


    for (i=0; i<Mesh[Num].NumVertex; i++){

         x = *(Mesh[Num].Vertex+k++)-GroupCenter[0];
         y = *(Mesh[Num].Vertex+k++)-GroupCenter[1];
         z = *(Mesh[Num].Vertex+k++)-GroupCenter[2];

         /* Temp is the outcome vertex after the rotation */
         Temp[0]  = x * CosY - z * SinY;
         Temp[2]  = z * CosY + x * SinY;

         z        = Temp[2];
         Temp[1]  = y * CosX - z * SinX;
         Temp[2]  = z * CosX + y * SinX + TPos;

         if (Temp[2] <=0.1) Temp[2] = 0.001f;

         /* We store the SGL vertex in TempVert */
         CamZ = 1.0/(Temp[2]);
    	 (TempVert[Num]+i)->fX    =  CamFocus * CamZ * Temp[0] + 320;
         (TempVert[Num]+i)->fY    = -CamFocus * CamZ * Temp[1] + 240;
	     (TempVert[Num]+i)->fInvW =  CamZ;

   }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : Shading                                                          */
/*  Inputs          : Num                                                              */
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Light1, MatInfo, Mesh, TempVert                                  */
/*  Description     : Shades a mesh.                                                   */
/*-------------------------------------------------------------------------------------*/
void Shading (int Num)
{
register   l=0, i, Val;
unsigned   k=0;
float      CosX, SinX, CosY, SinY, x, z, y ;
float      TempCo[3], TCo, Dir, LTemp[3], Light1[3]={1.0f, 1.0f, -1.0f};
sgl_uint32 Col[3];

    /* We just rotate the light vector in the opposite direction instead of rotating all the normals */
    Dir = sqrt (Light1[0]*Light1[0]+Light1[1]*Light1[1]+Light1[2]*Light1[2]);
    x = Light1[0]/Dir;
	y = Light1[1]/Dir;
	z = Light1[2]/Dir;

    CosX = cos(-XAng); SinX = sin(-XAng);
    CosY = cos(-YAng); SinY = sin(-YAng);

    LTemp[1]  = y * CosX - z * SinX;
    LTemp[2]  = z * CosX + y * SinX;

    z = LTemp[2];
    LTemp[0]  = x * CosY - z * SinY;
    LTemp[2]  = z * CosY + x * SinY;

    k = Mesh[Num].Material;

	/* This is the mesh colour */
    TempCo[0] = 255.0 * MatInfo[k].MatDiffuse[0];
    TempCo[1] = 255.0 * MatInfo[k].MatDiffuse[1];
    TempCo[2] = 255.0 * MatInfo[k].MatDiffuse[2];


    for (i=0; i<Mesh[Num].NumVertex; i++)
	{
    	x = *(Mesh[Num].Normals+l++);
        y = *(Mesh[Num].Normals+l++);
        z = *(Mesh[Num].Normals+l++);

		/* Val is a value from 0 to 255 depending on the angle between a normal */
		/* and the light direction.                                             */
		Val = (int) (127.0 * fabs( LTemp[0] * x + LTemp[1] * y + LTemp[2] * z + 1.0) );

        TCo = Shad[Val];

        Col[0] = (int)(TempCo[0]*TCo);
        Col[1] = (int)(TempCo[1]*TCo);
        Col[2] = (int)(TempCo[2]*TCo);

		/* Setting vertex colour */
        (TempVert[Num]+i)->u32Colour  = RGBColour (Col[0],Col[1],Col[2]);
    }

}
/*--------------------------- End of File --------------------------------*/

