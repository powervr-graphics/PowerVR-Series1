/******************************************************************************
 * Name   : BINARY.C ( Reads a SGL binary file (*.sgl) )
 * 
 * Author : Carlos Sarria
 * Date   : July 1997
 *
 * Copyright : 1997 by VideoLogic Limited. All rights reserved.
  *****************************************************************************/

#include <stdlib.h>
#include <malloc.h>
#include "ddraw.h"
#include "sgl.h"

#include "frontend.h"

#pragma warning (disable : 4244)

#define SGL_LOADBMPTEXTURE 0x0000000B

#define SGL_OBJECTMESH     0x00000003

#define SGL_SETTEXTUREMAP  0x00000010
#define SGL_SETDIFFUSE     0x0000000E
#define SGL_SETAMBIENT     0x00000012
#define SGL_SETSPECULAR    0x00000013
#define SGL_SETOPACITY     0x00000011

#define SGL_CREATEMESH     0x00000008
#define SGL_ADDVERTICES    0x00000009
#define SGL_ADDFACES       0x0000000F

#define SGL_ENDOFOBJECT    0x00000014

#define SGL_ENDOFFILE      0xFFFFFFFF


#define NAMED_ITEM			TRUE
#define UNAMED_ITEM			FALSE

#define	LENS_200MM			16.0f
#define	LENS_50MM			4.0f
#define	LENS_35MM			3.0f
#define	LENS_24MM			2.0f

static sgl_colour 	White   =	{0.8f,0.8f,0.8f};
static sgl_colour 	Black 	=	{0.0f,0.0f,0.0f};
static sgl_colour	DarkGrey=	{0.15f,0.15f,0.15f};


static int   Texture[100], Trans[100], NumMeshes = 0;
static float *Vertex, *Normal, *UV;

static int   logicalDevice, viewport1, finished = 0;
static int   Camera, camTran, Tran3DS[5];
static int   frame = 0;

float XAng = 0.0f, YAng = 0.0, XAng1=0.0f, YAng1=0.0f, TPos = -500.0;

sgl_vector LightDir = {100.0f, -100.0f, 100.0f};

static void SetupLights    (void);  
static void SetupAmbient   (void);
static void SetupCameras   (void);
static void SetupGround    (void);
static void ReadBinaryFile (char *FileName); 

/*---------------------------------------------------------------------------------------------------*/
int SetupScene (void)
{

	logicalDevice = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	if (logicalDevice<0) return ERR_CREATE_SCREEN_DEVICE;
	
	viewport1 = sgl_create_viewport (logicalDevice, 0, 0, 640, 480,100.0f, 0.0f, 580.0f, 480.0f);
  	if (viewport1<0) return ERR_CREATE_VIEWPORT;

    SetupLights   ();   
    SetupCameras  ();
    SetupAmbient  ();

    SetCursor (NULL);  /* This hides the pointer */
	sgl_qual_texture_filter (sgl_tf_bilinear); /* switch on bilinear filtering */

    ReadBinaryFile ("Example.sgl");
    
    return 0;
}

/*-----------------------------------------------------------------------------------------------------*/
void NextFrame()
{
register i;

    XAng += XAng1;
	YAng += YAng1;

	for (i=0; i<NumMeshes; i++){
        sgl_modify_transform (Trans[i], TRUE);
        sgl_rotate    (sgl_y_axis, YAng);
        sgl_rotate    (sgl_x_axis, XAng);
	}

    sgl_modify_transform (camTran, TRUE);
    sgl_translate (0.0, 0.0, TPos);

	sgl_render(viewport1, Camera, TRUE);
	frame++;
}
/*-----------------------------------------------------------------------------------------------------*/					   
void Finish()
{
	if(!finished){
		FreeAllBMPTextures ();
		sgl_delete_device(logicalDevice);	
		finished=1;
	}
}
/*-----------------------------------------------------------------------------------------------------*/
void SetupLights (void)
{
	sgl_create_ambient_light (UNAMED_ITEM, DarkGrey, FALSE); 

	sgl_create_parallel_light( NAMED_ITEM, White ,LightDir, 0,FALSE);
}
/*-----------------------------------------------------------------------------*/
void SetupAmbient (void)
{
	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
     	sgl_set_background_colour (Camera,Black);
    sgl_to_parent();
}
/*------------------------------------------------------------------------------*/
void SetupCameras (void)
{
	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
     	camTran = sgl_create_transform(TRUE);
		Camera = sgl_create_camera(LENS_35MM,10.0f,0.0f);
	
    sgl_to_parent();
}
/*-------------------------------------------------------------------------------*/
void ReadBinaryFile (char *FileName)
{
unsigned int i=0, Cont =0;
char TempStr[200];
FILE *fopen(), *Fich;
unsigned int SureExit =0;
unsigned int Chunk, Size, Len, Int, FilePos = 4, Map;
unsigned int NumVert, NumFaces, TmpFace[4];
float Translucent;
sgl_colour Colour;


     Fich = fopen (FileName, "rb");
	 if (Fich == NULL)  {OutputDebugString("SGL Binary file not found"); return;}

	 /* Reading identification string SGLB */
	 fread (TempStr, 4, 1, Fich);
	 if (TempStr[0] !='S' | TempStr[1] !='G' | TempStr[2] !='L' | TempStr[3] !='B') return;

	 /* Reading texture file names */
	 while (SureExit++<300)
	 {
           fread (&Chunk, sizeof(int), 1, Fich);
           fread (&Size,  sizeof(int), 1, Fich);
		   FilePos += Size;
           
           if (Chunk == SGL_ENDOFFILE)  break;

		   if (Chunk == SGL_LOADBMPTEXTURE)
		   {
			   fread (&Len, sizeof(int), 1, Fich);
			   fread (TempStr, sizeof(char), Len, Fich);
			   fread (&Int, sizeof(int), 1, Fich);
			   TempStr[Len] = 0; 
			   Texture[i++] = LoadBMPTexture (TempStr, Int, TRUE, TRUE);
		   }
		   fseek (Fich, FilePos, SEEK_SET);   
	}

    fseek (Fich, 4, SEEK_SET); /*  Starting from the begining  */
	
	Cont=0;FilePos=4;
   
	/* Reading 3d Data */
    while (TRUE)
	 {
           fread (&Chunk, sizeof(int), 1, Fich);
           fread (&Size,  sizeof(int), 1, Fich);
		   FilePos += Size;
  
           if (Chunk == SGL_ENDOFFILE)  break;

		   switch (Chunk) 
		   {
		   case SGL_OBJECTMESH:
               sgl_create_list (NAMED_ITEM, TRUE, FALSE);
			   Trans[Cont++] =  sgl_create_transform (TRUE);
			   
		   case SGL_SETTEXTUREMAP:
			   fread (&Int, sizeof(int), 1, Fich);
			   sgl_set_texture_map(Texture[Int], FALSE, FALSE);
			   break;
           case SGL_SETDIFFUSE:
			   fread (&Colour[0], sizeof (float), 1, Fich);
			   fread (&Colour[1], sizeof (float), 1, Fich);
			   fread (&Colour[2], sizeof (float), 1, Fich);
               sgl_set_diffuse (Colour);
			   break;
		   case SGL_SETAMBIENT:
			   fread (&Colour[0], sizeof (float), 1, Fich);
			   fread (&Colour[1], sizeof (float), 1, Fich);
			   fread (&Colour[2], sizeof (float), 1, Fich);
               sgl_set_ambient (Colour);
			   break;
		  case SGL_SETSPECULAR:
			   fread (&Colour[0], sizeof (float), 1, Fich);
			   fread (&Colour[1], sizeof (float), 1, Fich);
			   fread (&Colour[2], sizeof (float), 1, Fich);
               sgl_set_specular (Colour, 0.0f);
			   break;
		  case SGL_SETOPACITY:
			   fread (&Translucent, sizeof (float), 1, Fich);
               if(Translucent) sgl_set_opacity (1.0-Translucent);
			   break;

           case SGL_CREATEMESH:
               sgl_set_texture_effect (TRUE, TRUE, TRUE, FALSE);
			   sgl_create_mesh (FALSE);
			   NumMeshes++;
			   break;
           case SGL_ADDVERTICES:
			     /* Vertices */
			    fread (&Len, sizeof(int), 1, Fich);
   				Vertex = (float *) malloc (Len*sizeof(float)*3+100);
		        fread (Vertex, sizeof(float), Len*3, Fich);
             
    			/* Normals */
				fread (&Len, sizeof(int), 1, Fich);
  				Normal = (float *) malloc (Len*sizeof(float)*3);
			    fread (Normal, sizeof(float), Len*3, Fich);
                  
                /* UV Map */
                fread (&Map, sizeof(int), 1, Fich);
				if (Map > 0) 
				{
				   Len = Map;
		           UV = (float *) malloc (Len*sizeof(float)*2);
        		   fread (UV, sizeof(float), Len*2, Fich);
				}
    			/* Add Vertices */
				if (Map) 
				{
					sgl_add_vertices ( Len, (float (*)[3])Vertex, (float (*)[3])Normal, (float (*)[2])UV);
					free (Vertex); free (Normal); free (UV);
                }
                else 
				{
					sgl_add_vertices ( Len, (float (*)[3])Vertex, (float (*)[3])Normal, NULL);
			        free (Vertex); free (Normal);
                }
			    break;

			case SGL_ADDFACES:
                fread (&NumVert, sizeof(int), 1, Fich);
				fread (&NumFaces, sizeof(int), 1, Fich);
				for (i=0; i<NumFaces; i++)
				{
                    fread (TmpFace, sizeof(int), NumVert, Fich);
               	    sgl_add_face (3, TmpFace);
                }
				break;

            case SGL_ENDOFOBJECT:
                   sgl_to_parent(); 

		   default:
			    break;
		   }
		   fseek (Fich, FilePos, SEEK_SET);   
	}
 

    fclose (Fich);
}
/*------------------------------- End of File -----------------------------------*/

