/*****************************************************************************
  Name : FRONTEND.C  (Reduced Version)
  Date : July 1997
  Platform : ANSI compatible

  Copyright : 1997 by VideoLogic Limited. All rights reserved.   
******************************************************************************/

#include <windows.h>

#include "ddraw.h"
#include "sgl.h"

#include "frontend.h" 

static HINSTANCE    hInst;
static HWND         hwnd;
static BOOL         bActive;
static DWORD        LastError;
static BOOL         bQuit = FALSE;

extern float YAng1, XAng1, TPos;

static long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   WinMain                                                        */ 
/*  Inputs          :   hInstance, hPrevInstance, lpszCmdParam, nCmdShow               */  
/*  Outputs         :   None                                                           */
/*  Returns         :   0 if successful                                                */
/*  Globals Used    :   hWnd, bActive, hInst, nStrictLocks                             */
/*  Description     :   This is the initialization of a Windows application.           */
/*                      This routine calls SetupScene(), NextFrame() and Finish()      */
/*-------------------------------------------------------------------------------------*/
int PASCAL WinMain ( HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
MSG         msg;
WNDCLASS    wndclass;
int         iret;

     hInst = hInstance;

     if (!hPrevInstance)	{
        wndclass.style = CS_HREDRAW | CS_VREDRAW;
        wndclass.lpfnWndProc = WndProc;
        wndclass.cbClsExtra = 0;
        wndclass.cbWndExtra = 0;
        wndclass.hInstance = hInstance;
        wndclass.hIcon = NULL;
        wndclass.hCursor = NULL;
        wndclass.hbrBackground = NULL;
        wndclass.lpszMenuName = NULL;
        wndclass.lpszClassName = "SGLClass";
        RegisterClass (&wndclass);
    }

    hwnd = CreateWindowEx(WS_EX_TOPMOST, "SGLClass", NULL, WS_POPUP|WS_VISIBLE, 0, 0, 
                          GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),
                          NULL, NULL, hInstance, NULL );

    if (hwnd == NULL) {LastError = GetLastError();	return FALSE;}
	
    Sleep(200);

    /* Put sgl into direct draw mode */
    iret =  sgl_use_ddraw_mode (hwnd, NULL); 

    if (iret != sgl_no_err){
       ShowWindow(hwnd,SW_HIDE);
       MessageBox (NULL,"ERROR : sgl_use_ddraw_mode failed",NULL,MB_OK);
       DestroyWindow(hwnd);
       return FALSE;
    }
	
    iret = SetupScene ();

    if (iret != sgl_no_err) {
       if (iret == ERR_CREATE_SCREEN_DEVICE)
          MessageBox(NULL,"sgl_create_screen_device\n\nERROR : Graphics device does not support required direct draw mode", NULL, MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
	
       if (iret == ERR_CREATE_VIEWPORT)
          MessageBox(NULL,"sgl_create_viewport\n\nERROR : Graphics device does not support required direct draw mode",NULL, MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
		

       DestroyWindow(hwnd);
       return FALSE;
   }
   bActive = TRUE;

   while (1)
   {
         if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE )) 
		 {
            if (!GetMessage( &msg, NULL, 0, 0 )) {Finish(); break;}
            TranslateMessage(&msg); 
            DispatchMessage(&msg);
		 }
         else if (bActive) NextFrame();
         else WaitMessage();
   }
         

return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   WndProc                                                        */ 
/*  Inputs          :   hwnd, message, wParam, lParam                                  */  
/*  Outputs         :   None                                                           */
/*  Returns         :   DefWindowProc ()                                               */
/*  Globals Used    :   hWnd, bActive, hInst                                           */
/*  Description     :   This is the control routine of this Windows application.       */
/*-------------------------------------------------------------------------------------*/
long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam)
{

switch (message){

    case WM_ACTIVATEAPP:
             bActive = (BOOL)wParam;
             break;
		
    case WM_CREATE:
            return 0;
		
    case WM_DESTROY:
            bQuit = TRUE;
            PostQuitMessage (0);
            return 0;
		
    case WM_KEYDOWN:

		switch(wParam){
             case VK_F12:
             case VK_ESCAPE:
                  bActive = FALSE;
                  Sleep(100);
                  PostMessage(hwnd, WM_CLOSE, 0, 0);
                  break;
             case VK_F3:
				  YAng1 = 0.0f; XAng1 = 0.0f;
				  break;
             case VK_F1:  
				  TPos+=10; 
				  break;
             case VK_F2: 
				  TPos-=10; 
				  break;	  
             case VK_RIGHT: 
				  YAng1+=0.006f;
				  break;
			 case VK_LEFT: 
				  YAng1-=0.006f;
				  break;
             case VK_UP:  
				  XAng1+=0.006f;
				  break;
             case VK_DOWN: 
				  XAng1-=0.006f;
				  break;
          }
          break;
    }

return DefWindowProc (hwnd, message, wParam, lParam);
}

/*-----------------------------------  END OF FILE ---------------------------------------*/
