/*==========================================================================
 * Name : nefertt.c
 *
 * Copyright : 1996 by VideoLogic Limited. All rights reserved.
 * : No part of this software, either material or conceptual 
 * : may be copied or distributed, transmitted, transcribed,
 * : stored in a retrieval system or translated into any 
 * : human or computer language in any form by any means,
 * : electronic, mechanical, manual or other-wise, or 
 * : disclosed to third parties without the express written
 * : permission of VideoLogic Limited, Unit 8, HomePark
 * : Industrial Estate, King's Langley, Hertfordshire,
 * : WD4 8LZ, U.K.
 *
 * Description : PowerVR D3D Nefertti Example
 *
 * Platform : ANSI compatible
 *
 *****************************************************************************/

#include <math.h>
#include <malloc.h>
#include "ddraw.h"
#include "d3d.h"
#include "nefertt.h"
#include "d3ddemo.h"
#include "d3dappi.h"
#include "pvrd3d.h"

//
//
//
BOOL fPVRPresent = FALSE;

/*
 * Globals to keep track of execute buffer
 */
static D3DEXECUTEDATA d3dExData;
static LPDIRECT3DEXECUTEBUFFER lpD3DExBuf;
static D3DEXECUTEBUFFERDESC debDesc;
/*
 * Gobals for materials and lights
 */
LPDIRECT3DMATERIAL lpbmat;
LPDIRECT3DMATERIAL lpmat;
LPDIRECT3DLIGHT lpD3DLight;             
/*
 * Global projection, camera_transform, head_transform and identity matricies
 */
D3DMATRIXHANDLE hProj;
D3DMATRIXHANDLE hCameraTransform;
D3DMATRIXHANDLE hHeadTranform;
D3DMATRIXHANDLE hCubeTranform;
D3DMATRIXHANDLE hDWorld;
D3DMATRIXHANDLE hSpinCube;

D3DMATRIX proj = {
    D3DVAL(5.0*480.0/640.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(5.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(1.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(-1.0), D3DVAL(0.0)
};
D3DMATRIX camera_transform = {
    D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(60.0), D3DVAL(1.0)
};
D3DMATRIX head_transform= {
    D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0)
};
D3DMATRIX cube_transform= {
    D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0)
};
D3DMATRIX identity = {
    D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0)
};

/*
 * A structure which holds the object's data
 */
typedef struct 
{
    D3DMATERIALHANDLE hmat;                /* material handle      */
    D3DTEXTUREHANDLE hTex;                 /* texture map handles  */
    LPD3DVERTEX lpV;                       /* object's vertices    */
    LPD3DTRIANGLE lpTri;                   /* object's triangles   */
    int num_vertices, num_faces;
    LPDIRECTDRAWSURFACE lpDDSurface;
	LPDIRECT3DTEXTURE lpD3DTexture;
	PPVR_CTL psPVRCtl;
	
} OBJDATA, *POBJDATA;

OBJDATA Nefertiti;
OBJDATA Cube;

#define PI				3.15926f
#define ONEOVERTWOPI	(1.0f/(2.0f*PI))

#define DS 0.06f /* amount to spin head_transform each time */

BOOL IsPowerVRD3DDevice(LPDIRECTDRAW lpDD,LPDIRECT3DDEVICE lpD3DDev)
{
	D3DTEXTUREHANDLE 	hTex;
	DDSURFACEDESC 		DDSurfDesc;
	LPDIRECTDRAWSURFACE	lpDDSurface;
	LPDIRECT3DTEXTURE	lpD3DTexture;
	PPVR_CTL			lpPVRCtl;
    
	memset (&DDSurfDesc, 0, sizeof (DDSurfDesc));
	
	/*
		Try creating surface...
	*/
	DDSurfDesc.dwSize = sizeof (DDSURFACEDESC);
    DDSurfDesc.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
    DDSurfDesc.dwHeight = 2;
    DDSurfDesc.dwWidth = 2;
    DDSurfDesc.ddsCaps.dwCaps = DDSCAPS_TEXTURE; 
    DDSurfDesc.ddpfPixelFormat.dwSize = sizeof (DDPIXELFORMAT); 
    DDSurfDesc.ddpfPixelFormat.dwFlags = DDPF_FOURCC; 
	DDSurfDesc.ddpfPixelFormat.dwFourCC = FOURCC_PVR_CTL; 

	/*
		If creation failed, PVR isn't present.
	*/
    if (lpDD->lpVtbl->CreateSurface(lpDD,&DDSurfDesc,&lpDDSurface,NULL) != DD_OK)
	{
		OutputDebugString("Failed to create surface\r\n");

		return(FALSE);
	}

	/*
		Lock it to get pointer to our control structure.
	*/
	if (lpDDSurface->lpVtbl->Lock(lpDDSurface,NULL,&DDSurfDesc,DDLOCK_WAIT,NULL) != DD_OK)
	{
		OutputDebugString("Failed to lock surface\r\n");

		RELEASE(lpDDSurface);

		return(FALSE);
	}

	lpPVRCtl = (PPVR_CTL) DDSurfDesc.lpSurface;

	/*
		Have the pointer unlock surface now.
	*/
	lpDDSurface->lpVtbl->Unlock(lpDDSurface,&DDSurfDesc); 
					
	/*
		Get texturing interface
	*/
	if (lpDDSurface->lpVtbl->QueryInterface(lpDDSurface,&IID_IDirect3DTexture, &lpD3DTexture) !=DD_OK)
	{
		OutputDebugString("Failed to get texturing interface\r\n");
		
		RELEASE(lpDDSurface);

		return(FALSE);
	}

	/*
		Get a handle for the texture, if PowerVR is the supplied device we'll 
		see a non zero value in lpPVRCtl->pvReserved.
	*/	
	lpD3DTexture->lpVtbl->GetHandle(lpD3DTexture,lpD3DDev,&hTex);

	/*
		Release objects.
	*/
	RELEASE(lpD3DTexture);
    RELEASE(lpDDSurface);

	/*
		Zero ? Yes, then its not PVR.
	*/
	if (!lpPVRCtl->pvReserved)
	{
		OutputDebugString("Reserverd word is NULL\r\n");

		return(FALSE);
	}

	/*
		Must be PVR !
	*/
	return(TRUE);
}

void MatrixRotate (LPD3DMATRIX pM, float Axis[3], float Theta)
{
	float	halfTheta;
 	float	sinHalfTheta;
 	float	cosHalfTheta;
	float	MRot[3][4]; 
	float	W,X,Y,Z;
	float	Tm1,Tm2,Tm3,Tm4,Tm5,TmNorm;
	int		Row, Col;
	float	t[3][3];
	float	n[3][3];

	/* convert to quaternian */

	halfTheta = Theta * 0.5f;

	/*	Using double sin and cos  */ 

	cosHalfTheta = (float) cos(halfTheta);
	sinHalfTheta = (float) sin(halfTheta);

	W = cosHalfTheta;
	X = sinHalfTheta * Axis[0];
	Y = sinHalfTheta * Axis[1];
	Z = sinHalfTheta * Axis[2];

	/* convert quaternian into Matrix form */ 

	Tm1 = X * X;
	Tm2 = Y * Y;
	Tm3 = Z * Z;
	Tm4 = Tm2 + Tm3;

	TmNorm= W*W + Tm1 + Tm4;  /* Normalising term */

	if (TmNorm!=0.0f)
	{
		Tm5 = 2.0f / TmNorm; 
	}
	else
	{
		Tm5 = 0.0f;
	}

	MRot[0][0] = 1.0f - Tm5*Tm4;
	MRot[1][1] = 1.0f - Tm5*(Tm1+Tm3);    
	MRot[2][2] = 1.0f - Tm5*(Tm1+Tm2);

	Tm1 = Tm5*X;
	Tm2 = Tm5*Y;
	Tm4 = Tm5*Z*W;
	Tm5 = Tm1*Y; 

	MRot[0][1] = Tm5 - Tm4;
	MRot[1][0] = Tm5 + Tm4;

	Tm4 = Tm2*W;
	Tm5 = Tm1*Z;

	MRot[0][2] = Tm5 + Tm4;
	MRot[2][0] = Tm5 - Tm4;


	Tm4 = Tm1*W; 
	Tm5 = Tm2*Z;

	MRot[1][2] = Tm5 - Tm4;
	MRot[2][1] = Tm5 + Tm4;

	t[0][0] = pM->_11;
	t[0][1] = pM->_12;
	t[0][2] = pM->_13;
	t[1][0] = pM->_21;
	t[1][1] = pM->_22;
	t[1][2] = pM->_23;
	t[2][0] = pM->_31;
	t[2][1] = pM->_32;
	t[2][2] = pM->_33;

	for(Row = 0; Row < 3; Row ++)
	{
		for(Col = 0; Col < 3; Col ++)
		{
			/*
				unroll the innermost loop to do sr bit
			*/

			n[Col][Row] = t[Row][0] * MRot[0][Col] +
						  t[Row][1] * MRot[1][Col] +
						  t[Row][2] * MRot[2][Col];
		}
	}

	pM->_11 = n[0][0];
	pM->_12 = n[0][1];
	pM->_13 = n[0][2];
	pM->_21 = n[1][0];
	pM->_22 = n[1][1];
	pM->_23 = n[1][2];
	pM->_31 = n[2][0];
	pM->_32 = n[2][1];
	pM->_33 = n[2][2];
}

BOOL CreateNefertt (POBJDATA pObject, int nVertexOffset)
{
    int i;
    LPD3DVERTEX lpv;     /* Internal pointer for vertices */
    LPD3DTRIANGLE lptri; /* Internal pointer for trianlges */

    /*
     * Generate space for the required triangles and vertices.
     */
    pObject->lpV = (LPD3DVERTEX) malloc(sizeof(D3DVERTEX) * NEFERTT_VERTICES);
    pObject->lpTri = (LPD3DTRIANGLE) malloc(sizeof(D3DTRIANGLE) * NEFERTT_FACES);

    lpv = pObject->lpV;
    lptri = pObject->lpTri;
    pObject->num_vertices = NEFERTT_VERTICES;
    pObject->num_faces = NEFERTT_FACES;
											 
    /*
    	Generate vertices at the top and bottom points.
    */
	for(i=0;i<NEFERTT_VERTICES;i++)
	{
		lpv[i].x = Vertices[i][0] * 2.0f;
		lpv[i].y = (Vertices[i][1] + 3.0f) * 2.0f;
		lpv[i].z = (Vertices[i][2] - 1.0f) * 2.0f;

	    lpv[i].nx = Normals[i][0];
	    lpv[i].ny = Normals[i][1];
	    lpv[i].nz = Normals[i][2];

// center = {0.0f, -2.0f, 4.0f};
// fu =  10.0f,fv = 0.5f

	    lpv[i].tu = (((float) atan2 (Vertices[i][2] - 4.0f, Vertices[i][0] - 0.0f) + PI) * ONEOVERTWOPI) * 5.0f;
	    lpv[i].tv = (Vertices[i][1]  + 2.0f) * 0.5f;
	}

	for(i=0;i<NEFERTT_FACES;i++)
	{
	    lptri[i].wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE ;
	    lptri[i].v1 = Faces[i][0] + nVertexOffset;
	    lptri[i].v2 = Faces[i][1] + nVertexOffset;
	    lptri[i].v3 = Faces[i][2] + nVertexOffset;
 	}

    return TRUE;
}

BOOL CreateCube (POBJDATA pObject, int nVertexOffset)
{
	float SV[8][3] =
	{
		{-1.0f,	-1.0f,	-1.0f},
		{-1.0f,	-1.0f,	1.0f},
		{1.0f,	-1.0f,	1.0f},
		{1.0f,	-1.0f,	-1.0f},
		{-1.0f,	1.0f,	-1.0f},
		{-1.0f,	1.0f,	1.0f},
		{1.0f,	1.0f,	1.0f},
		{1.0f,	1.0f,	-1.0f}
	};

	static int SF[6][3] =
	{
		{0, 4, 5},
		{1, 5, 6},
		{2, 6, 7},
		{3, 7, 4},
		{4, 7, 6},
		{3, 0, 1}
	};

    int i;
    LPD3DVERTEX lpv;     /* Internal pointer for vertices */
    LPD3DTRIANGLE lptri; /* Internal pointer for trianlges */

    /*
     * Generate space for the required triangles and vertices.
     */
    pObject->lpV = (LPD3DVERTEX) malloc(sizeof(D3DVERTEX) * 8);
    pObject->lpTri = (LPD3DTRIANGLE) malloc(sizeof(D3DTRIANGLE) * 6);

    lpv = pObject->lpV;
    lptri = pObject->lpTri;
    pObject->num_vertices = 8;
    pObject->num_faces = 6;
											 
    /*
    	Generate vertices at the top and bottom points.
    */
	for(i=0;i<8;i++)
	{
		// normals and uv are not necessary as we won't be
		// lighting or texturing this object.

		lpv[i].x = SV[i][0] * 3;
		lpv[i].y = SV[i][1] * 3;
		lpv[i].z = SV[i][2] * 3;
	}

	for(i=0;i<6;i++)
	{
	    lptri[i].wFlags = 0;
	    lptri[i].v1 = SF[i][0] + nVertexOffset;
	    lptri[i].v2 = SF[i][1] + nVertexOffset;
	    lptri[i].v3 = SF[i][2] + nVertexOffset;
 	}

    return TRUE;
}


void
OverrideDefaults(Defaults* defaults)
{
    lstrcpy(defaults->Name, "Nefertiti");
    defaults->bClearsOn = TRUE;
}

/*
 * Each frame, renders the scene and calls mod_buffer to modify the object
 * for the next frame.
 */
BOOL
RenderScene(LPDIRECT3DDEVICE lpDev, LPDIRECT3DVIEWPORT lpView,
            LPD3DRECT lpExtent)
{
    /*
     * Execute the instruction buffer
     */
    if (lpDev->lpVtbl->BeginScene(lpDev) != D3D_OK)
        return FALSE;
    if (lpDev->lpVtbl->Execute(lpDev, lpD3DExBuf,
                               lpView, D3DEXECUTE_UNCLIPPED) != D3D_OK)
        return FALSE;
    if (lpDev->lpVtbl->EndScene(lpDev) != D3D_OK)
        return FALSE;
    if (lpD3DExBuf->lpVtbl->GetExecuteData(lpD3DExBuf, &d3dExData)!= D3D_OK)
        return FALSE;
    *lpExtent = d3dExData.dsStatus.drExtent;

    return TRUE;
}

BOOL
InitScene(void)
{
    /*
     * Generate the objects
     */
    if (CreateNefertt (&Nefertiti, 0) &&
		CreateCube (&Cube, Nefertiti.num_vertices))
	{
		return TRUE;
	}
	return (FALSE);
}

void
ReleaseScene(void)
{
    if (Nefertiti.lpV)
        free(Nefertiti.lpV);
    if (Nefertiti.lpTri)
		free(Nefertiti.lpTri);

    if (Cube.lpV)
        free(Cube.lpV);
    if (Cube.lpTri)
        free(Cube.lpTri);
}

/*
 * Release the memory allocated for the scene and all D3D objects created.
 */
void
ReleaseView(LPDIRECT3DVIEWPORT lpView)
{
    if (lpView)
        lpView->lpVtbl->DeleteLight(lpView, lpD3DLight);
    RELEASE(lpD3DLight);
    RELEASE(lpD3DExBuf);
    RELEASE(lpmat);
    RELEASE(lpbmat);

    if (Cube.lpDDSurface)
	{
		if (Cube.lpD3DTexture)
		{
			IDirect3DTexture_Release (Cube.lpD3DTexture);
		}

		IDirectDrawSurface_Release (Cube.lpDDSurface);
	}
}

/*
 * Builds the scene and initializes the execute buffer for rendering.  Returns 0 on failure.
 */
BOOL
InitView(LPDIRECTDRAW lpDD, LPDIRECT3D lpD3D, LPDIRECT3DDEVICE lpDev,
           LPDIRECT3DVIEWPORT lpView, int NumTextures,
           LPD3DTEXTUREHANDLE TextureHandle)
{
    /* Pointers into the exectue buffer. */
    LPVOID lpBufStart, lpInsStart, lpPointer;
    LPDIRECT3DEXECUTEBUFFER lpD3DExCmdBuf;
    size_t size;

    /* Light and materials */
    D3DLIGHT light;                                     
    D3DMATERIAL bmat;
    D3DMATERIALHANDLE hbmat;
    D3DMATERIAL mat;

    D3DMATRIX dworld, spincube;
	float Axis[3] = {0.0f, -1.0f, 0.0f};
	float Spin[3] = {1.0f, 1.0f, 1.0f};

	//==========================================================================
	// This is the setup for the shadows / light volumes.
	//==========================================================================
	fPVRPresent = FALSE;

	Cube.hTex = 0;
	Cube.lpD3DTexture = 0;
	Cube.lpDDSurface = 0;

	if (IsPowerVRD3DDevice(d3dappi.lpDD,d3dappi.lpD3DDevice))
	{
		HRESULT ddrval;
		DDSURFACEDESC DDSurfDesc;

		fPVRPresent = TRUE;

		// Attempt to create a 'shadow' texture. D3D will think it is an ordinary
		// texture, but we are actually using it to signal the HAL when to treat
		// a normal mesh as a shadow or light volume. 
		memset (&DDSurfDesc, 0, sizeof (DDSurfDesc));
		
		DDSurfDesc.dwSize = sizeof (DDSurfDesc);
	    DDSurfDesc.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
	    DDSurfDesc.dwHeight = 2;
	    DDSurfDesc.dwWidth = 2;
	    DDSurfDesc.ddsCaps.dwCaps = DDSCAPS_TEXTURE; 
	    DDSurfDesc.ddpfPixelFormat.dwSize = sizeof (DDPIXELFORMAT); 
	    DDSurfDesc.ddpfPixelFormat.dwFlags = DDPF_FOURCC; 
		DDSurfDesc.ddpfPixelFormat.dwFourCC = FOURCC_PVR_CTL; 

		// create a ddraw surface of the special format

		ddrval = D3DAppCreateSurface (&DDSurfDesc, &Cube.lpDDSurface);

		if (ddrval == DD_OK)
		{
			// Make a texture out of it. Query the surface for the texture
			// interface ...
			IDirectDrawSurface_QueryInterface (Cube.lpDDSurface, &IID_IDirect3DTexture, &Cube.lpD3DTexture);

			if (Cube.lpD3DTexture)
			{
				// Lock the texture so we can get at our parameter block. Instead 
				// of pixel data, DDSurfDesc.lpSurface will contain a pointer to 
				// a PVR_CTL structure (details in pvrd3d.h).

				memset (&DDSurfDesc, 0, sizeof (DDSurfDesc));
				DDSurfDesc.dwSize = sizeof (DDSurfDesc);
				DDSurfDesc.dwFlags = DDLOCK_SURFACEMEMORYPTR;	
				
				ddrval = IDirectDrawSurface_Lock (Cube.lpDDSurface, 
												  NULL,
												  &DDSurfDesc,
												  DDLOCK_WAIT, // Straight in there!
												  NULL);

				if (ddrval == DD_OK)
				{
					// A pointer to the special data structure is returned instead of
					// pixel data. 

					Cube.psPVRCtl = (PPVR_CTL) DDSurfDesc.lpSurface;
					
					#if 1
						// shadow volume!
						// not a particularly dark shadow. Values range between
						// 0.0 (completely dark) to 1.0 (indistinguishable from
						// surroundings). In light or in shadow, the character and
						// chrominance of shading is retained, but the intensity 
						// varies
						Cube.psPVRCtl->dwType = PVR_SHADOWVOL;
						Cube.psPVRCtl->fShadowBrightness = 0.6f;
					#else
						// light volume!
						// bright scungey green light volume. Any pixel that is in
						// this light volume has this colour ADDED.
						Cube.psPVRCtl->dwType = PVR_LIGHTVOL;
						Cube.psPVRCtl->dcLightVolumeColour = RGB_MAKE (0, 255, 0);
					#endif

					// Unlock the bugger

					IDirectDrawSurface_Unlock (Cube.lpDDSurface, &DDSurfDesc); 
				}
				else
				{
					OutputDebugString ("Texture lock failed\n");
					IDirect3DTexture_Release (Cube.lpD3DTexture);
					IDirectDrawSurface_Release (Cube.lpDDSurface);
					Cube.hTex = 0;
					Cube.lpD3DTexture = 0;
					Cube.lpDDSurface = 0;
				}

				// Get a handle to the texture, this gives us,
				// 1) A check that PVR is actually being used for this context (also done is IsPVRD3DDevice)
				// 2) A valid handle for specifying volume data in exe buffers
				// 3) Associates this control with this D3D context.
				IDirect3DTexture_GetHandle (Cube.lpD3DTexture, lpDev, &Cube.hTex);

				if (!Cube.hTex || !Cube.psPVRCtl->pvReserved)
				{
					OutputDebugString ("Texture get handle failed\n");
					IDirect3DTexture_Release (Cube.lpD3DTexture);
					IDirectDrawSurface_Release (Cube.lpDDSurface);
					Cube.lpD3DTexture = 0;
					Cube.lpDDSurface = 0;
					Cube.hTex = 0;
				}
			}
			else
			{
				OutputDebugString ("Texture query i/f failed\n");
				IDirectDrawSurface_Release (Cube.lpDDSurface);
				Cube.lpDDSurface = 0;
			}
		}
		else
		{
			OutputDebugString ("CreateSurface failed!\n");		
			Cube.lpDDSurface = 0;
		}
	}
	else
	{
		OutputDebugString("PowerVR not detected\n");
	}
	    
	/*
     * Set the camera_transform, head_transform and projection matrices
     */
    MAKE_MATRIX(lpDev, hProj, proj);
    MAKE_MATRIX(lpDev, hCameraTransform, camera_transform);
    MAKE_MATRIX(lpDev, hHeadTranform, head_transform);
    MAKE_MATRIX(lpDev, hCubeTranform, cube_transform);
    /*
     * Create a buffer for matrix set commands etc.
     */
    size = 0;
    size += sizeof(D3DINSTRUCTION) * 4;
    size += sizeof(D3DSTATE) * 7;
    memset(&debDesc, 0, sizeof(D3DEXECUTEBUFFERDESC));
    debDesc.dwSize = sizeof(D3DEXECUTEBUFFERDESC);
    debDesc.dwFlags = D3DDEB_BUFSIZE;
    debDesc.dwBufferSize = size;
    if (lpDev->lpVtbl->CreateExecuteBuffer(lpDev, &debDesc, &lpD3DExCmdBuf, NULL) != D3D_OK)
        return FALSE;
    if (lpD3DExCmdBuf->lpVtbl->Lock(lpD3DExCmdBuf, &debDesc) != D3D_OK)
        return FALSE;
    lpBufStart = debDesc.lpData;
    memset(lpBufStart, 0, size);
    lpPointer = lpBufStart;

    lpInsStart = lpPointer;
    OP_STATE_TRANSFORM(3, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_WORLD, hHeadTranform, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_VIEW, hCameraTransform, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_PROJECTION, hProj, lpPointer);
    OP_STATE_LIGHT(1, lpPointer);
        STATE_DATA(D3DLIGHTSTATE_AMBIENT, RGBA_MAKE(128, 128, 128, 255), lpPointer);
//	OP_STATE_RENDER (1, lpPointer);
//        STATE_DATA (D3DRENDERSTATE_WRAPU, TRUE, lpPointer);
//        STATE_DATA (D3DRENDERSTATE_WRAPV, TRUE, lpPointer);
//        STATE_DATA (D3DRENDERSTATE_CULLMODE, D3DCULL_NONE, lpPointer);
    OP_EXIT(lpPointer);
    /*
     * Setup the execute data describing the buffer
     */
    lpD3DExCmdBuf->lpVtbl->Unlock(lpD3DExCmdBuf);
    memset(&d3dExData, 0, sizeof(D3DEXECUTEDATA));
    d3dExData.dwSize = sizeof(D3DEXECUTEDATA);
    d3dExData.dwInstructionOffset = (ULONG) 0;
    d3dExData.dwInstructionLength = (ULONG) ((char*)lpPointer - (char*)lpInsStart);
    lpD3DExCmdBuf->lpVtbl->SetExecuteData(lpD3DExCmdBuf, &d3dExData);
    lpDev->lpVtbl->BeginScene(lpDev);
    lpDev->lpVtbl->Execute(lpDev, lpD3DExCmdBuf, lpView, D3DEXECUTE_UNCLIPPED);
    lpDev->lpVtbl->EndScene(lpDev);
    /*
     * We are done with the command buffer.
     */
    lpD3DExCmdBuf->lpVtbl->Release(lpD3DExCmdBuf);
    /*
     * Set background to black material
     */
    if (lpD3D->lpVtbl->CreateMaterial(lpD3D, &lpbmat, NULL) != D3D_OK)
        return FALSE;
    memset(&bmat, 0, sizeof(D3DMATERIAL));
    bmat.dwSize = sizeof(D3DMATERIAL);
    bmat.dwRampSize = 1;
    lpbmat->lpVtbl->SetMaterial(lpbmat, &bmat);
    lpbmat->lpVtbl->GetHandle(lpbmat, lpDev, &hbmat);
    lpView->lpVtbl->SetBackground(lpView, hbmat);
    /*
     * Create a material, set its description and obtain a handle to it.
     */
    Nefertiti.hTex = TextureHandle[1];
    if (lpD3D->lpVtbl->CreateMaterial(lpD3D, &lpmat, NULL) != D3D_OK)
        return FALSE;
    memset(&mat, 0, sizeof(D3DMATERIAL));
    mat.dwSize = sizeof(D3DMATERIAL);
    mat.diffuse.r = (D3DVALUE)1.0;
    mat.diffuse.g = (D3DVALUE)1.0;
    mat.diffuse.b = (D3DVALUE)1.0;
    mat.diffuse.a = (D3DVALUE)1.0;
    mat.ambient.r = (D3DVALUE)1.0;
    mat.ambient.g = (D3DVALUE)1.0;
    mat.ambient.b = (D3DVALUE)1.0;
    mat.specular.r = (D3DVALUE)1.0;
    mat.specular.g = (D3DVALUE)1.0;
    mat.specular.b = (D3DVALUE)1.0;
    mat.power = (float)1.0;
    mat.dwRampSize = 32;
    mat.hTexture = Nefertiti.hTex;
    lpmat->lpVtbl->SetMaterial(lpmat, &mat);
    lpmat->lpVtbl->GetHandle(lpmat, lpDev, &Nefertiti.hmat);
    /*
     * Create the matrix which spins the sphere
     */
    dworld = identity;
	MatrixRotate (&dworld, Axis, DS);
    MAKE_MATRIX(lpDev, hDWorld, dworld);
    /*
     * Create the matrix which spins the cube_transform
     */
    spincube = identity;
	MatrixRotate (&spincube, Spin, DS * 0.1f);
    MAKE_MATRIX(lpDev, hSpinCube, spincube);
    /*
     * Create the main execute buffer
     */
    size = sizeof(D3DVERTEX) * Cube.num_vertices;
    size += sizeof(D3DPROCESSVERTICES) * 1;
    size += sizeof(D3DTRIANGLE) * Cube.num_faces;
    size += sizeof(D3DSTATUS) * 1;
    size += sizeof(D3DINSTRUCTION) * 16;
    size += sizeof(D3DSTATE) * 10;
    size += sizeof(D3DMATRIXMULTIPLY) * 2;
    size += sizeof(D3DVERTEX) * Nefertiti.num_vertices;
    size += sizeof(D3DPROCESSVERTICES) * 1;
    size += sizeof(D3DTRIANGLE) * Nefertiti.num_faces;

    memset(&debDesc, 0, sizeof(D3DEXECUTEBUFFERDESC));
    debDesc.dwSize = sizeof(D3DEXECUTEBUFFERDESC);
    debDesc.dwFlags = D3DDEB_BUFSIZE;
    debDesc.dwBufferSize = size;
    if (lpDev->lpVtbl->CreateExecuteBuffer(lpDev, &debDesc, &lpD3DExBuf, 
                                           NULL) != D3D_OK)
                                               return FALSE;
    /*
     * lock it so it can be filled	  
     */
    if (lpD3DExBuf->lpVtbl->Lock(lpD3DExBuf, &debDesc) != D3D_OK)
        return FALSE;
    lpBufStart = debDesc.lpData;
    memset(lpBufStart, 0, size);
    lpPointer = lpBufStart;

    VERTEX_DATA(Nefertiti.lpV, Nefertiti.num_vertices, lpPointer);
    VERTEX_DATA(Cube.lpV, Cube.num_vertices, lpPointer);

    /*
     * Save the location of the first instruction and add instructions to 
     * execute buffer.
     */
	lpInsStart = lpPointer;

	OP_STATE_LIGHT (1, lpPointer);
        STATE_DATA (D3DLIGHTSTATE_MATERIAL, Nefertiti.hmat, lpPointer);
    OP_SET_STATUS (D3DSETSTATUS_ALL, D3DSTATUS_DEFAULT, 2048, 2048, 0, 0, lpPointer);

	OP_MATRIX_MULTIPLY (1, lpPointer);
        MATRIX_MULTIPLY_DATA (hDWorld, hHeadTranform, hHeadTranform, lpPointer);
    OP_PROCESS_VERTICES (1, lpPointer);
        PROCESSVERTICES_DATA (D3DPROCESSVERTICES_TRANSFORMLIGHT, 0, Nefertiti.num_vertices, lpPointer);
	
    OP_STATE_TRANSFORM (1, lpPointer);
	    STATE_DATA (D3DTRANSFORMSTATE_WORLD, hCubeTranform, lpPointer);

	OP_MATRIX_MULTIPLY (1, lpPointer);
        MATRIX_MULTIPLY_DATA (hSpinCube, hCubeTranform, hCubeTranform, lpPointer);
    OP_PROCESS_VERTICES (1, lpPointer);
        PROCESSVERTICES_DATA (D3DPROCESSVERTICES_TRANSFORM, Nefertiti.num_vertices, Cube.num_vertices, lpPointer);

    OP_STATE_TRANSFORM (1, lpPointer);
	    STATE_DATA (D3DTRANSFORMSTATE_WORLD, hHeadTranform, lpPointer);

	OP_STATE_RENDER (1, lpPointer);
        STATE_DATA (D3DRENDERSTATE_TEXTUREHANDLE, Nefertiti.hTex, lpPointer);
    
	/*
     * Make sure that the triangle data (not OP) will be QWORD aligned
     */
    if (QWORD_ALIGNED(lpPointer)) 
	{
        OP_NOP(lpPointer);
    }
    
	OP_TRIANGLE_LIST (Nefertiti.num_faces, lpPointer);
       TRIANGLE_LIST_DATA (Nefertiti.lpTri, Nefertiti.num_faces, lpPointer);

	if (Cube.hTex)
	{
		// if there is a valid handle for shadow etc, add the shadow/light volume

		OP_STATE_RENDER (1, lpPointer);
			STATE_DATA (D3DRENDERSTATE_TEXTUREHANDLE, Cube.hTex, lpPointer);

		if (QWORD_ALIGNED(lpPointer)) 
		{
			OP_NOP(lpPointer);
		}
    
		OP_TRIANGLE_LIST (Cube.num_faces, lpPointer);
		   TRIANGLE_LIST_DATA (Cube.lpTri, Cube.num_faces, lpPointer);
	}

	OP_EXIT(lpPointer);
    
	/*
     * Setup the execute data describing the buffer
     */
    lpD3DExBuf->lpVtbl->Unlock(lpD3DExBuf);
    memset(&d3dExData, 0, sizeof(D3DEXECUTEDATA));
    d3dExData.dwSize = sizeof(D3DEXECUTEDATA);
    d3dExData.dwVertexCount = Cube.num_vertices + Nefertiti.num_vertices;
    d3dExData.dwInstructionOffset = (ULONG)((char*)lpInsStart - (char*)lpBufStart);
    d3dExData.dwInstructionLength = (ULONG)((char*)lpPointer - (char*)lpInsStart);
    lpD3DExBuf->lpVtbl->SetExecuteData(lpD3DExBuf, &d3dExData);
    
	/*
     *  Create the light
     */
    memset(&light, 0, sizeof(D3DLIGHT));
    light.dwSize = sizeof(D3DLIGHT);
    light.dltType = D3DLIGHT_DIRECTIONAL;
    light.dcvColor.r = D3DVAL(1.0);
    light.dcvColor.g = D3DVAL(1.0);
    light.dcvColor.b = D3DVAL(1.0);
    light.dcvColor.a = D3DVAL(1.0);
    //light.dvPosition.x = D3DVAL(4.0);
    //light.dvPosition.y = D3DVAL(0.0);
    //light.dvPosition.z = D3DVAL(-10.0);
    light.dvDirection.x = D3DVALP(0.0, 12);
    light.dvDirection.y = D3DVALP(0.0, 12);
    light.dvDirection.z = D3DVALP(1.0, 12);
    light.dvAttenuation0 = (float)0.0;
    light.dvAttenuation1 = (float)0.0;
    light.dvAttenuation2 = (float)0.0;
    if (lpD3D->lpVtbl->CreateLight(lpD3D, &lpD3DLight, NULL) != D3D_OK)
        return FALSE;
    if (lpD3DLight->lpVtbl->SetLight(lpD3DLight, &light) != D3D_OK)
        return FALSE;
    if (lpView->lpVtbl->AddLight(lpView, lpD3DLight) != D3D_OK)
        return FALSE;

    return TRUE;
}


