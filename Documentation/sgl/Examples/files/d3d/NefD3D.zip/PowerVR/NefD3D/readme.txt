This directory contains a number of miscellaneous files used by the other
sample programs.  Many of them code that you may find useful in your
application.

Rather than browse through these files directly, we suggest that you start
with the sample that is doing something close to what you want to do.  Then
when you find references to functions which are not in the files in that
sample directory, you should look for them here.
