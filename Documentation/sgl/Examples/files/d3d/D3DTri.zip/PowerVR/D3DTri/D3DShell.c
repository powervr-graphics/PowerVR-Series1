/*****************************************************************************
  Name : D3DShell.c v1.1.5
  Date : May 1998
  Platform : ANSI compatible

  Build Info : D3DShell.c + D3DShell.h + DDRAW.LIB

  D3D Shell is a program used to make D3D programming easier and less 
  time-consuming. What it does is taking care of all DirectDraw and Direct3D
  initialisation for the user : handling DirectDraw and D3D devices, Fullscreen
  mode, resolution mode, window modes, buffering modes, Z-Buffer use, viewport
  creation, viewport clearing, etc...

  Although best used with DrawPrimitive, the Shell also supports execute buffers.
  To use execute buffers, the user should just retrieve DirectX 3.0 equivalent 
  variables to the interfaces passed to InitView and RenderScene. An example file, 
  called SceneEB.c, shows how to use Execute buffers with the D3D Shell.

  D3D Shell consists of only 2 files (D3DShell.c and D3DShell.h). It does NOT
  require a resource file of any kind. Thus, when creating your D3D application,
  you just have to link your files with these two, plus of course the DirectDraw
  library (DDRAW.LIB).

  The user is only responsible of creating all D3D variables that will be
  needed at rendering time (lights, materials, etc..).
  The user can choose preferences thanks to the D3DShellSetPreferences() function.
  A list of flags that can be passed to this function can be found in the
  D3DShell.h file.
  
  For a list of functions that the user has to use to interact with the
  D3D Shell, see the D3DShell.h file.

  
  * Screen capture

  During execution, a screen capture can be performed by pressing F12.
  The current contents of the back buffer will be saved as a .BMP file
  named ScreenXX.bmp. Up to 100 different images can be saved.
  
  
  *	Helper Functions :

  2 helper functions have also been added to the shell :

  D3DShellSetDisplayText(char *pszText, int nX, int nY)
  ->This function will display a text on the screen at the nX, nY position.
    Up to 50 strings can be displayed at the same time.
	This function should be used in the RenderScene() function.

  D3DShellLoadBMP(char *lpName, BOOL bTranslucent)
  ->This function enables the user to load a BMP texture from a resource or a file.
    This function should be used in the InitView function. If bTranslucent is set,
	then the file t+"Name" will also be read to retrieve the alpha values (given
	by the RED colour) for this texture.
	Up to 256 textures can be loaded with this function.
	You do NOT need to restore the texture surfaces at any time, as it is already
	done by the D3D Shell.


  Of course, the user doesn't have to use these helper functions, they are provided
  to make common rendering tasks easier.


  * Things to do :

  - Use a PolyText function instead of a GDI blit.
  - Improve the texture loading function.
  - Enable 32 bpp surface screen capture.
  
			  
  * Current bugs :

  - Single buffer mode does not work the first time you select it if a 
    secondary device is used. (The screen stays with the GDI)
	If anyone has any idea why, please let me know !

    
  Please report any bugs or comments to me. If, for any reason, you need to
  modify the D3D Shell, please report to me so I can do the modifications
  myself.

  
  * LATEST CHANGES :
  27/05/98 : - Changed texture function because it was loading texture
			 upside down.
			 - Reverse alpha channel (255-A) in texture loading function
			 so it can be SGL Direct compatible.
			 - Added name of filename when not found.
			 Versioning to 1.1.5.

  14/05/98 : - Added even proper exit to failing functions in WinMain().
			 Versioning to 1.1.4

  21/04/98 : - Fixed a tiny bug that reported MAX video memory for
			 window instead of 0.
			 Versioning to 1.1.3

  08/04/98 : - New viewport clear dimensions (removed the -1 of the width
			 and height values).
			 - Removed the call to D3DFEChangeD3DMode after DisplayInfo
			 toggled.

  07/04/98 : - Added the Clear menu option + Clear flags (DEFAULT_CLEAR_ON,
			 FORCE_CLEAR_ON and FORCE_CLEAR_OFF). 
			 - The value used to enable a resolution or not is now the
			 *exact* video memory reported. The value is not
			 averaged anymore because of some graphics cards not having
			 a fixed amount of physical video memory (GrafixStar 600
			 has 2.25 Mb of video memory, for instance).
			 - Switching from FullScreen mode to window mode while in a
			 secondary DirectDraw device causes the Shell to display
			 a message saying that the PRIMARY device has been selected
			 to enter window mode.
			 - Add proper exit to failing functions in WinMain().
			 - Use "magic numbers" when decreasing resolutions in window
			 mode if not enough memory.
			 - Added DISABLE_RAMP_MODE and DISABLE_MMX_MODE flags.
			 Versioning to 1.1b.

  18/03/98 : - Added a screen capture feature (F12).
			 - Added checking of current GDI colour depth with CAPS of 
			 D3D hardware device. 
			 - Added a change of default window size if GDI < 800x600.
			 - Fixed a bug in the D3DFECheckVideoMemoryForWindowMode() 
			 function (Z-Buffer memory was calculated incorrectly).
			 - Fixed a bug : passing from secondary Direct Draw device 
			 to primary by selecting FullScreen Off was incorrect.
			 - Added frame rate to display info.
			 Versioning to 1.1.

  13/03/98 : - Enabled the user to pass an accelerator table to the D3DShell 
			 by using D3DShellSetPreferences(...). 
			 - Added dwWidth and dwHeight in the InitView() function.
			 Versioning to 1.0c
	
  11/03/98 : - Fixed a bug in the D3DFEDisplayText() function.
			 - Enabled the user to pass an icon to the D3DShell by using
			 D3DShellSetPreferences(...). 
			 Versioning to 1.0b

  03/03/98 : - Fixed a bug in texture loading function that caused a line to
			 appear in a texture. 
			 Versioning to 1.0a


  -------------------------------------------------------------
  | READ D3DSHELL.TXT FOR FURTHER INFORMATION ABOUT D3DSHELL  |
  -------------------------------------------------------------

  Email any comments or feedback to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/

#ifndef INITGUID
#define INITGUID			/* Must be set up before everything */
#endif

/*************************
**		  Includes	    **
*************************/
#include <windowsx.h>
#include <stdio.h>			/* For sprintf(...) */
#include <ddraw.h>			/* DirectDraw header */
#include <d3d.h>			/* D3D header */

#include "D3DShell.h"		/* D3D Shell include */

/* DirectDraw errors 
   This header can be included (and linked with the 
   DDError.c file) to report DirectDraw errors */
/* #include "DDError.h" */
#ifndef DDERROR_H
#define DisplayHRESULTInDebug(x)
#define ASSERT(x)
#endif


/************************* 
**		Menu defines    **
*************************/
/*  These values are "weird" numbers on purpose, as we don't want
    to have duplicate menu items IDs from the Application own menu */
#define MAINMENU                        19101
#define ID_FILE                         19801
#define ID_FILE_QUIT					19802
#define ID_FILE_SCREENCAPTURE			19803
#define ID_FILE_DISPLAYINFO				19804
#define ID_DEVICES                      29801
#define ID_DEVICES_DDRAWDEV0            29810
#define ID_DEVICES_DDRAWDEV1            29811
#define ID_DEVICES_DDRAWDEV2            29812
#define ID_DEVICES_DDRAWDEV3            29813
#define ID_DEVICES_DDRAWDEV4            29814
#define ID_DEVICES_D3DDEV0	            29820
#define ID_DEVICES_D3DDEV1	            29821
#define ID_DEVICES_D3DDEV2	            29822
#define ID_DEVICES_D3DDEV3	            29823
#define ID_DEVICES_D3DDEV4	            29824
#define	ID_BUFFERING					39800
#define	ID_BUFFERING_ZBUFFER			39810
#define ID_BUFFERING_SINGLEBUFFER		39820
#define ID_BUFFERING_DOUBLEBUFFER		39821
#define ID_BUFFERING_TRIPLEBUFFER		39822
#define ID_BUFFERING_CLEAR				39823
#define ID_MODES						49801
#define ID_MODES_FULLSCREEN				49809
#define ID_MODES_RES0                   49810
#define ID_MODES_RES1                   49811
#define ID_MODES_RES2                   49812
#define ID_MODES_RES3                   49813
#define ID_MODES_RES4                   49814
#define ID_MODES_RES5                   49815
#define ID_MODES_RES6                   49816
#define ID_MODES_RES7                   49817
#define ID_MODES_RES8                   49818
#define ID_MODES_RES9                   49819
#define ID_MODES_RES10                  49820
#define ID_MODES_RES11                  49821
#define ID_MODES_RES12                  49822
#define ID_MODES_RES13                  49823
#define ID_MODES_RES14                  49824
#define ID_MODES_RES15                  49825
#define ID_MODES_RES16                  49826
#define ID_MODES_RES17                  49827
#define ID_MODES_RES18                  49828
#define ID_MODES_RES19                  49829
#define ID_MODES_RES20                  49830
#define ID_MODES_RES21                  49831
#define ID_MODES_RES22                  49832
#define ID_MODES_RES23                  49833
#define ID_MODES_RES24                  49834
#define ID_MODES_RES25                  49835
#define ID_MODES_RES26                  49836
#define ID_MODES_RES27                  49837
#define ID_MODES_RES28                  49838
#define ID_MODES_RES29                  49839


/*************************
**		  Defines	    **
*************************/
#define	DD_MAXDDDRIVERS		5	/* Maximum DD driver we ever expect to find */
#define DD_MAXDISPLAYMODES	30	/* Maximum DD display modes we ever expect to find */
#define D3D_MAXD3DDRIVERS	10	/* Maximum D3D drivers we ever expect to find */

#define TIMER_PERIOD		3000	/* Frame rate will be computed every 3 s */

#undef RELEASE
#define RELEASE(x)	if (x) { x->lpVtbl->Release(x); x=NULL; }

#define DEBUG(x)	OutputDebugString(x);

/* Uncomment the lines below to display debug messages on screen in a message box */
/*
#define DEBUG(x)	OutputDebugString(x); MessageBox(D3DFE.hwnd, x, "Debug message", MB_OK | MB_ICONERROR)
char *ErrorToString(HRESULT hres);
#undef DisplayHRESULTInDebug
#define DisplayHRESULTInDebug(x)	DEBUG(ErrorToString(x))
*/

#define MAX_NUMBER_OF_ACCELERATORS		50		/* Maximum number of accelerators */
#define MAX_NUMBER_OF_STRINGS			50		/* Maximum number of strings */
#define MAX_NUMBER_OF_TEXTURE_FORMAT	30		/* Maximum number of texture formats */
#define MAX_NUMBER_OF_TEXTURES			256		/* Maximum number of textures */


/*************************
**		  Typedefs	    **
*************************/
typedef struct _DDDriverInfo
{	
	GUID			Guid;						/* Direct Draw driver Guid */
	LPGUID			lpGuid;						/* Pointer on Direct Draw driver Guid */
	char			Name[50];					/* Name of Direct Draw driver */
	char			Description[255];			/* Description of Direct Draw driver */
	DDCAPS			DDCaps;						/* DDCAPS of Direct Draw driver */
} DDDriverInfo;


typedef struct _DDDisplayModeInfo
{
	DWORD			dwWidth;					/* Width (in pixels) of display mode */
	DWORD			dwHeight;					/* Height (in pixels) of display mode */
	DWORD			dwBPP;						/* Display mode colour depth */
	BOOL			bSupportedByD3DDriver;		/* Is this mode supported by current D3D driver ? */
} DDDisplayModeInfo;


typedef struct _D3DDriverInfo
{
	BOOL			bIsHardware;				/* hw or software driver */
	D3DDEVICEDESC	Desc;						/* D3DDEVICEDESC of D3D driver */
	BOOL			bSupportPalettised;			/* Does this D3D driver supports 8-bit palettised display modes ? */
	char			Name[50];					/* Name of D3D driver */
	char			About[255];					/* Description of D3D driver */
	GUID			Guid;						/* Guid of D3D driver */
} D3DDriverInfo;


typedef struct _D3DFEVariables
{
	/* DirectDraw variables */
	LPDIRECTDRAW            lpDD;					/* DirectDraw object */
	LPDIRECTDRAW2           lpDD2;					/* DirectDraw2 object */
	LPDIRECTDRAWSURFACE     lpDDSPrimary;			/* DirectDraw primary surface */
	LPDIRECTDRAWSURFACE     lpDDSBack;				/* DirectDraw back surface */
	LPDIRECTDRAWSURFACE		lpDDSZBuffer;			/* Z-Buffer surface */
	LPDIRECTDRAWCLIPPER		lpClipper;				/* DirectDraw clipper */
	LPDIRECTDRAWPALETTE		lpPalette;				/* DirectDraw palette */
	
	/* Direct3D variables (DrawPrimitive) */
	LPDIRECT3D2             lpD3D2;					/* Direct3D2 object */
	LPDIRECT3DDEVICE2       lpD3DDev2;				/* Direct3D device 2 */
	LPDIRECT3DVIEWPORT2		lpD3DView2;				/* Direct3D viewport 2 */

	/* Window management variables */
	MSG						msg;					/* WindowProc messages */
	HWND					hwnd;					/* window handle */
	WNDCLASS				wndclass;				/* window class */
	HICON					hIcon;					/* Application icon */
	DWORD					dwGDIWidth;				/* GDI screen width */
	DWORD					dwGDIHeight;			/* GDI screen height */
	DWORD					dwGDIBPP;				/* GDI screen colour depth */
	
	/* Window information variables */
	DWORD					dwWindowStyle;			/* Style of window */
	DWORD					dwWindowPositionX;		/* Window position (X) */
	DWORD					dwWindowPositionY;		/* Window position (Y) */
	DWORD					dwWindowWidth;			/* Window width */
	DWORD					dwWindowHeight;			/* Window height */
	DWORD					dwWindowFramePositionX;	/* Window frame position (X) */
	DWORD					dwWindowFramePositionY;	/* Window frame position (Y) */
	DWORD					dwWindowFrameWidth;		/* Window frame width */
	DWORD					dwWindowFrameHeight;	/* Window frame height */
	DWORD					dwWindowSpaceX;			/* Total space between window frame width and client area width */
	DWORD					dwWindowSpaceY;			/* Total space between window frame height and client area height */
	DWORD					dwMaxWindowWidth;		/* Max window width */
	DWORD					dwMaxWindowHeight;		/* Max window height */
	DWORD					dwMinWindowWidth;		/* min Window width */
	DWORD					dwMinWindowHeight;		/* Min window height */
	
	/* Menu variables */
	HMENU					hMenu;					/* Main menu handle */
	HMENU					hFileMenu;				/* File menu handle */
	HMENU					hDevicesMenu;			/* Devices menu handle */
	HMENU					hBufferingMenu;			/* Buffering menu handle */
	HMENU					hModesMenu;				/* Modes menu handle */
	HMENU					hUserMenu;				/* User menu handle */
	ACCEL					Accel[MAX_NUMBER_OF_ACCELERATORS];		/* Accelerator table */
	HACCEL					hAccel;					/* Accelerator table handle */
	
	/* Booleans */
	BOOL					bPaused;				/* FrontEnd paused ? */
	BOOL					bMinimized;				/* FrontEnd minimized ? */
	BOOL					bRenderingReady;		/* Are all the variables set up and ready to render ? */
	BOOL					bIgnoreWM_SIZE;			/* Ignore the WM_SIZE window message ? */
	BOOL					bFullScreen;			/* Are we in FullScreen mode ? */
	BOOL					bZBufferNeeded;			/* Do we need a Z-Buffer ? */
	BOOL					bSharedVideoMemory;		/* Indicate if Surface and Z-Buffer memory are shared */
	BOOL					bShowInfoBuffer;		/* Do we want to display the Info Buffer ? */
	BOOL					bClearViewport;			/* Will the viewport be cleared before each frame ? */
		
	/* Rendering variables */
	DWORD					dwPhysicalVideoMemory;	/* Physical amount of video memory */
	DWORD					dwTotalMemoryForWindow;	/* Total video memory to create window */
	DWORD					dwTotalMemoryForZBuffer;/* Total video memory to create Z-Buffer */
	int						nBufferingMode;			/* Single buffer, Double buffer(default) or triple buffer */
	
	/* Texture variables */
	int						nTextures;
	int						nTextureFormat;
	int						nBestOpaqueFormat;
	int						nBestTransFormat;
	
	/* Text display variables */
	HFONT					hTextFont;				/* Handle of text font */
	char					pszDisplayText[100];	/* String to display */
	DWORD					dwFrameRate;			/* Current frame rate */
	DWORD					dwFramesElapsed;		/* Number of frames elapsed in TIMER_PERIOD ms */
	
	/* User variables */
	DWORD					dwUserPreferences;		/* Flag to retrieve user preferences */
	char					pszFrontEndTitle[100];	/* Title of application */
	int						nNumberOfUserString;	/* Number of user text strings to display */
	char					pszUserText[MAX_NUMBER_OF_STRINGS][100];	/* User text to display on screen */
	int						nUserTextPositionX[MAX_NUMBER_OF_STRINGS];	/* Position of user text (X) */
	int						nUserTextPositionY[MAX_NUMBER_OF_STRINGS];	/* Position of user text (Y) */
} D3DFEVariables;


/*************************
**		  Globals	    **
*************************/

/* D3D Front End variables */
D3DFEVariables		D3DFE;

/* Textures variables */

/* Array of all the textures */

struct _TextureArray
{
	D3DTEXTUREHANDLE        TextureHandle[MAX_NUMBER_OF_TEXTURES];	/* Textures handles */
    LPDIRECTDRAWSURFACE     lpTextureSurf[MAX_NUMBER_OF_TEXTURES];	/* Textures surfaces */
    LPDIRECT3DTEXTURE2      lpTexture[MAX_NUMBER_OF_TEXTURES];		/* textures objects */
} TextureArray;


/* Array of all texture formats supported by D3D driver */
struct _TextureFormat
{
	DDSURFACEDESC	ddsd;
	int RedBPP;
	int GreenBPP; 
	int BlueBPP;
	int AlphaBPP;
} TextureFormat[MAX_NUMBER_OF_TEXTURE_FORMAT];

/* Debug purpose */
char		pszTmp[300];

/* Enumeration callback variables */
DDDriverInfo		DDDriver[DD_MAXDDDRIVERS];			/* Array to store all DD drivers */
int					nDDNumDrivers=0;					/* Total number of Direct Draw drivers */
int					nCurrentDDDriver=-1;				/* Number of current Direct Draw driver */

DDDisplayModeInfo	DDDisplayMode[DD_MAXDISPLAYMODES];	/* Array to store all Display modes */
int					nDDNumDisplayModes=0;				/* Total number of display modes supported by Direct Draw driver */
int					nSafeDisplayModeNumber=-1;			/* Number of "safe" display mode (usually 640x480x16) */
int					nCurrentResolution=-1;				/* Number of current display mode */

D3DDriverInfo		D3DDriver[D3D_MAXD3DDRIVERS];		/* Array to store all D3D drivers */
int					nD3DNumDrivers=0;					/* Total number of D3D driver */
int					nCurrentD3DDriver=-1;				/* Number of current D3D driver */

														
/************************
******* Prototypes ******
************************/
/* D3D FrontEnd function */
void				D3DFEInitFrontEnd();
void				D3DFEFinish();
void				D3DFEReleaseAll();
void				D3DFEReleaseTextures();
BOOL				D3DFECheckForLostSurfaces();
BOOL				D3DFEInitDirectDrawForD3D();
BOOL				D3DFEInitWindow();
BOOL				D3DFEInitFullScreen();
BOOL				D3DFEInitD3DDevice();
BOOL				D3DFEListDDDrivers();
BOOL				D3DFEListDisplayModes(LPDIRECTDRAW2 lpLocalDD2);
BOOL				D3DFEListD3DDrivers();
BOOL				D3DFEListTextureFormats(LPDIRECT3DDEVICE2 lpDev2);
BOOL WINAPI			D3DFEEnumDirectDrawCallback(GUID FAR* lpGuid, LPSTR lpDriverDesc, LPSTR lpDriverName, LPVOID lpContext);
HRESULT WINAPI		D3DFEEnumDisplayModesCallback(LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext);
HRESULT CALLBACK	D3DFEEnumD3DDeviceDriverCallback(LPGUID lpGuid, LPSTR lpDeviceDescription, LPSTR lpDeviceName, LPD3DDEVICEDESC lpHWDesc, LPD3DDEVICEDESC lpHELDesc, LPVOID lpUserArg);
HRESULT CALLBACK	D3DFEEnumTextureFormatsCallback(LPDDSURFACEDESC lpDDSD, LPVOID lpContext);
void				D3DFEChangeDirectDrawDriver(int nDDDriver);
void				D3DFEChangeD3DMode(int nRes, int nD3DDev, BOOL bScreenModeSelected);
BOOL				D3DFECreateViewAndScene();
BOOL				D3DFERender();
void				D3DFEDisplayToGDI();
DWORD				D3DFEFreeVideoMemoryInfo(DWORD dwCaps);
DWORD				D3DFETotalVideoMemoryInfo(DWORD dwCaps);
BOOL				D3DFECheckVideoMemoryForWindowMode(DWORD dwWidth, DWORD dwHeight, BOOL bZBuffer);
int WINAPI			WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow);
long CALLBACK		D3DFEWindowProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
void				D3DFEHandleWM_PAINT(HWND hWindow);
BOOL				D3DFEHandleWM_SIZE(LRESULT *lresult, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
void				D3DFEHandleWM_SIZING(LRESULT *lresult, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL				D3DFEBuildMenus();
void				D3DFECreateAccelerators();
void				D3DFEUpdateMenus();
void				D3DFEMouseVisible(BOOL bVisible);
void				D3DFEDisplayText();
void CALLBACK		D3DFETimerProc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime);

/* User functions */
void				D3DShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel, HICON hUserIcon, enum D3DFrontEndPrefs dwFlags);
void				D3DShellSetDisplayText(char *pszText, int nX, int nY);
D3DTEXTUREHANDLE	D3DShellLoadBMP(char *lpName, BOOL bTranslucent);
LPDIRECTDRAWSURFACE	D3DShellGetTextureSurface(D3DTEXTUREHANDLE hTexture);

/* Misc functions */
DWORD				BPPToDDBD(int bpp);
void				DisplayInfoAboutSurfaces();
void				D3DFEClearSurface(LPDIRECTDRAWSURFACE lpSurface);
BOOL				D3DFEScreenCapture();


/************************
******* Functions *******
************************/


/*******************************************************************************
 * Function Name  : D3DFEInitFrontEnd
 * Returns        : Nothing
 * Global Used    : D3DFE
 * Description    : Perform variables initialisation
 *******************************************************************************/
void D3DFEInitFrontEnd()
{
	/* Init DirectDraw variables */
	D3DFE.lpDD=NULL;				
	D3DFE.lpDD2=NULL;					
	D3DFE.lpDDSPrimary=NULL;
	D3DFE.lpDDSBack=NULL;		
	D3DFE.lpDDSZBuffer=NULL;			
	D3DFE.lpClipper=NULL;				
	D3DFE.lpPalette=NULL;				
	
	/* Init Direct3D variables (DrawPrimitive) */
	D3DFE.lpD3D2=NULL;					
	D3DFE.lpD3DDev2=NULL;				
	D3DFE.lpD3DView2=NULL;				
	
	/* Window management variables */
	D3DFE.hIcon=NULL;

	/* Init window variables */
	D3DFE.dwWindowStyle=0;
	D3DFE.dwWindowWidth=640;
	D3DFE.dwWindowHeight=480;
	D3DFE.dwMaxWindowWidth=1024;
	D3DFE.dwMaxWindowHeight=768;
	D3DFE.dwMinWindowWidth=240;
	D3DFE.dwMinWindowHeight=150;

	/* Init Booleans */
	D3DFE.bPaused=TRUE;
	D3DFE.bIgnoreWM_SIZE=TRUE;
	D3DFE.bMinimized=FALSE;
	D3DFE.bZBufferNeeded=FALSE;
	D3DFE.bRenderingReady=FALSE;
	D3DFE.bFullScreen=FALSE;
	D3DFE.bShowInfoBuffer=TRUE;
	D3DFE.bSharedVideoMemory=FALSE;
	D3DFE.bClearViewport=FALSE;
	
	/* Init menu variables */
	D3DFE.hMenu=NULL;
	D3DFE.hFileMenu=NULL;
	D3DFE.hDevicesMenu=NULL;
	D3DFE.hBufferingMenu=NULL;
	D3DFE.hModesMenu=NULL;
	D3DFE.hUserMenu=NULL;
	D3DFE.hAccel=NULL;

	/* Init rendering variables */
	D3DFE.dwTotalMemoryForWindow=0;
	D3DFE.dwTotalMemoryForZBuffer=0;
	D3DFE.nBufferingMode=2;				/* Double buffering by default */
	
	/* Init texture variables */
	D3DFE.nTextures=0;
	D3DFE.nTextureFormat=0;
	D3DFE.nBestOpaqueFormat=-1;
	D3DFE.nBestTransFormat=-1;

	/* User rendering variables */
	D3DFE.dwUserPreferences=0;
	strcpy(D3DFE.pszFrontEndTitle, "D3D Shell");
	D3DFE.nNumberOfUserString=0;
	D3DFE.dwFrameRate=0;
	D3DFE.dwFramesElapsed=0;
}


/*******************************************************************************
 * Function Name  : D3DFEFinish
 * Returns        : Nothing
 * Global Used    : D3DFE
 * Description    : Quit program
 *******************************************************************************/
void D3DFEFinish()
{
	/* Set the cooperative Level back to normal to avoid messing up the GDI screen */
	if (D3DFE.lpDD2 && D3DFE.bFullScreen)
	{
		if (D3DFE.lpDD2->lpVtbl->SetCooperativeLevel(D3DFE.lpDD2, D3DFE.hwnd, DDSCL_NORMAL)!=DD_OK)
		{
			DEBUG("SetCooperativeLevel failed in D3DFEFinish()\n");
		}
	}
	
	D3DFE.bPaused=TRUE;
	D3DFE.bRenderingReady=FALSE;

	/* Send a WM_DESTROY message to the event loop */
	DestroyWindow(D3DFE.hwnd);		
}


/*******************************************************************************
 * Function Name  : D3DFEReleaseAll
 * Returns        : Nothing
 * Global Used    : D3DFE
 * Description    : Release all memory used by DirectDraw and D3D variables
 *******************************************************************************/
void D3DFEReleaseAll()
{
    int i;
	
	D3DFEReleaseTextures();
	ReleaseView(D3DFE.lpD3DView2);
	RELEASE(D3DFE.lpD3DView2);
	RELEASE(D3DFE.lpD3DDev2);
	if (D3DFE.lpDDSZBuffer)
	{
		if (D3DFE.lpDDSBack)
		{
			/* If there is a back buffer, then Z Buffer must be attached to it */
			if (D3DFE.lpDDSBack->lpVtbl->DeleteAttachedSurface(D3DFE.lpDDSBack, 0, D3DFE.lpDDSZBuffer)!=DD_OK)
			{
				DEBUG("Failed to delete Z-Buffer surface from back buffer in D3DReleaseAll()\n");
			}
		}
		else
		{
			/* No back buffer -> Z Buffer is attached to primary surface */
			if (D3DFE.lpDDSPrimary->lpVtbl->DeleteAttachedSurface(D3DFE.lpDDSPrimary, 0, D3DFE.lpDDSZBuffer)!=DD_OK)
			{
				DEBUG("Failed to delete Z-Buffer surface from primary surface in D3DReleaseAll()\n");
			}
		}
	}
	RELEASE(D3DFE.lpDDSZBuffer);
	RELEASE(D3DFE.lpClipper);
	RELEASE(D3DFE.lpPalette);
	RELEASE(D3DFE.lpDDSBack);
	RELEASE(D3DFE.lpDDSPrimary);
	RELEASE(D3DFE.lpD3D2);
	RELEASE(D3DFE.lpDD2);  
	RELEASE(D3DFE.lpDD);

	/* Release menu handles */
	/* Important! The user menu must be detached from the main menu, otherwise it
	   will be destroyed as the same time the main menu is destroyed */
	if (D3DFE.hUserMenu)
	{
		for (i=0; i<GetMenuItemCount(D3DFE.hUserMenu); i++)
		{
			RemoveMenu(D3DFE.hMenu, (UINT)GetSubMenu(D3DFE.hUserMenu, i), MF_BYCOMMAND);
		}
	}
	/* If main menu exists, then destroy it */
	if (D3DFE.hMenu)
	{
		DestroyMenu(D3DFE.hMenu);
	}

	/* Release text font */
	DeleteObject(D3DFE.hTextFont);
} 


/*******************************************************************************
 * Function Name  : D3DFEReleaseTextures
 * Returns        : Nothing
 * Global Used    : D3DFE
 * Description    : Release all textures
 *******************************************************************************/
void D3DFEReleaseTextures()
{
	int i;

    for (i=0; i<D3DFE.nTextures; i++)
	{
		RELEASE(TextureArray.lpTextureSurf[i]);
		RELEASE(TextureArray.lpTexture[i]);
	}
    
	D3DFE.nTextures=0;
	D3DFE.nTextureFormat=0;
	D3DFE.nBestOpaqueFormat=-1;
	D3DFE.nBestTransFormat=-1;
}


/*******************************************************************************
 * Function Name  : D3DFECheckForLostSurfaces
 * Returns        : TRUE or FALSE
 * Global Used    : D3DFE
 * Description    : Restore surfaces that might have been lost
 *******************************************************************************/
BOOL D3DFECheckForLostSurfaces()
{
	HRESULT hres;
	BOOL	bInFlag=TRUE;
	int		i;
	
	/* Check if Z-Buffer surface is lost */
	if (D3DFE.lpDDSZBuffer && D3DFE.bZBufferNeeded) 
	{
		if (D3DFE.lpDDSZBuffer->lpVtbl->IsLost(D3DFE.lpDDSZBuffer)==DDERR_SURFACELOST)
		{
			hres=D3DFE.lpDDSZBuffer->lpVtbl->Restore(D3DFE.lpDDSZBuffer);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore Z-Buffer surface\n");
				DisplayHRESULTInDebug(hres);
				bInFlag=FALSE;
			}
			DEBUG("Z-Buffer surface has been restored\n");
		}
	}
	
	/* Check if Primary surface is lost 
	   If back buffer(s) have been created through the primary surface by use
	   of the DDSCAPS_COMPLEX flag, then the(se) back buffer(s) will be
	   automatically restored when the primary surface is restored */
	if (D3DFE.lpDDSPrimary) 
	{
		if (D3DFE.lpDDSPrimary->lpVtbl->IsLost(D3DFE.lpDDSPrimary)==DDERR_SURFACELOST)
		{
			hres=D3DFE.lpDDSPrimary->lpVtbl->Restore(D3DFE.lpDDSPrimary);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore primary surface\n");
				DisplayHRESULTInDebug(hres);
				bInFlag=FALSE;
			}
			DEBUG("Primary surface has been restored\n");
		}
	}
	
	/* If we are in Window mode, then back buffer has been created
	   separately from the primary surface, so restore it as well */
	if (!D3DFE.bFullScreen)
	{
		/* Restore back buffer */
		if (D3DFE.lpDDSBack->lpVtbl->IsLost(D3DFE.lpDDSBack)==DDERR_SURFACELOST)
		{
			hres=D3DFE.lpDDSBack->lpVtbl->Restore(D3DFE.lpDDSBack);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore back buffer surface\n");
				DisplayHRESULTInDebug(hres);
				bInFlag=FALSE;
			}
			DEBUG("Back buffer surface has been restored\n");
		}
	}

	/* Don't forget to restore any other surfaces (textures...) */
	for (i=0; i<D3DFE.nTextures;i++)
	{
		if (TextureArray.lpTextureSurf[i]->lpVtbl->IsLost(TextureArray.lpTextureSurf[i])==DDERR_SURFACELOST)
		{
			hres=TextureArray.lpTextureSurf[i]->lpVtbl->Restore(TextureArray.lpTextureSurf[i]);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore texture surface\n");
				DisplayHRESULTInDebug(hres);
				bInFlag=FALSE;
			}
			DEBUG("Texture surface surface has been restored\n");
		}
	}

	/* Return status */
	return (bInFlag);
}


/*******************************************************************************
 * Function Name  : D3DFEInitDirectDrawForD3D
 * Returns        : TRUE if no error occured
 * Global Used    : D3DFE
 *					nCurrentDDDriver, DDDriver[],
 *					nCurrentResolution, nDDNumDisplayModes, 
 *					nCurrentD3DDriver, nD3DNumDrivers.
 * Description    : Initialise directdraw for D3D use :
 *					- Create D3DFE.lpDD and D3DFE.lpDD2 device (corresponding to selection)
 *					- Enumerate all display modes
 *					- Enumerate all D3D drivers
 *					- Create a Direct3D2 interface
 *
 *******************************************************************************/
BOOL D3DFEInitDirectDrawForD3D()
{
	HRESULT	hres;
	int		i=0;
	RECT	Rect;
		
	/* Asserts */
	ASSERT(D3DFE.lpDD==NULL);
	ASSERT(D3DFE.lpDD2==NULL);
	ASSERT(D3DFE.lpD3D2==NULL);
	ASSERT(nCurrentDDDriver!=-1);

	/* Create D3DFE.lpDD for the DirectDraw driver currently selected */
    hres=DirectDrawCreate(&DDDriver[nCurrentDDDriver].Guid, &D3DFE.lpDD, NULL);
    if (hres!=DD_OK)
    {
        D3DFEMouseVisible(TRUE);
		DEBUG("DirectDrawCreate failed\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to create Direct Draw\n", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
    }

	/* Query interface for DirectDraw 2 */
	hres=D3DFE.lpDD->lpVtbl->QueryInterface(D3DFE.lpDD, &IID_IDirectDraw2, &D3DFE.lpDD2);
	if (hres!=DD_OK)
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("QueryInterface for DirectDraw2 failed in D3DFEInitDirectDraw()\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "DirectX 5.0 must be installed to use this program\n", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONSTOP);
		return FALSE;
	}

	/* Enumerate all display modes, store them in a structure and return 
	   safe display mode number (for 640x480x16) */
	nSafeDisplayModeNumber=-1;
	if (!D3DFEListDisplayModes(D3DFE.lpDD2))
	{
        D3DFEMouseVisible(TRUE);
		DEBUG("ListDisplayModes() failed\n");
		MessageBox(D3DFE.hwnd, "Failed to enumerate display modes\n", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
    }
			
	/* Check if 640x480x16 is a supported resolution */
	if (nSafeDisplayModeNumber==-1)
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("640x480x16 not supported\nExiting program\n");
		MessageBox(D3DFE.hwnd, "640x480x16 resolution not supported\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Set current resolution to a supported resolution */
	nCurrentResolution=nSafeDisplayModeNumber;

	/* Set current buffering mode to double */
	D3DFE.nBufferingMode=2;

	/* Enumerate all D3D drivers and store them in a structure */
	if (!D3DFEListD3DDrivers())
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("ListD3DDrivers() failed\n");
		MessageBox(D3DFE.hwnd, "Failed to enumerate D3D drivers\n", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Choose a D3D Driver (RGB software by default) */
	nCurrentD3DDriver=1;
	
	/* Return the first HW driver, if any */
	for (i=0; i<nD3DNumDrivers; i++) 
	{
		if (D3DDriver[i].bIsHardware)
		{
			nCurrentD3DDriver=i;
			break;
		}
	}

	/* Check if current GDI colour depth is supported by current D3D device */
	if ( nCurrentDDDriver==0 && !D3DFE.bFullScreen && D3DDriver[nCurrentD3DDriver].bIsHardware &&
		 !(D3DDriver[nCurrentD3DDriver].Desc.dwDeviceRenderBitDepth & BPPToDDBD(D3DFE.dwGDIBPP)) )
	{
		D3DFEMouseVisible(TRUE);
		sprintf(pszTmp, "GDI colour depth (%d bpp) is not supported by current hardware D3D device.\nForcing to FullScreen mode.\n", D3DFE.dwGDIBPP);
		DEBUG(pszTmp);
		MessageBox(D3DFE.hwnd, pszTmp, D3DFE.pszFrontEndTitle, MB_OK | MB_ICONWARNING);
		D3DFE.dwUserPreferences|=FORCE_FULLSCREEN;
		D3DFE.bFullScreen=TRUE;
	}
		
	/* Let's get Direct3D2 */
    hres=D3DFE.lpDD2->lpVtbl->QueryInterface(D3DFE.lpDD2, &IID_IDirect3D2, &D3DFE.lpD3D2);
    if (hres!=DD_OK) 
	{
        D3DFEMouseVisible(TRUE);
		DEBUG("QueryInterface failed (for D3D2) in D3DFEInitDirectDraw()\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to get D3D2 interface from Direct Draw 2\n", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Retrieve video memory information */
	D3DFE.dwTotalMemoryForWindow=D3DFEFreeVideoMemoryInfo(DDSCAPS_PRIMARYSURFACE);
	D3DFE.dwTotalMemoryForZBuffer=D3DFEFreeVideoMemoryInfo(DDSCAPS_ZBUFFER);

	/* !!! It seems you can not allocate the totality of video memory, 
	   so it's better returning a slightly lower value !!! */
	if (D3DFE.dwTotalMemoryForWindow>8192)
	{
		D3DFE.dwTotalMemoryForWindow-=8192;
	}
	if (D3DFE.dwTotalMemoryForZBuffer>8192)
	{
		D3DFE.dwTotalMemoryForZBuffer-=8192;
	}

	/* If memory for window is equal to memory for Z-Buffer, it 
	   means that the video memory is shared between the two */
	if (D3DFE.dwTotalMemoryForWindow==D3DFE.dwTotalMemoryForZBuffer)
	{
		D3DFE.bSharedVideoMemory=TRUE;
	}
	else
	{
		D3DFE.bSharedVideoMemory=FALSE;
	}

	/* Check if GDI memory is enough to support current window size */
	if (!D3DFE.bFullScreen)
	{
		while ( (D3DFE.dwWindowWidth*D3DFE.dwWindowHeight*D3DFE.dwGDIBPP/8>D3DFE.dwTotalMemoryForWindow)
			     && !D3DFE.bFullScreen )
		{
			switch (D3DFE.dwWindowHeight)
			{
				case 480 :		D3DFE.dwWindowWidth=640;
								D3DFE.dwWindowHeight=400;
								break;
				case 400 :		D3DFE.dwWindowWidth=512;
								D3DFE.dwWindowHeight=384;
								break;
				case 384 :		D3DFE.dwWindowWidth=320;
								D3DFE.dwWindowHeight=240;
								break;
				case 240 :		D3DFE.dwWindowWidth=320;
								D3DFE.dwWindowHeight=200;
								break;
				case 200 :		D3DFE.dwWindowWidth=0;
								D3DFE.dwWindowHeight=0;
								break;
			}
			if (D3DFE.dwWindowWidth<D3DFE.dwMinWindowWidth || D3DFE.dwWindowHeight<D3DFE.dwMinWindowHeight)
			{
				D3DFE.dwWindowWidth=D3DFE.dwMinWindowWidth;
				D3DFE.dwWindowHeight=D3DFE.dwMinWindowHeight;
				sprintf(pszTmp, "Not enough GDI memory to support\nthe minimum window size (%d*%d)\nSwitching to FullScreen", 
								 D3DFE.dwWindowWidth, D3DFE.dwWindowHeight);
				MessageBox(D3DFE.hwnd, pszTmp, D3DFE.pszFrontEndTitle, MB_OK | MB_ICONWARNING);
				D3DFE.dwUserPreferences|=FORCE_FULLSCREEN;
				D3DFE.bFullScreen=TRUE;
			}
		}
		/* If there is enough GDI memory to support a smaller window, 
		   calculate new window coordinates */
		if (!D3DFE.bFullScreen)
		{
			sprintf(pszTmp, "New window size = %d %d\n", D3DFE.dwWindowWidth, D3DFE.dwWindowHeight);
			DEBUG(pszTmp);

			/* Compute new window position (screen centre) */
			D3DFE.dwWindowPositionX=(D3DFE.dwGDIWidth-D3DFE.dwWindowWidth)/2;
			D3DFE.dwWindowPositionY=(D3DFE.dwGDIHeight-D3DFE.dwWindowHeight)/2;
	
			/* Compute new window size corresponding to client area size */
			SetRect(&Rect,  D3DFE.dwWindowPositionX, D3DFE.dwWindowPositionY, 
							D3DFE.dwWindowWidth+D3DFE.dwWindowPositionX-1, D3DFE.dwWindowHeight+D3DFE.dwWindowPositionY-1);
			AdjustWindowRect(&Rect, D3DFE.dwWindowStyle, TRUE);

			/* Set window frame values */
			D3DFE.dwWindowFramePositionX=Rect.left;
			D3DFE.dwWindowFramePositionY=Rect.top;
			D3DFE.dwWindowFrameWidth=(Rect.right-Rect.left)+1;
			D3DFE.dwWindowFrameHeight=(Rect.bottom-Rect.top)+1;
	
			/* Compute window space between client and window */
			D3DFE.dwWindowSpaceX=D3DFE.dwWindowFrameWidth-D3DFE.dwWindowWidth;
			D3DFE.dwWindowSpaceY=D3DFE.dwWindowFrameHeight-D3DFE.dwWindowHeight;

			/* Resize window to its new size */
			D3DFE.bIgnoreWM_SIZE=TRUE;
			SetWindowPos(D3DFE.hwnd, NULL, 
						 D3DFE.dwWindowFramePositionX, D3DFE.dwWindowFramePositionY, 
						 D3DFE.dwWindowFrameWidth, D3DFE.dwWindowFrameHeight, 
						 SWP_NOZORDER | SWP_SHOWWINDOW);
			D3DFE.bIgnoreWM_SIZE=FALSE;
		}
	}

	/* Debug output */
	sprintf(pszTmp, "Surface memory = %u\nZ-Buffer memory = %u\n%s", D3DFE.dwTotalMemoryForWindow, D3DFE.dwTotalMemoryForZBuffer,
					D3DFE.bSharedVideoMemory==TRUE ? "Shared Video Memory\n" : "Video memory not shared\n");
	DEBUG(pszTmp);
	sprintf(pszTmp, "Texture memory available : %u\n", D3DFEFreeVideoMemoryInfo(DDSCAPS_TEXTURE));
	DEBUG(pszTmp);

	/* Build menus */
	if (!D3DFEBuildMenus())
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("D3DFEBuildMenus() failed in D3DFEInitDirectDrawForD3D\n");
		/* No MessageBox here, as the only problem that could happen in D3DFEBuildMenus
		   already displays a MessageBox */
		return FALSE;
	}
	
	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFEInitFullScreen
 * Returns        : TRUE if no error occured
 * Global Used    : D3DFE
 * Description    : Initialize D3D for FullScreen mode :
 *					- Set Cooperative level to EXCLUSIVE and FULLSCREEN
 *					- Set display mode to current selection
 *					- Create a complex Primary surface with the selected number
 *					  of back buffers (Single buffer, Double buffer or Triple buffer)
 *					- Retrieve variable to back buffer (currently only supports double
 *					  buffering)
 *				
 *******************************************************************************/
BOOL D3DFEInitFullScreen()
{
	DDSCAPS             ddscaps;
	DDSURFACEDESC       ddsd;
	HRESULT             hres;
	HDC					hdc;
	PALETTEENTRY		pe[256];
	int					i=0;

	/* Asserts */
	ASSERT(D3DFE.lpDD2!=NULL);
	ASSERT(D3DFE.lpD3D2!=NULL);
	ASSERT(D3DFE.lpDDSPrimary==NULL);
	ASSERT(D3DFE.lpDDSBack==NULL);
	ASSERT(D3DFE.nBufferingMode>0 && D3DFE.nBufferingMode<4);
	
	/* Set cooperative level to exclusive, fullscreen mode 
	   Set D3DFE.bIgnoreWM_SIZE because SetCooperativeLevel causes such a message
	   and we don't need to change the buffers in that case */
	D3DFE.bIgnoreWM_SIZE=TRUE;
	hres=D3DFE.lpDD2->lpVtbl->SetCooperativeLevel(D3DFE.lpDD2, D3DFE.hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
	D3DFE.bIgnoreWM_SIZE=FALSE;
	if (hres!=DD_OK)
	{
	    DEBUG("SetCooperativeLevel failed in D3DFEInitFullScreen()\n");
		DisplayHRESULTInDebug(hres);
		D3DFEMouseVisible(TRUE);
		MessageBox(D3DFE.hwnd, "Failed to set Cooperative Level to FullScreen\nExiting program", 
										D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Debug output */
	sprintf(pszTmp, "Switching to %ux%ux%u\n",  DDDisplayMode[nCurrentResolution].dwWidth, 
												DDDisplayMode[nCurrentResolution].dwHeight, 
												DDDisplayMode[nCurrentResolution].dwBPP);
	DEBUG(pszTmp);

	/* Set the video mode to current resolution */
	D3DFE.bIgnoreWM_SIZE=TRUE;
	hres=D3DFE.lpDD2->lpVtbl->SetDisplayMode(D3DFE.lpDD2, DDDisplayMode[nCurrentResolution].dwWidth,
														  DDDisplayMode[nCurrentResolution].dwHeight, 
														  DDDisplayMode[nCurrentResolution].dwBPP, 0, 0);
	D3DFE.bIgnoreWM_SIZE=FALSE;
	if (hres!=DD_OK)
	{
	    DEBUG("SetDisplayMode failed\n");
		DisplayHRESULTInDebug(hres);
		sprintf(pszTmp, "Unable to set display mode to %ux%ux%u\nExiting program", 
						 DDDisplayMode[nCurrentResolution].dwWidth,
						 DDDisplayMode[nCurrentResolution].dwHeight, 
						 DDDisplayMode[nCurrentResolution].dwBPP);
		MessageBox(D3DFE.hwnd, pszTmp, D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Set DDSURFACEDESC structure to 0 */
	memset(&ddsd, 0, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);

	/* If we are using a single buffered mode, just create primary surface */
	if (D3DFE.nBufferingMode==1)
	{
		ddsd.dwFlags=DDSD_CAPS;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE | DDSCAPS_3DDEVICE;
		hres=D3DFE.lpDD2->lpVtbl->CreateSurface(D3DFE.lpDD2, &ddsd, &D3DFE.lpDDSPrimary, NULL);
		if (hres!=DD_OK)
		{
		    D3DFEMouseVisible(TRUE);
			if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY) 
			{
				MessageBox(D3DFE.hwnd, "Not enough memory to create front buffer\nPlease restart the program with a lower resolution",
							D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			else
			{
				MessageBox(D3DFE.hwnd, "Failed to create primary surface", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			DEBUG("CreateSurface failed (D3DFE.lpDDSPrimary) in D3DFEInitFullScreen()\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
		
		/* Get surface description of primary buffer */
		hres=D3DFE.lpDDSPrimary->lpVtbl->GetSurfaceDesc(D3DFE.lpDDSPrimary, &ddsd);
		if (hres!=DD_OK)
		{
			D3DFEMouseVisible(TRUE);
			DEBUG("GetSurfaceDesc failed in D3DFEInitFullScreen()\n");
			DisplayHRESULTInDebug(hres);
			MessageBox(D3DFE.hwnd, "Unable to get front buffer surface description\nExiting program", 
							  D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}
	}
	else
	{
		/* Otherwise create a primary surface with one (double buffer) 
		   or two (triple buffer) back buffers */
		ddsd.dwFlags=DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
		ddsd.ddsCaps.dwCaps =	DDSCAPS_PRIMARYSURFACE | 
								DDSCAPS_FLIP |
								DDSCAPS_3DDEVICE |
								DDSCAPS_COMPLEX;
		ddsd.dwBackBufferCount=D3DFE.nBufferingMode-1;
		hres=D3DFE.lpDD2->lpVtbl->CreateSurface(D3DFE.lpDD2, &ddsd, &D3DFE.lpDDSPrimary, NULL);
		if (hres!=DD_OK)
		{
		    D3DFEMouseVisible(TRUE);
			if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY) 
			{
				MessageBox(D3DFE.hwnd, "Not enough memory to create surfaces\nPlease restart the program with a lower resolution or with a lower Buffering mode",
							D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			else
			{
				MessageBox(D3DFE.hwnd, "Failed to create surface", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			DEBUG("CreateSurface failed (D3DFE.lpDDSPrimary) in D3DFEInitFullScreen()\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}

		/* Retrieve variable to back buffer */
		ddscaps.dwCaps=DDSCAPS_BACKBUFFER;
		hres=D3DFE.lpDDSPrimary->lpVtbl->GetAttachedSurface(D3DFE.lpDDSPrimary, &ddscaps, &D3DFE.lpDDSBack);
		if( hres!=DD_OK )
		{
		    D3DFEMouseVisible(TRUE);
			DEBUG("GetAttachedSurface failed\n");
			DisplayHRESULTInDebug(hres);
			MessageBox(D3DFE.hwnd, "Unable to retrieve variable to back buffer", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}

		/* Get surface description of back buffer */
		hres=D3DFE.lpDDSBack->lpVtbl->GetSurfaceDesc(D3DFE.lpDDSBack, &ddsd);
		if (hres!=DD_OK)
		{
			D3DFEMouseVisible(TRUE);
			DEBUG("GetSurfaceDesc failed in D3DFEInitFullScreen()\n");	
			DisplayHRESULTInDebug(hres);
			MessageBox(D3DFE.hwnd, "Unable to get back buffer surface description", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}
	}

	/* Debug output */
	sprintf(pszTmp, "Back buffer creation : %d\n", D3DFE.nBufferingMode-1);
	DEBUG(pszTmp);

	/* Create palette for 8 bpp screen modes */
	if (ddsd.ddpfPixelFormat.dwRGBBitCount<16)
	{
		/* Release memory of any previous palette */
		RELEASE(D3DFE.lpPalette);
		
		/* Set up palette */
		/* Save our current hardware palette */
		hdc=GetDC(NULL);
		GetSystemPaletteEntries (hdc, 0, 256, pe);
		ReleaseDC (NULL, hdc);

		/* Remember that, in a windowed mode, the first and last 10 palette 
		   entries should be left for system use, the middle 236 are ours */
	   	for (i=0; i<10; i++) pe[i].peFlags=D3DPAL_READONLY;
	   	for (i=10; i<246; i++) pe[i].peFlags=PC_RESERVED;
	   	for (i=246; i<256; i++) pe[i].peFlags=D3DPAL_READONLY;
		 
		/* Create palette */
		hres=D3DFE.lpDD2->lpVtbl->CreatePalette(D3DFE.lpDD2, DDPCAPS_8BIT | DDPCAPS_INITIALIZE, 
												pe, &D3DFE.lpPalette, NULL);
		if (hres!=DD_OK)
		{
			D3DFEMouseVisible(TRUE);
			DEBUG("CreatePalette() failed in D3DFEInitFullScreen()\n");	
			DisplayHRESULTInDebug(hres);
			MessageBox(D3DFE.hwnd, "Failed to create palette\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}

		/* If a back buffer exists, then attach the palette to back buffer */
		if (D3DFE.nBufferingMode>1)
		{
			hres=D3DFE.lpDDSBack->lpVtbl->SetPalette(D3DFE.lpDDSBack, D3DFE.lpPalette);
			if (hres!=DD_OK)
			{
				D3DFEMouseVisible(TRUE);
				DEBUG("SetPalette() failed in D3DFEInitFullScreen()\n");	
				DisplayHRESULTInDebug(hres);
				MessageBox(D3DFE.hwnd, "Unable to attach palette to back buffer\nExiting program", 
									D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
				return FALSE;
			}
		}

		/* Now attach the palette to primary surface */
		hres=D3DFE.lpDDSPrimary->lpVtbl->SetPalette(D3DFE.lpDDSPrimary, D3DFE.lpPalette);
		if (hres!=DD_OK)
		{
			D3DFEMouseVisible(TRUE);
			DEBUG("SetPalette() failed in D3DFEInitFullScreen()\n");	
			DisplayHRESULTInDebug(hres);
			MessageBox(D3DFE.hwnd, "Unable to attach palette to front buffer\nExiting program", 
								D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}
	}

	/* Hide Cursor in FullScreen */
	D3DFEMouseVisible(FALSE);
	
	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFEInitWindow
 * Returns        : TRUE if no error occured
 * Global Used    : D3DFE
 * Description    : Initialize D3D for Window mode :
 *					- Set Cooperative level to NORMAL
 *					- Create Primary and Back buffer (surfaces)
 *					- Create clipper and attach it to Primary surface
 *******************************************************************************/
BOOL D3DFEInitWindow()
{
	DDSURFACEDESC       ddsd;
	HRESULT             hres;

	/* Asserts */
	ASSERT(D3DFE.lpDD2!=NULL);
	ASSERT(D3DFE.lpD3D2!=NULL);
	ASSERT(D3DFE.lpDDSPrimary==NULL);
	ASSERT(D3DFE.lpDDSBack==NULL);
	ASSERT(D3DFE.lpClipper==NULL);
		
	/* Set cooperative level to NORMAL mode
	   Set D3DFE.bIgnoreWM_SIZE because SetCooperativeLevel causes such a message
	   and we don't need to change the buffers in that case */
	D3DFE.bIgnoreWM_SIZE=TRUE;
	hres=D3DFE.lpDD2->lpVtbl->SetCooperativeLevel(D3DFE.lpDD2, D3DFE.hwnd, DDSCL_NORMAL);
	D3DFE.bIgnoreWM_SIZE=FALSE;
	if (hres!=DD_OK)
	{
	    DEBUG("SetCooperativeLevel() failed in D3DFEInitWindow()\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Unable to set Cooperative Level to Normal for Window mode\nExiting program", 
							D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Set DDSURFACEDESC structure to 0 */
	memset(&ddsd, 0, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);

	/* Create front buffer (primary surface) */
	ddsd.dwFlags=DDSD_CAPS;
	ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;

	hres=D3DFE.lpDD2->lpVtbl->CreateSurface(D3DFE.lpDD2, &ddsd, &D3DFE.lpDDSPrimary, NULL);
	if (hres!=DD_OK)
	{
		if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY)
		{
			MessageBox(D3DFE.hwnd, "Not enough memory to create primary surface\nPlease restart the program with a lower window size", 
								D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		else
		{
			MessageBox(D3DFE.hwnd, "Failed to create primary surface for Window mode\nExiting program", 
								D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		DEBUG("CreateSurface failed (D3DFE.lpDDSPrimary) in D3DFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Create back buffer */
	ddsd.dwFlags=DDSD_WIDTH | DDSD_HEIGHT | DDSD_CAPS;
	ddsd.dwWidth=D3DFE.dwWindowWidth;
	ddsd.dwHeight=D3DFE.dwWindowHeight;
	ddsd.ddsCaps.dwCaps=DDSCAPS_3DDEVICE | DDSCAPS_OFFSCREENPLAIN;

	/* Create back surface */
	hres=D3DFE.lpDD2->lpVtbl->CreateSurface(D3DFE.lpDD2, &ddsd, &D3DFE.lpDDSBack , NULL);
	if (hres!=DD_OK)
	{
		if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY)
		{
			MessageBox(D3DFE.hwnd, "Not enough memory to create back buffer\nPlease restart the program with a lower window size",
							D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		else
		{
			MessageBox(D3DFE.hwnd, "Failed to create back buffer in Window mode\nExiting program",
							D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		DEBUG("CreateSurface failed (D3DFE.lpDDSBack) in D3DFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}
	
	/* Create a clipper and attach it to our window */
	hres=D3DFE.lpDD2->lpVtbl->CreateClipper(D3DFE.lpDD2, 0, &D3DFE.lpClipper, NULL);
	if (hres!=DD_OK)
	{
		DEBUG("CreateClipper failed in D3DFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to create Clipper\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}
		
	/* Sets the window handle that will obtain the clipping information */
	hres=D3DFE.lpClipper->lpVtbl->SetHWnd(D3DFE.lpClipper, 0, D3DFE.hwnd);
	if (hres!=DD_OK)
	{
		DEBUG("SetHWnd failed in D3DFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to set window handle for clipping\nExiting program", 
							D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Assign clipper to front buffer */
	D3DFE.lpDDSPrimary->lpVtbl->SetClipper(D3DFE.lpDDSPrimary, D3DFE.lpClipper);
	if (hres!=DD_OK)
	{
		DEBUG("SetClipper failed in D3DFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to assign Clipper to Front Buffer\nExiting program", 
							D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}
	
	/* Show Cursor in window mode */
	D3DFEMouseVisible(TRUE);
	
	/* No problem occured */
	return TRUE;		
}


/*******************************************************************************
 * Function Name  : D3DFEInitD3DDevice()
 * Returns        : TRUE if no error occured
 * Global Used    : D3DFE, D3DDriver[], nCurrentD3DDriver, nDDNumDisplayModes,
 *					DDDisplayMode[]
 * Description    : Initialise Direct3D device selected :
 *					- Create Z-Buffer if needed	
 *					- Create Buffer Info surface if needed
 *					- Create D3D device 2 by using CreateDevice
 *					- Check if listed display modes are supported by this device
 *******************************************************************************/
BOOL D3DFEInitD3DDevice()
{
	int				i=0;
	HRESULT			hres;
	DDSURFACEDESC   ddsd;
			
	/* Asserts */  
	if (D3DFE.nBufferingMode>1)
	{
		ASSERT(D3DFE.lpDDSBack!=NULL);
	}
	ASSERT(nDDNumDisplayModes>0);
	ASSERT(D3DFE.hModesMenu!=NULL);
	ASSERT(D3DFE.lpDDSZBuffer==NULL);
	
	/* Do we need a Z-Buffer ? */
	if (D3DFE.bZBufferNeeded)
	{
		/* Check if device can support a 16-bit Z-buffer depth */
		if (!(D3DDriver[nCurrentD3DDriver].Desc.dwDeviceZBufferBitDepth & DDBD_16))
		{
			D3DFEMouseVisible(TRUE);
			DEBUG("16 bpp Z-Buffer not supported : Z-Buffer not created.\n");
			MessageBox(D3DFE.hwnd, "16 bit-per-pixel Z-Buffer not supported\nZ-Buffer disabled", 
								D3DFE.pszFrontEndTitle, MB_OK | MB_ICONWARNING);
			D3DFE.bZBufferNeeded=FALSE;
		}
		else
		{
			/* Set DDSURFACEDESC structure to 0 */
			memset(&ddsd, 0, sizeof(ddsd));
			ddsd.dwSize=sizeof(ddsd);
			
			/* Set up Z-Buffer creation info */
			ddsd.dwFlags=DDSD_WIDTH | DDSD_HEIGHT | DDSD_CAPS | DDSD_ZBUFFERBITDEPTH;
			if (D3DFE.bFullScreen)
			{
				ddsd.dwWidth=DDDisplayMode[nCurrentResolution].dwWidth;
				ddsd.dwHeight=DDDisplayMode[nCurrentResolution].dwHeight;
			}
			else
			{
				ddsd.dwWidth=D3DFE.dwWindowWidth;
				ddsd.dwHeight=D3DFE.dwWindowHeight;
			}
			ddsd.dwZBufferBitDepth=16;
			ddsd.ddsCaps.dwCaps=DDSCAPS_ZBUFFER;
   
			/* If D3D Driver is hardware, then use Video Memory for Z-Buffer */
			if (D3DDriver[nCurrentD3DDriver].bIsHardware)
			{
				ddsd.ddsCaps.dwCaps |= DDSCAPS_VIDEOMEMORY;
				
			}
			else
			{
				ddsd.ddsCaps.dwCaps |= DDSCAPS_SYSTEMMEMORY;
			}

			/* Create it */
			hres=D3DFE.lpDD2->lpVtbl->CreateSurface(D3DFE.lpDD2,  &ddsd, &D3DFE.lpDDSZBuffer, NULL);
			if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY) 
			{
				D3DFEMouseVisible(TRUE);
				DEBUG("Not enough memory to create Z-Buffer\n");
				DisplayHRESULTInDebug(hres);
				MessageBox(D3DFE.hwnd, "Not enough memory to create Z-Buffer surface\nExiting program",
								  D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
				return FALSE;
			}
			else
			if (hres!=DD_OK)
			{
				D3DFEMouseVisible(TRUE);
				DEBUG("Z-Buffer creation failed in D3DFEInitD3DDevice()\n");
				DisplayHRESULTInDebug(hres);
				MessageBox(D3DFE.hwnd, "Failed to create Z-Buffer\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
				return FALSE;
			}

			/* If a back buffer exists, then attach the Z-Buffer to it */
			if (D3DFE.lpDDSBack)
			{
				/* Attach the Z-buffer to the back buffer */
				hres=D3DFE.lpDDSBack->lpVtbl->AddAttachedSurface(D3DFE.lpDDSBack, D3DFE.lpDDSZBuffer);
				if (hres!=DD_OK)
				{
					D3DFEMouseVisible(TRUE);
					DEBUG("Failed to attach Z-Buffer to Back buffer in D3DFEInitWindow()\n");
					DisplayHRESULTInDebug(hres);
					MessageBox(D3DFE.hwnd, "Failed to attach Z-Buffer to back buffer\nExiting program", 
										D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
					return FALSE;
				}
			}
			else
			{
				/* Attach the Z-buffer to the primary buffer */
				hres=D3DFE.lpDDSPrimary->lpVtbl->AddAttachedSurface(D3DFE.lpDDSPrimary, D3DFE.lpDDSZBuffer);
				if (hres!=DD_OK)
				{
					D3DFEMouseVisible(TRUE);
					DEBUG("Failed to attach Z-Buffer to Primary buffer in D3DFEInitWindow()\n");
					DisplayHRESULTInDebug(hres);
					MessageBox(D3DFE.hwnd, "Failed to attach Z-Buffer to primary buffer\nExiting program", 
										D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
					return FALSE;
				}
			}
		}
	}

	/* DEBUG Info : display some info about surfaces */
	DisplayInfoAboutSurfaces();

	/* If a Back Buffer exist, query D3D device interface from it */
	if (D3DFE.lpDDSBack)
	{
		/* Create the Direct3D device 2 selected and attach it to the back buffer */
		hres=D3DFE.lpD3D2->lpVtbl->CreateDevice(D3DFE.lpD3D2, &D3DDriver[nCurrentD3DDriver].Guid, D3DFE.lpDDSBack, &D3DFE.lpD3DDev2);
		if (hres!=DD_OK)
		{
			D3DFEMouseVisible(TRUE);
			DEBUG("CreateSurface failed (for D3D Device 2)\n");
			DisplayHRESULTInDebug(hres);
			MessageBox(D3DFE.hwnd, "Unable to create D3D device 2\nExiting program", 
										D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}
	}
	else
	{
		/* Create the Direct3D device 2 selected and attach it to the front buffer */
		hres=D3DFE.lpD3D2->lpVtbl->CreateDevice(D3DFE.lpD3D2, &D3DDriver[nCurrentD3DDriver].Guid, D3DFE.lpDDSPrimary, &D3DFE.lpD3DDev2);
		if (hres!=DD_OK)
		{
			D3DFEMouseVisible(TRUE);
			DEBUG("CreateSurface failed (for D3D Device 2)\n");
			DisplayHRESULTInDebug(hres);
			MessageBox(D3DFE.hwnd, "Unable to create D3D device 2\nExiting program", 
										D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}
	}
		
	/* Check if display modes are supported by 3D device selected (Bit depth) */
	for (i=0; i<nDDNumDisplayModes; i++)
	{
		if (BPPToDDBD(DDDisplayMode[i].dwBPP) & D3DDriver[nCurrentD3DDriver].Desc.dwDeviceRenderBitDepth)
		{
			DDDisplayMode[i].bSupportedByD3DDriver=TRUE;
			/* Enable menu item */
			EnableMenuItem(D3DFE.hModesMenu, ID_MODES_RES0+i, MF_ENABLED);
		}
		else
		{
			DDDisplayMode[i].bSupportedByD3DDriver=FALSE;
			/* Disable menu item */
			EnableMenuItem(D3DFE.hModesMenu, ID_MODES_RES0+i, MF_GRAYED);
		}
	}

	/* If primary driver, then check if display modes are supported by 3D device 
	   selected (Memory used) */
	if (D3DFE.bZBufferNeeded)
	{
		if (D3DFE.bSharedVideoMemory)
		{
			for (i=0; i<nDDNumDisplayModes; i++)
			{
				/* D3DFE.nBufferingMode+1 because of Z-Buffer */
				if ((D3DFE.nBufferingMode+1)*DDDisplayMode[i].dwWidth*DDDisplayMode[i].dwHeight*DDDisplayMode[i].dwBPP/8
					>D3DFE.dwPhysicalVideoMemory)
				{
					/* This resolution is not supported in the selected Buffering mode */
					DDDisplayMode[i].bSupportedByD3DDriver=FALSE;
					/* Disable menu item */
					EnableMenuItem(D3DFE.hModesMenu, ID_MODES_RES0+i, MF_GRAYED);
				}
			}
		}
		else
		{
			for (i=0; i<nDDNumDisplayModes; i++)
			{
				/* Z-Buffer and surface memory are separate */
				if ((D3DFE.nBufferingMode*DDDisplayMode[i].dwWidth*DDDisplayMode[i].dwHeight*DDDisplayMode[i].dwBPP/8
					>D3DFE.dwPhysicalVideoMemory)
					|| (DDDisplayMode[i].dwWidth*DDDisplayMode[i].dwHeight*DDDisplayMode[i].dwBPP/8>D3DFE.dwTotalMemoryForZBuffer))
				{
					/* This resolution is not supported in the selected Buffering mode with Z-Buffer */
					DDDisplayMode[i].bSupportedByD3DDriver=FALSE;
					/* Disable menu item */
					EnableMenuItem(D3DFE.hModesMenu, ID_MODES_RES0+i, MF_GRAYED);
				}
			}
		}
	}
	else
	{
		/* No Z-Buffer */
		for (i=0; i<nDDNumDisplayModes; i++)
		{
			if (D3DFE.nBufferingMode*DDDisplayMode[i].dwWidth*DDDisplayMode[i].dwHeight*DDDisplayMode[i].dwBPP/8
				>D3DFE.dwPhysicalVideoMemory)
			{
				/* This resolution is not supported in the selected Buffering mode */
				DDDisplayMode[i].bSupportedByD3DDriver=FALSE;
				/* Disable menu item */
				EnableMenuItem(D3DFE.hModesMenu, ID_MODES_RES0+i, MF_GRAYED);
			}
		}
	}

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFEListDDDrivers
 * Returns        : TRUE if no error occured
 * Global Used    : nCurrentDDDriver, DDDriver[]
 * Description    : List all DirectDraw drivers available.
 *					This function should only be run once (in the beginning of
 *					D3D initialisation).
 *******************************************************************************/
BOOL D3DFEListDDDrivers()
{
	HRESULT		hres;
			
	/* Enumerate all DirectDraw drivers */
	hres=DirectDrawEnumerate(D3DFEEnumDirectDrawCallback, NULL);              
	if (hres!=DD_OK)
	{
		DEBUG("Failed in DirectDrawEnumerate in ListDDDrivers()\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* If secondary device has been forced On, then make it the default */
	if (D3DFE.dwUserPreferences & (FORCE_SECONDARYDEVICE | DEFAULT_SECONDARYDEVICE))
	{
		nCurrentDDDriver=1;
	}
	else
	{
		/* Default DD Driver is primary driver (=0) */
		nCurrentDDDriver=0;
	}
	
	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFEListDisplayModes
 * Returns        : TRUE if no error occured
 * Global Used    : nDDNumDisplayModes, nSafeDisplayModeNumber, nCurrentDDDriver
 * Description    : List all display modes available for the current device.
 *					Also calculate the amount of physical video memory installed
 *					by reporting the highest amount of memory used for a video
 *					mode for the primary device.
 *******************************************************************************/
BOOL D3DFEListDisplayModes(LPDIRECTDRAW2 lpLocalDD2)
{
	HRESULT				hres;
	int					i, BackCount=0;
	BOOL				Swap=FALSE;
	DDDisplayModeInfo	Dummy;
	DWORD				dwMaxVideoMemory=0;

	/* Setting first display mode to 0 */
	nDDNumDisplayModes=0;

	/* Call display mode callback */
	hres=lpLocalDD2->lpVtbl->EnumDisplayModes(lpLocalDD2, 0, NULL, NULL, D3DFEEnumDisplayModesCallback);
	if (hres!=DD_OK)
	{
		DEBUG("Problem with EnumDisplayModes\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Test if any display modes were found */
	if (nDDNumDisplayModes==0)
	{
		DEBUG("No display modes were found\n");
		return FALSE;
	}

	/* Sort all the display mode. That's a crap sorting method (bubble sort), 
	   but for a small amount of numbers it's all right, so who cares ?! */
	do
	{
		Swap=FALSE;
		BackCount++;
		for (i=0;i<nDDNumDisplayModes-BackCount;i++)
		{
			if (1000*DDDisplayMode[i].dwBPP+DDDisplayMode[i].dwWidth+DDDisplayMode[i].dwHeight<
				1000*DDDisplayMode[i+1].dwBPP+DDDisplayMode[i+1].dwWidth+DDDisplayMode[i+1].dwHeight)
			{
				/* Swap required */
				Dummy=DDDisplayMode[i+1];
				DDDisplayMode[i+1]=DDDisplayMode[i];
				DDDisplayMode[i]=Dummy;
				Swap=TRUE;
			}
		}
	}
	while (Swap && BackCount<nDDNumDisplayModes);
	
	/* Calculate video card physical memory */
	dwMaxVideoMemory=D3DFETotalVideoMemoryInfo(DDSCAPS_PRIMARYSURFACE);
		
	/* If Direct Draw driver is primary, memory is already used by GDI so
	   add GDI memory to dwMaxVideoMemory */
	if (nCurrentDDDriver==0)
	{
		dwMaxVideoMemory+=D3DFE.dwGDIWidth*D3DFE.dwGDIHeight*D3DFE.dwGDIBPP/8;
	}
		
	/* Find closest Meg-approximation of video memory retrieved */
	/*
	if (dwMaxVideoMemory<=128*1024*1024)	D3DFE.dwPhysicalVideoMemory=128*1024*1024;	
	if (dwMaxVideoMemory<=16*1024*1024)		D3DFE.dwPhysicalVideoMemory=16*1024*1024;	
	if (dwMaxVideoMemory<=8*1024*1024)		D3DFE.dwPhysicalVideoMemory=8*1024*1024;	
	if (dwMaxVideoMemory<=6*1024*1024)		D3DFE.dwPhysicalVideoMemory=6*1024*1024;	
	if (dwMaxVideoMemory<=4*1024*1024)		D3DFE.dwPhysicalVideoMemory=4*1024*1024;	
	if (dwMaxVideoMemory<=3*1024*1024)		D3DFE.dwPhysicalVideoMemory=3*1024*1024;	
	if (dwMaxVideoMemory<=2*1024*1024)		D3DFE.dwPhysicalVideoMemory=2*1024*1024;	
	if (dwMaxVideoMemory<=1*1024*1024)		D3DFE.dwPhysicalVideoMemory=1*1024*1024;	
	if (dwMaxVideoMemory<=512*1024)			D3DFE.dwPhysicalVideoMemory=512*1024;
	*/

	D3DFE.dwPhysicalVideoMemory=dwMaxVideoMemory;
	
	/* Debug output */
	sprintf(pszTmp, "Video card memory : %.2f Megs\n", (float)D3DFE.dwPhysicalVideoMemory/(1024.0f*1024.0f));
	DEBUG(pszTmp);

	/* Find display mode number corresponding to 640x480x16 */
	for (i=0;i<nDDNumDisplayModes;i++)
	{
		if (DDDisplayMode[i].dwWidth==640 && DDDisplayMode[i].dwHeight==480 && DDDisplayMode[i].dwBPP==16)
		{
			nSafeDisplayModeNumber=i;
		}
	}

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFEListD3DDrivers
 * Returns        : TRUE if no error occured
 * Global Used    : D3DFE
 * Description    : List all D3D drivers available for the current device.
 *******************************************************************************/
BOOL D3DFEListD3DDrivers()
{
	LPDIRECT3D2		lpLocalD3D2;
	HRESULT			hres;
	
	/* Asserts */
	ASSERT(D3DFE.lpDD2!=NULL);
		
	/* Setting number of D3D drivers to 0 */
	nD3DNumDrivers=0;

	/* Let's get Direct3D 2 only for enumerating MMX D3D driver */
    hres=D3DFE.lpDD2->lpVtbl->QueryInterface(D3DFE.lpDD2, &IID_IDirect3D2, (void**) &lpLocalD3D2);
    if (hres!=DD_OK) 
	{
        DEBUG("QueryInterface failed (for D3D2) in ListD3DDrivers()\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Enumerate available D3D devices (including MMX driver) */
	hres=lpLocalD3D2->lpVtbl->EnumDevices(lpLocalD3D2, D3DFEEnumD3DDeviceDriverCallback, NULL);
	if (hres!=DD_OK)
	{
		DEBUG("Failed in EnumDevices in ListD3DDrivers()\n");
		DisplayHRESULTInDebug(hres);
		RELEASE(lpLocalD3D2);
		return FALSE;
	}
	
	/* Test if at least one D3D driver has been found */
	if (nD3DNumDrivers==0)
	{
		DEBUG("No D3D driver has been found\n");
		RELEASE(lpLocalD3D2);
		return FALSE;
	}

	/* Release local memory */
	RELEASE(lpLocalD3D2);

	/* No problem occured */
	return TRUE;
}


/*****************************************************************************
 * Function Name  : D3DFEListTextureFormats
 * Inputs		  : lpDev2
 * Description    : List all available texture formats for the current D3D
 *				    driver by calling the texture format enumeration callback.
 *
 *****************************************************************************/
BOOL D3DFEListTextureFormats(LPDIRECT3DDEVICE2 lpDev2)
{
	HRESULT hres;
	int		i;
	int		tr=0, tg=0, tb=0, ta=0;
	int		r=0,g=0,b=0,a=0;
	int		bUse16BitsTextures=FALSE;
    
	/* Set default values */
	D3DFE.nBestOpaqueFormat=-1;
    D3DFE.nBestTransFormat=-1;
    D3DFE.nTextureFormat=0;

    /* Call texture format enumeration function */
	hres=lpDev2->lpVtbl->EnumTextureFormats(lpDev2, D3DFEEnumTextureFormatsCallback, NULL);
    if (hres != DD_OK) 
	{
        OutputDebugString("Enumeration of texture formats failed.");
        return FALSE;
    }

	/* Parse all enumerated texture format to pick best opaque format */
	for (i=0;i<D3DFE.nTextureFormat;i++)
	{
		tr=TextureFormat[i].RedBPP;
		tg=TextureFormat[i].GreenBPP;
		tb=TextureFormat[i].BlueBPP;
		ta=TextureFormat[i].AlphaBPP;
				
		/* Select best opaque format */
		if (ta==0)
		{
			/* Check if current texture format channels are larger than the previous choice */
			if (tr+tg+tb>r+g+b)
			{
				/* If 16 bits textures have to be used, use them */
				if (bUse16BitsTextures)
				{
					if (tr+tg+tb<=16)
					{
						D3DFE.nBestOpaqueFormat=i;
						r=tr;
						g=tg;
						b=tb;
						a=0;
					}
				}
				else
				{
					/* Otherwise just pick the best format (with the most bits per colour channel) */
					D3DFE.nBestOpaqueFormat=i;
					r=tr;
					g=tg;
					b=tb;
					a=0;
				}
			}
		}
	}

	/* Reset values to 0 */
	r=0;
	g=0;
	b=0;
	a=0;

	/* Parse all enumerated texture format to pick best translucent format */
	for (i=0;i<D3DFE.nTextureFormat;i++)
	{
		tr=TextureFormat[i].RedBPP;
		tg=TextureFormat[i].GreenBPP;
		tb=TextureFormat[i].BlueBPP;
		ta=TextureFormat[i].AlphaBPP;
		
		/* Check if current alpha channel is larger than the previous choice */
		if (ta>a)
		{
			/* If 16 bits textures have to be used, use them */
			if (bUse16BitsTextures)
			{
				if (tr+tg+tb+ta<=16)
				{
					D3DFE.nBestTransFormat=i;
					r=tr;
					g=tg;
					b=tb;
					a=ta;
				}
			}
			else
			{
				/* Otherwise just pick the best format (with the most bits in the alpha channel) */
				D3DFE.nBestTransFormat=i;
				r=tr;
				g=tg;
				b=tb;
				a=ta;
			}
		}
	}

	/* If best opaque format has not been found */
	if (D3DFE.nBestOpaqueFormat==-1) 
	{
		DEBUG("No opaque texture format was found in D3DFEListtextureFormat\n");
	}

	/* If best translucent format has not been found */
	if (D3DFE.nBestTransFormat==-1) 
	{
		DEBUG("No translucent texture format was found in D3DFEListtextureFormat\n");
	}
		
	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFEEnumDirectDrawCallback
 * Description    : Callback function which enumerates all available display
 *					modes for a DirectDraw device.
 *
 ******************************************************************************/
BOOL WINAPI D3DFEEnumDirectDrawCallback(GUID FAR* lpGuid, LPSTR lpDriverDesc, LPSTR lpDriverName, LPVOID lpContext)
{
	LPDIRECTDRAW lpLocalDD;
	DDCAPS       DDCaps, HELCaps;
      
	/* Try to create a DD device using the specified GUID */
	if (DirectDrawCreate(lpGuid, &lpLocalDD, NULL )!=DD_OK)
	{
		/* Failed, so ignore this device */
		return DDENUMRET_OK;
	}

    /* Get caps of this DD driver. If it fails, move on to the next driver */
	memset(&DDCaps, 0, sizeof(DDCaps));
	DDCaps.dwSize=sizeof(DDCaps);
	memset(&HELCaps, 0, sizeof(HELCaps));
	HELCaps.dwSize=sizeof(HELCaps);
	if (lpLocalDD->lpVtbl->GetCaps(lpLocalDD, &DDCaps, &HELCaps)!=DD_OK)
	{
		RELEASE(lpLocalDD);
		return DDENUMRET_OK;
	}

	/* Everything's OK, so save this driver's info */
	if (lpGuid==NULL)
	{
		DDDriver[nDDNumDrivers].lpGuid=0;
	}
	else
	{
		DDDriver[nDDNumDrivers].lpGuid=&DDDriver[nDDNumDrivers].Guid;
		memcpy(&DDDriver[nDDNumDrivers].Guid, lpGuid, sizeof(GUID));
	}
	lstrcpy (DDDriver[nDDNumDrivers].Name, lpDriverName);
	lstrcpy (DDDriver[nDDNumDrivers].Description, lpDriverDesc);
	memcpy (&DDDriver[nDDNumDrivers].DDCaps, &DDCaps, sizeof(DDCAPS));

	/* Debug output */
	sprintf(pszTmp, "DD Driver #%d :\nGuid=%u %u %u %s\nName=%s\nDescription=%s\n\n", nDDNumDrivers, 
			DDDriver[nDDNumDrivers].Guid.Data1, DDDriver[nDDNumDrivers].Guid.Data2, DDDriver[nDDNumDrivers].Guid.Data3, 
			DDDriver[nDDNumDrivers].Guid.Data4, DDDriver[nDDNumDrivers].Name, DDDriver[nDDNumDrivers].Description);
	DEBUG(pszTmp);

	/* Increase number of drivers found */
	nDDNumDrivers++;
	if (nDDNumDrivers>DD_MAXDDDRIVERS)
	{
		DEBUG("Reached maximum number of direct draw drivers\n\n");
		RELEASE(lpLocalDD);
		return DDENUMRET_CANCEL;
	}
	
	/* Release local memory */
	RELEASE(lpLocalDD);

	/* Continue enumeration */
	return DDENUMRET_OK;
}


/*******************************************************************************
 * Function Name  : D3DFEEnumDisplayModesCallback
 * Description    : Callback function which enumerates all available display
 *					modes for a DirectDraw device.
 *
 ******************************************************************************/
HRESULT WINAPI D3DFEEnumDisplayModesCallback(LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext)
{
	
	/* If the user asked for it, disable resolutions above 1024x768 */
	if (D3DFE.dwUserPreferences & DISABLE_VERYHIGHRES)
	{
		if (lpDDSurfaceDesc->dwWidth>1024)
		{
			return DDENUMRET_OK;
		}
	}

	/* Fill the DDDisplayMode structure with relevant information */
	DDDisplayMode[nDDNumDisplayModes].dwWidth=lpDDSurfaceDesc->dwWidth;
	DDDisplayMode[nDDNumDisplayModes].dwHeight=lpDDSurfaceDesc->dwHeight;
	DDDisplayMode[nDDNumDisplayModes].dwBPP=lpDDSurfaceDesc->ddpfPixelFormat.dwRGBBitCount;
	
	/* Increase number of display modes found */
	nDDNumDisplayModes++;
	if (nDDNumDisplayModes>DD_MAXDISPLAYMODES)
	{
		DEBUG("Reached maximum number of display modes\n\n");
		return DDENUMRET_CANCEL;
	}

	/* Continue enumeration */
	return DDENUMRET_OK;
}


/*******************************************************************************
 * Function Name  : D3DFEEnumD3DDeviceDriverCallback
 * Description    : Callback function which enumerates all D3D available drivers
 *
 ******************************************************************************/
HRESULT CALLBACK D3DFEEnumD3DDeviceDriverCallback(LPGUID lpGuid, LPSTR lpDeviceDescription,
												  LPSTR lpDeviceName, LPD3DDEVICEDESC lpHWDesc,
												  LPD3DDEVICEDESC lpHELDesc, LPVOID lpUserArg)
{
	/* Save this driver's info; we'll figure out which one we 
	   want to use in PickDriver */
    memcpy (&D3DDriver[nD3DNumDrivers].Guid, lpGuid, sizeof(GUID));
    lstrcpy (D3DDriver[nD3DNumDrivers].About, lpDeviceDescription);
    lstrcpy (D3DDriver[nD3DNumDrivers].Name, lpDeviceName);
    
	/* If the color model for a HW (HAL) driver is invalid or 0, then the 
	   driver must be a SW (HEL) driver, so use this as a test to see 
	   which type of driver we just saved */
    if (lpHWDesc->dcmColorModel)
	{
        D3DDriver[nD3DNumDrivers].bIsHardware=TRUE;
        memcpy (&D3DDriver[nD3DNumDrivers].Desc, lpHWDesc, sizeof(D3DDEVICEDESC));
    }
	else
	{
        D3DDriver[nD3DNumDrivers].bIsHardware=FALSE;
        memcpy (&D3DDriver[nD3DNumDrivers].Desc, lpHELDesc, sizeof(D3DDEVICEDESC));
	}

	/* Check if 3D driver can render onto a palettised surface */
	if (D3DDriver[nD3DNumDrivers].Desc.dwDeviceRenderBitDepth & DDBD_8)
	{
		D3DDriver[nD3DNumDrivers].bSupportPalettised=TRUE;
	}
	else
	{
		D3DDriver[nD3DNumDrivers].bSupportPalettised=FALSE;
	}

	/* Increase number of D3D drivers found */
    nD3DNumDrivers++;
	if (nD3DNumDrivers>D3D_MAXD3DDRIVERS)
	{
		DEBUG("Reached maximum number of D3D drivers\n\n");
		return DDENUMRET_CANCEL;
	}

	/* Continue enumeration */
	return (D3DENUMRET_OK);
}


/*****************************************************************************
 * Function Name  : D3DFEEnumTextureFormatsCallback
 * Description    : Callback function which enumerates all available texture
 *				    formats for the current D3D driver.
 *					Calculate the "best" opaque and translucent formats.
 *
 *****************************************************************************/
HRESULT CALLBACK D3DFEEnumTextureFormatsCallback(LPDDSURFACEDESC lpDDSD, LPVOID lpContext)
{
	DWORD	m;
	int		r=0, g=0, b=0, a=0, i;
	int		*lpStartFormat=(int *)lpContext;
	char	pszString[100];
  
    /* Set structure to 0 */
	memset(&TextureFormat[D3DFE.nTextureFormat], 0, sizeof(DDSURFACEDESC)+sizeof(int)*4);
	memcpy(&TextureFormat[D3DFE.nTextureFormat].ddsd,lpDDSD, sizeof(DDSURFACEDESC));
   
    /* We don't want 4-bit palettised textures */
	if (lpDDSD->ddpfPixelFormat.dwFlags & DDPF_PALETTEINDEXED4) 
	{
        return DDENUMRET_OK;
	}

	/* We don't want 8-bit palettised textures */
    if (lpDDSD->ddpfPixelFormat.dwFlags & DDPF_PALETTEINDEXED8) 
	{
		return DDENUMRET_OK;
	}
	
    /* Calculate the number of bits available for each channel R,G,B,A */
	m=lpDDSD->ddpfPixelFormat.dwRBitMask; 
	for (i=0; i<32; i++)
	{
		if ((1<<i) & m)
		{
			r++;
		}
	}
    m=lpDDSD->ddpfPixelFormat.dwGBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m) 
		{
			g++;
		}
	}
	m=lpDDSD->ddpfPixelFormat.dwBBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m) 
		{
			b++;
		}
	}
	if (lpDDSD->ddpfPixelFormat.dwFlags & DDPF_ALPHAPIXELS) 
	{
  		m = lpDDSD->ddpfPixelFormat.dwRGBAlphaBitMask; 
		for (i=0; i<32; i++) 
		{
			if (m & (1<<i)) 
			{
				a++;
			}
		}
		/* We don't want to enumerate this "weird" format for now */
		if (r==3 && g==3 && b==2 && a==8)
		{
			return DDENUMRET_OK;

		}
		TextureFormat[D3DFE.nTextureFormat].AlphaBPP=a;
    } 

	/* Fill the structure with texture format channel information */
	TextureFormat[D3DFE.nTextureFormat].RedBPP=r;
    TextureFormat[D3DFE.nTextureFormat].GreenBPP=g;
    TextureFormat[D3DFE.nTextureFormat].BlueBPP=b;
	    
    /* Increase total number of texture format */
	D3DFE.nTextureFormat++;

	/* Debug output */
	sprintf (pszString, "Enumerated texture Format : %d%d%d%d\n",r,g,b,a);
	DEBUG(pszString);

	/* Enumeration OK */
	return DDENUMRET_OK;
}


/*******************************************************************************
 * Function Name  : D3DFEChangeDirectDrawDriver
 * Inputs		  : nDDDriver
 * Global Used    : D3DFE
 * Description    : Choose another DirectDraw device
 *******************************************************************************/
void D3DFEChangeDirectDrawDriver(int nDDDriver)
{
	/* Pause execution */
	D3DFE.bPaused=TRUE;

	/* If the DirectDraw driver is not the primary (eg 3DFX and its secondary driver) 
	   and window mode is required then ask the user what to do */
	if (nDDDriver!=0 && !D3DFE.bFullScreen)
	{
		if (MessageBox(D3DFE.hwnd, "This display driver requires a FullScreen mode.\nPress OK to enter FullScreen mode\nor Cancel to keep the Primary Display Driver",
				D3DFE.pszFrontEndTitle, MB_OKCANCEL | MB_ICONINFORMATION)==IDOK)
		{
			/* OK : go for FullScreen mode */
			D3DFE.bFullScreen=TRUE;
		}
		else
		{
			D3DFE.bPaused=FALSE;
			return;
		}

	}

	/* Set Rendering state */
	D3DFE.bRenderingReady=FALSE;
	
	/* Release all DirectDraw objects */
	D3DFEReleaseAll();

	/* Assign current DirectDraw driver to selected driver */
	nCurrentDDDriver=nDDDriver;

	/* Create DirectDraw objects for D3D */
	if(!D3DFEInitDirectDrawForD3D())
	{
		DEBUG("D3DFEInitDirectDrawForD3D() failed in D3DFEChangeDirectDrawDriver()\n");
		D3DFEFinish();
		return;
	}

	/* Perform FullScreen or windowed initialisation */
	if (D3DFE.bFullScreen)
	{
		/* FullScreen mode */
		if (!D3DFEInitFullScreen())
		{
			DEBUG("D3DFEInitFullScreen() failed in D3DFEChangeDirectDrawDriver()\n");
			D3DFEFinish();
			return;
		}
	}
	else
	{
		/* Window mode */
		if (!D3DFEInitWindow())
		{
			DEBUG("D3DFEInitWindow() failed in D3DFEChangeDirectDrawDriver()\n");
			D3DFEFinish();
			return;
		}
	}

	/* Perform D3D device initialisation */
	if (!D3DFEInitD3DDevice())
	{
		DEBUG("D3DFEInitD3DDevice() failed in D3DFEChangeDirectDrawDriver()\n");
		D3DFEFinish();
		return;
	}

	/* Call D3DFECreateViewAndScene */
	if (!D3DFECreateViewAndScene())
	{
		DEBUG("D3DFECreateViewAndScene() failed in D3DFEChangeDirectDrawDriver()\n");
		D3DFEFinish();
		return;
	}
}


/*******************************************************************************
 * Function Name  : D3DFEChangeD3DMode
 * Inputs		  : nRes, nD3DDev, bScreenModeSelected
 * Global Used    : D3DFE
 * Description    : Change screen mode and D3D device.
 *******************************************************************************/
void D3DFEChangeD3DMode(int nRes, int nD3DDev, BOOL bScreenModeSelected)
{
	char	pszString[300];
	HRESULT	hres;
		
	/* Pause execution */
	D3DFE.bPaused=TRUE;

	/* If we are in Window mode, first check if required 
	   resolution is available for Window mode */
	if (!D3DFE.bFullScreen && bScreenModeSelected)
	{
		/* First check colour depth */
		if (DDDisplayMode[nRes].dwBPP!=D3DFE.dwGDIBPP)
		{
			sprintf(pszTmp, "Your current GDI colour depth is %u bpp\nand does not correspond to the selected resolution.\nTherefore you can not set this resolution in Window Mode.\nSelect OK to set this resolution in FullScreen mode.", D3DFE.dwGDIBPP);
			if (MessageBox(D3DFE.hwnd, pszTmp, D3DFE.pszFrontEndTitle, MB_OKCANCEL | MB_ICONWARNING)==IDOK)
			{
				/* Ok for this resolution in FullScreen */
				D3DFE.bFullScreen=TRUE;
			}
			else
			{
				/* Keep current window size */
				D3DFE.bPaused=FALSE;
				return;
			}
		} 
		else
		{
			/* Then check if GDI memory is enough to support this resolution in window mode */
			if (D3DFECheckVideoMemoryForWindowMode(DDDisplayMode[nRes].dwWidth, DDDisplayMode[nRes].dwHeight, D3DFE.bZBufferNeeded))
			{
				/* Selected mode supported */
				D3DFE.dwWindowWidth=DDDisplayMode[nRes].dwWidth;
				D3DFE.dwWindowHeight=DDDisplayMode[nRes].dwHeight;
				D3DFE.dwWindowFrameWidth=D3DFE.dwWindowWidth+D3DFE.dwWindowSpaceX;
				D3DFE.dwWindowFrameHeight=D3DFE.dwWindowHeight+D3DFE.dwWindowSpaceY;
				D3DFE.bFullScreen=FALSE;	/* Just to be sure */
			}
			else
			{
				/* This resolution is not supported in Window Mode : ask for FullScreen mode */
				sprintf(pszTmp, "Your current GDI memory is not enough to set this window size.\nSelect OK to enter FullScreen mode.");
				if (MessageBox(D3DFE.hwnd, pszTmp, D3DFE.pszFrontEndTitle, MB_OKCANCEL | MB_ICONWARNING)==IDOK)
				{
					/* Ok for this resolution in FullScreen */
					D3DFE.bFullScreen=TRUE;
				}
				else
				{
					/* Keep current window size */
					D3DFE.bPaused=FALSE;
					return;
				}
			}
		}
	}

	/* We are about to recreate all D3D variables, so set the Rendering state to FALSE */
	D3DFE.bRenderingReady=FALSE;
	
	/* Release memory */  
	D3DFEReleaseTextures();
	ReleaseView(D3DFE.lpD3DView2);
	RELEASE(D3DFE.lpD3DView2);
	RELEASE(D3DFE.lpD3DDev2);
	if (D3DFE.lpDDSZBuffer)
	{
		if (D3DFE.lpDDSBack)
		{
			/* If there is a back buffer, then Z Buffer must be attached to it */
			if (D3DFE.lpDDSBack->lpVtbl->DeleteAttachedSurface(D3DFE.lpDDSBack, 0, D3DFE.lpDDSZBuffer)!=DD_OK)
			{
				DEBUG("Failed to delete Z-Buffer surface from Back buffer in D3DFEChangeD3DMode()\n");
			}
		}
		else
		{
			/* No back buffer -> Z Buffer is attached to primary surface */
			if (D3DFE.lpDDSPrimary->lpVtbl->DeleteAttachedSurface(D3DFE.lpDDSPrimary, 0, D3DFE.lpDDSZBuffer)!=DD_OK)
			{
				DEBUG("Failed to delete Z-Buffer surface from Primary buffer in D3DFEChangeD3DMode()\n");
			}
		}
	}
	RELEASE(D3DFE.lpDDSZBuffer);
    RELEASE(D3DFE.lpClipper);
	RELEASE(D3DFE.lpDDSBack);
	RELEASE(D3DFE.lpDDSPrimary);
    
	/* Asserts */
	ASSERT(D3DFE.lpDD2!=NULL);
	ASSERT(D3DFE.lpD3D2!=NULL);

	/* Initialise FullScreen mode */
	if (D3DFE.bFullScreen)
	{
		/* Current Resolution = submitted resolution */
		nCurrentResolution=nRes;	
	
		/* Check if current resolution is palettised and if selected D3D driver
		   can do palettised rendering */
		if (DDDisplayMode[nCurrentResolution].dwBPP<16 &&
			!D3DDriver[nD3DDev].bSupportPalettised)
		{
			/* Go back to supported display mode */
			nCurrentResolution=nSafeDisplayModeNumber;
		}
							
		if (!D3DFEInitFullScreen())
		{
			sprintf(pszString, "Failed to set %ux%ux%u resolution\nPlease restart program and choose an other resolution", 
						DDDisplayMode[nCurrentResolution].dwWidth, 
						DDDisplayMode[nCurrentResolution].dwHeight, 
						DDDisplayMode[nCurrentResolution].dwBPP);
			MessageBox(D3DFE.hwnd, pszString, D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			D3DFEFinish();
			return;
		}
	}
	else
	{
		/* Initialise Window mode */

		/* Prevent from the following for shared video memory D3D devices :
		   - Set Z-Buffer Off
		   - Select a large window size (a size that cannot be reached with Z-Buffer On)
		   - Go to FullScreen
		   - Select Z-Buffer On
		   - Go back to window mode
		*/
		if ( D3DFE.bSharedVideoMemory && D3DFE.bZBufferNeeded &&
			 !D3DFECheckVideoMemoryForWindowMode(D3DFE.dwWindowWidth, D3DFE.dwWindowHeight, TRUE) )
		{
			D3DFE.bZBufferNeeded=FALSE;
		}
		/* Restore display mode for windowed mode */
		D3DFE.bIgnoreWM_SIZE=TRUE;
		hres=D3DFE.lpDD2->lpVtbl->RestoreDisplayMode(D3DFE.lpDD2);
		D3DFE.bIgnoreWM_SIZE=FALSE;
		if (hres!=DD_OK)
		{
			DEBUG("RestoreDisplayMode() failed in D3DFEChangeD3DMode()\n");
			DisplayHRESULTInDebug(hres);
			D3DFEFinish();
			return;
		}
	
		/* Resize window to its size because window size information might 
		   have been lost when switching back from FullScreen mode */
		D3DFE.bIgnoreWM_SIZE=TRUE;
		SetWindowPos(D3DFE.hwnd, NULL, 
					 D3DFE.dwWindowFramePositionX, D3DFE.dwWindowFramePositionY, 
					 D3DFE.dwWindowFrameWidth, D3DFE.dwWindowFrameHeight, 
					 SWP_NOZORDER | SWP_SHOWWINDOW);
		D3DFE.bIgnoreWM_SIZE=FALSE;
										
		/* Initialise Window mode */
		if (!D3DFEInitWindow())
		{
			DEBUG("D3DFEInitWindow() failed in D3DFEChangeD3DMode()\n");
			MessageBox(D3DFE.hwnd, "Failed to initialise Window mode\n", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			D3DFEFinish();
			return;
		}
	}

	/* Assign Current D3D Device to submitted one */
	nCurrentD3DDriver=nD3DDev;

	/* Initialise D3D device */
	if (!D3DFEInitD3DDevice())
	{
		DEBUG("D3DFEInitD3DDevice() failed in D3DFEChangeD3DMode()\n");
		D3DFEFinish();
		return;
	}

	/* Create viewport and D3D scene */
	if (!D3DFECreateViewAndScene())
	{
		DEBUG("D3DFECreateViewAndScene() failed in D3DFEChangeD3DMode()\n");
		D3DFEFinish();
		return;
	}
}


/*******************************************************************************
 * Function Name  : D3DFECreateViewAndScene
 * Returns        : TRUE if no error occured
 * Global Used    : D3DFE
 * Description    : Create a viewport
 *******************************************************************************/
BOOL D3DFECreateViewAndScene()
{
	HRESULT			hres;
	D3DVIEWPORT2	ViewData2;
	int				i=0;
	float			inv_aspect;
	DWORD			dwCurrentWidth, dwCurrentHeight;

	/* Asserts */
	ASSERT(D3DFE.lpD3D2!=NULL);
	ASSERT(D3DFE.lpD3DDev2!=NULL);
	ASSERT(D3DFE.lpD3DView2==NULL);
	
	/* Update menu items
	   The call of this function is located here because D3DCreateViewAndScene() is
	   the last function to be called during D3D initialisation. Therefore menus are up
	   to date at this point. */
	D3DFEUpdateMenus();

	/* Create a Viewport 2 interface */
	hres=D3DFE.lpD3D2->lpVtbl->CreateViewport(D3DFE.lpD3D2, &D3DFE.lpD3DView2, NULL);
	if (hres!=DD_OK)
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("Create viewport 2 failed\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to create Viewport 2\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}
	
	/* Add viewport */
	hres=D3DFE.lpD3DDev2->lpVtbl->AddViewport(D3DFE.lpD3DDev2, D3DFE.lpD3DView2);
	if (hres!=DD_OK)
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("AddViewport failed\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to Add Viewport\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}
	
	/* Setup the viewport for the viewing area */
	memset(&ViewData2, 0, sizeof(D3DVIEWPORT2));
	ViewData2.dwSize=sizeof(D3DVIEWPORT2);
	ViewData2.dwX=0;
	ViewData2.dwY=0;
	if (D3DFE.bFullScreen)
	{
		ViewData2.dwWidth=DDDisplayMode[nCurrentResolution].dwWidth;
		ViewData2.dwHeight=DDDisplayMode[nCurrentResolution].dwHeight;
	}
	else
	{
		ViewData2.dwWidth=D3DFE.dwWindowWidth;
		ViewData2.dwHeight=D3DFE.dwWindowHeight;
	}

	inv_aspect = (float)ViewData2.dwHeight/ViewData2.dwWidth;
	ViewData2.dvClipX = -1.0f;
	ViewData2.dvClipY = inv_aspect;
    ViewData2.dvClipWidth = 2.0f;
    ViewData2.dvClipHeight = 2.0f * inv_aspect;
    ViewData2.dvMinZ = 0.0f;
    ViewData2.dvMaxZ = 1.0f;

	/* Set viewport */
	hres=D3DFE.lpD3DView2->lpVtbl->SetViewport2(D3DFE.lpD3DView2, &ViewData2);
	if (hres!=DD_OK)
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("SetViewport2 failed\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to set Viewport2\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* New stuff ! */
	hres=D3DFE.lpD3DDev2->lpVtbl->SetCurrentViewport(D3DFE.lpD3DDev2, D3DFE.lpD3DView2);
	if (hres!=DD_OK)
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("SetCurrentViewport failed\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(D3DFE.hwnd, "Failed to SetCurrentViewport\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}
	 
	/* Get dimensions of rendering surface */
	if (D3DFE.bFullScreen)
	{
		dwCurrentWidth=DDDisplayMode[nCurrentResolution].dwWidth;
		dwCurrentHeight=DDDisplayMode[nCurrentResolution].dwHeight;
	}
	else
	{
		dwCurrentWidth=D3DFE.dwWindowWidth;
		dwCurrentHeight=D3DFE.dwWindowHeight;
	}

	/* Call user function InitView to initialise the user rendering */
	if (!(InitView(D3DFE.lpDD2, D3DFE.lpD3D2, D3DFE.lpD3DDev2, D3DFE.lpD3DView2, dwCurrentWidth, dwCurrentHeight)))
	{
		D3DFEMouseVisible(TRUE);
		DEBUG("InitView function failed\n");
		MessageBox(D3DFE.hwnd, "The InitView() function has failed\nExiting program", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}
	 
	/* No problem occured */
	D3DFE.bRenderingReady=TRUE;
	D3DFE.bPaused=FALSE;
	
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFERender
 * Returns        : TRUE if no error occured
 * Global Used    : D3DFE
 * Description    : Render D3D scene.
 *					Full Screen : call Flip() to update display.
 *					Windowed : do a Blit() from the back surface to the primary
 *					surface.
 *******************************************************************************/
BOOL D3DFERender()
{
	D3DRECT dummy;
	RECT	rect;
	RECT	SrcRect, DstRect;
	POINT	pt;
	HRESULT	hres;
	
	/* Clear values for rectangles */
	dummy.x1=0;
	dummy.y1=0;
	rect.left=0;
	rect.top=0;
	
	/* Retrieve blitting rectangle information */
	if (D3DFE.bFullScreen)
	{
		dummy.x2=DDDisplayMode[nCurrentResolution].dwWidth;
		dummy.y2=DDDisplayMode[nCurrentResolution].dwHeight;
		rect.right=dummy.x2;
		rect.bottom=dummy.y2;
	}
	else
	{
		dummy.x2=D3DFE.dwWindowWidth;
		dummy.y2=D3DFE.dwWindowHeight;
		rect.right=D3DFE.dwWindowWidth;
		rect.bottom=D3DFE.dwWindowHeight;
	}

	/* Clear the target surface and Z-Buffer (if it exists) */
	if (D3DFE.bClearViewport)
	{
		/* In window mode, wait for the previous blit to finish before clearing the viewport */
		if (!D3DFE.bFullScreen)
		{
			if (D3DFE.lpDDSPrimary->lpVtbl->GetBltStatus(D3DFE.lpDDSPrimary, DDGBS_ISBLTDONE)==DDERR_WASSTILLDRAWING)
			{
				while (D3DFE.lpDDSPrimary->lpVtbl->GetBltStatus(D3DFE.lpDDSPrimary, DDGBS_ISBLTDONE)!=DD_OK);
			}
		}

		/* Clear viewport */
		/* SPECIAL STUFF FOR VERY QUICK RENDERS */
		/* D3DFEClearSurface(D3DFE.lpDDSBack);
		   while (D3DFE.lpDDSBack->lpVtbl->GetBltStatus(D3DFE.lpDDSBack, DDGBS_ISBLTDONE)!=DD_OK); */
		
		hres=D3DFE.lpD3DView2->lpVtbl->Clear(D3DFE.lpD3DView2, 1, &dummy, D3DCLEAR_TARGET);
		if (hres!=DD_OK)
		{
			DEBUG("Viewport clear failed in D3DFERender()\n");
			DisplayHRESULTInDebug(hres);
		}
	}
	if (D3DFE.lpDDSZBuffer)
	{
		hres=D3DFE.lpD3DView2->lpVtbl->Clear(D3DFE.lpD3DView2, 1, &dummy, D3DCLEAR_ZBUFFER);
		if (hres!=DD_OK)
		{
			DEBUG("ZBuffer clear failed in D3DFERender()\n");
			DisplayHRESULTInDebug(hres);
		}
	}
	
	/* Check for lost surfaces */
	if (!D3DFECheckForLostSurfaces())
	{
		DEBUG("CheckForLostSurfaces() failed in D3DFERender()\n");
		return FALSE;
	}

	/* Call user rendering routine */
	if (!RenderScene(D3DFE.lpD3DDev2, D3DFE.lpD3DView2))
	{
		DEBUG("RenderScene failed in D3DFERender()\n");
		return FALSE;
	}

	/* Display text if required */
	if (D3DFE.bShowInfoBuffer || (D3DFE.nNumberOfUserString>0))
	{
		D3DFEDisplayText();
	}

	if (D3DFE.bFullScreen)
	{
		/* If at least 2 surfaces (front and back buffers) */
		if (D3DFE.nBufferingMode>1)
		{
			/* Fullscreen mode : update the primary surface by performing a flip */
			hres=D3DFE.lpDDSPrimary->lpVtbl->Flip(D3DFE.lpDDSPrimary, NULL, DDFLIP_WAIT);
			if (hres!=DD_OK)
			{
				DEBUG("Flip() failed in D3DFERender()\n");
				DisplayHRESULTInDebug(hres);
				return FALSE;
			}
		}
	}
	else
	{
		/* Windowed mode : perform a blit from back buffer to front buffer */
		ASSERT(D3DFE.lpDDSBack);

		/* SrcRect is relative to offscreen buffer */
		GetClientRect(D3DFE.hwnd, &SrcRect);

		/* DstRect is relative to screen space so needs translation */
		pt.x=0;
		pt.y=0;
		ClientToScreen(D3DFE.hwnd, &pt);
		DstRect=SrcRect;
		DstRect.left+=pt.x;
		DstRect.right+=pt.x;
		DstRect.top+=pt.y;
		DstRect.bottom+=pt.y;

		/* Perform the blit from backbuffer to primary, using
		   src_rect and dst_rect */
		hres=D3DFE.lpDDSPrimary->lpVtbl->Blt(D3DFE.lpDDSPrimary, &DstRect, D3DFE.lpDDSBack, &SrcRect, DDBLT_WAIT, 0);
		if (hres!=DD_OK) 
		{
			DEBUG("Blit() failed in D3DFERender()\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
	}

	/* No problem occured */
	return TRUE;
}



/*******************************************************************************
 * Function Name  : D3DFEDisplayToGDI
 * Global Used    : D3DFE
 * Description    : Redraw window in GDI for secondary device (eg : 3DFX) 
 *					in Fullscreen mode
 *******************************************************************************/
void D3DFEDisplayToGDI()
{
	HRESULT		hres;
	char		pszPaused[50];
	RECT		rect;
	HDC			hdc;
	HPEN		hOldPen;
    HBRUSH		hOldBrush;
    COLORREF	crOldTextColor;
    INT			oldMode;
    INT			x;
    INT			y;
    SIZE		size;
    INT			nStrLen;
	POINT		pt;
	LPDIRECTDRAWSURFACE	lpDDS=NULL;
	
	/* Flip to GDI surface to make sure the user sees the menu (if Back buffer exists) */
	if (D3DFE.lpDDSBack)
	{
		hres=D3DFE.lpDD2->lpVtbl->FlipToGDISurface(D3DFE.lpDD2);
		if (hres!=DD_OK)
		{
			DEBUG("Failed in FlipToGDISurface()\n");
			DisplayHRESULTInDebug(hres);
		}
	}
	
	/* If DirectDraw driver is not primary, then display a paused window */
	if (D3DFE.hwnd && IsWindow(D3DFE.hwnd) && nCurrentDDDriver!=0)
	{
		/* Get Device Context for this window */
		hdc=GetWindowDC(D3DFE.hwnd);

		/* Display black screen + "Paused" message */
		strcpy(pszPaused, "Paused");

		/* Black background */
		hOldPen=(HPEN)SelectObject(hdc, GetStockObject (NULL_PEN));
		hOldBrush=(HBRUSH)SelectObject(hdc, GetStockObject (BLACK_BRUSH));

		/* White text */
		oldMode=SetBkMode(hdc, TRANSPARENT);
		crOldTextColor=SetTextColor(hdc, RGB(255, 255, 255));

		/* Retrieves coordinates of a window */
		GetClientRect(D3DFE.hwnd, &rect);
		
		/* rect is relative to screen space so needs translation */
		pt.x=0;
		pt.y=0;
		ClientToScreen(D3DFE.hwnd, &pt);
		rect.left+=pt.x;
		rect.right+=pt.x;
		rect.top+=pt.y;
		rect.bottom+=pt.y;
		
	    /* Clear the client area */
	    Rectangle(hdc, rect.left, rect.top, rect.right + 1, rect.bottom + 1);

		/* Draw the string centered in the client area */
	    nStrLen=strlen(pszPaused);
		GetTextExtentPoint32(hdc, pszPaused, nStrLen, &size);
		x=(rect.right  - size.cx) / 2;
		y=(rect.bottom - size.cy) / 2;
		TextOut (hdc, x, y, pszPaused, nStrLen);

		/* Cleanup */
		SetTextColor(hdc, crOldTextColor);
		SetBkMode(hdc, oldMode);
		SelectObject(hdc, hOldBrush);
		SelectObject(hdc, hOldPen);

		/* Release Device Context for this window because we finished our painting */
		ReleaseDC(D3DFE.hwnd, hdc);
	}

	/* Draw menu bar and window */
	D3DFE.bIgnoreWM_SIZE=TRUE;
	DrawMenuBar(D3DFE.hwnd);
	RedrawWindow(D3DFE.hwnd, NULL, NULL, RDW_FRAME);
	D3DFE.bIgnoreWM_SIZE=FALSE;
} 


/*******************************************************************************
 * Function Name  : D3DFEFreeVideoMemoryInfo
 * Returns		  :	Amount of free video memory (minus GDI memory)
 * Global Used    : D3DFE
 * Description    : Returns amount of free video memory that can be used by
 *					a surface
 *******************************************************************************/
DWORD D3DFEFreeVideoMemoryInfo(DWORD dwCaps)
{
	DDSCAPS	ddsCaps;
	HRESULT	hres;
	DWORD	dwTotal=0;
	DWORD   dwFree=0;

	/* If no memory check is specified, return max value for video memory */
	if (D3DFE.dwUserPreferences & NO_MEMORY_CHECK)
	{
		return 16*1024*1024;
	}

	/* If D3DFE.lpDD2 has not yet been created, return max value */
	if (!D3DFE.lpDD2) 
	{
		return 16*1024*1024;
	}
	
	/* Call this function to retrieve the amount of video memory */
	ddsCaps.dwCaps=dwCaps;
	hres=D3DFE.lpDD2->lpVtbl->GetAvailableVidMem(D3DFE.lpDD2, &ddsCaps, &dwTotal, &dwFree);
	if (hres!=DD_OK)
	{
		DEBUG("GetAvailableVidMem() failed in FreeVideoMemoryInfo()\n");
		DisplayHRESULTInDebug(hres);
	}
	
	return dwFree;
}


/*******************************************************************************
 * Function Name  : D3DFETotalVideoMemoryInfo
 * Returns		  :	Amount of total video memory (minus GDI memory)
 * Global Used    : D3DFE
 * Description    : Returns amount of total video memory that can be used by
 *					a surface
 *******************************************************************************/
DWORD D3DFETotalVideoMemoryInfo(DWORD dwCaps)
{
	DDSCAPS	ddsCaps;
	HRESULT	hres;
	DWORD	dwTotal=0;
	DWORD   dwFree=0;

	/* If no memory check is specified, return max value for video memory */
	if (D3DFE.dwUserPreferences & NO_MEMORY_CHECK) 
	{
		return 16*1024*1024;
	}
	
	/* If D3DFE.lpDD2 has not yet been created, return max value */
	if (!D3DFE.lpDD2) return 16*1024*1024;

	/* Call this function to retrieve the amount of video memory */
	ddsCaps.dwCaps=dwCaps;
	hres=D3DFE.lpDD2->lpVtbl->GetAvailableVidMem(D3DFE.lpDD2, &ddsCaps, &dwTotal, &dwFree);
	if (hres!=DD_OK)
	{
		DEBUG("GetAvailableVidMem() failed in TotalVideoMemoryInfo()\n");
		DisplayHRESULTInDebug(hres);
	}
		
	return dwTotal;
}


/*******************************************************************************
 * Function Name  : D3DFECheckVideoMemoryForWindowMode
 * Returns		  :	TRUE if memory is OK for this window mode
 * Global Used    : D3DFE
 * Description    : Check if there is enough video memory (both surface and
 *					Z-Buffer) to set window dimensions
 *******************************************************************************/
BOOL D3DFECheckVideoMemoryForWindowMode(DWORD dwWidth, DWORD dwHeight, BOOL bZBuffer)
{
	/* First check maximums */
	if (dwWidth>D3DFE.dwMaxWindowWidth || dwHeight>D3DFE.dwMaxWindowHeight)
	{
		/* Selected window size exceeds maximum width and/or height */
		DEBUG("Video memory check : Window dimensions exceeds maximums\n");
		return FALSE;
	}
	
	if (D3DFE.bSharedVideoMemory)
	{
		/* Check if client area has enough primary surface memory */
		if (bZBuffer)
		{
			/* Use GDI colour depth for surface and 16 bit surface for Z-Buffer */
			if ( (dwWidth*dwHeight*D3DFE.dwGDIBPP/8) + (dwWidth*dwHeight*2) > D3DFE.dwTotalMemoryForWindow )
			{
				/* Not enough memory for window with current window size because of Z-Buffer */
				DEBUG("Video memory check : Not enough memory for Z-Buffer\n");
				return FALSE;				   
			}
		}
		else
		{
			/* No Z-Buffer needed, just check if there is enough memory for surface */
			if (dwWidth*dwHeight*D3DFE.dwGDIBPP/8>D3DFE.dwTotalMemoryForWindow)
			{
				/* Not enough memory for window with current window size */
				DEBUG("Video memory check : Not enough memory for window surface\n");
				return FALSE;
			}
		}
	}
	else
	{
		/* Surface memory and Z-Buffer memory are separate */
		if (bZBuffer)
		{
			/* Check if client area has enough Z-Buffer 16 bit surface memory for this size */
			if (dwWidth*dwHeight*2>D3DFE.dwTotalMemoryForZBuffer)
			{
				/* Not enough memory for window with current window size because of Z-Buffer memory */
				DEBUG("Video memory check : Not enough memory for Z-Buffer\n");
				return FALSE;
			}
		}
		/* Check if client area has enough surface memory for this size */
		if (dwWidth*dwHeight*D3DFE.dwGDIBPP/8>D3DFE.dwTotalMemoryForWindow)
		{
			/* Not enough memory for window with current window size */
			DEBUG("Video memory check : Not enough memory for window surface\n");
			return FALSE;
		}
	}

	/* There is enough video memory to support this window size */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : WinMain 
 * Description    : Main function of the program
 *******************************************************************************/
int WINAPI WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	int			idle, done = FALSE;
	static int	nRenderFailed=0;
	RECT		Rect;
	HDC			hdc;
	
	/* Initialise D3D Shell variables */
	D3DFEInitFrontEnd();

	/* set up and register window class */
	if (!hPrevInstance)	
	{
		D3DFE.wndclass.style=CS_HREDRAW | CS_VREDRAW;
		D3DFE.wndclass.lpfnWndProc=(WNDPROC)D3DFEWindowProc;
		D3DFE.wndclass.cbClsExtra=0;
		D3DFE.wndclass.cbWndExtra=0;
		D3DFE.wndclass.hInstance=hInstance;
		D3DFE.wndclass.hIcon=D3DFE.hIcon;
		D3DFE.wndclass.hCursor=LoadCursor(NULL, IDC_ARROW);
		D3DFE.wndclass.hbrBackground=NULL; 
		D3DFE.wndclass.lpszMenuName=NULL;
		D3DFE.wndclass.lpszClassName="D3DShellClass";
		RegisterClass (&D3DFE.wndclass);
	}

	/* First call InitApplication() to retrieve user choices */
	InitApplication();

	/* Compute Window style */
	D3DFE.dwWindowStyle=WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
	if (!(D3DFE.dwUserPreferences & DISABLE_RESIZING))
	{
		D3DFE.dwWindowStyle|=WS_THICKFRAME;
	}
	
	/* Get Screen default dimensions and bpp */
	D3DFE.dwGDIWidth=GetSystemMetrics(SM_CXSCREEN);
	D3DFE.dwGDIHeight=GetSystemMetrics(SM_CYSCREEN);
	hdc=GetDC(NULL);
	D3DFE.dwGDIBPP=GetDeviceCaps(hdc, BITSPIXEL);
	ReleaseDC(NULL, hdc);

	/* Update maximum width and height of window */
	if (D3DFE.dwGDIWidth<D3DFE.dwMaxWindowWidth)
	{
		D3DFE.dwMaxWindowWidth=D3DFE.dwGDIWidth;
	}
	if (D3DFE.dwGDIHeight<D3DFE.dwMaxWindowHeight)
	{
		D3DFE.dwMaxWindowHeight=D3DFE.dwGDIHeight;
	}
	
	/* If GDI resolution is below 640x480, use 512x384 window */
	if (D3DFE.dwGDIWidth<800)
	{
		D3DFE.dwWindowWidth=512;
		D3DFE.dwWindowHeight=384;
	}

	/* Check if colour depth is at least 16 bpp */
	if (D3DFE.dwGDIBPP<16)
	{
		DEBUG("Color depth is lower than 16 bpp\n");
		sprintf(pszTmp, "Can not run program with a color depth of %u\nColor depth must be at least 16 bpp", D3DFE.dwGDIBPP);
		MessageBox(NULL, pszTmp, D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();	/* To release any memory allocated by application */
		return 0;
	}
	
	/* Compute window position (screen centre) */
	D3DFE.dwWindowPositionX=(D3DFE.dwGDIWidth-D3DFE.dwWindowWidth)/2;
	D3DFE.dwWindowPositionY=(D3DFE.dwGDIHeight-D3DFE.dwWindowHeight)/2;
	
	/* Compute window size corresponding to client area size */
	SetRect(&Rect,  D3DFE.dwWindowPositionX, D3DFE.dwWindowPositionY, 
					D3DFE.dwWindowWidth+D3DFE.dwWindowPositionX-1, D3DFE.dwWindowHeight+D3DFE.dwWindowPositionY-1);
	AdjustWindowRect(&Rect, D3DFE.dwWindowStyle, TRUE);

	/* Set window frame values */
	D3DFE.dwWindowFramePositionX=Rect.left;
	D3DFE.dwWindowFramePositionY=Rect.top;

	D3DFE.dwWindowFrameWidth=(Rect.right-Rect.left)+1;
	D3DFE.dwWindowFrameHeight=(Rect.bottom-Rect.top)+1;
	
	/* Compute window space between client and window */
	D3DFE.dwWindowSpaceX=D3DFE.dwWindowFrameWidth-D3DFE.dwWindowWidth;
	D3DFE.dwWindowSpaceY=D3DFE.dwWindowFrameHeight-D3DFE.dwWindowHeight;

	/* create a window */
    D3DFE.hwnd = CreateWindowEx(0,
								"D3DShellClass",
								D3DFE.pszFrontEndTitle,
								D3DFE.dwWindowStyle,
								D3DFE.dwWindowFramePositionX,
								D3DFE.dwWindowFramePositionY,
								D3DFE.dwWindowFrameWidth,
								D3DFE.dwWindowFrameHeight,
								NULL,
								D3DFE.hMenu,
								hInstance,
								NULL );

	/* If window could not be created */
    if (D3DFE.hwnd==NULL)
    {
        DEBUG("Window could not be created\n");
		MessageBox(NULL, "Unable to create Window", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();	/* To release any memory allocated by application */
		return 0;
    }

	/* Debug output */
	sprintf(pszTmp, "Window position = %d %d %d %d\nWindow frame position = %d %d %d %d\nWindow space = %d %d\n",
			D3DFE.dwWindowPositionX, D3DFE.dwWindowPositionY, D3DFE.dwWindowWidth, D3DFE.dwWindowHeight,
			D3DFE.dwWindowFramePositionX, D3DFE.dwWindowFramePositionY, D3DFE.dwWindowFrameWidth, D3DFE.dwWindowFrameHeight,
			D3DFE.dwWindowSpaceX, D3DFE.dwWindowSpaceY);
	DEBUG(pszTmp);

	/* Create font */
	D3DFE.hTextFont=CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
							   ANSI_CHARSET,
							   OUT_DEFAULT_PRECIS,
							   CLIP_DEFAULT_PRECIS,
							   DEFAULT_QUALITY,
							   VARIABLE_PITCH,
							   "Arial" );
	
	/* Set up cursor */
	SetCursor(D3DFE.wndclass.hCursor);
	D3DFEMouseVisible(TRUE);

	/* Create accelerator table */
	D3DFECreateAccelerators();

	/* Show and update window */
    ShowWindow(D3DFE.hwnd, nCmdShow);
    UpdateWindow(D3DFE.hwnd);

	/* List all DirectDraw devices (Primary, Secondary, etc...)
	   Only run at the first initialisation */
	if (!D3DFEListDDDrivers())
	{
		DEBUG("ListDDDrivers() failed in WinMain()\n");
		MessageBox(NULL, "Failed to enumerate DirectDraw devices", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();
		D3DFEReleaseAll();
		return 0;
	}

	/* Create DirectDraw objects for D3D */
	if(!D3DFEInitDirectDrawForD3D())
	{
		DEBUG("D3DFEInitDirectDrawForD3D() failed in WinMain\n");
		MessageBox(NULL, "Failed to initialise DirectDraw", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();
		D3DFEReleaseAll();
		return 0;
	}

	/* Perform FullScreen or windowed initialisation */
	if (D3DFE.bFullScreen)
	{
		/* FullScreen mode */
		if (!D3DFEInitFullScreen())
		{
			DEBUG("D3DFEInitFullScreen() failed in WinMain\n");
			MessageBox(D3DFE.hwnd, "Failed to initialise FullScreen mode", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			QuitApplication();
			D3DFEReleaseAll();
			return 0;
		}
	}
	else
	{
		/* Window mode */
		if (!D3DFEInitWindow())
		{
			DEBUG("D3DFEInitWindow() failed in WinMain\n");
			MessageBox(NULL, "Failed to initialise Window mode", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			QuitApplication();
			D3DFEReleaseAll();
			return 0;
		}
	}

	/* Perform D3D device initialisation */
	if (!D3DFEInitD3DDevice())
	{
		DEBUG("D3DFEInitD3DDevice() failed in WinMain\n");
		MessageBox(D3DFE.hwnd, "Failed to initialise D3D device", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();
		D3DFEReleaseAll();
		return 0;
	}

	/* Call D3DCreateViewAndScene */
	if (!D3DFECreateViewAndScene())
	{
		DEBUG("D3DFECreateViewAndScene() failed in WinMain\n");
		MessageBox(D3DFE.hwnd, "Failed to initialise scene", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();
		D3DFEReleaseAll();
		return 0;
	}

	/* Create a timer used to calculate frame rate (we use 99 for the counter
	   ID, as we don't want the user to set a timer with 1 for an ID) */
	SetTimer(D3DFE.hwnd, 99, TIMER_PERIOD, (TIMERPROC)D3DFETimerProc);
	
	/* D3D Initialisation complete! */
			
	/* Message loop */
	while (!done)
    {   
		idle = TRUE;
		while (PeekMessage(&D3DFE.msg, NULL, 0, 0, PM_REMOVE))
		{
			idle=FALSE;
			if (D3DFE.msg.message==WM_QUIT)
			{	
				done=TRUE;
				break;
			}
			if (!TranslateAccelerator(D3DFE.hwnd, D3DFE.hAccel, &D3DFE.msg))
			{
				TranslateMessage(&D3DFE.msg);
				DispatchMessage(&D3DFE.msg);
			}
		}
		
		/* If we are not minimised nor paused and the rendering is ready */
		if (!D3DFE.bMinimized && !D3DFE.bPaused && D3DFE.bRenderingReady)
		{
			/* Call the rendering routine */
			if (!D3DFERender())
			{
				DEBUG("D3DFERender() failed\n");
				if (++nRenderFailed>3)
				{
					D3DFE.bRenderingReady=FALSE;
					D3DFE.bPaused=TRUE;
					D3DFEMouseVisible(TRUE);
					DEBUG("D3DFERender() has failed more than 3 times ! Aborting program\n");
					MessageBox(D3DFE.hwnd, "Rendering has failed too many times\nAborting program", 
									  D3DFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
					D3DFEFinish();
				}
			}
		}
    }

	/* Give time to free all variables and erase windows */
	Sleep(100);
	
	QuitApplication();
	DEBUG("Releasing memory\n");
	D3DFEReleaseAll();
	DestroyAcceleratorTable(D3DFE.hAccel);
	D3DFEMouseVisible(TRUE);

	DEBUG("End of program\n");
    return D3DFE.msg.wParam;
}


/*******************************************************************************
 * Function Name  : D3DFEWindowProc
 * Description    : Messages handling function
 *******************************************************************************/
long CALLBACK D3DFEWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  	LRESULT			lresult;
	HRESULT			hres;
	RECT			Rectangle;
		
	/* Let the user process window message (menus and keystrokes) */
	UserWindowProc(hWnd, message, wParam, lParam);
	
	/* FrontEnd window messages */
	switch(message)
    {
	case	WM_ENTERMENULOOP :	if (D3DFE.bFullScreen)
								{
									if (nCurrentDDDriver!=0 && D3DFE.nBufferingMode==1)
									{
										/* We are in single buffer mode in a secondary device */
										D3DFE.bIgnoreWM_SIZE=TRUE;
										hres=D3DFE.lpDD2->lpVtbl->SetCooperativeLevel(D3DFE.lpDD2, hWnd, DDSCL_NORMAL);
										D3DFE.bIgnoreWM_SIZE=FALSE;
										if (hres!=DD_OK)
										{
											DEBUG("SetCooperativeLevel() failed in D3DFEWindowProc()\n");
											DisplayHRESULTInDebug(hres);
										}
									}
									D3DFEMouseVisible(TRUE);
									D3DFEDisplayToGDI();
								}
								break;

	case	WM_EXITMENULOOP :	if (D3DFE.bFullScreen)
								{
									if (nCurrentDDDriver!=0 && D3DFE.nBufferingMode==1)
									{
										/* We are in single buffer mode in a secondary device */
										D3DFE.bIgnoreWM_SIZE=TRUE;
										hres=D3DFE.lpDD2->lpVtbl->SetCooperativeLevel(D3DFE.lpDD2, hWnd, DDSCL_FULLSCREEN | DDSCL_EXCLUSIVE);
										D3DFE.bIgnoreWM_SIZE=FALSE;
										if (hres!=DD_OK)
										{
											DEBUG("SetCooperativeLevel() failed in D3DFEWindowProc()\n");
											DisplayHRESULTInDebug(hres);
										}
									}
									D3DFEMouseVisible(FALSE);
								}
								break;

	/* Used to disable rendering if window is not activated */
	case	WM_ACTIVATEAPP :    if (D3DFE.bRenderingReady)
								{
									if (!(BOOL)wParam)
									{
										D3DFE.bPaused=TRUE;
									}
									else
									{
										D3DFE.bPaused=FALSE;
									}
								}
						        break;

	case	WM_SYSCOMMAND :	    switch (wParam & 0xFFF0)
								{
									/* Close Window */
									case SC_CLOSE:	DestroyWindow(D3DFE.hwnd);
													break;
									
									/* Disable Screen saver */	
									case SC_SCREENSAVE:

									/* Disable monitor power down */
									case SC_MONITORPOWER:	return 0; break;

									/* Minimize has been selected */
									case SC_MINIMIZE :		D3DFE.bMinimized=TRUE; break;

									default : break;
								}
								return (DefWindowProc(hWnd, message, wParam, lParam));
								break;	

	case	WM_SIZE :			if (!D3DFE.bIgnoreWM_SIZE) 
								{		
									D3DFE.bPaused=TRUE;
									D3DFEHandleWM_SIZE(&lresult, hWnd, message, wParam, lParam);
									D3DFE.bPaused=FALSE;
									return 0;
								}
								break;

	case	WM_MOVE :			/* Update window position information after a move */
								if (!D3DFE.bFullScreen && !D3DFE.bMinimized && !D3DFE.bIgnoreWM_SIZE && !D3DFE.bPaused)
								{
									GetWindowRect(hWnd, &Rectangle);
									D3DFE.dwWindowFramePositionX=Rectangle.left; 
									D3DFE.dwWindowFramePositionY=Rectangle.top;
								}
								break;
	
	case	WM_SIZING :			/* Prevent the window to reach unwanted size */
								/* No resize allowed if DISABLE_RESIZING is set or if in Fullscreen mode */
								if ( (D3DFE.dwUserPreferences & DISABLE_RESIZING) || (D3DFE.bFullScreen) )
								{
									GetWindowRect(hWnd, (LPRECT)lParam);
									return 0;							
								}
								else
								{
									D3DFEHandleWM_SIZING(&lresult, hWnd, message, wParam, lParam);
								}
								break;

								/* Prevent the window from moving in fullscreen */
	case	WM_MOVING	:		if (D3DFE.bFullScreen) 
								{
									GetWindowRect(hWnd, (LPRECT)lParam);
									return 0;								
								}
								break;

	case	WM_PAINT :			if (D3DFE.bPaused)
								{
									D3DFEHandleWM_PAINT(hWnd);
									/* DEBUG("WM_PAINT occured\n"); */
								}
								return (DefWindowProc(hWnd, message, wParam, lParam));
								break;

	case	WM_DESTROY :		/* Handle window destroying */
								PostQuitMessage(0);
								break;

	case	WM_QUIT :			/* Quit program */
								DEBUG("Quitting D3DFrontEnd\n");
								break;

	/* Handle FrontEnd menu messages */
	case	WM_COMMAND : 
		
		switch(GET_WM_COMMAND_ID(wParam,lParam))
		{
			/* Handle FILE menu message */
			case	ID_FILE_SCREENCAPTURE : DEBUG("Screen capture occuring\n"); 
											D3DFEScreenCapture();
											break;	
		
			case	ID_FILE_DISPLAYINFO	:	if (D3DFE.bShowInfoBuffer)
											{
												D3DFE.bShowInfoBuffer=FALSE;
											}
											else
											{
												D3DFE.bShowInfoBuffer=TRUE;
											}
											D3DFEUpdateMenus();
											break;
			
			case	ID_FILE_QUIT : 	D3DFE.bPaused=TRUE;
									if (D3DFE.bFullScreen)
									{
										D3DFEFinish();
									}
									else  
									{
										/* In window mode, ask the user for confirmation */
										D3DFEMouseVisible(TRUE);
										if (MessageBox(hWnd, "Are you sure you want to quit ?", D3DFE.pszFrontEndTitle, MB_YESNO | MB_ICONINFORMATION)==IDYES)
										{
											D3DFEFinish();
										}
									}
									D3DFE.bPaused=FALSE;
									if (D3DFE.bFullScreen) 
									{
										D3DFEMouseVisible(FALSE);
									}
									break;

			/* Handle DEVICES menu messages */
			case	ID_DEVICES_DDRAWDEV0	:	if (nCurrentDDDriver!=0) D3DFEChangeDirectDrawDriver(0); break;
			case	ID_DEVICES_DDRAWDEV1	:	if (nCurrentDDDriver!=1) D3DFEChangeDirectDrawDriver(1); break;
			case	ID_DEVICES_DDRAWDEV2	:	if (nCurrentDDDriver!=2) D3DFEChangeDirectDrawDriver(2); break;
			case	ID_DEVICES_DDRAWDEV3	:	if (nCurrentDDDriver!=3) D3DFEChangeDirectDrawDriver(3); break;
			case	ID_DEVICES_DDRAWDEV4	:	if (nCurrentDDDriver!=4) D3DFEChangeDirectDrawDriver(4); break;

			case	ID_DEVICES_D3DDEV0 :		if (nCurrentD3DDriver!=0) 
													D3DFEChangeD3DMode(nCurrentResolution, 0, FALSE);
												break;

			case	ID_DEVICES_D3DDEV1 :		if (nCurrentD3DDriver!=1) 
													D3DFEChangeD3DMode(nCurrentResolution, 1, FALSE);
												break;

			case	ID_DEVICES_D3DDEV2 :		if (nCurrentD3DDriver!=2) 
													D3DFEChangeD3DMode(nCurrentResolution, 2, FALSE);
												break;

			case	ID_DEVICES_D3DDEV3 :		if (nCurrentD3DDriver!=3) 
													D3DFEChangeD3DMode(nCurrentResolution, 3, FALSE);
												break;

			case	ID_DEVICES_D3DDEV4 :		if (nCurrentD3DDriver!=4) 
													D3DFEChangeD3DMode(nCurrentResolution, 4, FALSE);
												break;

			/* Handle BUFFERING menu messages */
			case	ID_BUFFERING_ZBUFFER :	if (D3DFE.bZBufferNeeded)
											{
												D3DFE.bZBufferNeeded=FALSE;
											}
											else
											{
												D3DFE.bZBufferNeeded=TRUE;
											}
											/* We need to recreate the primary and back surfaces when
											   Z-Buffer is changed */
											D3DFEChangeD3DMode(nCurrentResolution, nCurrentD3DDriver, FALSE);
											break;

			case	ID_BUFFERING_SINGLEBUFFER :	D3DFE.nBufferingMode=1;
												D3DFEChangeD3DMode(nCurrentResolution, nCurrentD3DDriver, FALSE);
												break;

			case	ID_BUFFERING_DOUBLEBUFFER :	D3DFE.nBufferingMode=2;
												D3DFEChangeD3DMode(nCurrentResolution, nCurrentD3DDriver, FALSE);
												break;

			case	ID_BUFFERING_TRIPLEBUFFER :	D3DFE.nBufferingMode=3;
												D3DFEChangeD3DMode(nCurrentResolution, nCurrentD3DDriver, FALSE);
												break;

			case	ID_BUFFERING_CLEAR :		if ( !(D3DFE.dwUserPreferences & (FORCE_CLEAR_ON | FORCE_CLEAR_OFF)) )
												{
													if (D3DFE.bClearViewport)
													{
														D3DFE.bClearViewport=FALSE;
													}
													else
													{
														D3DFE.bClearViewport=TRUE;
													}
													/* Don't need to recreate variables for this choice */
													D3DFEUpdateMenus();
												}
												break;

			/* Handle SCREEN menu messages */
			case	ID_MODES_FULLSCREEN	:	if ((!(D3DFE.dwUserPreferences & FORCE_FULLSCREEN)) && D3DFE.bRenderingReady)
											{
												/* If we are in a secondary ddraw mode, we already are in FullScreen */
												if (nCurrentDDDriver!=0)
												{
													D3DFE.bFullScreen=FALSE;
													D3DFEChangeDirectDrawDriver(0);
													D3DFE.bPaused=TRUE;
													MessageBox(hWnd, "DirectDraw PRIMARY device selected", D3DFE.pszFrontEndTitle, MB_OK | MB_ICONINFORMATION);
													D3DFE.bPaused=FALSE;
												}
												else
												{
													if (D3DFE.bFullScreen==TRUE) 
													{
														D3DFE.bFullScreen=FALSE;
													}
													else 
													{
														nCurrentResolution=nSafeDisplayModeNumber;
														D3DFE.bFullScreen=TRUE;
													}
													D3DFEChangeD3DMode(nCurrentResolution, nCurrentD3DDriver, FALSE);
												}
											}
											break;
			
			case	ID_MODES_RES0 :			D3DFEChangeD3DMode(0, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES1 :			D3DFEChangeD3DMode(1, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES2 :			D3DFEChangeD3DMode(2, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES3 :			D3DFEChangeD3DMode(3, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES4 :			D3DFEChangeD3DMode(4, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES5 :			D3DFEChangeD3DMode(5, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES6 :			D3DFEChangeD3DMode(6, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES7 :			D3DFEChangeD3DMode(7, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES8 :			D3DFEChangeD3DMode(8, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES9 :			D3DFEChangeD3DMode(9, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES10 :		D3DFEChangeD3DMode(10, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES11 :		D3DFEChangeD3DMode(11, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES12 :		D3DFEChangeD3DMode(12, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES13 :		D3DFEChangeD3DMode(13, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES14 :		D3DFEChangeD3DMode(14, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES15 :		D3DFEChangeD3DMode(15, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES16 :		D3DFEChangeD3DMode(16, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES17 :		D3DFEChangeD3DMode(17, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES18 :		D3DFEChangeD3DMode(18, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES19 :		D3DFEChangeD3DMode(19, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES20 :		D3DFEChangeD3DMode(20, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES21 :		D3DFEChangeD3DMode(21, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES22 :		D3DFEChangeD3DMode(22, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES23 :		D3DFEChangeD3DMode(23, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES24 :		D3DFEChangeD3DMode(24, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES25 :		D3DFEChangeD3DMode(25, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES26 :		D3DFEChangeD3DMode(26, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES27 :		D3DFEChangeD3DMode(27, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES28 :		D3DFEChangeD3DMode(28, nCurrentD3DDriver, TRUE); break;
			case	ID_MODES_RES29 :		D3DFEChangeD3DMode(29, nCurrentD3DDriver, TRUE); break;
						
			default : return DefWindowProc(hWnd, message, wParam, lParam);
		 }
		 break;

    default:	return DefWindowProc(hWnd, message, wParam, lParam);
    }

    /* Message handled OK */
	return 0;
}


/*******************************************************************************
 * Function Name  : D3DFEHandleWM_PAINT
 * Global Used    : D3DFE
 * Description    : Paint the window when paused
 *******************************************************************************/
void D3DFEHandleWM_PAINT(HWND hWindow)
{
    HPEN		hOldPen;
    HBRUSH		hOldBrush;
    COLORREF	crOldTextColor;
    INT			oldMode;
	HDC			hdc;
    INT			x;
    INT			y;
    SIZE		size;
    RECT		rect;
    INT			nStrLen;
	char		pszPaused[50];
	RECT		SrcRect, DstRect;
	POINT		pt;
	HRESULT		hres;

	/* If D3D init is already set up, blit back buffer on screen */
	if (D3DFE.bRenderingReady && D3DFE.lpDDSBack && D3DFE.lpDDSBack->lpVtbl->IsLost(D3DFE.lpDDSBack)==DD_OK)
	{
		/* Windowed mode : perform a blit from back buffer to front buffer */
		
		/* SrcRect is relative to offscreen buffer */
		GetClientRect(hWindow, &SrcRect);

		/* DstRect is relative to screen space so needs translation */
		pt.x=0;
		pt.y=0;
		ClientToScreen(hWindow, &pt);
		DstRect=SrcRect;
		DstRect.left+=pt.x;
		DstRect.right+=pt.x;
		DstRect.top+=pt.y;
		DstRect.bottom+=pt.y;

		/* Perform the blit from backbuffer to primary, using src_rect and dst_rect */
		hres=D3DFE.lpDDSPrimary->lpVtbl->Blt(D3DFE.lpDDSPrimary, &DstRect, D3DFE.lpDDSBack, &SrcRect, DDBLT_WAIT, 0);
		if (hres==DDERR_SURFACELOST)
		{
			hres=D3DFE.lpDDSPrimary->lpVtbl->Restore(D3DFE.lpDDSPrimary);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore primary surface\n");
				DisplayHRESULTInDebug(hres);
			}
		}
		else
		if (hres!=DD_OK)
		{
			DEBUG("A problem occured while blitting\n");
			DisplayHRESULTInDebug(hres);
		}
	}
	else
	{
		/* Display black screen + "Paused" message */
		strcpy(pszPaused, "Paused");
    
		hdc=GetDC(hWindow);

		/* Black background */
		hOldPen=(HPEN)SelectObject (hdc, GetStockObject (NULL_PEN));
		hOldBrush=(HBRUSH)SelectObject (hdc, GetStockObject (BLACK_BRUSH));

		/* White text */
		oldMode=SetBkMode (hdc, TRANSPARENT);
		crOldTextColor=SetTextColor (hdc, RGB(255, 255, 255));

		/* Get client area */
		GetClientRect(hWindow, &rect);

		/* Clear the client area */
	    Rectangle(hdc, rect.left, rect.top, rect.right + 1, rect.bottom + 1);

		/* Draw the string centered in the client area */
	    nStrLen=strlen(pszPaused);
		GetTextExtentPoint32(hdc, pszPaused, nStrLen, &size);
		x=(rect.right  - size.cx) / 2;
		y=(rect.bottom - size.cy) / 2;
		TextOut (hdc, x, y, pszPaused, nStrLen);

		/* Cleanup */
		SetTextColor(hdc, crOldTextColor);
		SetBkMode(hdc, oldMode);

		SelectObject(hdc, hOldBrush);
		SelectObject(hdc, hOldPen);

		ReleaseDC(hWindow, hdc);
	}
}


/*******************************************************************************
 * Function Name  : D3DFEHandleWM_SIZE
 * Global Used    : D3DFE
 * Description    : Handle the WM_SIZE message from the window loop.
 *					Deal with minimising and unminimising initialisations in both 
 *					window and FullScreen mode, and resizing in window mode.
 *******************************************************************************/
BOOL D3DFEHandleWM_SIZE(LRESULT *lresult, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	RECT	Rect;
	
	/* If we have minimized, take note and call the default window proc */
    if (wParam==SIZE_MINIMIZED) 
	{
        D3DFE.bMinimized=TRUE;
        *lresult=DefWindowProc(hWnd, message, wParam, lParam);
        return TRUE;
    }

    /* If we are minimized, this is the un-minimized size message */
    if (D3DFE.bMinimized)									 
	{
		/* DEBUG("Restoring screen...\n"); */
		D3DFE.bMinimized=FALSE;
        *lresult=DefWindowProc(hWnd, message, wParam, lParam);
		return TRUE;
    }
    
    /* At this point we should only be handling a simple window resizing
	   message */
	/* DEBUG("Window resizing occuring\n"); */

    /* We should never be FullScreen at this point but let's be sure */
	if (!D3DFE.bFullScreen) 
	{
		/* Retrieve client area dimensions */
		D3DFE.dwWindowWidth=LOWORD(lParam);
		D3DFE.dwWindowHeight=HIWORD(lParam);

		/* Retrieve frame window coordinates and dimensions */
		GetWindowRect(hWnd, &Rect);
		D3DFE.dwWindowFramePositionX=Rect.left;
		D3DFE.dwWindowFramePositionY=Rect.top;
		D3DFE.dwWindowFrameWidth=Rect.right-Rect.left;
		D3DFE.dwWindowFrameHeight=Rect.bottom-Rect.top;
		
		/* Test if the menu takes more than one line height */
		if ((D3DFE.dwWindowHeight+D3DFE.dwWindowSpaceY)<D3DFE.dwWindowFrameHeight)
		{
			DEBUG("Menu takes more than one line\n");
		}

		/* We are about to change all variables to set rendering state to FALSE */
		D3DFE.bRenderingReady=FALSE; 

		/* Release memory */
		D3DFEReleaseTextures();
		ReleaseView(D3DFE.lpD3DView2);
		RELEASE(D3DFE.lpD3DView2);
		RELEASE(D3DFE.lpD3DDev2);
		if (D3DFE.lpDDSZBuffer)
		{
			if (D3DFE.lpDDSBack)
			{
				/* If there is a back buffer, then Z Buffer must be attached to it */
				if (D3DFE.lpDDSBack->lpVtbl->DeleteAttachedSurface(D3DFE.lpDDSBack, 0, D3DFE.lpDDSZBuffer)!=DD_OK)
				{
					DEBUG("Failed to delete Z-Buffer surface from Back buffer in D3DFEHandleWM_SIZE()\n");
				}
			}
			else
			{
				/* No back buffer -> Z Buffer is attached to primary surface */
				if (D3DFE.lpDDSPrimary->lpVtbl->DeleteAttachedSurface(D3DFE.lpDDSPrimary, 0, D3DFE.lpDDSZBuffer)!=DD_OK)
				{
					DEBUG("Failed to delete Z-Buffer surface from Primary surface in D3DFEHandleWM_SIZE()\n");
				}
			}
		}
		RELEASE(D3DFE.lpDDSZBuffer);
		RELEASE(D3DFE.lpClipper);
		RELEASE(D3DFE.lpDDSBack);
		RELEASE(D3DFE.lpDDSPrimary);
    
		/* Recreate window with new coordinates and surfaces */
		if (!D3DFEInitWindow())
		{
			DEBUG("D3DInitWindow() failed in D3DHandleWM_SIZE\n");
			D3DFEFinish();
			return FALSE;
		}

		/* Initialise D3D device */
		if (!D3DFEInitD3DDevice())
		{
			DEBUG("D3DInitD3DDevice() failed in D3DFEHandleWM_SIZE()\n");
			D3DFEFinish();
			return FALSE;
		}

		/* Create viewport and D3D scene */
		if (!D3DFECreateViewAndScene())
		{
			DEBUG("D3DCreateViewAndScene() failed in D3DFEHandleWM_SIZE()\n");
			D3DFEFinish();
			return FALSE;
		}
	}

	/* No problem encountered */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFEHandleWM_SIZING
 * Global Used    : D3DFE
 * Description    : Handle the WM_SIZING message from the window loop.
 *					Prevent the user from selecting a window size too large
 *******************************************************************************/
void D3DFEHandleWM_SIZING(LRESULT *lresult, HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	DWORD	dwClientAreaResizedWidth;
	DWORD	dwClientAreaResizedHeight;	

	/* Keep trace of the current size of the window to prevent user from 
	   creating a window too large */
	
	/* Get width and height of current window size */
	dwClientAreaResizedWidth=((LPRECT)lParam)->right-((LPRECT)lParam)->left-D3DFE.dwWindowSpaceX+1;
	dwClientAreaResizedHeight=((LPRECT)lParam)->bottom-((LPRECT)lParam)->top-D3DFE.dwWindowSpaceY+1;

	/* Get Window position */
	D3DFE.dwWindowPositionX=((LPRECT)lParam)->left;
	D3DFE.dwWindowPositionY=((LPRECT)lParam)->top;
	
	/* First check minimums and maximums */
	if (dwClientAreaResizedWidth<D3DFE.dwMinWindowWidth)
	{
		dwClientAreaResizedWidth=D3DFE.dwMinWindowWidth;
	}
	if (dwClientAreaResizedWidth>D3DFE.dwMaxWindowWidth) 
	{
		dwClientAreaResizedWidth=D3DFE.dwMaxWindowWidth;
	}
	if (dwClientAreaResizedHeight<D3DFE.dwMinWindowHeight) 
	{
		dwClientAreaResizedHeight=D3DFE.dwMinWindowHeight;
	}
	if (dwClientAreaResizedHeight>D3DFE.dwMaxWindowHeight) 
	{
		dwClientAreaResizedHeight=D3DFE.dwMaxWindowHeight;
	}
																		
	/* If video memory is shared, that means that Surface and Z-Buffer
	   memory are in the same memory heap */
	if (D3DFE.bSharedVideoMemory)
	{
		/* Check if client area has enough primary surface memory (half the total amount of
		   memory because of the Z-Buffer */
		if (D3DFE.bZBufferNeeded)
		{
			if (dwClientAreaResizedWidth*dwClientAreaResizedHeight*D3DFE.dwGDIBPP/8>D3DFE.dwTotalMemoryForWindow/2)
			{
				/* Not enough memory for window with current window size because of Z-Buffer
				   So resize window */
				if (dwClientAreaResizedWidth>dwClientAreaResizedHeight)
				{
					/* Width is bigger, so resize it */ 
					dwClientAreaResizedWidth=((8*D3DFE.dwTotalMemoryForWindow/2)/(dwClientAreaResizedHeight*D3DFE.dwGDIBPP));
				}																					
				else
				{
					/* Height is bigger, so resize it */
					dwClientAreaResizedHeight=((8*D3DFE.dwTotalMemoryForWindow/2)/(dwClientAreaResizedWidth*D3DFE.dwGDIBPP));
				}
			}
		}
		else
		{
			/* No Z-Buffer needed, just check if there is enough memory for surface */
			if (dwClientAreaResizedWidth*dwClientAreaResizedHeight*D3DFE.dwGDIBPP/8>D3DFE.dwTotalMemoryForWindow)
			{
				/* Not enough memory for window with current window size so resize window */
				if (dwClientAreaResizedWidth>dwClientAreaResizedHeight)
				{
					/* Width is bigger, so resize it */
					dwClientAreaResizedWidth=(8*D3DFE.dwTotalMemoryForWindow/(dwClientAreaResizedHeight*D3DFE.dwGDIBPP));
				}																					
				else
				{
					/* Height is bigger, so resize it */
					dwClientAreaResizedHeight=(8*D3DFE.dwTotalMemoryForWindow/(dwClientAreaResizedWidth*D3DFE.dwGDIBPP));
				}
			}
		}
	}
	else
	{
		/* Surface memory and Z-Buffer memory are separate */
		if (D3DFE.bZBufferNeeded)
		{
			/* Check if client area has enough Z-Buffer surface memory for this size */
			if (dwClientAreaResizedWidth*dwClientAreaResizedHeight*D3DFE.dwGDIBPP/8>D3DFE.dwTotalMemoryForZBuffer)
			{
				/* Not enough memory for window with current window size because of Z-Buffer memory  */
				if (dwClientAreaResizedWidth>dwClientAreaResizedHeight)
				{
					/* Width is bigger, so resize it */
					dwClientAreaResizedWidth=(8*D3DFE.dwTotalMemoryForZBuffer/(dwClientAreaResizedHeight*D3DFE.dwGDIBPP));
				}																					
				else
				{
					/* Height is bigger, so resize it */
					dwClientAreaResizedHeight=(8*D3DFE.dwTotalMemoryForZBuffer/(dwClientAreaResizedWidth*D3DFE.dwGDIBPP));
				}
			}
		}
		/* Check if client area has enough surface memory for this size */
		if (dwClientAreaResizedWidth*dwClientAreaResizedHeight*D3DFE.dwGDIBPP/8>D3DFE.dwTotalMemoryForWindow)
		{
			/* Not enough memory for window with current window size */
			if (dwClientAreaResizedWidth>dwClientAreaResizedHeight)
			{
				/* Width is bigger, so resize it */
				dwClientAreaResizedWidth=(8*D3DFE.dwTotalMemoryForWindow/(dwClientAreaResizedHeight*D3DFE.dwGDIBPP));
			}																					
			else
			{
				/* Height is bigger, so resize it */
				dwClientAreaResizedHeight=(8*D3DFE.dwTotalMemoryForWindow/(dwClientAreaResizedWidth*D3DFE.dwGDIBPP));
			}
		}
	}

	/* Re-check minimums and maximums for security */
	if (dwClientAreaResizedWidth<D3DFE.dwMinWindowWidth) 
	{
		dwClientAreaResizedWidth=D3DFE.dwMinWindowWidth;
	}
	if (dwClientAreaResizedWidth>D3DFE.dwMaxWindowWidth) 
	{
		dwClientAreaResizedWidth=D3DFE.dwMaxWindowWidth;
	}
	if (dwClientAreaResizedHeight<D3DFE.dwMinWindowHeight) 
	{
		dwClientAreaResizedHeight=D3DFE.dwMinWindowHeight;
	}
	if (dwClientAreaResizedHeight>D3DFE.dwMaxWindowHeight) 
	{
		dwClientAreaResizedHeight=D3DFE.dwMaxWindowHeight;
	}
								
	/* Send processed Window rectangle information */
	((LPRECT)lParam)->left=D3DFE.dwWindowPositionX;
	((LPRECT)lParam)->top=D3DFE.dwWindowPositionY;
	((LPRECT)lParam)->right=D3DFE.dwWindowPositionX+dwClientAreaResizedWidth-1+D3DFE.dwWindowSpaceX;
	((LPRECT)lParam)->bottom=D3DFE.dwWindowPositionY+dwClientAreaResizedHeight-1+D3DFE.dwWindowSpaceY;
}


/*******************************************************************************
 * Function Name  : D3DFEBuildMenus
 * Returns		  : TRUE if no problem occurs.
 * Global Used    : D3DFE
 * Description    : Build all menus to be used in the D3D FrontEnd
 *******************************************************************************/
BOOL D3DFEBuildMenus()
{
	int		i;
	char	pszString[100];

	/*********************** Create main menu ************************/
	if (D3DFE.hMenu)
	{
		DestroyMenu(D3DFE.hMenu);
	}
	D3DFE.hMenu=CreateMenu();
	if (D3DFE.hMenu==NULL)
	{
		DEBUG("Failed to create main menu in BuildMenus()\n");
	}
	

	/*********************** Create File menu ************************/
	if (D3DFE.hFileMenu)
	{
		DeleteMenu(D3DFE.hMenu, (UINT)D3DFE.hFileMenu, MF_BYCOMMAND);
	}
	D3DFE.hFileMenu=CreatePopupMenu();
	if (D3DFE.hFileMenu==NULL)
	{
		DEBUG("Failed to create File menu in BuildMenus()\n");
	}

	/* Attach File menu to main menu */
	AppendMenu(D3DFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)D3DFE.hFileMenu, "&File");

	/* Add Screen capture menu item */
	AppendMenu(D3DFE.hFileMenu, MF_STRING | MF_ENABLED, ID_FILE_SCREENCAPTURE, "&Screen capture\tF12");

	/* Then append a separator */
	AppendMenu(D3DFE.hFileMenu, MF_SEPARATOR, 0, 0);

	/* Add Display Info choice */
	AppendMenu(D3DFE.hFileMenu, MF_ENABLED, ID_FILE_DISPLAYINFO, "Display &Info\tTAB");
	
	/* Then append a separator */
	AppendMenu(D3DFE.hFileMenu, MF_SEPARATOR, 0, 0);
	
	/* Add Quit menu item */
	AppendMenu(D3DFE.hFileMenu, MF_STRING | MF_ENABLED, ID_FILE_QUIT, "&Quit\t<Alt+F4>");


	/********************* Create Devices menu ***********************/
	if (D3DFE.hDevicesMenu)
	{
		DeleteMenu(D3DFE.hMenu, (UINT)D3DFE.hDevicesMenu, MF_BYCOMMAND);
	}
	D3DFE.hDevicesMenu=CreatePopupMenu();
	if (D3DFE.hDevicesMenu==NULL)
	{
		DEBUG("Failed to create Devices menu in D3DFEBuildMenus()\n");
	}

	/* Attach Devices menu to main menu */
	AppendMenu(D3DFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)D3DFE.hDevicesMenu, "&Devices");
	
	sprintf(pszTmp, "nDDNumDrivers = %d\n", nDDNumDrivers);
	DEBUG(pszTmp);
	
	/* Check if a secondary Direct Draw device is available if secondary 
	   device is forced On */
	if ( (D3DFE.dwUserPreferences & (FORCE_SECONDARYDEVICE | DEFAULT_SECONDARYDEVICE)) &&
		 (nDDNumDrivers<2) )
	{
		DEBUG("No secondary device exists so it can't be forced On!\n");
		MessageBox(D3DFE.hwnd, 
					"Secondary device has been selected in the User Preferences\nbut no secondary device is available. Exiting program",
					D3DFE.pszFrontEndTitle, MB_OK | MB_ICONEXCLAMATION );
		return FALSE;
	}
	
	/* If Primary device is forced On, then insert it only in the menu */
	if (D3DFE.dwUserPreferences & FORCE_PRIMARYDEVICE)
	{
		AppendMenu(D3DFE.hDevicesMenu, MF_ENABLED, ID_DEVICES_DDRAWDEV0, DDDriver[0].Description);
	}
	else
	{
		/* If secondary device has been forced On, then insert it only in the menu */
		if (D3DFE.dwUserPreferences & FORCE_SECONDARYDEVICE)
		{
			AppendMenu(D3DFE.hDevicesMenu, MF_ENABLED, ID_DEVICES_DDRAWDEV1, DDDriver[1].Description);
		}
		else
		{
			/* Insert all DDraw devices */
			for (i=0;i<nDDNumDrivers;i++)
			{
				AppendMenu(D3DFE.hDevicesMenu, MF_ENABLED, ID_DEVICES_DDRAWDEV0+i, DDDriver[i].Description);
			}
		}
	}

	/* Then append a separator */
	AppendMenu(D3DFE.hDevicesMenu, MF_SEPARATOR, 0, 0);

	/* Create menu items corresponding to D3D drivers */
	for (i=0;i<nD3DNumDrivers;i++)
	{
		if ( ((D3DFE.dwUserPreferences & DISABLE_RAMP_MODE) && (i==0)) ||
			 ((D3DFE.dwUserPreferences & DISABLE_MMX_MODE) && (i==3)) )
		{
			/* Don't add Ramp or MMX mode because user chose to disable it */
		}
		else
		{
			AppendMenu(D3DFE.hDevicesMenu, MF_ENABLED, ID_DEVICES_D3DDEV0+i, D3DDriver[i].Name);
		}
	}

	/********************* Create Buffering menu ***********************/
	if (D3DFE.hBufferingMenu)
	{
		DeleteMenu(D3DFE.hMenu, (UINT)D3DFE.hBufferingMenu, MF_BYCOMMAND);
	}
	D3DFE.hBufferingMenu=CreatePopupMenu();
	if (D3DFE.hBufferingMenu==NULL)
	{
		DEBUG("Failed to create Buffering menu in D3DFEBuildMenus()\n");
	}

	/* Attach Buffering menu to main menu */
	AppendMenu(D3DFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)D3DFE.hBufferingMenu, "&Buffering");
	
	/* Add ZBuffer choice */
	/* If user has chosen a ZBuffer mode by default, then do not display this choice */
	if (D3DFE.dwUserPreferences & FORCE_ZBUFFER_ON)
	{
		D3DFE.bZBufferNeeded=TRUE;
	}
	else
	if (D3DFE.dwUserPreferences & FORCE_ZBUFFER_OFF)
	{
		D3DFE.bZBufferNeeded=FALSE;
	}
	else
	{
		/* No ZBuffer mode has been chosen by default -> display menu item */
		AppendMenu(D3DFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_ZBUFFER, "&Z Buffer\tF5");
	
		/* Draw separator */	
		AppendMenu(D3DFE.hBufferingMenu, MF_SEPARATOR, 0, 0);
	}
	
	/* Add buffering modes */
	/* If user has chosen a Buffering mode, then do not display Buffering modes choices */
	if (D3DFE.dwUserPreferences & FORCE_SINGLEBUFFER) 
	{
		D3DFE.nBufferingMode=1;
	}
	else if (D3DFE.dwUserPreferences & FORCE_DOUBLEBUFFER) 
	{
		D3DFE.nBufferingMode=2;
	}
	else if (D3DFE.dwUserPreferences & FORCE_TRIPLEBUFFER) 
	{
		D3DFE.nBufferingMode=3;
	}
	else
	{
		/* Display Buffering Modes choices */
		/* Display Single Buffer menu item if not disabled */
		if (!(D3DFE.dwUserPreferences & DISABLE_SINGLEBUFFER))
		{
			AppendMenu(D3DFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_SINGLEBUFFER, "&Single Buffer");
		}
		/* Always display Double Buffer menu item (no option to disable it) */
		AppendMenu(D3DFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_DOUBLEBUFFER, "&Double Buffer");
		/* Display Triple Buffer menu item if not disabled */
		if (!(D3DFE.dwUserPreferences & DISABLE_TRIPLEBUFFER))
		{
			AppendMenu(D3DFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_TRIPLEBUFFER, "&Triple Buffer");
		}
	}

	/* Clear choice */
	if ( !(D3DFE.dwUserPreferences & (FORCE_CLEAR_ON | FORCE_CLEAR_OFF)) )
	{
		/* Draw separator */	
		AppendMenu(D3DFE.hBufferingMenu, MF_SEPARATOR, 0, 0);

		/* Add Clear menu choice */
		AppendMenu(D3DFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_CLEAR, "&Clear\tF6");
	}
	
	/* If buffering modes are already forced On or Off, no point using this menu */
	if ( (D3DFE.dwUserPreferences & (FORCE_SINGLEBUFFER | FORCE_DOUBLEBUFFER | FORCE_TRIPLEBUFFER)) &&
		 (D3DFE.dwUserPreferences & (FORCE_ZBUFFER_ON | FORCE_ZBUFFER_OFF)) &&
		 (D3DFE.dwUserPreferences & (FORCE_CLEAR_ON | FORCE_CLEAR_OFF)) )
	{
		DeleteMenu(D3DFE.hMenu, (UINT)D3DFE.hBufferingMenu, MF_BYCOMMAND);
		D3DFE.hBufferingMenu=NULL;
	}


	/*********************** Create Modes menu ************************/
	if (D3DFE.hModesMenu)
	{
		DeleteMenu(D3DFE.hMenu, (UINT)D3DFE.hModesMenu, MF_BYCOMMAND); 
	}
	D3DFE.hModesMenu=CreatePopupMenu();
	if (D3DFE.hModesMenu==NULL)
	{
		DEBUG("Failed to create Screen menu in D3DFEBuildMenus()\n");
	}

	/* Attach Modes menu to main menu */
	AppendMenu(D3DFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)D3DFE.hModesMenu, "&Modes");

	/* Create FullScreen choice if permitted */
	if (!(D3DFE.dwUserPreferences & FORCE_FULLSCREEN))
	{
		/* Create FullScreen choice */
		AppendMenu(D3DFE.hModesMenu, MF_ENABLED, ID_MODES_FULLSCREEN, "&Full Screen\t<Alt+Enter>");
	
		/* Draw separator */
		AppendMenu(D3DFE.hModesMenu, MF_SEPARATOR, 0, 0);
	}

	/* Create menu items corresponding to screen resolutions */
	for (i=0;i<nDDNumDisplayModes;i++)
	{
		sprintf(pszString, "%ux%ux%u", DDDisplayMode[i].dwWidth, DDDisplayMode[i].dwHeight, DDDisplayMode[i].dwBPP);
		AppendMenu(D3DFE.hModesMenu, MF_ENABLED, ID_MODES_RES0+i, pszString);
		if (DDDisplayMode[i].dwWidth==640 && DDDisplayMode[i].dwHeight==480 && DDDisplayMode[i].dwBPP==16)
		{
			nSafeDisplayModeNumber=i;
		}
	}

	/*********************** Create User menu ************************/
	/* If user menu has been submitted, then append it to the D3D Shell menu */
	if (D3DFE.hUserMenu)
	{
		for (i=0; i<GetMenuItemCount(D3DFE.hUserMenu); i++)
		{
			GetMenuString(D3DFE.hUserMenu, i, pszString, 100, MF_BYPOSITION);
			AppendMenu(D3DFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)GetSubMenu(D3DFE.hUserMenu, i), pszString);
		}
	}
	
	/* Attach menu to window */
	D3DFE.bIgnoreWM_SIZE=TRUE;
	SetMenu(D3DFE.hwnd, D3DFE.hMenu);
	DrawMenuBar(D3DFE.hwnd);
	D3DFE.bIgnoreWM_SIZE=FALSE;

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFECreateAccelerators
 * Global Used    : D3DFE
 * Description    : Create menus and accelerators
 *******************************************************************************/
void D3DFECreateAccelerators()
{
	int	nNumberOfAccel=6;
	int nNumberOfUserAccel=0;
	
	/* If a user accelerator table has been submitted */
	if (D3DFE.hAccel)
	{
		/* Retrieve number of accelerators from user table */
		nNumberOfUserAccel=CopyAcceleratorTable(D3DFE.hAccel, NULL, 0);

		/* Test if number of accelerators exceeds maximum */
		if (nNumberOfAccel+nNumberOfUserAccel>MAX_NUMBER_OF_ACCELERATORS)
		{
			DEBUG("Number of accelerators is too high : disabling user accelerators\n");
			nNumberOfUserAccel=0;
		}
		else
		{
			/* Copy user table into D3DFE.Accel */
			CopyAcceleratorTable(D3DFE.hAccel, &D3DFE.Accel[0], nNumberOfUserAccel);
		}
	}

	/* Compute total number of accelerators */
	nNumberOfAccel+=nNumberOfUserAccel;
	
	/* Assign ALT+RETURN for FullScreen */
	D3DFE.Accel[nNumberOfUserAccel].fVirt=FALT | FVIRTKEY;
	D3DFE.Accel[nNumberOfUserAccel].key=VK_RETURN;
	D3DFE.Accel[nNumberOfUserAccel].cmd=ID_MODES_FULLSCREEN;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign ESCAPE for quit */
	D3DFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	D3DFE.Accel[nNumberOfUserAccel].key=VK_ESCAPE;
	D3DFE.Accel[nNumberOfUserAccel].cmd=ID_FILE_QUIT;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign TAB for DispayInfo */
	D3DFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	D3DFE.Accel[nNumberOfUserAccel].key=VK_TAB;
	D3DFE.Accel[nNumberOfUserAccel].cmd=ID_FILE_DISPLAYINFO;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign F5 for Z-Buffer */
	D3DFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	D3DFE.Accel[nNumberOfUserAccel].key=VK_F5;
	D3DFE.Accel[nNumberOfUserAccel].cmd=ID_BUFFERING_ZBUFFER;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign F6 for Viewport Clear */
	D3DFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	D3DFE.Accel[nNumberOfUserAccel].key=VK_F6;
	D3DFE.Accel[nNumberOfUserAccel].cmd=ID_BUFFERING_CLEAR;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign F12 for Screen Capture */
	D3DFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	D3DFE.Accel[nNumberOfUserAccel].key=VK_F12;
	D3DFE.Accel[nNumberOfUserAccel].cmd=ID_FILE_SCREENCAPTURE;

	/* CreateAccelerator Table */
	D3DFE.hAccel=CreateAcceleratorTable(D3DFE.Accel, nNumberOfAccel);
}


/*******************************************************************************
 * Function Name  : D3DFEUpdateMenus
 * Global Used    : D3DFE, nDDNumDrivers, nD3DNumDrivers, nDDNumDisplayModes
 * Description    : Check availability of choices in menu by graying or enabling
 *					menu items. Update check boxes on menu items.
 *******************************************************************************/
void D3DFEUpdateMenus()
{
	int		i;
	DWORD	dwMemory=0;

	/* Asserts */
	ASSERT(nDDNumDrivers>0);
	ASSERT(nD3DNumDrivers>0);
	ASSERT(nDDNumDisplayModes>0);
	ASSERT(D3DFE.hDevicesMenu!=NULL);
	ASSERT(D3DFE.hModesMenu!=NULL);

	/* Update menu item corresponding to "Display Info" */
	if (D3DFE.bShowInfoBuffer)
	{
		CheckMenuItem(D3DFE.hFileMenu, ID_FILE_DISPLAYINFO, MF_CHECKED);
	}
	else
	{
		CheckMenuItem(D3DFE.hFileMenu, ID_FILE_DISPLAYINFO, MF_UNCHECKED);
	}
	
	/* DirectDraw drivers */
	for (i=0;i<nDDNumDrivers;i++)
	{
		CheckMenuItem(D3DFE.hDevicesMenu, ID_DEVICES_DDRAWDEV0+i, MF_UNCHECKED);
	}
	CheckMenuItem(D3DFE.hDevicesMenu, ID_DEVICES_DDRAWDEV0+nCurrentDDDriver, MF_CHECKED);

	/* Direct3D drivers */
	for (i=0;i<nD3DNumDrivers;i++)
	{
		CheckMenuItem(D3DFE.hDevicesMenu, ID_DEVICES_D3DDEV0+i, MF_UNCHECKED);
	}
	CheckMenuItem(D3DFE.hDevicesMenu, ID_DEVICES_D3DDEV0+nCurrentD3DDriver, MF_CHECKED);

	/* Z-Buffer */
	if (D3DFE.hBufferingMenu)
	{
		EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_ZBUFFER, MF_ENABLED);
		if (D3DFE.bZBufferNeeded)
		{
			CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_ZBUFFER, MF_CHECKED);
		}
		else
		{
			CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_ZBUFFER, MF_UNCHECKED);
		}
		/* Enable or Disable Z-Buffer option in FullScreen */
		if (D3DFE.bFullScreen)
		{
			if (D3DFE.bSharedVideoMemory)
			{
				if ((D3DFE.nBufferingMode+1)*DDDisplayMode[nCurrentResolution].dwWidth*
									DDDisplayMode[nCurrentResolution].dwHeight*
									DDDisplayMode[nCurrentResolution].dwBPP/8 > D3DFE.dwPhysicalVideoMemory)
				{
					/* Z-Buffer option should not be enabled */
					EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_ZBUFFER, MF_GRAYED);
				}
			}
			else
			{
				/* Z-Buffer and surface memory are separate */
				if ( (D3DFE.nBufferingMode*DDDisplayMode[nCurrentResolution].dwWidth*
					    			DDDisplayMode[nCurrentResolution].dwHeight*
					   	 			DDDisplayMode[nCurrentResolution].dwBPP/8 > D3DFE.dwPhysicalVideoMemory) &&
					(DDDisplayMode[nCurrentResolution].dwWidth*
					DDDisplayMode[nCurrentResolution].dwHeight*
					DDDisplayMode[nCurrentResolution].dwBPP/8 > D3DFE.dwTotalMemoryForZBuffer) )
				{
					/* Z-Buffer option should not be enabled */
					EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_ZBUFFER, MF_GRAYED);
				}
			}
		}
		else
		{
			/* Enable or Disable Z-Buffer option in Window mode */
			if (D3DFE.bSharedVideoMemory)
			{
				if (2*D3DFE.dwWindowWidth*D3DFE.dwWindowHeight*D3DFE.dwGDIBPP/8 > D3DFE.dwTotalMemoryForWindow)
				{
					/* Z-Buffer option should not be enabled */
					EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_ZBUFFER, MF_GRAYED);
				}
			}
			else
			{
				/* Z-Buffer and surface memory are separate */
				if ( (D3DFE.dwWindowWidth*D3DFE.dwWindowHeight*D3DFE.dwGDIBPP/8 > D3DFE.dwTotalMemoryForWindow) ||
					D3DFE.dwWindowWidth*D3DFE.dwWindowHeight*D3DFE.dwGDIBPP/8 > D3DFE.dwTotalMemoryForZBuffer)
				{
					/* Z-Buffer option should not be enabled */
					EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_ZBUFFER, MF_GRAYED);
				}
			}
		}

		/* Buffering modes */
		/* First uncheck them all */
		CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_UNCHECKED);
		CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_UNCHECKED);
		CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_UNCHECKED);
		/* Buffering modes are only available in FullScreen */
		if (D3DFE.bFullScreen)
		{
			EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_ENABLED);
			EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_ENABLED);
			EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_ENABLED);
			switch (D3DFE.nBufferingMode)
			{
			case	1	:	CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_CHECKED); break;
			case	2	:	CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_CHECKED); break;
			case	3	:	CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_CHECKED); break;
			default : DEBUG("Incorrect value for Buffering Mode\n"); break;
			}
	
			/* Gray buffering modes or not corresponding to the current resolution
			   eg if you are in 1024x768x24 in single buffering mode you should not be
			   able to select double or triple buffering if you don't have the video
			   memory for it */
			dwMemory=D3DFE.dwPhysicalVideoMemory;
			if (D3DFE.bZBufferNeeded && D3DFE.bSharedVideoMemory)
			{
				dwMemory-=DDDisplayMode[nCurrentResolution].dwWidth*
						DDDisplayMode[nCurrentResolution].dwHeight*
						DDDisplayMode[nCurrentResolution].dwBPP/8;
			}
			if (2*DDDisplayMode[nCurrentResolution].dwWidth*
				DDDisplayMode[nCurrentResolution].dwHeight*
				DDDisplayMode[nCurrentResolution].dwBPP/8	> dwMemory)
			{
				EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_GRAYED);
			}
			if (3*DDDisplayMode[nCurrentResolution].dwWidth*
				DDDisplayMode[nCurrentResolution].dwHeight*
				DDDisplayMode[nCurrentResolution].dwBPP/8	> dwMemory)
			{
				EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_GRAYED);
			}
		}
		else
		{
			/* In Window mode gray all buffering modes menu items */
			EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_GRAYED);
			EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_GRAYED);
			EnableMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_GRAYED);
		}

		/* Clear viewport mode */
		if (D3DFE.bClearViewport)
		{
			CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_CLEAR, MF_CHECKED);
		}
		else
		{
			CheckMenuItem(D3DFE.hBufferingMenu, ID_BUFFERING_CLEAR, MF_UNCHECKED);
		}
	}
	
	/* Uncheck all resolutions in Screen menu */
	for (i=0;i<nDDNumDisplayModes;i++)
	{
		CheckMenuItem(D3DFE.hModesMenu, ID_MODES_RES0+i, MF_UNCHECKED);
	}

	/* FullScreen or not */
	if (D3DFE.bFullScreen)
	{
		CheckMenuItem(D3DFE.hModesMenu, ID_MODES_FULLSCREEN, MF_CHECKED);
		/* Check current resolution */
		CheckMenuItem(D3DFE.hModesMenu, ID_MODES_RES0+nCurrentResolution, MF_CHECKED);
	}
	else
	{
		/* Not in FullScreen mode -> Uncheck item */
		CheckMenuItem(D3DFE.hModesMenu, ID_MODES_FULLSCREEN, MF_UNCHECKED);
	}
}
	

/*******************************************************************************
 * Function Name  : D3DFEMouseVisible
 * Global Used    : None
 * Description    : Simple function which makes the mouse cursor visible or not
 *******************************************************************************/
void D3DFEMouseVisible(BOOL bVisible)
{
	static BOOL	bMouseVisible=TRUE;

	if (bVisible)
	{
		/* We want the mouse visible */
		/* We call ShowCursor(TRUE) only if mouse was invisible before */
		if (!bMouseVisible)
		{
			ShowCursor(TRUE);
			bMouseVisible=TRUE;
		}
	}
	else
	{	
		/* We want the mouse invisible */
		/* We call ShowCursor(FALSE) only if mouse was visible before */
		if (bMouseVisible)
		{
			ShowCursor(FALSE);
			bMouseVisible=FALSE;
		}
	}
}


/*******************************************************************************
 * Function Name  : D3DFEDisplayText
 * Global Used    : D3DFE
 * Description    : Function used to display text on screen
 *					NOTE : this is actually a bad function, as it performs
 *					GDI operations onto D3D and DD operations and that's
 *					especially bad for 3D hardware that have the NO2DDURING3D
 *					flag enabled. A better way of writing text onto screen
 *					would be to display text as a textured transparent polygons.
 *******************************************************************************/
void D3DFEDisplayText()
{
	HRESULT			hres;
	HDC				hdc;
	int				i;
	DWORD			dwW, dwH, dwBPP;

	/* Increase the number of frames */
	D3DFE.dwFramesElapsed++;	
	
	/* Get render surface dimensions */
	if (D3DFE.bFullScreen)
	{
		dwW=DDDisplayMode[nCurrentResolution].dwWidth;
		dwH=DDDisplayMode[nCurrentResolution].dwHeight;
		dwBPP=DDDisplayMode[nCurrentResolution].dwBPP;
	}
	else
	{
		dwW=D3DFE.dwWindowWidth;
		dwH=D3DFE.dwWindowHeight;
		dwBPP=D3DFE.dwGDIBPP;
	}

	/* Create display string */
	sprintf(D3DFE.pszDisplayText, "%ux%ux%u  %s  %s   %d fps", dwW, dwH, dwBPP, D3DFE.bZBufferNeeded ? "Z" : " ",
			(!D3DFE.bFullScreen) ? "" : D3DFE.nBufferingMode==1 ? "SB" : D3DFE.nBufferingMode==2 ? "DB" : "TB", 
			D3DFE.dwFrameRate);

	/* If a back buffer exists, display text on it
	   Otherwise use front buffer */
	if (D3DFE.lpDDSBack)
	{
		/* Retrieve a device context for the back buffer */
		hres=D3DFE.lpDDSBack->lpVtbl->GetDC(D3DFE.lpDDSBack, &hdc);
		if (hres!=DD_OK)
		{
			DEBUG("Unable to get DC for back buffer in D3DFEDisplayText()\n");
			DisplayHRESULTInDebug(hres);
			D3DFE.nNumberOfUserString=0;
			/* Not a critical error so just quit the function */
			return;
		}
	}
	else
	{
		/* Retrieve a device context for the front buffer */
		hres=D3DFE.lpDDSPrimary->lpVtbl->GetDC(D3DFE.lpDDSPrimary, &hdc);
		if (hres!=DD_OK)
		{
			DEBUG("Unable to get DC for back buffer in D3DFEDisplayText()\n");
			DisplayHRESULTInDebug(hres);
			D3DFE.nNumberOfUserString=0;
			/* Not a critical error so just quit the function */
			return;
		}
	}

	/* Select text preferences */
	SetBkMode(hdc, TRANSPARENT);
	SelectObject(hdc, D3DFE.hTextFont);
	SetTextColor(hdc, RGB(255, 255, 0));

	/* Display info text */
	if (D3DFE.bShowInfoBuffer)
	{
		TextOut(hdc, 10, D3DFE.bFullScreen ? DDDisplayMode[nCurrentResolution].dwHeight-22 : D3DFE.dwWindowHeight-22, 
				D3DFE.pszDisplayText, strlen(D3DFE.pszDisplayText));
	}
	
	/* Display user text */
	if (D3DFE.nNumberOfUserString>0)
	{
		for (i=0;i<D3DFE.nNumberOfUserString;i++)
		{
			TextOut(hdc, D3DFE.nUserTextPositionX[i], D3DFE.nUserTextPositionY[i], 
				D3DFE.pszUserText[i], strlen(D3DFE.pszUserText[i]));
		}
	}

	/* Release DC */
	if (D3DFE.lpDDSBack)
	{
		D3DFE.lpDDSBack->lpVtbl->ReleaseDC(D3DFE.lpDDSBack, hdc);
	}
	else
	{
		D3DFE.lpDDSPrimary->lpVtbl->ReleaseDC(D3DFE.lpDDSPrimary, hdc);
	}

	/* Put number of user strings back to 0 */
	D3DFE.nNumberOfUserString=0;
}


/*******************************************************************************
 * Function Name  : D3DShellSetPreferences
 * Global Used    : D3DFE
 * Description    : Function called by the user to submit a menu and set
 *					preferences.
 *******************************************************************************/
void D3DShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel, HICON hUserIcon, enum D3DShellPrefs dwFlags)
{
	/* If the user has submitted a name for his/her application */
	if (pszApplicationName)
	{
		strcpy(D3DFE.pszFrontEndTitle, pszApplicationName);
	}
	
	/* If the user has submitted a menu */
	if (hUserMenuID)
	{
		D3DFE.hUserMenu=hUserMenuID;
	}

	/* If the user has submitted an accelator table */
	if (hUserAccel)
	{
		D3DFE.hAccel=hUserAccel;
	}

	/* If the user has submitted an icon */
	if (hUserIcon)
	{
		D3DFE.hIcon=hUserIcon;
	}

	/* Retrieve user's preferences */
	D3DFE.dwUserPreferences=dwFlags;

	/* If secondary device is chosen as a default, then default to FullScreen */
	if (D3DFE.dwUserPreferences & DEFAULT_SECONDARYDEVICE)
	{
		D3DFE.dwUserPreferences|=DEFAULT_FULLSCREEN;
	}		
	
	/* If Z-Buffer as been chosen as a default, enable it */
	if (D3DFE.dwUserPreferences & DEFAULT_ZBUFFER_ON)
	{
		D3DFE.bZBufferNeeded=TRUE;
	}

	/* If Clear viewport On as been chosen as a default, enable it */
	if (D3DFE.dwUserPreferences & DEFAULT_CLEAR_ON)
	{
		D3DFE.bClearViewport=TRUE;
	}

	/* If FullScreen as been chosen as a default, enable it */
	if (D3DFE.dwUserPreferences & DEFAULT_FULLSCREEN)
	{
		D3DFE.bFullScreen=TRUE;
	}
	
	/* Set the fullscreen flag if required */
	if (D3DFE.dwUserPreferences & FORCE_FULLSCREEN)
	{
		D3DFE.bFullScreen=TRUE;
	}

	/* If clear viewport is forced On or Off, then set
	   the state of the corresponding BOOL variable */
	if (D3DFE.dwUserPreferences & FORCE_CLEAR_ON)
	{
		D3DFE.bClearViewport=TRUE;
	}
	if (D3DFE.dwUserPreferences & FORCE_CLEAR_OFF)
	{
		D3DFE.bClearViewport=FALSE;
	}

	/* If both primary and secondary devices are forced On (invalid), then 
	   remove them from the flags */
	if ( (D3DFE.dwUserPreferences & FORCE_PRIMARYDEVICE) &&
		 (D3DFE.dwUserPreferences & FORCE_SECONDARYDEVICE) )
	{
		D3DFE.dwUserPreferences^=(FORCE_PRIMARYDEVICE | FORCE_SECONDARYDEVICE);
	}
	
	/* If secondary ddraw device is to be used exclusively, then 
	   use FORCE_FULLSCREEN flag as well */
	if (D3DFE.dwUserPreferences & FORCE_SECONDARYDEVICE)
	{
		D3DFE.dwUserPreferences|=FORCE_FULLSCREEN;
		D3DFE.bFullScreen=TRUE;
	}
}


/*******************************************************************************
 * Function Name  : D3DShellSetDisplayText
 * Inputs		  : pszText, nX, nY
 * Global Used    : D3DFE
 * Description    : Function called by the user to display a text onto the screen.
 *					Works in both FullScreen mode and Window mode.
 *******************************************************************************/
void D3DShellSetDisplayText(char *pszText, int nX, int nY)
{
	/* Record user text and text position */
	strcpy(D3DFE.pszUserText[D3DFE.nNumberOfUserString], pszText);
	D3DFE.nUserTextPositionX[D3DFE.nNumberOfUserString]=nX;
	D3DFE.nUserTextPositionY[D3DFE.nNumberOfUserString]=nY;

	/* Increment number of user text string */
	D3DFE.nNumberOfUserString++;
}


/*******************************************************************************
 * Function Name  : D3DShellLoadBMP
 * Returns		  : Handle of loaded texture.
 * Inputs		  : lpName, bTranslucent
 * Global Used    : D3DFE
 * Description    : Simple texture loading function which load BMP textures.
 *					The BMP file can either be loaded from the resource or as
 *					a file. 
 *					RGB and OS/2 formats are supported. RLE encoded format 
 *					is NOT supported by this function.
 *					Does NOT support 4-bit or 8-bit palettised yet.
 *					A future version of D3DShell might have better texture
 *					loading facilities.
 *******************************************************************************/
D3DTEXTUREHANDLE D3DShellLoadBMP(char *lpName, BOOL bTranslucent)
{
	HRESULT					hres;
	LPDIRECTDRAWSURFACE		lpSrcTextureSurf=NULL;
	LPDIRECTDRAWSURFACE		lpDDS=NULL;
	LPDIRECT3DTEXTURE2		lpSrcTexture=NULL;
	DDSURFACEDESC			ddsd;
	DDPIXELFORMAT			PixelFormat;
	HBITMAP					Bitmap, BitmapTrans;
	BITMAP					bm, bmTrans;
	DWORD					x, y;
	DWORD					r=0, g=0, b=0, a=0, m=0;
	DWORD					dwMemoryUsedByTexture=0;
	unsigned				R, G, B, A;
	unsigned				Cont = 0;
	unsigned char			*lp8b;
	unsigned short			*lp16b;
	unsigned int			*lp32b;
	int						i, j, Mode, nFormat;
	char					*pLineBuffer, *pLineBufferTrans;
	char					LeftR,LeftG,LeftB,LeftA; 
	char					RightR,RightG,RightB,RightA;
	char					pszString[300];
			
	/* First check if device can support texturing */
	if ( (!(D3DDriver[nCurrentD3DDriver].Desc.dwDevCaps & D3DDEVCAPS_TEXTUREVIDEOMEMORY)) &&
		 (!(D3DDriver[nCurrentD3DDriver].Desc.dwDevCaps & D3DDEVCAPS_TEXTURESYSTEMMEMORY)) )
	{
		DEBUG("D3D device does not support texturing\n");
		return 0;
	}
	
	/* If D3DFE.nBestOpaque is equal to -1, then texture formats 
	   have not been enumerated yet */
	if (D3DFE.nBestOpaqueFormat==-1) 
	{
		if (!D3DFEListTextureFormats(D3DFE.lpD3DDev2))
		{
			DEBUG("No texture format supported\n");
			return 0;
		}
	}

	/* Test if we have at least an opaque texture format */
	if (D3DFE.nBestOpaqueFormat==-1)
	{
		DEBUG("No Opaque format supported\n");
		return 0;
	}
	
	/* If D3DFE.nBestTransFormat is equal to -1, it means that no
	   translucent format was found */
	if (D3DFE.nBestTransFormat==-1) 
	{
		DEBUG("No Translucent texture format was found\nTexture forced to opaque\n");
		bTranslucent=FALSE;
	}
	
	/* Pick the "best" opaque format */
	nFormat=D3DFE.nBestOpaqueFormat;
	
	/* Load texture : first try to load from resource */
	Bitmap=(HBITMAP)LoadImage(GetModuleHandle(NULL), lpName, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
    if (Bitmap==NULL)
	{
		/* Load from file */
		Bitmap=(HBITMAP)LoadImage(NULL, lpName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
		if (Bitmap==NULL)
		{
			sprintf(pszString, "\nFile %s not found\n",lpName);
			DEBUG(pszString);
			return 0;
		}
		DEBUG("\nLoading from file\n");
	}
	else
	{
		DEBUG("\nLoading from resource\n");
	}

	/* If translucent, then also read the file t+lpName */
	if (bTranslucent)
	{
		/* Translucent file name = t+lpName */
		sprintf (pszString, "t%s", lpName);
	
		/* Load translucent texture : first try to load from resource */
		BitmapTrans=(HBITMAP)LoadImage(GetModuleHandle(NULL), pszString, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
		if (BitmapTrans==NULL)
		{
			/* Load from file */
			BitmapTrans=(HBITMAP)LoadImage(NULL, pszString, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
			if (BitmapTrans==NULL)
			{
				DEBUG("\nFile ");
				DEBUG(pszString);
				DEBUG(" not found.\n");
				DeleteObject(Bitmap);
				return 0;
			}
		}
		nFormat=D3DFE.nBestTransFormat;
	}
	
	/* Get bitmap description */
    GetObject(Bitmap, sizeof(bm), &bm);

	if (bTranslucent)
	{
		/* Get bitmap description */
		GetObject(BitmapTrans, sizeof(bmTrans), &bmTrans);
	}

	/* Get width and height of bitmap */
	x=bm.bmWidth;
	y=bm.bmWidth;

	/* Debug output */
	sprintf(pszString, "Loading texture : %s%s (%u*%u)\n", bTranslucent ? "(t)" : "", lpName, x, y);
	DEBUG(pszString);
	
	/* Calculate memory used by texture */
	dwMemoryUsedByTexture=x*y*((TextureFormat[nFormat].RedBPP+
							    TextureFormat[nFormat].GreenBPP+
							    TextureFormat[nFormat].BlueBPP+
							    TextureFormat[nFormat].AlphaBPP+1)/8);
	
	/* Debug output */
	sprintf(pszString, "Memory used by texture = %u\n", dwMemoryUsedByTexture);
	DEBUG(pszString);

	/* See if there is enough video texture memory to load this texture
	   For device that store texture into System memory, this function
	   will never fail as the video texture memory size won't be changed */
	if (D3DFEFreeVideoMemoryInfo(DDSCAPS_TEXTURE)<dwMemoryUsedByTexture)
	{
		DEBUG("Not enough memory to allocate texture\n");
		DeleteObject(Bitmap);
		if (bTranslucent) 
		{
			DeleteObject(BitmapTrans);
		}
		return 0;
	}

	/* If translucent texture has also been loaded, check that both 
	   widths and heights are equal */
	if (bTranslucent)
	{
		if (bm.bmWidth!=bmTrans.bmWidth || bm.bmHeight!=bmTrans.bmHeight)
		{
			/* Dimensions are not the same : abort */
			DEBUG("Dimensions of texture and translucent texture do not match.\n");
			DeleteObject(Bitmap);
			DeleteObject(BitmapTrans);
			return 0;
		}
	}

	/* Security : discard any size above 256 pixels */
	if (x>256 || y>256)
	{
		DEBUG("Texture size too large\n");
		DeleteObject(Bitmap);
		if (bTranslucent) 
		{
			DeleteObject(BitmapTrans);
		}
		return 0;
	}

	/* Allocate memory so that we can read data */
	pLineBuffer=(char *)malloc(bm.bmWidthBytes*sizeof(char));
	pLineBufferTrans=(char *)malloc(bm.bmWidthBytes*sizeof(char));

	/* Initialise PixelFormat structure */
	memset(&PixelFormat, 0, sizeof(DDPIXELFORMAT));
	PixelFormat.dwSize=sizeof(DDPIXELFORMAT);

	/* Copy the texture format used into PixelFormat */
	memcpy(&PixelFormat, &TextureFormat[nFormat].ddsd.ddpfPixelFormat, sizeof(DDPIXELFORMAT));

	/* Display texture format used in Debug */
	m=PixelFormat.dwRBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) r++;
	}
    m=PixelFormat.dwGBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) g++;
	}
	m=PixelFormat.dwBBitMask; 
	for (i=0; i<32; i++)
	{
		if ((1<<i) & m ) b++;
	}
	if (bTranslucent)
	{
		m=PixelFormat.dwRGBAlphaBitMask; 
		for (i=0; i<32; i++) 
		{
			if ((1<<i) & m ) a++;
		}
	}
    sprintf(pszString, "format used for this texture : %u%u%u%u\n", r, g, b, a);
	DEBUG(pszString);
  
	/* Find right shifting values */
	RightR=8 - TextureFormat[nFormat].RedBPP;
	RightG=8 - TextureFormat[nFormat].GreenBPP;
	RightB=8 - TextureFormat[nFormat].BlueBPP;

    /* Find left shifting values */
	for (i=0; (PixelFormat.dwRBitMask & (1<<i))==0 ; i++); LeftR = i; 
    for (i=0; (PixelFormat.dwGBitMask & (1<<i))==0 ; i++); LeftG = i;
    for (i=0; (PixelFormat.dwBBitMask & (1<<i))==0 ; i++); LeftB = i;

	/* If texture is translucent, also find the right and 
	   left shifting value corresponding to alpha */
	if (bTranslucent) 
	{
        RightA=8 - TextureFormat[nFormat].AlphaBPP;
		for (i=0; (PixelFormat.dwRGBAlphaBitMask & (1<<i))==0 ; i++);
		LeftA=i;
	}

	/* Create texture surface */
    memset(&ddsd, 0, sizeof(DDSURFACEDESC));
    ddsd.dwSize=sizeof(DDSURFACEDESC);
    ddsd.dwFlags=DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
    ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE | DDSCAPS_SYSTEMMEMORY;
    ddsd.dwHeight=x;
    ddsd.dwWidth=y;
	ddsd.ddpfPixelFormat=PixelFormat;

	hres=D3DFE.lpDD2->lpVtbl->CreateSurface(D3DFE.lpDD2, &ddsd, &lpDDS, NULL);
	if (hres!=DD_OK) 
	{
		DEBUG("Failed to create surface\n");
		DisplayHRESULTInDebug(hres);
		DeleteObject(Bitmap);
		if (bTranslucent) 
		{
			DeleteObject(BitmapTrans);
		}
		return 0;
	}
	
    /* Initialise surface */
	memset(&ddsd, 0, sizeof(DDSURFACEDESC));
    ddsd.dwSize=sizeof(DDSURFACEDESC);
	
	/* Lock texture surface to fill it */
    hres=lpDDS->lpVtbl->Lock(lpDDS, NULL, &ddsd, 0, NULL); 
    if (hres!=DD_OK) 
	{
		DEBUG("Failed to lock texture surface\n");
		DisplayHRESULTInDebug(hres);
		DeleteObject(Bitmap);
		if (bTranslucent) 
		{
			DeleteObject(BitmapTrans);
		}
		return 0;
	}

	/* Compute mode used */
	Mode=PixelFormat.dwRGBBitCount + (int)bTranslucent;
	
	for (i=y; i!=0; i--)
	{
		/* Calculate pointers corresponding to texture format (8, 16 or 32 bits) */
		lp8b  = (unsigned char *) (((char *)ddsd.lpSurface) + x*i-1);
		lp16b = (unsigned short *)(((char *)ddsd.lpSurface) + x*i*2-2);
		lp32b = (unsigned int *)  (((char *)ddsd.lpSurface) + x*i*4-4);

		/* Copy the current line from the bitmap to pLineBuffer */
		/* Texture was upside down so I changed the following line */
		/* memcpy(pLineBuffer, ((char *)bm.bmBits+(y-i)*bm.bmWidthBytes), bm.bmWidthBytes); */
		memcpy(pLineBuffer, ((char *)bm.bmBits+(i-1)*bm.bmWidthBytes), bm.bmWidthBytes);
		if (bTranslucent)
		{
			/* Copy the current line from the transparent bitmap to pLineBuffer */
			/* Texture was upside down so I changed the following line */
			/* memcpy(pLineBufferTrans, ((char *)bmTrans.bmBits+(y-i)*bmTrans.bmWidthBytes), bmTrans.bmWidthBytes); */
			memcpy(pLineBufferTrans, ((char *)bmTrans.bmBits+(i-1)*bmTrans.bmWidthBytes), bmTrans.bmWidthBytes);
		}

        /* Has been changed to x*3-1 because last value is NOT x*3, it's x*3-1 */
		Cont=x*3-1;
		
		for (j=0; (DWORD)j<x; j++)
		{ 
			R = *(pLineBuffer+Cont--) & 255;
			G = *(pLineBuffer+Cont--) & 255;
			B = *(pLineBuffer+Cont--) & 255;
														
			switch (Mode)
			{
			case 8: 
				/* 8 Bits Opaque */
				*(lp8b--) = (R>>RightR)<<LeftR | (G>>RightG)<<LeftG | (B>>RightB)<<LeftB ;
				break;

			case 9: 
				/* 8 Bits Translucent */
				A = 255-(*(pLineBufferTrans+Cont+3) & 255);
				*(lp8b--) = (R>>RightR)<<LeftR | (G>>RightG)<<LeftG | (B>>RightB)<<LeftB | (A>>RightA)<<LeftA;
				break;

			case 16:
				/* 16 Bits Opaque */
				*(lp16b--) = (R>>RightR)<<LeftR | (G>>RightG)<<LeftG | (B>>RightB)<<LeftB ;
				break;

			case 17:
				/* 16 Bits Translucent */
				A = 255-(*(pLineBufferTrans+Cont+3) & 255);
				*(lp16b--) = (R>>RightR)<<LeftR | (G>>RightG)<<LeftG | (B>>RightB)<<LeftB | (A>>RightA)<<LeftA;
				break;

			case 32:
				/* 32 Bits Opaque */
				*(lp32b--) = (R>>RightR)<<LeftR | (G>>RightG)<<LeftG | (B>>RightB)<<LeftB ;
				break;

			case 33:
				/* 32 Bits Translucent */
				A = 255-(*(pLineBufferTrans+Cont+3) & 255);
				*(lp32b--) = (R>>RightR)<<LeftR | (G>>RightG)<<LeftG | (B>>RightB)<<LeftB | (A>>RightA)<<LeftA;
				break;

			default:
				/* Unknow pixel format : free memory and abort */
				lpDDS->lpVtbl->Unlock(lpDDS, NULL);
				free(pLineBuffer);
				free(pLineBufferTrans);
				DeleteObject(Bitmap);
				if (bTranslucent) 
				{
					DeleteObject(BitmapTrans);
				}
                lpDDS->lpVtbl->Release(lpDDS);
                DEBUG("Unknown pixel format\n");
                return 0;
			}
		}
	}

    /* Unlock texture surface because we're done filling it */
	hres=lpDDS->lpVtbl->Unlock(lpDDS, NULL);
	if (hres!=DD_OK)
	{
		DEBUG("Unlock failed in LoadTexture\n");
		DisplayHRESULTInDebug(hres);
	}
    
	lpSrcTextureSurf=lpDDS;

	/* QueryInterface for a Direct3DTexture2 interface */
	hres=lpSrcTextureSurf->lpVtbl->QueryInterface(lpSrcTextureSurf, &IID_IDirect3DTexture2,(LPVOID*)&lpSrcTexture);
	if (hres!=DD_OK) 
	{
		DEBUG("QueryInterface failed\n");
		DisplayHRESULTInDebug(hres);
		DeleteObject(Bitmap);
		if (bTranslucent) 
		{
			DeleteObject(BitmapTrans);
		}
		return 0;
	}

	/* Get surface description */
	hres=lpSrcTextureSurf->lpVtbl->GetSurfaceDesc(lpSrcTextureSurf, &ddsd);
	if (hres!=DD_OK) 
	{
		DEBUG("GetSurfaceDesc failed\n");
		DisplayHRESULTInDebug(hres);
		DeleteObject(Bitmap);
		if (bTranslucent) 
		{
			DeleteObject(BitmapTrans); 
		}
		return 0;
	}
    
    /* Create texture surface */
	memset(&ddsd, 0, sizeof(DDSURFACEDESC));
    ddsd.dwSize=sizeof(DDSURFACEDESC);
    ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE | DDSCAPS_ALLOCONLOAD;
	/* If current D3D device does not support texture in video 
	   memory, use system memory */
	if (!(D3DDriver[nCurrentD3DDriver].Desc.dwDevCaps & D3DDEVCAPS_TEXTUREVIDEOMEMORY))
	{
		ddsd.ddsCaps.dwCaps|=DDSCAPS_SYSTEMMEMORY;
	}
    ddsd.dwHeight=x;
    ddsd.dwWidth=y;
	ddsd.ddpfPixelFormat=PixelFormat;
	ddsd.dwFlags=DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
    hres=D3DFE.lpDD2->lpVtbl->CreateSurface(D3DFE.lpDD2, &ddsd, &TextureArray.lpTextureSurf[D3DFE.nTextures], NULL);
	if (hres!=DD_OK) 
	{
		DEBUG("CreateSurface failed\n");
		DisplayHRESULTInDebug(hres);
		return 0;
	}

	/* QueryInterface for a Direct3DTexture2 interface */
	hres=TextureArray.lpTextureSurf[D3DFE.nTextures]->lpVtbl->QueryInterface(TextureArray.lpTextureSurf[D3DFE.nTextures], 
												&IID_IDirect3DTexture2,(LPVOID*)&TextureArray.lpTexture[D3DFE.nTextures]);
    if (hres!=DD_OK) 
	{
		DEBUG("QueryInterface failed\n");
		DisplayHRESULTInDebug(hres);
		return 0;
	}
	
	/* Load texture into memory */
	hres=TextureArray.lpTexture[D3DFE.nTextures]->lpVtbl->Load(TextureArray.lpTexture[D3DFE.nTextures], lpSrcTexture);
	if (hres!=DD_OK)
	{
		DEBUG("Load failed\n");
		DisplayHRESULTInDebug(hres);
		return 0;
	}
      
	/* Get handle of texture */
	hres=TextureArray.lpTexture[D3DFE.nTextures]->lpVtbl->GetHandle(TextureArray.lpTexture[D3DFE.nTextures], 
												D3DFE.lpD3DDev2, &TextureArray.TextureHandle[D3DFE.nTextures]);

	/* Release surfaces and memory */
	RELEASE(lpSrcTexture);
    RELEASE(lpSrcTextureSurf);
	
	free(pLineBuffer);
	free(pLineBufferTrans);

	DeleteObject(Bitmap);
	if (bTranslucent) 
	{
		DeleteObject(BitmapTrans);
	}	

	/* Debug output */
	sprintf(pszString, "Free Texture memory = %u\n", D3DFEFreeVideoMemoryInfo(DDSCAPS_TEXTURE));
	DEBUG(pszString);
	
	/* Return texture handle */
    return (TextureArray.TextureHandle[D3DFE.nTextures++]);
}


/*******************************************************************************
 * Function Name  : D3DFEScreenCapture
 * Global Used    : D3DFE
 * Description    : Take a screenshot of the current scene.
 *******************************************************************************/
BOOL D3DFEScreenCapture()
{
	HRESULT				hres;
	DDSURFACEDESC		ddsd;
	LPDIRECTDRAWSURFACE	lpDDS;
	WORD				*pWord;
	unsigned char		*pByte;
	DWORD				Pitch;
	char				pszString[100];
	BITMAPFILEHEADER	BitmapFileHeader;
	BITMAPINFO			BitmapInfo;
	DWORD				dwWidth, dwHeight, dwBPP;
	DWORD				BMPHeaderSize=54;
	FILE				*f;
	unsigned char		*pByteLineBuffer;
	WORD				*pWordLineBuffer;
	unsigned char		Red, Green, Blue;
	static int			nScreenshotCount=0;
	char				pszScreenshotName[20];
	int					i;
	DWORD				j;
	DWORD				m;
	DWORD				dwRedBits=0, dwGreenBits=0, dwBlueBits=0;

	/* In single buffer mode (Fullscreen mode), use front buffer
	   to perform screenshot */
	if (D3DFE.nBufferingMode==1 && D3DFE.bFullScreen)
	{
		/* Surface to capture is front buffer */
		lpDDS=D3DFE.lpDDSPrimary;
	}
	else
	{
		/* Surface to capture is back buffer */
		lpDDS=D3DFE.lpDDSBack;
	}
	
	/* Set state */
	D3DFE.bPaused=TRUE;
	
	/* Initialise ddsd */
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	
	/* Get description of surface */
	hres=lpDDS->lpVtbl->GetSurfaceDesc(lpDDS, &ddsd);
	if (hres!=DD_OK)
	{
		DEBUG("GetSurfaceDesc() failed in D3DFEScreenCapture()\n");
		DisplayHRESULTInDebug(hres);
		D3DFE.bPaused=FALSE;
		return FALSE;
	}

	/* Assigning values */
	dwWidth=ddsd.dwWidth;
	dwHeight=ddsd.dwHeight;
	dwBPP=ddsd.ddpfPixelFormat.dwRGBBitCount;
	
	/* Debug output */
	sprintf(pszString, "Width=%u  Height=%u  bpp=%u\n", dwWidth, dwHeight, dwBPP);
	DEBUG(pszString);
	
	/* Test if capture is valid */
	if (dwBPP!=16 && dwBPP!=24)
	{
		DEBUG("Don't support screen capture for 8 or 32-bit surfaces\n");
		D3DFE.bPaused=FALSE;
		return FALSE;
	}
	
	/* Lock surface */
	hres=lpDDS->lpVtbl->Lock(lpDDS, NULL, &ddsd, DDLOCK_WAIT, NULL);				
	if (hres!=DD_OK)
	{
		DEBUG("Lock() failed in D3DFEScreenCapture()\n");
		DisplayHRESULTInDebug(hres);
		D3DFE.bPaused=FALSE;
		return FALSE;
	}
	
	/* Get pointers */
	if (dwBPP==16)
	{
		/* 16-bit surface */
		pWord=(WORD *)ddsd.lpSurface;
		Pitch=(WORD)ddsd.lPitch;
	}
	else
	{
		/* 24-bit surface */
		pByte=(unsigned char *)ddsd.lpSurface;
		Pitch=(WORD)ddsd.lPitch;
	}

	/* Unlock render surface */
	hres=lpDDS->lpVtbl->Unlock(lpDDS, NULL);		
	if (hres!=DD_OK)
	{
		OutputDebugString("Unlock() failed in D3DFEScreenCapture\n");
		DisplayHRESULTInDebug(hres);
		D3DFE.bPaused=FALSE;
		return FALSE;
	}

	/* Debug output */
	sprintf(pszString, "Surface pointer=%X\nPitch=%u\n", dwBPP==16 ? (unsigned char *)pWord : pByte, Pitch);
	DEBUG(pszString);

	/* Allocate memory for Read buffer */
	if (dwBPP==16)
	{
		pWordLineBuffer=(WORD *)malloc(Pitch*sizeof(WORD)/2);
	}
	else
	{
		pByteLineBuffer=(unsigned char *)malloc(Pitch*sizeof(unsigned char));
	}

	/* Fill BITMAPFILEHEADER structure */
	BitmapFileHeader.bfType='MB';
	BitmapFileHeader.bfSize=BMPHeaderSize+(dwWidth*dwHeight*3);
	BitmapFileHeader.bfReserved1=0;
	BitmapFileHeader.bfReserved2=0;
	BitmapFileHeader.bfOffBits=BMPHeaderSize;

	/* Fill BITMAPINFO structure */
	/* Fill BITMAPINFOHEADER structure inside BITMAPINFO structure */
	BitmapInfo.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
	BitmapInfo.bmiHeader.biWidth=dwWidth;
	BitmapInfo.bmiHeader.biHeight=dwHeight;
	BitmapInfo.bmiHeader.biPlanes=1;
	BitmapInfo.bmiHeader.biBitCount=24;		/* Image will always be saved as 24-bit BMP */
	BitmapInfo.bmiHeader.biCompression=BI_RGB;
	BitmapInfo.bmiHeader.biSizeImage=dwWidth*dwHeight*3;
	BitmapInfo.bmiHeader.biXPelsPerMeter=0;
	BitmapInfo.bmiHeader.biYPelsPerMeter=0;
	BitmapInfo.bmiHeader.biClrUsed=0;
	BitmapInfo.bmiHeader.biClrImportant=0;

	/* Compute file name */
	sprintf(pszScreenshotName, "Screen%02d.bmp", nScreenshotCount);
	if ( !(f=fopen(pszScreenshotName, "wb")) )
	{
		sprintf(pszString, "Unable to write %s\n", pszScreenshotName);
		DEBUG(pszString);
	}

	/* Write BitmapFileheader */
	if (fwrite(&BitmapFileHeader, sizeof(BITMAPFILEHEADER), 1, f)<1)
	{
		sprintf(pszString, "Error in writing BITMAPFILEHEADER in %s\n", pszScreenshotName);
		DEBUG(pszString);
		fclose(f);
		DeleteFile(pszScreenshotName);
		D3DFE.bPaused=FALSE;
		return FALSE;
	}

	/* Write BitmapInfoHeader */
	if (fwrite(&BitmapInfo.bmiHeader, sizeof(BITMAPINFOHEADER), 1, f)<1)
	{
		sprintf(pszString, "Error in writing BITMAPINFOHEADER in %s\n", pszScreenshotName);
		DEBUG(pszString);
		fclose(f);
		DeleteFile(pszScreenshotName);
		D3DFE.bPaused=FALSE;
		return FALSE;
	}

	// Find number of bits for each channel
	m=ddsd.ddpfPixelFormat.dwRBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) dwRedBits++;
	}
	m=ddsd.ddpfPixelFormat.dwGBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) dwGreenBits++;
	}
	m=ddsd.ddpfPixelFormat.dwBBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) dwBlueBits++;
	}

	sprintf(pszString, "Surface format : %d %d %d\nBit mask : %02X %02X %02X\n", 
						dwRedBits, dwGreenBits, dwBlueBits,
						ddsd.ddpfPixelFormat.dwRBitMask, ddsd.ddpfPixelFormat.dwGBitMask, ddsd.ddpfPixelFormat.dwBBitMask);
	DEBUG(pszString);
	
	/* Write bitmap data */
	
	/* 16-bit surface */
	if (dwBPP==16)
	{
		WORD	ReadWord;
		WORD	*pWordCounter;

		/* Read all lines from bottom to top */
		for (i=dwHeight-1; i>=0; i--)
		{
			//memcpy(pWordLineBuffer, pWord+(i*dwWidth), Pitch);
			memcpy(pWordLineBuffer, pWord+((i*Pitch)/2), Pitch);
			pWordCounter=pWordLineBuffer;

			for (j=0; j<dwWidth; j++)
			{
				/* Read next word in surface */
				ReadWord=*pWordCounter++;
				
				/* Get red, green, blue channels */
				Blue=(unsigned char)(ReadWord & ddsd.ddpfPixelFormat.dwBBitMask);
				Green=(unsigned char)((ReadWord & ddsd.ddpfPixelFormat.dwGBitMask)>>dwBlueBits);
				Red=(unsigned char)((ReadWord & ddsd.ddpfPixelFormat.dwRBitMask)>>(dwBlueBits+dwGreenBits));
								
				/* Set the colour channels to 8 bits each because picture is saved as 24 bpp */
				Blue<<=(8-dwBlueBits);
				Green<<=(8-dwGreenBits);
				Red<<=(8-dwRedBits);
				
				/* Write colour channels */
				if (fwrite(&Blue, sizeof(unsigned char), 1, f)<1)
				{
					sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
					DEBUG(pszString);
					fclose(f);
					DeleteFile(pszScreenshotName);
					D3DFE.bPaused=FALSE;
					return FALSE;
				}
				if (fwrite(&Green, sizeof(unsigned char), 1, f)<1)
				{
					sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
					DEBUG(pszString);
					fclose(f);
					DeleteFile(pszScreenshotName);
					D3DFE.bPaused=FALSE;
					return FALSE;
				}
				if (fwrite(&Red, sizeof(unsigned char), 1, f)<1)
				{
					sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
					DEBUG(pszString);
					fclose(f);
					DeleteFile(pszScreenshotName);
					D3DFE.bPaused=FALSE;
					return FALSE;
				}
			}

			/* Align line in BMP on a DWORD boundary */
			if ( ((3*dwWidth)%4)!=0 )
			{
				unsigned char bBlank=0;
							
				if (fwrite(&bBlank, sizeof(unsigned char), 4-((3*dwWidth)%4), f)<1)
				{
					sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
					DEBUG(pszString);
					fclose(f);
					DeleteFile(pszScreenshotName);
					D3DFE.bPaused=FALSE;
					return FALSE;
				}
			}
		}
	}
	else
	{
		/* 24-bit surface */
		/* Read and write all lines from bottom to top */
		for (i=dwHeight-1; i>=0; i--)
		{
			if (fwrite(pByte+(i*Pitch), Pitch*sizeof(unsigned char), 1, f)<1)
			{
				sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
				DEBUG(pszString);
				fclose(f);
				DeleteFile(pszScreenshotName);
				D3DFE.bPaused=FALSE;
				return FALSE;
			}
		}
	}
	
	/* Close file */
	if (fclose(f)!=0)
	{
		sprintf(pszString, "Error in closing %s\n", pszScreenshotName);
		DEBUG(pszString);
	}

	/* Free memory */
	if (dwBPP==16)
	{
		free(pWordLineBuffer);
	}
	else
	{
		free(pByteLineBuffer);
	}

	/* Increase number of screen shot (maximum 100) */
	if (++nScreenshotCount>99)
	{
		nScreenshotCount=0;
	}

	/* Beep = screen capture OK */
	MessageBeep(MB_OK);
	DEBUG("Screen capture successful\n");

	/* Set state back to normal */
	D3DFE.bPaused=FALSE;
	
	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : D3DFETimerProc
 * Inputs		  : hwnd, uMsg, idEvent, dwTime
 * Global Used    : D3DFE
 * Description    : Timer callback procedure
 *******************************************************************************/
void CALLBACK D3DFETimerProc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	/* Compute frame rate if ready */
	if (D3DFE.bRenderingReady && !D3DFE.bPaused && !D3DFE.bMinimized)
	{
		D3DFE.dwFrameRate=(D3DFE.dwFramesElapsed * 1000) / TIMER_PERIOD;
		D3DFE.dwFramesElapsed=0;
	}
	else
	{
		D3DFE.dwFrameRate=0;
		D3DFE.dwFramesElapsed=0;
	}
}


/********************************************************************
****************** HERE STARTS THE MISC FUNCTIONS *******************
********************************************************************/


/* Convert an integer bit per pixel number to a DirectDraw bit depth flag */
DWORD BPPToDDBD(int bpp)
{
    switch(bpp)
	{
		case 1 :	return DDBD_1;
        case 2 :	return DDBD_2;
        case 4 :	return DDBD_4;
        case 8 :	return DDBD_8;
        case 16 :	return DDBD_16;
        case 24 :	return DDBD_24;
        case 32 :	return DDBD_32;
    }
}


/* Useful function which reports if surfaces are located in Video memory or in System memory */
void DisplayInfoAboutSurfaces()
{
	DDSURFACEDESC	ddsd;
	HRESULT			hres;

	/* Set DDSURFACEDESC structure to 0 */
	memset(&ddsd, 0, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);

	/* Get surface description of Primary buffer */
	hres=D3DFE.lpDDSPrimary->lpVtbl->GetSurfaceDesc(D3DFE.lpDDSPrimary, &ddsd);
	if (hres!=DD_OK)
	{
		DEBUG("GetSurfaceDesc failed for primary surface in DisplayInfoAboutSurfaces()\n");	
		DisplayHRESULTInDebug(hres);
	}
	sprintf(pszTmp, "\nPrimary surface is in %s memory\n", (ddsd.ddsCaps.dwCaps & DDSCAPS_VIDEOMEMORY) ? "VIDEO" : "SYSTEM");
	DEBUG(pszTmp);

	/* Get surface description of Back buffer */
	if (D3DFE.lpDDSBack)
	{
		hres=D3DFE.lpDDSBack->lpVtbl->GetSurfaceDesc(D3DFE.lpDDSBack, &ddsd);
		if (hres!=DD_OK)
		{
			DEBUG("GetSurfaceDesc failed for back buffer in DisplayInfoAboutSurfaces()\n");	
			DisplayHRESULTInDebug(hres);
		}
		sprintf(pszTmp, "Back surface is in %s memory\n", (ddsd.ddsCaps.dwCaps & DDSCAPS_VIDEOMEMORY) ? "VIDEO" : "SYSTEM");
		DEBUG(pszTmp);
	}

	/* Get surface description of Z-Buffer */
	if (D3DFE.lpDDSZBuffer)
	{
		hres=D3DFE.lpDDSZBuffer->lpVtbl->GetSurfaceDesc(D3DFE.lpDDSZBuffer, &ddsd);
		if (hres!=DD_OK)
		{
			DEBUG("GetSurfaceDesc failed for Z Buffer in DisplayInfoAboutSurfaces()\n");	
			DisplayHRESULTInDebug(hres);
		}
		sprintf(pszTmp, "Z-Buffer surface is in %s memory\n", (ddsd.ddsCaps.dwCaps & DDSCAPS_VIDEOMEMORY) ? "VIDEO" : "SYSTEM");
		DEBUG(pszTmp);
	}
}


/*******************************************************************************
 * Function Name  : D3DFEClearSurface
 * Inputs		  : 
 * Global Used    : D3DFE
 * Description    : Clear a surface to black
 *******************************************************************************/
void D3DFEClearSurface(LPDIRECTDRAWSURFACE lpSurface)
{
   RECT dst;
   DDBLTFX ddbltfx;
   DDSURFACEDESC ddsd;
   HRESULT		hres;

   ddsd.dwSize = sizeof(ddsd);
   lpSurface->lpVtbl->GetSurfaceDesc(lpSurface, &ddsd);   

   memset(&ddbltfx, 0, sizeof(ddbltfx));
   ddbltfx.dwSize = sizeof(DDBLTFX);
   ddbltfx.dwFillColor = 0;
   dst.left = dst.top = 0;
   dst.right = ddsd.dwWidth;
   dst.bottom = ddsd.dwHeight;

   hres=lpSurface->lpVtbl->Blt(lpSurface, &dst, NULL, NULL, DDBLT_COLORFILL | DDBLT_WAIT, &ddbltfx );
   if (hres!=DD_OK)
   {
      DEBUG("Clearsurface failed\n");
	  DisplayHRESULTInDebug(hres);
   }
}


/*******************************************************************************
 * Function Name  : D3DFEClearSurface
 * Inputs		  : hTexture
 * Global Used    : D3DFE
 * Description    : Returns the texture surface corresponding to handle
 *******************************************************************************/
LPDIRECTDRAWSURFACE	D3DShellGetTextureSurface(D3DTEXTUREHANDLE hTexture)
{
	int i;

	/* Parse all textures loaded */	
	for (i=0; i<D3DFE.nTextures; i++)
	{
		if (hTexture==TextureArray.TextureHandle[i])
		{
			return TextureArray.lpTextureSurf[i];
		}
	}
	
	/* If we get to that point, no texture handle matching 
	   the parameter has been found */
	DEBUG("Texture handle does not exist\n");
	
	/* Return 0 */
	return 0;
}
	
