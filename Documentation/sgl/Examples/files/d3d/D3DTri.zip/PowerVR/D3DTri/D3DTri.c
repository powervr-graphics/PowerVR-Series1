/*****************************************************************************
  Name : D3Dri.c
  Date : March 1998
  
  D3DTri.c is the simplest scene file that make use of D3D Shell. 
  The scene file should be included in a project where the D3DShell.c and 
  D3DShell.h files are included. The DDRAW.LIB library file should of course
  be included in the project. Make sure your application include D3DShell.h 
  to have access to D3D Shell functions and flags.

  Basic functions have to be implemented to interact correctly with the D3D 
  Shell. A list of these functions is :

  
  **************************
  * void InitApplication() *
  **************************

  This function will be called by the D3D Shell before anything happens, at the very
  beginning of the D3DShell WinMain() function. That's the only time this function
  will be called. This function enables the user to perform any initialisation before 
  the program is actually run.
  From this function the user can call D3DShellSetPreferences() to :
  - Specify the application name.
  - Submit a menu and/or an accelerator table.
  - Specify the icon used for the application.
  - Control the execution of the application by specifying some flags.

  A prototype of the function is :
	
	void D3DShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel,
								HICON hUserIcon, enum D3DFrontEndPrefs dwFlags);

  A list of flags and their functions can be found in the D3DShell.h file.


  **************************
  * void QuitApplication() *
  **************************

  This function will be called by the D3D Shell just before finishing the program.
  It enables the user to release any memory allocated before.
  

  ******************************************************************************
  * void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) *
  ******************************************************************************

  This function is the user Window Procedure function. It enables the user to retrieve
  menu choices, keystrokes or other messages.
  If you don't want to use this function, put nothing in it :
    
	void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
    {
	  // Nothing !
    }

  The D3D Shell processes many window messages. If the user needs to 
  process these messages in his/her application, he/she should make sure
  NOT to return DefWindowProc() as it will prevent the D3D Shell WindowProc
  to do its own processing for these messages.
  The window messages processed by the D3D Shell are :

  WM_ENTERMENULOOP, WM_EXITMENULOOP,
  WM_ACTIVATEAPP,
  WM_SYSCOMMAND,
  WM_SIZE, WM_MOVE, WM_SIZING, WM_MOVING,
  WM_PAINT,
  WM_DESTROY, WM_QUIT

  Note : do NOT process the VK_ESCAPE key, as it is already used by the 
		 D3D Shell to quit the application.


  *************************************************************************
  * BOOL RenderScene(LPDIRECT3DDEVICE2 lpDev, LPDIRECT3DVIEWPORT2 lpView) *
  *************************************************************************

  That's the main user function in which you have to do your own rendering.
  Pointers to the D3D device (LPDIRECT3DDEVICE2) and the D3D viewport
  (LPDIRECT3DVIEWPORT2) are passed to this function so you can use them
  to control your rendering (Render states, lights, etc...)
  In this function you only have to do your transformations (if needed) and
  use DrawPrimitive or Execute Buffers.
  

  *********************************************************************************
  * BOOL InitView(LPDIRECTDRAW2 lpDD, LPDIRECT3D2 lpD3D, LPDIRECT3DDEVICE2 lpDev, *
  *				  LPDIRECT3DVIEWPORT2 lpView, DWORD dwWidth, DWORD dwHeight)	  *
  *********************************************************************************

  This function enables the user to create execute buffers, materials, set 
  rendering values, etc... This function will be called each time the surfaces
  and objects will be recreated (i.e. switching to FullScreen, enabling Z-Buffer, 
  etc...).
  You might need the DirectDraw and D3D variables passed to this function to
  create viewports, light, set render states, etc...
  dwWidth and dwHeight are the current Width and Height of the rendering
  surface. You might need these values if you use D3DTLVERTEX.


  ***********************************************************************
  * void ReleaseView(LPDIRECT3DVIEWPORT2 lpView)						    *
  ***********************************************************************

  This function enables the user to release any devices he/she has created.
  The function will be called each time the surfaces and variables have to 
  be recreated. A pointer to the viewport is passed, as the user might 
  need it to delete any lights attached to the viewport.
  

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/

/* Includes */
#include <d3d.h>
#include "D3DShell.h"	// D3DShell include


/* Defines */
#ifndef RELEASE
#define RELEASE(x)	if (x) { x->lpVtbl->Release(x); x=NULL; }
#endif


/* Globals */
D3DTLVERTEX	TriangleVertex[3]= 
{   { 	 0.0f,	-100.0f, 0.1f, 10.0f, RGB_MAKE(0,0,255), RGB_MAKE(0, 0, 255), 0.0f, 0.0f },
	{  100.0f,	  33.0f, 0.1f, 10.0f, RGB_MAKE(0,0,128), RGB_MAKE(0, 0, 128), 1.0f, 0.0f },
	{ -100.0f,	  33.0f, 0.1f, 10.0f, RGB_MAKE(0,0,64),  RGB_MAKE(0, 0, 64),  0.0f, 1.0f }	};

WORD		TriangleIndices[3]= { 0, 1, 2 };


/* Prototypes for the six D3DShell functions are already defined in D3DShell.h */

/* Application functions */
void SetMaterialForBackground(LPDIRECT3D2 lpD3D2, LPDIRECT3DDEVICE2 lpDev2, LPDIRECT3DVIEWPORT2 lpView2);


/****************************************************************************
** InitApplication() is called by D3DShell to enable user to initialise	   **
** his/her application									2				   **
****************************************************************************/
void InitApplication()
{
	/* No memory or instance to initialise */

	/* Just use D3DShellSetPreferences to specify the application name
	   and a couple of flags.
	   We need to clear the viewport before every frame, as we don't render
	   over all the viewport.
	   Single buffer mode should be disabled in that case.
	   We chose to disable resolutions above 1024x768 */
	D3DShellSetPreferences("Triangle example for D3DShell", 
							NULL,
							NULL,
							NULL,
							DISABLE_VERYHIGHRES | DEFAULT_CLEAR_ON);
}


/****************************************************************************
** QuitApplication() is called by D3D Shell to enable user to release      **
** any memory before quitting the program.								   **
****************************************************************************/
void QuitApplication()
{
	/* No memory to free or instance to release */
}


/*******************************************************************************
 * Function Name  : UserWindowProc
 * Returns        : TRUE if no error occured
 * Global Used    : None
 * Description    : Application's window messages handler
 *					When processing keystrokes, DO NOT process ESCAPE key 
 *					(VK_ESCAPE), as it is already used by the Shell.
 *					
 *******************************************************************************/
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/* We don't process any user input for this application */
}


/*******************************************************************************
 * Function Name  : RenderScene
 * Returns        : TRUE if no error occured
 * Global Used    : None
 * Description    : Application's rendering function
 *					
 *******************************************************************************/
BOOL RenderScene(LPDIRECT3DDEVICE2 lpDev2, LPDIRECT3DVIEWPORT2 lpView2)
{
	HRESULT	hres;
	BOOL	bRSOK=TRUE;
	
	/* Begin Scene */
	lpDev2->lpVtbl->BeginScene(lpDev2);
		
	/* Draw Nefertiti primitive */
	hres=lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
											  (LPVOID)TriangleVertex, 3, 
											  (LPWORD)TriangleIndices, 3,
											  D3DDP_WAIT);
	if (hres!=DD_OK)
	{
		OutputDebugString("DrawIndexedPrimitive for Triangle failed\n");
		bRSOK=FALSE;
	}

	/* End Scene */
    lpDev2->lpVtbl->EndScene(lpDev2);

	/* No problem occured */
	return bRSOK;
}
	

/*******************************************************************************
 * Function Name  : InitView
 * Inputs		  : lpDD2, lpD3D2, lpDev2, lpView2, dwWidth, dwHeight
 * Returns        : TRUE on success
 * Global Used    : None
 * Description    : Application's viewport initialisation function
 *					Create execute buffers, materials, etc...
 *******************************************************************************/
BOOL InitView(LPDIRECTDRAW2 lpDD2, LPDIRECT3D2 lpD3D2, LPDIRECT3DDEVICE2 lpDev2,
              LPDIRECT3DVIEWPORT2 lpView2, DWORD dwWidth, DWORD dwHeight)
{
	D3DMATERIALHANDLE	hTriangleMat=0;
	LPDIRECT3DMATERIAL2 lpTriangleMat=NULL;
	D3DMATERIAL			TriangleMat;

	/* Assign the background colour to be black.
	   This is needed to assign a colour to the viewport */
	SetMaterialForBackground(lpD3D2, lpDev2, lpView2);


	/* The following lines are only needed for Ramp Emulation D3D device 
	   In this device, a material must be assigned for light */

	/* Create triangle material */
	lpD3D2->lpVtbl->CreateMaterial(lpD3D2, &lpTriangleMat, NULL);
	
	/* Fill D3DMATERIAL structure */
	memset(&TriangleMat, 0, sizeof(D3DMATERIAL));
    TriangleMat.dwSize = sizeof(D3DMATERIAL);
    TriangleMat.diffuse.r = (D3DVALUE)1.0;
    TriangleMat.diffuse.g = (D3DVALUE)1.0;
    TriangleMat.diffuse.b = (D3DVALUE)1.0;
    TriangleMat.ambient.r = (D3DVALUE)1.0;
    TriangleMat.ambient.g = (D3DVALUE)1.0;
    TriangleMat.ambient.b = (D3DVALUE)1.0;
    TriangleMat.specular.r = (D3DVALUE)1.0;
    TriangleMat.specular.g = (D3DVALUE)1.0;
    TriangleMat.specular.b = (D3DVALUE)1.0;
    TriangleMat.power = (float)1.0;
    TriangleMat.hTexture = 0;
    TriangleMat.dwRampSize = 32;
    
	/* Set material and retrieve a handle for it */
	lpTriangleMat->lpVtbl->SetMaterial(lpTriangleMat, &TriangleMat);
    lpTriangleMat->lpVtbl->GetHandle(lpTriangleMat, lpDev2, &hTriangleMat);	

	/* Defines the material that is lit and used to compute the 
	   final color and intensity values during rasterization (must 
	   exist for RAMP mode).*/
	lpDev2->lpVtbl->SetLightState(lpDev2, D3DLIGHTSTATE_MATERIAL, hTriangleMat);
		
	/* Update new triangle vertices to make it centered on the screen */
	TriangleVertex[0].sx=0.0f+(dwWidth/2);
	TriangleVertex[0].sy=-100.0f+(dwHeight/2);
	
	TriangleVertex[1].sx=100.0f+(dwWidth/2);
	TriangleVertex[1].sy=33.0f+(dwHeight/2);
	
	TriangleVertex[2].sx=-100.0f+(dwWidth/2);
	TriangleVertex[2].sy=33.0f+(dwHeight/2);

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : ReleaseView
 * Input		  : lpView2
 * Returns        : Nothing
 * Global Used    : None
 * Description    : Application's rendering function
 *					D3DShell passes the viewport variable to this function 
 *					so you can delete any lights you created previously 
 *******************************************************************************/
void ReleaseView(LPDIRECT3DVIEWPORT2 lpView2)
{
    /* Nothing to release */
}


/**************************
** Application functions **
**************************/


/* Assign a BLACK material to the background */
void SetMaterialForBackground(LPDIRECT3D2 lpD3D2, LPDIRECT3DDEVICE2 lpDev2, LPDIRECT3DVIEWPORT2 lpView2)
{
	D3DMATERIALHANDLE hMat=0;					
	LPDIRECT3DMATERIAL2 lpMat=NULL;
	D3DMATERIAL mat;
	HRESULT	hres;

	/* Create material */
	if (lpD3D2->lpVtbl->CreateMaterial(lpD3D2, &lpMat, NULL) != D3D_OK) 
	{
		OutputDebugString("Failed in CreateMaterial\n");
    }
    memset(&mat, 0, sizeof(D3DMATERIAL));
    mat.dwSize = sizeof(D3DMATERIAL);
    mat.diffuse.r = (D3DVALUE)0.0;
    mat.diffuse.g = (D3DVALUE)0.0;
    mat.diffuse.b = (D3DVALUE)0.0;
    mat.ambient.r = (D3DVALUE)1.0;
    mat.ambient.g = (D3DVALUE)1.0;
    mat.ambient.b = (D3DVALUE)1.0;
    mat.specular.r = (D3DVALUE)1.0;
    mat.specular.g = (D3DVALUE)1.0;
    mat.specular.b = (D3DVALUE)1.0;
    mat.power = (float)40.0;
    mat.hTexture = 0;
    mat.dwRampSize = 1;
    lpMat->lpVtbl->SetMaterial(lpMat, &mat);
    lpMat->lpVtbl->GetHandle(lpMat, lpDev2, &hMat);

	/* Set the background */
	hres=lpView2->lpVtbl->SetBackground(lpView2, hMat);
	if (hres!=DD_OK)
	{
		OutputDebugString("SetBackground failed\n");
	}
}

