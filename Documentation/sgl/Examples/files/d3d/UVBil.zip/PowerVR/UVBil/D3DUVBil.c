/*****************************************************************************
  Name : D3DUVBil.c
  Date : May 1998
  Platform : ANSI compatible

  DESCRIPTION : Application showing how to implement a background using
				textures without these "bilinear cutlines".
 
  
  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/
#include <stdio.h>
#include <d3d.h>
#include "D3DShell.h"	/* D3D Shell include */
#include "resource.h"	/* Resource include */
              

/* Macros */
#define SWAP(x)		if (x) { x=FALSE; } else x=TRUE


/* Vertices and Triangles used to display all textures */
D3DTLVERTEX	BackgroundTLVertices[4]={
    { 	 0.0f,	   0.0f, 0.999f, 0.001f, RGB_MAKE(255, 255, 255), RGB_MAKE(0, 0, 0), 0.0f, 1.0f },
	{  256.0f,	   0.0f, 0.999f, 0.001f, RGB_MAKE(255, 255, 255), RGB_MAKE(0, 0, 0), 1.0f, 1.0f },
	{  256.0f,	 256.0f, 0.999f, 0.001f, RGB_MAKE(255, 255, 255), RGB_MAKE(0, 0, 0), 1.0f, 0.0f },
	{    0.0f,	 256.0f, 0.999f, 0.001f, RGB_MAKE(255, 255, 255), RGB_MAKE(0, 0, 0), 0.0f, 0.0f }	};

WORD	BackgroundTriangles[2][3]={
	{ 0, 1, 2 }, {2, 3, 0}  };


/* Global variables */
float				fScaleFactor=0.88f;
BOOL				bBilinearOn=TRUE;
BOOL				bTextOn=TRUE;
BOOL				bMaxUV=TRUE;
BOOL				bSupportAlphaTexture;
D3DTEXTUREHANDLE	hBackgroundTexture[2][3];
D3DTEXTUREHANDLE	hTextTexture;
static	DWORD		dwCurrentWidth;
static	DWORD		dwCurrentHeight;
HICON				hMyIcon;


/* Prototypes */
void SetMaterialForBackground(LPDIRECT3D2 lpD3D2, LPDIRECT3DDEVICE2 lpDev2, LPDIRECT3DVIEWPORT2 lpView2);


/* D3DShell Functions */


/* InitApplication() is called by D3DShell */
void InitApplication()
{
	/* Load icon from resouce */
	hMyIcon=LoadIcon(NULL, MAKEINTRESOURCE(IDI_UV));

	/* Set application name, no menu, no accelerator, User Icon and flags */
	D3DShellSetPreferences("Bilinear Offset in UV texturing", NULL, NULL, hMyIcon, DISABLE_VERYHIGHRES |
																				   DEFAULT_CLEAR_ON |
																				   DISABLE_RAMP_MODE |
																				   DISABLE_MMX_MODE);
}


/* QuitApplication() is called by D3DShell */
void QuitApplication()
{
	/* Nothing to release */
	OutputDebugString("Application memory released\n");
}


/* UserWindowProc() is called by D3DShell */
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/* Handle user messages */
	switch(message)
	{
		case WM_KEYDOWN:	switch(wParam)
							{
								case 'U' :			SWAP(bMaxUV); break;
								case 'F' :			SWAP(bBilinearOn); break;
								
								case VK_UP :
								case VK_ADD :		fScaleFactor+=0.01f; break;
								case VK_DOWN :
								case VK_SUBTRACT :	if (fScaleFactor>0.01f) fScaleFactor-=0.01f; break;
								
								case VK_F1 :		SWAP(bTextOn); break;
							}
							break;
	}
}


/* InitView() is called by D3DShell */
BOOL InitView(LPDIRECTDRAW2 lpDD2, LPDIRECT3D2 lpD3D2, LPDIRECT3DDEVICE2 lpDev2, 
			  LPDIRECT3DVIEWPORT2 lpView2, DWORD dwWidth, DWORD dwHeight)
{
	D3DDEVICEDESC	HALDesc;
	D3DDEVICEDESC	HELDesc;
	
	/* Update new width and height */
	dwCurrentWidth=dwWidth;
	dwCurrentHeight=dwHeight;
	
	/* Look if device can support alpha texture (for RGB mode in fact)
	   This is just to avoid the display of a plain red texture instead
	   of the text on the top right corner of the screen */
	ZeroMemory(&HALDesc, sizeof(D3DDEVICEDESC));
	ZeroMemory(&HELDesc, sizeof(D3DDEVICEDESC));
	HELDesc.dwSize=sizeof(D3DDEVICEDESC);
	HALDesc.dwSize=sizeof(D3DDEVICEDESC);
	lpDev2->lpVtbl->GetCaps(lpDev2, &HALDesc, &HELDesc);
	if (!(HALDesc.dpcTriCaps.dwTextureCaps & D3DPTEXTURECAPS_ALPHA))
	{
		OutputDebugString("D3D Device does not support Alpha textures.\n");
		bSupportAlphaTexture=FALSE;
	}
	else
	{
		bSupportAlphaTexture=TRUE;
	}

	/* Set black background */
	SetMaterialForBackground(lpD3D2, lpDev2, lpView2);
	
	/* Load textures from resource */
	/* All texture compisiting the background */
	hBackgroundTexture[0][0]=D3DShellLoadBMP("SAND1-1", FALSE);
	hBackgroundTexture[0][1]=D3DShellLoadBMP("SAND1-2", FALSE);
	hBackgroundTexture[0][2]=D3DShellLoadBMP("SAND1-3", FALSE);
	hBackgroundTexture[1][0]=D3DShellLoadBMP("SAND2-1", FALSE);
	hBackgroundTexture[1][1]=D3DShellLoadBMP("SAND2-2", FALSE);
	hBackgroundTexture[1][2]=D3DShellLoadBMP("SAND2-3", FALSE);
	/* Translucent text texture */
	hTextTexture=D3DShellLoadBMP("TEXT", TRUE);

	/* Default render states */
	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_CULLMODE, D3DCULL_CCW);
	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREMAPBLEND, D3DTBLEND_MODULATE);
	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_SRCBLEND, D3DBLEND_SRCALPHA);
	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_DESTBLEND, D3DBLEND_INVSRCALPHA);
		
	/* InitView OK */
	return TRUE;
}


/* RenderScene() is called by D3DShell */
BOOL RenderScene(LPDIRECT3DDEVICE2 lpDev2, LPDIRECT3DVIEWPORT2 lpView2)
{
	float	fNewTextureSize;
	float	fBilinearOffset;
	char	pszString[200];
	
	/* Compute new texture size (normal size is 256) */
	fNewTextureSize=fScaleFactor*256.0f;

	/* Compute bilinear offset */
	fBilinearOffset=1.0f/256.0f;
	
	/* Text display */
	if (bTextOn)
	{
		sprintf(pszString, "Scale factor : %.2f", fScaleFactor);
		D3DShellSetDisplayText(pszString, 10, 10);
		sprintf(pszString, "Bilinear (F)iltering %s", bBilinearOn ? "On" : "Off");
		D3DShellSetDisplayText(pszString, 10, 30);
		sprintf(pszString, "(U)V Values : %s", bMaxUV ? "Maximum (0.0f and 1.0f)" : "Bilinear special (0.0f+X, 1.0f-X)");
		D3DShellSetDisplayText(pszString, 10, 50);
		if (bMaxUV)
		{
			D3DShellSetDisplayText("Press U to fix the lines problem !", 10, 90);
		}
	}

	/* What UV values are we going to use ? */
	if (bMaxUV)
	{
		/* Wrong values : maximum (0.0 and 1.0) */
		BackgroundTLVertices[0].tu=0.0f;
		BackgroundTLVertices[0].tv=1.0f;
		BackgroundTLVertices[1].tu=1.0f;
		BackgroundTLVertices[1].tv=1.0f;
		BackgroundTLVertices[2].tu=1.0f;
		BackgroundTLVertices[2].tv=0.0f;
		BackgroundTLVertices[3].tu=0.0f;
		BackgroundTLVertices[3].tv=0.0f;
	}
	else
	{
		/* Good values : maximum with Bilinear offset (0.0+BOffset and 1.0-BOffset) */
		BackgroundTLVertices[0].tu=0.0f+fBilinearOffset;
		BackgroundTLVertices[0].tv=1.0f-fBilinearOffset;
		BackgroundTLVertices[1].tu=1.0f-fBilinearOffset;
		BackgroundTLVertices[1].tv=1.0f-fBilinearOffset;
		BackgroundTLVertices[2].tu=1.0f-fBilinearOffset;
		BackgroundTLVertices[2].tv=0.0f+fBilinearOffset;
		BackgroundTLVertices[3].tu=0.0f+fBilinearOffset;
		BackgroundTLVertices[3].tv=0.0f+fBilinearOffset;
	}

	/* Bilinear On or Off ? */
	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREMAG, bBilinearOn ? D3DFILTER_LINEAR : D3DFILTER_NEAREST);
	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREMIN, bBilinearOn ? D3DFILTER_LINEAR : D3DFILTER_NEAREST);

	
	/* Begin Scene */
	lpDev2->lpVtbl->BeginScene(lpDev2);
		
	/* Draw background as 6 different textured polygons */

	/* Opaque textures : turn AlphaBlend OFF */
	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_ALPHABLENDENABLE, FALSE);
	
	/* Background tile 1-1 : */
	BackgroundTLVertices[0].sx=0.0f;
	BackgroundTLVertices[0].sy=0.0f;
	BackgroundTLVertices[1].sx=fNewTextureSize;
	BackgroundTLVertices[1].sy=0.0f;
	BackgroundTLVertices[2].sx=fNewTextureSize;
	BackgroundTLVertices[2].sy=fNewTextureSize;
	BackgroundTLVertices[3].sx=0.0f;
	BackgroundTLVertices[3].sy=fNewTextureSize;

	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREHANDLE, hBackgroundTexture[0][0]);
	lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
										 (LPVOID)BackgroundTLVertices, 4, 
										 (LPWORD)BackgroundTriangles, 3*2,
										 D3DDP_WAIT);
	
	/* Background tile 1-2 : */
	BackgroundTLVertices[0].sx=fNewTextureSize;
	BackgroundTLVertices[0].sy=0.0f;
	BackgroundTLVertices[1].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].sy=0.0f;
	BackgroundTLVertices[2].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].sy=fNewTextureSize;
	BackgroundTLVertices[3].sx=fNewTextureSize;
	BackgroundTLVertices[3].sy=fNewTextureSize;

	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREHANDLE, hBackgroundTexture[0][1]);
	lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
										 (LPVOID)BackgroundTLVertices, 4, 
										 (LPWORD)BackgroundTriangles, 3*2,
										 D3DDP_WAIT);
	
	/* Background tile 1-3 : */
	BackgroundTLVertices[0].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[0].sy=0.0f;
	BackgroundTLVertices[1].sx=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].sy=0.0f;
	BackgroundTLVertices[2].sx=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].sy=fNewTextureSize;
	BackgroundTLVertices[3].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].sy=fNewTextureSize;

	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREHANDLE, hBackgroundTexture[0][2]);
	lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
										 (LPVOID)BackgroundTLVertices, 4, 
										 (LPWORD)BackgroundTriangles, 3*2,
										 D3DDP_WAIT);
	
	/* Background tile 2-1 : */
	BackgroundTLVertices[0].sx=0.0f;
	BackgroundTLVertices[0].sy=fNewTextureSize;
	BackgroundTLVertices[1].sx=fNewTextureSize;
	BackgroundTLVertices[1].sy=fNewTextureSize;
	BackgroundTLVertices[2].sx=fNewTextureSize;
	BackgroundTLVertices[2].sy=fNewTextureSize+fNewTextureSize;;
	BackgroundTLVertices[3].sx=0.0f;
	BackgroundTLVertices[3].sy=fNewTextureSize+fNewTextureSize;;

	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREHANDLE, hBackgroundTexture[1][0]);
	lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
										 (LPVOID)BackgroundTLVertices, 4, 
										 (LPWORD)BackgroundTriangles, 3*2,
										 D3DDP_WAIT);
	
	/* Background tile 2-2 : */
	BackgroundTLVertices[0].sx=fNewTextureSize;
	BackgroundTLVertices[0].sy=fNewTextureSize;
	BackgroundTLVertices[1].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].sy=fNewTextureSize;
	BackgroundTLVertices[2].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].sy=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].sx=fNewTextureSize;
	BackgroundTLVertices[3].sy=fNewTextureSize+fNewTextureSize;

	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREHANDLE, hBackgroundTexture[1][1]);
	lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
										 (LPVOID)BackgroundTLVertices, 4, 
										 (LPWORD)BackgroundTriangles, 3*2,
										 D3DDP_WAIT);
	
	/* Background tile 2-3 : */
	BackgroundTLVertices[0].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[0].sy=fNewTextureSize;
	BackgroundTLVertices[1].sx=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].sy=fNewTextureSize;
	BackgroundTLVertices[2].sx=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].sy=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].sx=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].sy=fNewTextureSize+fNewTextureSize;

	lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREHANDLE, hBackgroundTexture[1][2]);
	lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
										 (LPVOID)BackgroundTLVertices, 4, 
										 (LPWORD)BackgroundTriangles, 3*2,
										 D3DDP_WAIT);
	
	/* Display text as a translucent alpha texture */
	if (bSupportAlphaTexture)
	{
		BackgroundTLVertices[0].sx=(float)dwCurrentWidth-256.0f;
		BackgroundTLVertices[0].sy=0.0f;
		BackgroundTLVertices[1].sx=(float)dwCurrentWidth;
		BackgroundTLVertices[1].sy=0.0f;
		BackgroundTLVertices[2].sx=(float)dwCurrentWidth;
		BackgroundTLVertices[2].sy=0.0f+256.0f;
		BackgroundTLVertices[3].sx=(float)dwCurrentWidth-256.0f;
		BackgroundTLVertices[3].sy=0.0f+256.0f;

		/* Alpha Blend ON */
		lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_ALPHABLENDENABLE, TRUE);
		lpDev2->lpVtbl->SetRenderState(lpDev2, D3DRENDERSTATE_TEXTUREHANDLE, hTextTexture);
		lpDev2->lpVtbl->DrawIndexedPrimitive(lpDev2, D3DPT_TRIANGLELIST, D3DVT_TLVERTEX, 
											 (LPVOID)BackgroundTLVertices, 4, 
											 (LPWORD)BackgroundTriangles, 3*2,
											 D3DDP_WAIT);
	}

	/* End Scene */
    lpDev2->lpVtbl->EndScene(lpDev2);

	/* RenderScene OK */
	return TRUE;
}


/* ReleaseView() is called by D3DShell */
void ReleaseView(LPDIRECT3DVIEWPORT2 lpView2)
{
	/* Nothing to release */
}


/**************************
***************************
** Application functions **
***************************
**************************/


/* Assign a material to the background */
void SetMaterialForBackground(LPDIRECT3D2 lpD3D2, LPDIRECT3DDEVICE2 lpDev2, LPDIRECT3DVIEWPORT2 lpView2)
{
	D3DMATERIALHANDLE hMat=0;					
	LPDIRECT3DMATERIAL2 lpMat=NULL;
	D3DMATERIAL mat;
	HRESULT	hres;

	/* Create material */
	if (lpD3D2->lpVtbl->CreateMaterial(lpD3D2, &lpMat, NULL) != D3D_OK) 
	{
		OutputDebugString("Failed in CreateMaterial\n");
    }
    memset(&mat, 0, sizeof(D3DMATERIAL));
    mat.dwSize = sizeof(D3DMATERIAL);
    mat.diffuse.r = (D3DVALUE)0.0;
    mat.diffuse.g = (D3DVALUE)0.0;
    mat.diffuse.b = (D3DVALUE)0.0;
    mat.ambient.r = (D3DVALUE)1.0;
    mat.ambient.g = (D3DVALUE)1.0;
    mat.ambient.b = (D3DVALUE)1.0;
    mat.specular.r = (D3DVALUE)1.0;
    mat.specular.g = (D3DVALUE)1.0;
    mat.specular.b = (D3DVALUE)1.0;
    mat.power = (float)40.0;
    mat.hTexture = 0;
    mat.dwRampSize = 1;
    lpMat->lpVtbl->SetMaterial(lpMat, &mat);
    lpMat->lpVtbl->GetHandle(lpMat, lpDev2, &hMat);

	/* Set the background */
	hres=lpView2->lpVtbl->SetBackground(lpView2, hMat);
	if (hres!=DD_OK)
	{
		OutputDebugString("SetBackground failed\n");
	}
}
