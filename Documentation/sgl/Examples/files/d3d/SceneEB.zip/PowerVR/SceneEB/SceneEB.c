/*****************************************************************************
  Name : SceneEB.c
  Date : March 1998
  
  SceneEB.c is execute buffers demo to be used with the D3D Shell. 
  The scene file should be included in a project where the D3DShell.c and 
  D3DShell.h files are included. The DDRAW.LIB library file should of course
  be included in the project. Make sure your application include D3DShell.h 
  to have access to D3D Shell functions and flags.

  Basic functions have to be implemented to interact correctly with the D3D 
  Shell. A list of these functions is :

  
  **************************
  * void InitApplication() *
  **************************

  This function will be called by the D3D Shell before anything happens, at the very
  beginning of the D3DShell WinMain() function. That's the only time this function
  will be called. This function enables the user to perform any initialisation before 
  the program is actually run.
  From this function the user can call D3DShellSetPreferences() to :
  - Specify the application name.
  - Submit a menu and/or an accelerator table.
  - Specify the icon used for the application.
  - Control the execution of the application by specifying some flags.

  A prototype of the function is :
	
	void D3DShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel,
								HICON hUserIcon, enum D3DFrontEndPrefs dwFlags);

  A list of flags and their functions can be found in the D3DShell.h file.


  **************************
  * void QuitApplication() *
  **************************

  This function will be called by the D3D Shell just before finishing the program.
  It enables the user to release any memory allocated before.
  

  ******************************************************************************
  * void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) *
  ******************************************************************************

  This function is the user Window Procedure function. It enables the user to retrieve
  menu choices, keystrokes or other messages (WM_TIMER for instance).
  If you don't want to use this function, put nothing in it :
    
	void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
    {
	  // Nothing !
    }

  The D3D Shell processes many window messages. If the user needs to 
  process these messages in his/her application, he/she should make sure
  NOT to return DefWindowProc() as it will prevent the D3D Shell WindowProc
  to do its own processing for these messages.
  The window messages processed by the D3D Shell are :

  WM_ENTERMENULOOP, WM_EXITMENULOOP,
  WM_ACTIVATEAPP,
  WM_SYSCOMMAND,
  WM_SIZE, WM_MOVE, WM_SIZING, WM_MOVING,
  WM_PAINT,
  WM_DESTROY, WM_QUIT

  Note : do NOT process the VK_ESCAPE key, as it is already used by the 
		 D3D Shell to quit the application.


  *************************************************************************
  * BOOL RenderScene(LPDIRECT3DDEVICE2 lpDev, LPDIRECT3DVIEWPORT2 lpView) *
  *************************************************************************

  That's the main user function in which you have to do your own rendering.
  Pointers to the D3D device (LPDIRECT3DDEVICE2) and the D3D viewport
  (LPDIRECT3DVIEWPORT2) are passed to this function so you can use them
  to control your rendering (Render states, lights, etc...)
  In this function you only have to do your transformations (if needed) and
  use DrawPrimitive or Execute Buffers.
  

  *********************************************************************************
  * BOOL InitView(LPDIRECTDRAW2 lpDD, LPDIRECT3D2 lpD3D, LPDIRECT3DDEVICE2 lpDev, *
  *				  LPDIRECT3DVIEWPORT2 lpView, DWORD dwWidth, DWORD dwHeight)	  *
  *********************************************************************************

  This function enables the user to create execute buffers, materials, set 
  rendering values, etc... This function will be called each time the surfaces
  and objects will be recreated (i.e. switching to FullScreen, enabling Z-Buffer, 
  etc...).
  You might need the DirectDraw and D3D variables passed to this function to
  create viewports, light, set render states, etc...
  dwWidth and dwHeight are the current Width and Height of the rendering
  surface. You might need these values if you use D3DTLVERTEX.


  ***********************************************************************
  * void ReleaseView(LPDIRECT3DVIEWPORT2 lpView)						    *
  ***********************************************************************

  This function enables the user to release any devices he/she has created.
  The function will be called each time the surfaces and variables have to 
  be recreated. A pointer to the viewport is passed, as the user might 
  need it to delete any lights attached to the viewport.
  

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/
/* Includes */
#include <windowsx.h>
#include <math.h>
#include <d3d.h>

#include "D3DShell.h"	// D3D Shell include
#include "d3dmacs.h"	// d3d macros from D3D SDK
#include "Easy3D.h"
#include "resource.h"

/* Defines */
#define NUM_VERTICES 6
#define NUM_TRIANGLES 8

#define PI 3.14159f

/* Global variables */
static D3DEXECUTEDATA			d3dExData;              // Direct3D execute data
static LPDIRECT3DEXECUTEBUFFER	lpD3DExBuf;				// Direct3D execute buffer
static D3DEXECUTEBUFFERDESC		debDesc;				// Direct3D execute buffer description
LPDIRECT3DLIGHT					lpD3DLight;				// Direct3D light

D3DMATRIXHANDLE hProj;                 // Projection matrix handle
D3DMATRIXHANDLE hView;                 // View matrix handle
D3DMATRIXHANDLE hWorld;				   // World matrix handle
BOOL			bRotationX=TRUE;
BOOL			bRotationY=TRUE;
BOOL			bRotationZ=TRUE;
BOOL			bDithering=FALSE;
HMENU			hMyMenu;
D3DVALUE		ScaleValue=2.0f;

// Projection matrix
D3DMATRIX proj = {
    D3DVAL(2.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(2.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(1.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(-1.0), D3DVAL(0.0)
};

// View matrix
D3DMATRIX view = {
    D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(10.0), D3DVAL(1.0)
};

// World matrix
D3DMATRIX world = {
    D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
    D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0)
};




/****************************************************************************
** InitApplication() is called by D3D Shell to enable user to initialise   **
** his/her application													   **
** DISABLE_SINGLEBUFFER is advised as it's not yet working perfectly on	   **
** secondary Direct Draw device.										   **
****************************************************************************/
void InitApplication()
{
	/* User stuff */
	
	/* Put NULL for the hInstance as you don't need to know the FrontEnd 
	   window instance */
	hMyMenu=LoadMenu(NULL, MAKEINTRESOURCE(ID_USERMENU));
	
	/* User can submit a menu from the resource */
	D3DShellSetPreferences("Execute buffers example with D3DShell",	// Title 
							hMyMenu,								// Menu
							NULL,									// Accelerator table = none
							NULL,									// Icon = none
							DISABLE_VERYHIGHRES | DEFAULT_CLEAR_ON | DISABLE_SINGLEBUFFER);	// Flags

	/* User stuff */
}


/****************************************************************************
** QuitApplication() is called by D3D Shell to enable user to release      **
** any memory before quitting the program.								   **	
*****************************************************************************/
void QuitApplication()
{
	OutputDebugString("Application memory released\n");
}


/************************************************************
 * UserWindowProc is the application's rendering function  **
 * When processing keystrokes, DO NOT process ESCAPE key   **
 * (VK_ESCAPE), as it is already used by the D3D Shell.    **
 ***********************************************************/
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	/* User can process menu choices */
	case	WM_COMMAND :	switch(GET_WM_COMMAND_ID(wParam,lParam))
							{
							// Rotate user menu message
							case	ID_ROTATION_ROTATEX : if (bRotationX) bRotationX=FALSE;
															else bRotationX=TRUE; break;
							case	ID_ROTATION_ROTATEY : if (bRotationY) bRotationY=FALSE;
															else bRotationY=TRUE; break;
							case	ID_ROTATION_ROTATEZ : if (bRotationZ) bRotationZ=FALSE;
															else bRotationZ=TRUE; break;
							default : break;
							}
							break;

	/* User can process keystrokes ( DO NOT USE ESCAPE, as it is used to terminate the Shell ) */
	case	WM_KEYDOWN :    switch(wParam)
							{
								case VK_UP :	ScaleValue+=0.1f;
												//if (ScaleValue>2.0f) ScaleValue=2.0f;
												break;
								case VK_DOWN :	ScaleValue-=0.1f;
												if (ScaleValue<0.1f) ScaleValue=0.1f;
												break;

								case 'D' : if (bDithering) bDithering=FALSE;
												else bDithering=TRUE; 
										   OutputDebugString("Dithering selected\n");
										   break;
							}
							break;
	default : break;
	}
}


/*******************************************************************************
 * Function Name  : RenderScene
 * Returns        : TRUE if no error occured
 * Global Used    : None
 * Description    : Application's rendering function
 *******************************************************************************/
BOOL RenderScene(LPDIRECT3DDEVICE2 lpDev, LPDIRECT3DVIEWPORT2 lpView)
{
	LPVOID					lpBufStart, lpInsStart, lpPointer;
	LPDIRECT3DEXECUTEBUFFER lpD3DExCmdBuf;
	LPDIRECT3DDEVICE		lpLocalD3DDev;
	LPDIRECT3DVIEWPORT		lpLocalD3DViewport;
	size_t					size;
	D3DVALUE				Pos=20;
	static D3DVALUE			rX=0.0f;
	static D3DVALUE			rY=0.0f;
	static D3DVALUE			rZ=0.0f;
	D3DMATRIX				Tmp1, Tmp2;
	HRESULT					hres;

	/* To use execute buffers, you need the DirectX 3.0 version of the parameters
	   So you can use QueryInterface to retrieve "old" interfaces from these */

	/* Retrieve a D3DDEVICE interface from D3DDEVICE2 */
	hres=lpDev->lpVtbl->QueryInterface(lpDev, &IID_IDirect3DDevice, &lpLocalD3DDev);
	if (hres!=DD_OK)
	{
		OutputDebugString("QueryInterface for Direct3DDevice failed (in RenderScene)\n");
	}

	/* Retrieve a D3DVIEWPORT interface from D3DVIEWPORT2 */
	hres=lpView->lpVtbl->QueryInterface(lpView, &IID_IDirect3DViewport, &lpLocalD3DViewport);
	if (hres!=DD_OK)
	{
		OutputDebugString("QueryInterface for Direct3DDevice failed (in RenderScene)\n");
	}

	/* Set user text to be displayed */
	D3DShellSetDisplayText("This is an application text", 6, 10);
	
	/* Transformation stuff */
	world=IdentityMatrix();

	/* Update menu choices */
	if (bRotationX)
	{
		rX+=0.01f;
		if (rX>2*PI)
		{
			rX=2*PI-rX;
		}
		CheckMenuItem(hMyMenu, ID_ROTATION_ROTATEX, MF_CHECKED);
	}
	else CheckMenuItem(hMyMenu, ID_ROTATION_ROTATEX, MF_UNCHECKED);
	Tmp1=RotateX(rX);

	if (bRotationY) 
	{
		rY+=0.01f;
		if (rY>2*PI)
		{
			rY=2*PI-rY;
		}
		CheckMenuItem(hMyMenu, ID_ROTATION_ROTATEY, MF_CHECKED);
	}
	else CheckMenuItem(hMyMenu, ID_ROTATION_ROTATEY, MF_UNCHECKED);
	Tmp2=RotateY(rY);

	world=MatrixMult(Tmp1, Tmp2);
	
	if (bRotationZ) 
	{
		rZ+=0.01f;
		if (rZ>2*PI)
		{
			rZ=2*PI-rZ;
		}
		CheckMenuItem(hMyMenu, ID_ROTATION_ROTATEZ, MF_CHECKED);
	}
	else CheckMenuItem(hMyMenu, ID_ROTATION_ROTATEZ, MF_UNCHECKED);
	Tmp1=RotateZ(rZ);
		
	world=MatrixMult(world, Tmp1);
	Tmp1=Scale(ScaleValue, ScaleValue, ScaleValue);
	world=MatrixMult(world, Tmp1);
			
	/* Set the view, world and projection matrices
	   Create a buffer for matrix set commands etc. */
	MAKE_MATRIX(lpLocalD3DDev, hView, view);
    MAKE_MATRIX(lpLocalD3DDev, hProj, proj);
    MAKE_MATRIX(lpLocalD3DDev, hWorld, world);
    size = 0;
    size += sizeof(D3DINSTRUCTION) * 3;
    size += sizeof(D3DSTATE) * 4;
    memset(&debDesc, 0, sizeof(D3DEXECUTEBUFFERDESC));
    debDesc.dwSize = sizeof(D3DEXECUTEBUFFERDESC);
    debDesc.dwFlags = D3DDEB_BUFSIZE;
    debDesc.dwBufferSize = size;

	// Create an execute buffer the proper size
    if (lpLocalD3DDev->lpVtbl->CreateExecuteBuffer(lpLocalD3DDev, &debDesc, &lpD3DExCmdBuf, NULL) != D3D_OK)
	{
        return FALSE;
	}

    /* Lock it so it can be filled */
    if (lpD3DExCmdBuf->lpVtbl->Lock(lpD3DExCmdBuf, &debDesc) != D3D_OK)
	{
        return FALSE;
	}
    lpBufStart = debDesc.lpData;
    memset(lpBufStart, 0, size);
    lpPointer = lpBufStart;

    lpInsStart = lpPointer; 
    OP_STATE_TRANSFORM(3, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_VIEW, hView, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_WORLD, hWorld, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_PROJECTION, hProj, lpPointer);
    OP_STATE_LIGHT(1, lpPointer);
        STATE_DATA(D3DLIGHTSTATE_AMBIENT, RGBA_MAKE(64, 64, 64, 64), lpPointer);
    OP_EXIT(lpPointer);

    /* Setup the execute data describing the buffer */
    lpD3DExCmdBuf->lpVtbl->Unlock(lpD3DExCmdBuf);
    memset(&d3dExData, 0, sizeof(D3DEXECUTEDATA));
    d3dExData.dwSize = sizeof(D3DEXECUTEDATA);
    d3dExData.dwInstructionOffset = (ULONG) 0;
    d3dExData.dwInstructionLength = (ULONG) ((char *)lpPointer - (char*)lpInsStart);
    lpD3DExCmdBuf->lpVtbl->SetExecuteData(lpD3DExCmdBuf, &d3dExData);

	/* Execute the instruction buffer */
    if (lpLocalD3DDev->lpVtbl->BeginScene(lpLocalD3DDev) != D3D_OK)
        return FALSE;
	if (lpLocalD3DDev->lpVtbl->Execute(lpLocalD3DDev, lpD3DExCmdBuf, lpLocalD3DViewport, D3DEXECUTE_UNCLIPPED)!=D3D_OK)
		return FALSE;		// I added that (command execute buffer)
	if (lpLocalD3DDev->lpVtbl->Execute(lpLocalD3DDev, lpD3DExBuf, lpLocalD3DViewport, D3DEXECUTE_CLIPPED) != D3D_OK)
        return FALSE;
    if (lpLocalD3DDev->lpVtbl->EndScene(lpLocalD3DDev) != D3D_OK)
        return FALSE;
    if (lpD3DExBuf->lpVtbl->GetExecuteData(lpD3DExBuf, &d3dExData) != D3D_OK)
        return FALSE;
    
	lpD3DExCmdBuf->lpVtbl->Release(lpD3DExCmdBuf);

	/* Release local D3D objects */
	RELEASE(lpLocalD3DViewport);
	RELEASE(lpLocalD3DDev);

    return TRUE;
}


/*******************************************************************************
 * Function Name  : InitView
 * Inputs		  : lpDD, lpD3D, lpDev, lpView
 * Returns        : TRUE on success
 * Global Used    : None
 * Description    : Application's viewport initialisation function
 *					Create execute buffers, materials, etc...
 *******************************************************************************/
BOOL InitView(LPDIRECTDRAW2 lpDD, LPDIRECT3D2 lpD3D, LPDIRECT3DDEVICE2 lpDev,
              LPDIRECT3DVIEWPORT2 lpView, DWORD dwWidth, DWORD dwHeight)
{
    /* Direct X 3.0 version of the D3D parameters */
	LPDIRECT3D				lpLocalD3D;
	LPDIRECT3DDEVICE		lpLocalD3DDev;
	LPDIRECT3DVIEWPORT		lpLocalD3DViewport;
	D3DLIGHT				light;
    LPVOID					lpBufStart, lpInsStart, lpPointer;
    LPDIRECT3DEXECUTEBUFFER lpD3DExCmdBuf;
	LPDIRECT3DMATERIAL		lpBmat, lpMat1, lpMat2;
	D3DMATERIAL				bmat, mat1, mat2;
    D3DMATERIALHANDLE		hBmat, hMat1, hMat2;
	D3DVERTEX				v[NUM_VERTICES];
	LPD3DTRIANGLE			lpTri;
    size_t					size;
	HRESULT					hres;
    int						i;
	int						t[8][3] = {
										0, 1, 2,
										0, 2, 3,
										0, 3, 4,
										0, 4, 1,
										5, 2, 1,
										5, 3, 2,
										5, 4, 3,
										5, 1, 4 };
    
	/* Get DirectX 3.0 interfaces */
										
	/* Retrieve a D3D interface from D3D2 */
	hres=lpD3D->lpVtbl->QueryInterface(lpD3D, &IID_IDirect3D, &lpLocalD3D);
	if (hres!=DD_OK)
	{
		OutputDebugString("QueryInterface for Direct3D failed (in RenderScene)\n");
	}
	
	/* Retrieve a D3DDEVICE interface from D3DDEVICE2 */
	hres=lpDev->lpVtbl->QueryInterface(lpDev, &IID_IDirect3DDevice, &lpLocalD3DDev);
	if (hres!=DD_OK)
	{
		OutputDebugString("QueryInterface for Direct3DDevice failed (in RenderScene)\n");
	}

	/* Retrieve a D3DVIEWPORT interface from D3DVIEWPORT2 */
	hres=lpView->lpVtbl->QueryInterface(lpView, &IID_IDirect3DViewport, &lpLocalD3DViewport);
	if (hres!=DD_OK)
	{
		OutputDebugString("QueryInterface for Direct3DViewport failed (in RenderScene)\n");
	}
	
	// Create the background material
    memset(&bmat, 0, sizeof(D3DMATERIAL));
    bmat.dwSize = sizeof(D3DMATERIAL);
    bmat.diffuse.r = (D3DVALUE)0.0;
    bmat.diffuse.g = (D3DVALUE)0.0;
    bmat.diffuse.b = (D3DVALUE)1.0;
    bmat.ambient.r = (D3DVALUE)0.0;
    bmat.ambient.g = (D3DVALUE)0.0;
    bmat.ambient.b = (D3DVALUE)1.0;
	bmat.power = (D3DVALUE)0.0f;
	bmat.hTexture = 0;
    bmat.dwRampSize = 1;
    if (lpLocalD3D->lpVtbl->CreateMaterial(lpLocalD3D, &lpBmat, NULL) != D3D_OK)
	{
        OutputDebugString("CreateMaterial failed in InitView\n");
		return FALSE;
    }
    if (lpBmat->lpVtbl->SetMaterial(lpBmat, &bmat) != D3D_OK) 
	{
        OutputDebugString("SetMaterial failed in InitView\n");
		return FALSE;
    }
    if (lpBmat->lpVtbl->GetHandle(lpBmat, lpLocalD3DDev, &hBmat) != D3D_OK) 
	{
        OutputDebugString("GetHandle failed in InitView\n");
		return FALSE;
    }
	// Set the background material to the D3D viewport's background
    if (lpLocalD3DViewport->lpVtbl->SetBackground(lpLocalD3DViewport, hBmat) != D3D_OK) 
	{
        OutputDebugString("SetBackground failed in InitView\n");
		return FALSE;
    }

    /* Set the view, world and projection matrices
	   Create a buffer for matrix set commands etc. */
	MAKE_MATRIX(lpLocalD3DDev, hView, view);
    MAKE_MATRIX(lpLocalD3DDev, hProj, proj);
    MAKE_MATRIX(lpLocalD3DDev, hWorld, world);
    size = 0;
    size += sizeof(D3DINSTRUCTION) * 3;
    size += sizeof(D3DSTATE) * 5;
    memset(&debDesc, 0, sizeof(D3DEXECUTEBUFFERDESC));
    debDesc.dwSize = sizeof(D3DEXECUTEBUFFERDESC);
    debDesc.dwFlags = D3DDEB_BUFSIZE;
    debDesc.dwBufferSize = size;

	// Create an execute buffer the proper size
    if (lpLocalD3DDev->lpVtbl->CreateExecuteBuffer(lpLocalD3DDev, &debDesc, &lpD3DExCmdBuf,
                                           NULL) != D3D_OK)
	{
        OutputDebugString("CreateExecuteBuffer failed in InitView\n");
		return FALSE;
	}

    /* Lock it so it can be filled */
    if (lpD3DExCmdBuf->lpVtbl->Lock(lpD3DExCmdBuf, &debDesc) != D3D_OK)
	{
        OutputDebugString("Lock failed in InitView\n");
		return FALSE;
	}
    lpBufStart = debDesc.lpData;
    memset(lpBufStart, 0, size);
    lpPointer = lpBufStart;

    lpInsStart = lpPointer;
    OP_STATE_TRANSFORM(3, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_VIEW, hView, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_WORLD, hWorld, lpPointer);
        STATE_DATA(D3DTRANSFORMSTATE_PROJECTION, hProj, lpPointer);
    OP_STATE_LIGHT(1, lpPointer);
        STATE_DATA(D3DLIGHTSTATE_AMBIENT, RGBA_MAKE(64, 64, 64, 64), lpPointer);
	OP_STATE_RENDER(1, lpPointer);
		STATE_DATA(D3DRENDERSTATE_DITHERENABLE, bDithering ? 1 : 0, lpPointer);
    OP_EXIT(lpPointer);

    /* Setup the execute data describing the buffer */
    lpD3DExCmdBuf->lpVtbl->Unlock(lpD3DExCmdBuf);
    memset(&d3dExData, 0, sizeof(D3DEXECUTEDATA));
    d3dExData.dwSize = sizeof(D3DEXECUTEDATA);
    d3dExData.dwInstructionOffset = (ULONG) 0;
    d3dExData.dwInstructionLength = (ULONG) ((char *)lpPointer - (char*)lpInsStart);
    lpD3DExCmdBuf->lpVtbl->SetExecuteData(lpD3DExCmdBuf, &d3dExData);

	/* Execute the buffer to set the states */
    hres=lpLocalD3DDev->lpVtbl->BeginScene(lpLocalD3DDev);
	if (hres!=DD_OK)
	{
		OutputDebugString("BeginScene() failed\n");
	}
    hres=lpLocalD3DDev->lpVtbl->Execute(lpLocalD3DDev, lpD3DExCmdBuf, lpLocalD3DViewport, D3DEXECUTE_UNCLIPPED);
    if (hres!=DD_OK)
	{
		OutputDebugString("Execute() failed\n");
	}
	hres=lpLocalD3DDev->lpVtbl->EndScene(lpLocalD3DDev);
	if (hres!=DD_OK)
	{
		OutputDebugString("EndScene() failed\n");
	}

    /* We are done with the command buffer. */
    lpD3DExCmdBuf->lpVtbl->Release(lpD3DExCmdBuf);

    /* Setup a material */
    if (lpLocalD3D->lpVtbl->CreateMaterial(lpLocalD3D, &lpMat1, NULL) != D3D_OK) 
	{
        OutputDebugString("CreateMaterial (2) failed in InitView\n");
		return FALSE;
    }
    if (lpLocalD3D->lpVtbl->CreateMaterial(lpLocalD3D, &lpMat2, NULL) != D3D_OK) 
	{
        OutputDebugString("CreateMaterial (3) failed in InitView\n");
		return FALSE;
    }
    memset(&mat1, 0, sizeof(D3DMATERIAL));
    mat1.dwSize = sizeof(D3DMATERIAL);
    
    mat1.diffuse.r = (D3DVALUE)1.0;
    mat1.diffuse.g = (D3DVALUE)0.0;
    mat1.diffuse.b = (D3DVALUE)0.0;
    mat1.ambient.r = (D3DVALUE)1.0;
    mat1.ambient.g = (D3DVALUE)0.0;
    mat1.ambient.b = (D3DVALUE)0.0;
    mat1.specular.r = (D3DVALUE)1.0;
    mat1.specular.g = (D3DVALUE)0.0;
    mat1.specular.b = (D3DVALUE)0.0;
    mat1.power = (float)20.0;
    mat1.dwRampSize = 1;
    lpMat1->lpVtbl->SetMaterial(lpMat1, &mat1);
    lpMat1->lpVtbl->GetHandle(lpMat1, lpLocalD3DDev, &hMat1);
    memset(&mat2, 0, sizeof(D3DMATERIAL));
    mat2.dwSize = sizeof(D3DMATERIAL);
    mat2.diffuse.r = (D3DVALUE)0.0;
    mat2.diffuse.g = (D3DVALUE)1.0;
    mat2.diffuse.b = (D3DVALUE)0.0;
    mat2.ambient.r = (D3DVALUE)0.0;
    mat2.ambient.g = (D3DVALUE)1.0;
    mat2.ambient.b = (D3DVALUE)0.0;
    mat2.specular.r = (D3DVALUE)0.0;
    mat2.specular.g = (D3DVALUE)1.0;
    mat2.specular.b = (D3DVALUE)0.0;
    mat2.power = (float)20.0;
    mat2.dwRampSize = 1;
    lpMat2->lpVtbl->SetMaterial(lpMat2, &mat2);
    lpMat2->lpVtbl->GetHandle(lpMat2, lpLocalD3DDev, &hMat2);

    /* Setup vertices */
    memset(&v[0], 0, sizeof(D3DVERTEX) * NUM_VERTICES);

    /* V 0 */
    v[0].x = D3DVAL(0.0);
    v[0].y = D3DVAL(1.0);
    v[0].z = D3DVAL(1.0);

    v[0].nx = D3DVAL(0.0);
    v[0].ny = D3DVAL(1.0);
    v[0].nz = D3DVAL(0.0);

	PNormalize((LPD3DVECTOR)&v[0].nx);

    /* V 1 */
    v[1].x = D3DVAL(1.0);
    v[1].y = D3DVAL(0.0);
    v[1].z = D3DVAL(0.0);

    v[1].nx = D3DVAL(1.0);
    v[1].ny = D3DVAL(0.0);
    v[1].nz = D3DVAL(-1.0);

    PNormalize((LPD3DVECTOR)&v[1].nx);

    /* V 2 */
    v[2].x = D3DVAL(-1.0);
    v[2].y = D3DVAL(0.0);
    v[2].z = D3DVAL(0.0);

    v[2].nx = D3DVAL(-1.0);
    v[2].ny = D3DVAL(0.0);
    v[2].nz = D3DVAL(-1.0);

    PNormalize((LPD3DVECTOR)&v[2].nx);

    /* V 3 */
    v[3].x = D3DVAL(-1.0);
    v[3].y = D3DVAL(0.0);
    v[3].z = D3DVAL(2.0);

    v[3].nx = D3DVAL(-1.0);
    v[3].ny = D3DVAL(0.0);
    v[3].nz = D3DVAL(1.0);

    PNormalize((LPD3DVECTOR)&v[3].nx);

    /* V 4 */
    v[4].x = D3DVAL(1.0);
    v[4].y = D3DVAL(0.0);
    v[4].z = D3DVAL(2.0);

    v[4].nx = D3DVAL(1.0);
    v[4].ny = D3DVAL(0.0);
    v[4].nz = D3DVAL(1.0);

    PNormalize((LPD3DVECTOR)&v[4].nx);

    /* V 5 */
    v[5].x = D3DVAL(0.0);
    v[5].y = D3DVAL(-1.0);
    v[5].z = D3DVAL(1.0);

    v[5].nx = D3DVAL(0.0);
    v[5].ny = D3DVAL(-1.0);
    v[5].nz = D3DVAL(0.0);

    PNormalize((LPD3DVECTOR)&v[5].nx);

    /* Create an execute buffer */
    size = sizeof(D3DVERTEX) * NUM_VERTICES;
    size += sizeof(D3DSTATUS) * 1;
    size += sizeof(D3DPROCESSVERTICES) * 2;
    size += sizeof(D3DINSTRUCTION) * 8;
    size += sizeof(D3DSTATE) * 2;
    size += sizeof(D3DTRIANGLE) * NUM_TRIANGLES;
    memset(&debDesc, 0, sizeof(D3DEXECUTEBUFFERDESC));
    debDesc.dwSize = sizeof(D3DEXECUTEBUFFERDESC);
    debDesc.dwFlags = D3DDEB_BUFSIZE;
    debDesc.dwBufferSize = size;
    if (lpLocalD3DDev->lpVtbl->CreateExecuteBuffer(lpLocalD3DDev, &debDesc, &lpD3DExBuf, NULL) != D3D_OK) 
	{
        OutputDebugString("CreateExecuteBuffer failed in InitView\n");
		return FALSE;
    }
    if (lpD3DExBuf->lpVtbl->Lock(lpD3DExBuf, &debDesc) != D3D_OK) 
	{
        OutputDebugString("Lock failed in InitView\n");
		return FALSE;
    }
    lpBufStart = debDesc.lpData;
    memset(lpBufStart, 0, size);
    lpPointer = lpBufStart;

    /* Copy vertices to execute buffer */
    VERTEX_DATA(&v[0], NUM_VERTICES, lpPointer);

    /* Setup instructions in execute buffer */
    lpInsStart = lpPointer;
    OP_STATE_LIGHT(1, lpPointer);
        STATE_DATA(D3DLIGHTSTATE_MATERIAL, hMat1, lpPointer);
    OP_SET_STATUS(D3DSETSTATUS_ALL, D3DSTATUS_DEFAULT, 2048, 2048, 0, 0, lpPointer);
    OP_PROCESS_VERTICES(1, lpPointer);
        PROCESSVERTICES_DATA(D3DPROCESSVERTICES_TRANSFORMLIGHT, 0, 5, lpPointer);
    OP_STATE_LIGHT(1, lpPointer);
        STATE_DATA(D3DLIGHTSTATE_MATERIAL, hMat2, lpPointer);
    OP_PROCESS_VERTICES(1, lpPointer);
        PROCESSVERTICES_DATA(D3DPROCESSVERTICES_TRANSFORMLIGHT, 5, 1, lpPointer);

    /* Make sure that the triangle data (not OP) will be QWORD aligned */
    if (QWORD_ALIGNED(lpPointer)) 
	{
        OP_NOP(lpPointer);
    }
    OP_TRIANGLE_LIST(NUM_TRIANGLES, lpPointer);
        lpTri = (LPD3DTRIANGLE)lpPointer;
        for (i = 0; i < NUM_TRIANGLES; i++) 
		{
            lpTri->v1 = t[i][0];
            lpTri->v2 = t[i][1];
            lpTri->v3 = t[i][2];
            lpTri->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE;
            lpTri++;
        }
        lpPointer = (void*)lpTri;
    OP_EXIT(lpPointer);

    /* Setup the execute data */
    lpD3DExBuf->lpVtbl->Unlock(lpD3DExBuf);
    memset(&d3dExData, 0, sizeof(D3DEXECUTEDATA));
    d3dExData.dwSize = sizeof(D3DEXECUTEDATA);
    d3dExData.dwVertexCount = NUM_VERTICES;
    d3dExData.dwInstructionOffset = (ULONG) ((char *)lpInsStart - (char *)lpBufStart);
    d3dExData.dwInstructionLength = (ULONG) ((char *)lpPointer - (char*)lpInsStart);
    lpD3DExBuf->lpVtbl->SetExecuteData(lpD3DExBuf, &d3dExData);

    /* Setup lights */
    memset(&light, 0, sizeof(D3DLIGHT));
    light.dwSize = sizeof(D3DLIGHT);
    light.dltType = D3DLIGHT_DIRECTIONAL;
    light.dcvColor.r = D3DVAL(1.0);
    light.dcvColor.g = D3DVAL(1.0);
    light.dcvColor.b = D3DVAL(1.0);
    light.dcvColor.a = D3DVAL(1.0);
    light.dvDirection.x = D3DVAL(1.0);
    light.dvDirection.y = D3DVAL(0.0);
    light.dvDirection.z = D3DVAL(0.0);
    if (lpLocalD3D->lpVtbl->CreateLight(lpLocalD3D, &lpD3DLight, NULL) != D3D_OK) 
	{
        OutputDebugString("CreateLight failed in InitView\n");
		return FALSE;
    }
    if (lpD3DLight->lpVtbl->SetLight(lpD3DLight, &light) != D3D_OK) 
	{
        OutputDebugString("SetLight failed in InitView\n");
		return FALSE;
    }
    if (lpLocalD3DViewport->lpVtbl->AddLight(lpLocalD3DViewport, lpD3DLight) != D3D_OK) 
	{
        OutputDebugString("AddLight failed in InitView\n");
		return FALSE;
    }
    
	/* Release local D3D objects */
	RELEASE(lpLocalD3DViewport);
	RELEASE(lpLocalD3DDev);
	RELEASE(lpLocalD3D);

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : ReleaseView
 * Returns        : Nothing
 * Global Used    : None
 * Description    : Application's rendering function
 *					D3DShell passes the viewport variable to this function 
 *					so you can delete any lights you created previously 
 *******************************************************************************/
void ReleaseView(LPDIRECT3DVIEWPORT2 lpView)
{
    LPDIRECT3DVIEWPORT	lpLocalD3DViewport;
	HRESULT				hres;
	
	/* Get DirectX 3.0 interfaces */
	
	/* Retrieve a D3DVIEWPORT interface from D3DVIEWPORT2 */
	hres=lpView->lpVtbl->QueryInterface(lpView, &IID_IDirect3DViewport, &lpLocalD3DViewport);
	if (hres!=DD_OK)
	{
		OutputDebugString("QueryInterface for Direct3DViewport failed (in ReleaseView)\n");
	}
	
	/* Delete light */
	if (lpLocalD3DViewport)
	{
		lpLocalD3DViewport->lpVtbl->DeleteLight(lpLocalD3DViewport, lpD3DLight);
	}
	RELEASE(lpLocalD3DViewport);
    
	/* Release memory */
	RELEASE(lpD3DExBuf);
}

