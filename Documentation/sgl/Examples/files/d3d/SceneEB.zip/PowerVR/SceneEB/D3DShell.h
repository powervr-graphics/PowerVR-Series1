/*****************************************************************************
  Name : D3DShell.h		v1.1.5
  Date : May 1998
  Platform : ANSI compatible

  Header file to be used with D3DShell.c

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/

#ifndef _D3DSHELL_H_
#define _D3DSHELL_H_


#ifdef __cplusplus
extern "C" {
#endif

/* Enum */
enum _D3DShellPrefs
{
	FORCE_PRIMARYDEVICE		=0x00000001,	// Primary device will be used by default (no other DDraw driver will appear in the menu)
	FORCE_SECONDARYDEVICE	=0x00000002,	// Secondary device will be used by default (no DDraw driver will appear in the menu)
	FORCE_ZBUFFER_ON		=0x00000004,	// Z-Buffer will be forced On and will not appear in the menu
	FORCE_ZBUFFER_OFF		=0x00000008,	// Z-Buffer will be forced Off and will not appear in the menu
	FORCE_SINGLEBUFFER		=0x00000010,	// Single Buffer will be forced On and will not appear in the menu
	FORCE_DOUBLEBUFFER		=0x00000020,	// Double Buffer will be forced On and will not appear in the menu
	FORCE_TRIPLEBUFFER		=0x00000040,	// Triple Buffer will be forced On and will not appear in the menu
	FORCE_FULLSCREEN		=0x00000080,	// FullScreen mode will be used all the time (Unable to got to Window mode)
	DISABLE_SINGLEBUFFER	=0x00000100,	// Single Buffer choice will not appear in the menu 
	DISABLE_TRIPLEBUFFER	=0x00000200,	// Triple Buffer choice will not appear in the menu
	DISABLE_VERYHIGHRES		=0x00000400,	// Disable resolution above 1024x768
	DISABLE_RESIZING		=0x00000800,	// Prevent the application to be resized by mouse drag
	DEFAULT_SECONDARYDEVICE =0x00001000,	// Secondary device will be selected by default
	DEFAULT_ZBUFFER_ON		=0x00002000,	// Application will start with a Z-Buffer as default
	DEFAULT_FULLSCREEN		=0x00004000,	// Application will start FullScreen by default
	FORCE_CLEAR_ON			=0x00008000,	// Viewport clear will be forced On and will not appear in the menu
	FORCE_CLEAR_OFF			=0x00010000,	// Viewport clear will be forced Off and will not appear in the menu
	DEFAULT_CLEAR_ON		=0x00020000,	// Viewport clear is On by default
	DISABLE_RAMP_MODE		=0x00040000,	// Disable Ramp emulation D3D device. This choice will not appear in the menu.
	DISABLE_MMX_MODE		=0x00080000,	// Disable MMX emulation D3D device. This choice will not appear in the menu.
	NO_MEMORY_CHECK			=0x00100000 	// Video memory will not be checked, thus attempting to create all variables without checking if there is enough memory for them
} D3DShellPrefs;


/* D3D Shell helper functions declarations */

/* This function is used to pass preferences to the D3D FrontEnd */
void D3DShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel, 
							HICON hUserIcon, enum D3DShellPrefs dwFlags);

/* This function enables the user to display text on screen */
void D3DShellSetDisplayText(char *pszText, int nX, int nY);

/* This function loads a BMP texture and returns its handle */
D3DTEXTUREHANDLE D3DShellLoadBMP(char *lpName, BOOL bTranslucent);

/* This function is for development only for now */
LPDIRECTDRAWSURFACE	D3DShellGetTextureSurface(D3DTEXTUREHANDLE hTexture);
LPDIRECTDRAWSURFACE	D3DShellGetTextureSurfaceSM(D3DTEXTUREHANDLE hTexture);


/*******************************
** User interaction functions **
*******************************/

/* These functions have to exist in the scene file (e.g. scene.c).
   They are used to interract with the D3D Shell */

void	InitApplication();
/*
InitApplication()
  
This function will be called by the D3D Shell before anything happens, at the very
beginning of the D3DShell WinMain() function. That's the only time this function
will be called. This function enables the user to perform any initialisation before 
the program is actually run.
From this function the user can call D3DShellSetPreferences() to set default
values or submit a menu to the D3D Shell. A prototype of the function is :
	
void D3DShellSetPreferences(char *pszApplicationName, HMENU	hUserMenuID, 
							HICON hUserIcon, enum D3DFrontEndPrefs dwFlags);

A list of flags and their functions can be found in the D3DShell.h file.
*/


void QuitApplication();
/*
QuitApplication()

This function will be called by the D3D Shell just before finishing the program.
It enables the user to release any memory allocated before.
*/


void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
/*
UserWindowProc(hWnd, message, wParam, lParam)

This function is the user Window Procedure function. It enables the user to retrieve
menu choices, keystrokes or other messages (WM_TIMER for instance).
If you don't want to use this function, put nothing in it :
    
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Nothing !
}

The D3D Shell processes many window messages. If the user needs to 
process these messages in his/her application, he/she should make sure
NOT to return DefWindowProc() as it will prevent the D3D Shell WindowProc
to do its own processing for these messages.
The window messages processed by the D3D Shell are :

WM_ENTERMENULOOP, WM_EXITMENULOOP,
WM_ACTIVATEAPP,
WM_SYSCOMMAND,
WM_SIZE, WM_MOVE, WM_SIZING, WM_MOVING,
WM_PAINT,
WM_DESTROY, WM_QUIT

Note : do NOT process the VK_ESCAPE key, as it is already used by the 
  	   D3D Shell to quit the application.
*/


BOOL RenderScene(LPDIRECT3DDEVICE2 lpDev2, LPDIRECT3DVIEWPORT2 lpView2);
/*
RenderScene(lpDev2, lpView2)

That's the main user function in which you have to do your own rendering.
Pointers to the D3D device (LPDIRECT3DDEVICE2) and the D3D viewport
(LPDIRECT3DVIEWPORT2) are passed to this function so you can use them
to control your rendering (Render states, lights, etc...)
In this function you only have to do your transformations (if needed) and
use DrawPrimitive or Execute Buffers.
*/


BOOL InitView(LPDIRECTDRAW2 lpDD2, LPDIRECT3D2 lpD3D2, LPDIRECT3DDEVICE2 lpDev2, 
			  LPDIRECT3DVIEWPORT2 lpView2, DWORD dwWidth, DWORD dwHeight);
/*
InitView(lpDD2, lpD3D2, lpDev2, lpView2, dwWidth, dwHeight)

This function enables the user to create execute buffers, materials, set 
rendering values, load textures, etc... This function will be called each 
time the surfaces and objects will be recreated (i.e. switching to FullScreen, 
enabling Z-Buffer, etc...)
dwWidth and dwHeight are the current dimensions of the rendering surface.
*/

void ReleaseView(LPDIRECT3DVIEWPORT2 lpView2);
/*
ReleaseView(lpView2)

This function enables the user to release any devices he/she has created 
in the InitView function.
The function will be called each time the surfaces and variables have to 
be recreated. A pointer to the viewport is passed, as the user might 
need it to delete any lights attached to the viewport, for instance.
*/

#ifdef __cplusplus
}
#endif

#endif
