/*****************************************************************************
  Name : Easy3D.c
  Date : February 1998
  Platform : ANSI compatible
 
  Description : some helper functions dealing with 3D transformations and
				matrices.

  Notes : of course these functions are very simple and unoptimised.
		  Look-up tables could be used as a first optimisation.

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/
#include <math.h>
#include <stdio.h>
#include <d3d.h>
#include "Easy3D.h"


// Initializes matrix to zero
D3DMATRIX ZeroMatrix()  
{
    D3DMATRIX ret;
	
	ret._11=0.0f;			ret._12=0.0f;		ret._13=0.0f;			ret._14=0.0f;	
	ret._21=0.0f;			ret._22=0.0f;		ret._23=0.0f;			ret._24=0.0f;	
	ret._31=0.0f;			ret._32=0.0f;		ret._33=0.0f;			ret._34=0.0f;	
	ret._41=0.0f;			ret._42=0.0f;		ret._43=0.0f;			ret._44=0.0f;	
    
    return ret;
}   


// Initializes matrix to identity
D3DMATRIX IdentityMatrix()
{
	D3DMATRIX ret=ZeroMatrix();

	ret._11=1.0f;			ret._12=0.0f;		ret._13=0.0f;			ret._14=0.0f;	
	ret._21=0.0f;			ret._22=1.0f;		ret._23=0.0f;			ret._24=0.0f;	
	ret._31=0.0f;			ret._32=0.0f;		ret._33=1.0f;			ret._34=0.0f;	
	ret._41=0.0f;			ret._42=0.0f;		ret._43=0.0f;			ret._44=1.0f;	

	return ret;
}


// Multiply two matrices together
D3DMATRIX MatrixMult(const D3DMATRIX a, const D3DMATRIX b)  
{
    D3DMATRIX ret;
	
	ret._11 = a._11*b._11 + a._12*b._21 + a._13*b._31 + a._14*b._41;
	ret._12 = a._11*b._12 + a._12*b._22 + a._13*b._32 + a._14*b._42;
	ret._13 = a._11*b._13 + a._12*b._23 + a._13*b._33 + a._14*b._43;
	ret._14 = a._11*b._14 + a._12*b._24 + a._13*b._34 + a._14*b._44;

	ret._21 = a._21*b._11 + a._22*b._21 + a._23*b._31 + a._24*b._41;
	ret._22 = a._21*b._12 + a._22*b._22 + a._23*b._32 + a._24*b._42;
	ret._23 = a._21*b._13 + a._22*b._23 + a._23*b._33 + a._24*b._43;
	ret._24 = a._21*b._14 + a._22*b._24 + a._23*b._34 + a._24*b._44;

	ret._31 = a._31*b._11 + a._32*b._21 + a._33*b._31 + a._34*b._41;
	ret._32 = a._31*b._12 + a._32*b._22 + a._33*b._32 + a._34*b._42;
	ret._33 = a._31*b._13 + a._32*b._23 + a._33*b._33 + a._34*b._43;
	ret._34 = a._31*b._14 + a._32*b._24 + a._33*b._34 + a._34*b._44;

	ret._41 = a._41*b._11 + a._42*b._21 + a._43*b._31 + a._44*b._41;
	ret._42 = a._41*b._12 + a._42*b._22 + a._43*b._32 + a._44*b._42;
	ret._43 = a._41*b._13 + a._42*b._23 + a._43*b._33 + a._44*b._43;
	ret._44 = a._41*b._14 + a._42*b._24 + a._43*b._34 + a._44*b._44;

	return ret;
}   


// Make a translation matrix
D3DMATRIX Translate(const float dx, const float dy, const float dz)
{
    D3DMATRIX ret;

	ret._11=1.0f;			ret._12=0.0f;		ret._13=0.0f;			ret._14=0.0f;	
	ret._21=0.0f;			ret._22=1.0f;		ret._23=0.0f;			ret._24=0.0f;	
	ret._31=0.0f;			ret._32=0.0f;		ret._33=1.0f;			ret._34=0.0f;	
	ret._41=dx;				ret._42=dy;			ret._43=dz;				ret._44=1.0f;	
    
    return ret;
}   


// Make a X rotation matrix
D3DMATRIX RotateX(const float rads)
{
    D3DMATRIX ret;
	float    cosine, sine;

    cosine=(D3DVALUE)cos(rads);		// Should be changed for a look-up 
    sine=(D3DVALUE)sin(rads);
    
	ret._11=1.0f;			ret._12=0.0f;		ret._13=0.0f;			ret._14=0.0f;	
	ret._21=0.0f;			ret._22=cosine;		ret._23=sine;			ret._24=0.0f;	
	ret._31=0.0f;			ret._32=-sine;		ret._33=cosine;			ret._34=0.0f;	
	ret._41=0.0f;			ret._42=0.0f;		ret._43=0.0f;			ret._44=1.0f;	
	
    return ret;
}   


// Make a Y rotation matrix
D3DMATRIX RotateY(const float rads)
{
    D3DMATRIX ret;
	float    cosine, sine;

    cosine=(D3DVALUE)cos(rads);		// Should be changed for a look-up 
    sine=(D3DVALUE)sin(rads);
	
	ret._11=cosine;			ret._12=0.0f;		ret._13=-sine;			ret._14=0.0f;	
	ret._21=0.0f;			ret._22=1.0f;		ret._23=0.0f;			ret._24=0.0f;	
	ret._31=sine;			ret._32=0.0f;		ret._33=cosine;			ret._34=0.0f;	
	ret._41=0.0f;			ret._42=0.0f;		ret._43=0.0f;			ret._44=1.0f;	
	
    return ret;
}   


// Make a Z rotation matrix
D3DMATRIX RotateZ(const float rads)
{
    D3DMATRIX ret;
	float    cosine, sine;

    cosine=(D3DVALUE)cos(rads);		// Should be changed for a look-up 
    sine=(D3DVALUE)sin(rads);
	
	ret._11=cosine;			ret._12=sine;		ret._13=0.0f;			ret._14=0.0f;	
	ret._21=-sine;			ret._22=cosine;		ret._23=0.0f;			ret._24=0.0f;	
	ret._31=0.0f;			ret._32=0.0f;		ret._33=1.0f;			ret._34=0.0f;	
	ret._41=0.0f;			ret._42=0.0f;		ret._43=0.0f;			ret._44=1.0f;	

    return ret;
}   


// Make a scaling matrix
D3DMATRIX Scale(const float sizeX, const float sizeY, const float sizeZ)
{
	D3DMATRIX ret;
	
	ret._11=sizeX;			ret._12=0.0f;		ret._13=0.0f;			ret._14=0.0f;	
	ret._21=0.0f;			ret._22=sizeY;		ret._23=0.0f;			ret._24=0.0f;	
	ret._31=0.0f;			ret._32=0.0f;		ret._33=sizeZ;			ret._34=0.0f;	
	ret._41=0.0f;			ret._42=0.0f;		ret._43=0.0f;			ret._44=1.0f;	
 
   return ret;
}


// Compute dot product
D3DVALUE DotProduct(D3DVECTOR VectorA, D3DVECTOR VectorB)
{
	return (VectorA.x*VectorB.x+VectorA.y*VectorB.y+VectorA.z*VectorB.z);
}

// Compute Cross Product
D3DVECTOR CrossProduct(const D3DVECTOR v1, const D3DVECTOR v2)
{
    D3DVECTOR result;

    result.x = v1.y * v2.z - v1.z * v2.y;
    result.y = v1.z * v2.x - v1.x * v2.z;
    result.z = v1.x * v2.y - v1.y * v2.x;
    return result;
}

// Normalize a vector
D3DVECTOR Normalize(D3DVECTOR v)
{
    float vx, vy, vz, inv_mod;
	D3DVECTOR	Result;

    vx = v.x;	
    vy = v.y;
    vz = v.z;
    if ((vx == 0) && (vy == 0) && (vz == 0))
        return v;
    inv_mod = (float)(1.0 / sqrt(vx * vx + vy * vy + vz * vz));
    Result.x = vx * inv_mod;
    Result.y = vy * inv_mod;
    Result.z = vz * inv_mod;
	return Result;
}


// Normalize a vector
void PNormalize(D3DVECTOR *v)
{
    float vx, vy, vz, inv_mod;
	
    vx = v->x;	
    vy = v->y;
    vz = v->z;
    if ((vx == 0) && (vy == 0) && (vz == 0))
        return ;
    inv_mod = (float)(1.0 / sqrt(vx * vx + vy * vy + vz * vz));
    v->x = vx * inv_mod;
    v->y = vy * inv_mod;
	v->z = vz * inv_mod;
}


void DisplayMatrixInDebug(D3DMATRIX *Mat)
{
	char	pszTmp[300];
	
	sprintf(pszTmp, "%f	%f	%f	%f\n%f	%f	%f	%f\n%f	%f	%f	%f\n%f	%f	%f	%f\n",
	Mat->_11, Mat->_12, Mat->_13, Mat->_14, 
	Mat->_21, Mat->_22, Mat->_23, Mat->_24, 
	Mat->_31, Mat->_32, Mat->_33, Mat->_34,
	Mat->_41, Mat->_42, Mat->_43, Mat->_44);
	OutputDebugString(pszTmp);
}


/* Create a View matrix */
D3DMATRIX CreateViewMatrix(const D3DVECTOR from,      // camera location
						   const D3DVECTOR at,        // camera look-at target
						   const D3DVECTOR world_up,  // world's up, usually 0, 1, 0
						   const float roll)          // clockwise roll around
													//    viewing direction, 
													//    in radians
{
    D3DMATRIX  view = IdentityMatrix();
    D3DVECTOR  up, right, view_dir;
	D3DVECTOR  minus;

	minus.x=at.x-from.x;
	minus.y=at.y-from.y;
	minus.z=at.z-from.z;
    
    view_dir = Normalize(minus);
    right = CrossProduct(world_up, view_dir);
    up = CrossProduct(view_dir, right);
    
    right = Normalize(right);
    up = Normalize(up);
    
    view._11 = right.x;
    view._21 = right.y;
    view._31 = right.z;
    view._12 = up.x;
    view._22 = up.y;
    view._32 = up.z;
    view._13 = view_dir.x;
    view._23 = view_dir.y;
    view._33 = view_dir.z;
    
    view._41 = -DotProduct(right, from);
    view._42 = -DotProduct(up, from);
    view._43 = -DotProduct(view_dir, from);
    
    if (roll != 0.0f) 
	{
        view = MatrixMult(RotateZ(-roll), view); 
    }
    
    return view;
}


D3DMATRIX CreateProjectionMatrix(const float near_plane,     // distance to near clipping plane
								 const float far_plane,      // distance to far clipping plane
								 const float fov)            // field of view angle, in radians
{
    float    c, s, Q;
	D3DMATRIX	ret;

    c = (float)cos(fov*0.5);
    s = (float)sin(fov*0.5);
    Q = s/(1.0f - near_plane/far_plane);

    ret = ZeroMatrix();
    ret._11 = c;
    ret._22 = c;
    ret._33 = Q;

    ret._43 = -Q*near_plane;
    ret._34 = s;
    return ret;
}