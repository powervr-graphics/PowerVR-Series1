//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UserEB.rc
//
#define ID_USERMENU                     101
#define ID_USER1_USER1A                 40001
#define ID_ROTATION_ROTATEX             40001
#define ID_USER1_USER1B                 40002
#define ID_ROTATION_ROTATEY             40002
#define ID_USER1_USER1C                 40003
#define ID_ROTATION_ROTATEZ             40003
#define ID_USER2_USER2A                 40004
#define ID_USER2_USER2B_USER2BA         40005
#define ID_USER2_USER2B_USER2BBETA      40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
