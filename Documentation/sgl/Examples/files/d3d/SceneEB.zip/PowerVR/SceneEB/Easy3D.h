/*****************************************************************************
  Name : Easy3D.h
  Date : February 1998
  Platform : ANSI compatible
 
  Description : Header file of Easy3D.c.
				Contains prototypes of all functions in Easy3D.c
  
  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/

#ifndef PI
#define PI 3.14159f
#endif

/* Prototypes */
D3DMATRIX	ZeroMatrix();
D3DMATRIX	IdentityMatrix(); 
D3DMATRIX	Translate(const float dx, const float dy, const float dz);
D3DMATRIX	MatrixMult(const D3DMATRIX a, const D3DMATRIX b);
D3DMATRIX	Scale(const float sizeX, const float sizeY, const float sizeZ);
D3DMATRIX	RotateX(const float size);
D3DMATRIX	RotateY(const float size);
D3DMATRIX	RotateZ(const float size);

D3DVALUE	DotProduct(D3DVECTOR VectorA, D3DVECTOR VectorB);
D3DVECTOR	CrossProduct(const D3DVECTOR v1, const D3DVECTOR v2);
D3DVECTOR	Normalize(D3DVECTOR v);
void		PNormalize(D3DVECTOR *v);

void	  DisplayMatrixInDebug(D3DMATRIX *Mat);

D3DMATRIX CreateViewMatrix(const D3DVECTOR from, const D3DVECTOR at, const D3DVECTOR world_up, const float roll);
D3DMATRIX CreateProjectionMatrix(const float near_plane, const float far_plane, const float fov);