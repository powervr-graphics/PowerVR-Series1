/* sglwin.h */

#ifndef SGLWIN
#define SGLWIN

extern int	    SetupScene ();
extern void	    NextFrame();
extern void	    Finish();

#define ERR_CREATE_SCREEN_DEVICE	-1
#define ERR_CREATE_VIEWPORT			-2

#endif
