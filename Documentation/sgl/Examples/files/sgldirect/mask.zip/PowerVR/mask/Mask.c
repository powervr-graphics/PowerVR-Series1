
/*-----------------------------------------------------------------------------
   Name   : MASK  ( PowerVR SGL-Direct )
   Author : Carlos Sarria   - send comments to csarria@videologic.com
   Date   : July 1997
   Project: mask.c + frontend.c + sgl.lib
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#include <math.h>
#include <malloc.h>
#include <memory.h>
#include <ddraw.h>

#include "sgl.h"
#include "frontend.h"
#include "mask.h"   /* This is the file with 3D data */

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */

#define PI	3.1416f

int   Device, Init = TRUE, frame = 0,  Texture[100], TempTex;
int   TPos = 800, NumP = 10, LH= 128;
float XAng = 0, YAng =0, XAng1 = 0.0, YAng1 =0.0,  Shad[255];
char  MCol[3][20*30*4];

SGLCONTEXT SGLContext;
SGLVERTEX  *TempVert[NUM_MESHES];
float      *TempNormals[NUM_MESHES];
sgl_intermediate_map BuffTex[10];

#define RGBColour(r, g, b) ((sgl_uint32) (((sgl_uint32)(r&0x000000FF)<<16) | ((sgl_uint32)(g&0x000000FF) << 8) | (sgl_uint32)(b&0x000000FF)))

void InitMeshes       (void);
void SetupContext     (void);
void SetupTextures    (void);
void DrawAll          (void);
void Shading          (int);
void UpdateVertex     (int Num);
void UpdateReflection (int Num);
void MoveBalls        (void);
void PutBallsOn       (void);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device                                                         */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
	Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

    SetupTextures (); 
	SetupContext  ();
    InitMeshes ();

    SetCursor (NULL);   /* This hides the pointer */

	return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContext                                                     */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame()
{
   sgltri_startofframe (&SGLContext);
      	DrawAll ();
   sgltri_render   (&SGLContext);

   frame++;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/				   
void Finish()
{
	FreeAllBMPTextures ();
	sgl_delete_device(Device);	
	Init = FALSE;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  DrawAll                                                         */ 
/*  Inputs          :  None                                                            */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, XAng1, YAng1, SGLContext                            */
/*  Description     :  Updates and draws all the meshes in the model.                  */
/*  Note            :  The definition of Mesh[i] struct is in logo.h                   */
/*-------------------------------------------------------------------------------------*/
void DrawAll()
{
register i;

    YAng += YAng1;    /* Scene angles are changed every frame */
    XAng += XAng1;    /* XAng1 and YAng1 are the speed        */
    MoveBalls ();    
    PutBallsOn();     /* Balls are drawn on the reflection map */

    for (i=0; i<NUM_MESHES; i++){
       
        if (frame==0) UpdateVertex(i); 
        else if (i==REFLECT || i==MASK) UpdateVertex  (i);
        
        if (i==REFLECT){UpdateReflection (i);}
        if (i==MASK) Shading (i); /* We do not want to shade the reflection of the mask */

		/* Updating texture parameters for each mesh of the model */
	    SGLContext.nTextureName = Texture[Mesh[i].Material];
        SGLContext.u32Flags     = SGLTT_TEXTURE | SGLTT_GOURAUD  | SGLTT_BILINEAR;

		/* The mask has got two faces */
        if (i==MASK) SGLContext.bCullBackfacing = FALSE;
        else         SGLContext.bCullBackfacing = TRUE;
  
        if (i==REFLECT){ 
           /* Global Translucent for the reflection */
           SGLContext.u32Flags =  SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_GLOBALTRANS  | SGLTT_BILINEAR;
           SGLContext.u32GlobalTrans = (sgl_uint32) (0x0000FF & LH);
        }

		/* And now... triangles  */
	    sgltri_triangles (&SGLContext, Mesh[i].NumFaces, (int(*)[3])Mesh[i].Faces, TempVert[i]);
    } 
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupTextures                                                    */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : NumMaterials, Texture, MatInfo                                   */
/*  Description     : Loads BMP files getting the information from MatInfo struct      */
/*                    Creates new textures changing colours in the intermediate map.   */
/*-------------------------------------------------------------------------------------*/	
void SetupTextures (void)
{
register i,j;
unsigned char Red, Green, Blue, Alfa;
int cont=0;


    BuffTex[5] = ConvertBMPtoSGL   (MatInfo[0].MatFile, FALSE); /* Reflection background */

 	/* This BMP is a little ball. I have used a front ball shot.  */
	/* I know the back one is more correct, but doesn't look good */
    BuffTex[6] = ConvertBMPtoSGL   ("backrfl.bmp", TRUE);     

    BuffTex[0] = ConvertBMPtoSGL   (MatInfo[0].MatFile, FALSE); /* Buffer map for refletion  */
    Texture[0] = sgl_create_texture( sgl_map_16bit, sgl_map_128x128, FALSE, FALSE, &BuffTex[5],  NULL);

    BuffTex[4] = ConvertBMPtoSGL   (MatInfo[4].MatFile, FALSE);
    Texture[4] = sgl_create_texture( sgl_map_16bit, sgl_map_256x256, FALSE, FALSE, &BuffTex[4],  NULL);

    BuffTex[1] = ConvertBMPtoSGL   (MatInfo[1].MatFile, TRUE);   /* Red ball */
    Texture[1] = sgl_create_texture( sgl_map_trans16, sgl_map_256x256, FALSE, FALSE, &BuffTex[1],  NULL);

    BuffTex[2] = ConvertBMPtoSGL   (MatInfo[2].MatFile, TRUE);   /* Red ball */
    BuffTex[3] = ConvertBMPtoSGL   (MatInfo[3].MatFile, TRUE);   /* Red ball */

    /* Changing ball colours */
	for (i=0; i<254*255; i++)
	{
        Red   = (BuffTex[1].pixels+i)->red;
        Green = (BuffTex[1].pixels+i)->green;
        Blue  = (BuffTex[1].pixels+i)->blue;

        ((BuffTex[2].pixels)+i)->red  = Red;
        ((BuffTex[2].pixels)+i)->blue = Red;
      
        ((BuffTex[3].pixels)+i)->red  = Blue;
        ((BuffTex[3].pixels)+i)->blue  = Red;
    }
     
    Texture[2] = sgl_create_texture( sgl_map_trans16, sgl_map_256x256, FALSE, FALSE, &BuffTex[2],  NULL);
    Texture[3] = sgl_create_texture( sgl_map_trans16, sgl_map_256x256, FALSE, FALSE, &BuffTex[3],  NULL);

	/* Changing colours of small balls for the mask reflection */
    cont = 0;
    for (j=0;j<20;j++)
	{
        for (i=0; i<20; i++)
		{
            Red   = (BuffTex[6].pixels+i+j*128)->red;
            Green = (BuffTex[6].pixels+i+j*128)->green;
            Blue  = (BuffTex[6].pixels+i+j*128)->blue;
            Alfa  = (BuffTex[6].pixels+i+j*128)->alpha;
         
                   MCol[0][cont]   = Alfa; 
                   MCol[1][cont]   = Alfa; 
                   MCol[2][cont++] = Alfa; 

                   MCol[0][cont]   = Red; 
                   MCol[1][cont]   = Red; 
                   MCol[2][cont++] = Blue;

                   MCol[0][cont]   = Green;
                   MCol[1][cont]   = Green;
                   MCol[2][cont++] = Green; 
           
                   MCol[0][cont]   = Blue; 
                   MCol[1][cont]   = Red;
                   MCol[2][cont++] = Red;
		}
   }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupContext                                                     */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : SGLContext                                                       */
/*  Description     : Sets default values for the render context.                      */
/*-------------------------------------------------------------------------------------*/	
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 5;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = ENABLE_SHADOWS;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.RenderRegions        = 0;
    SGLContext.n32MipmapOffset      = 0;
    SGLContext.u32GlobalTrans       = 255;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : InitMeshes                                                       */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Shad, Mesh, TempVert, TempNormals                                */
/*  Description     : Sets initials values for meshes managing                         */
/*-------------------------------------------------------------------------------------*/	
void InitMeshes (void)
{
float  x, z, y, DX;
register i, j, k=0;

    /* This function is in mask.h and creates an array of structures with 3D data */
    CreateMeshesArray ();
   
    /* Shad is a 255 values array whit information for smooth shading */
    for (i=0; i<120; i++)  Shad[k++] = (float)(120-i)/480.0;
    for (i=0; i<100; i++)  Shad[k++] = (float) i/100.0;
    for (i=0; i<35;  i++)  Shad[k++] = 1.0f;

	/* Memory allocation for TempVert and TempNormals */ 
    for (i=0; i<NUM_MESHES; i++)
	{
         TempVert[i] = (SGLVERTEX *) malloc (Mesh[i].NumVertex*sizeof(SGLVERTEX));
         TempNormals[i] = (float *)  malloc (Mesh[i].NumVertex*sizeof(float)*3);
	}
	/* Setting UV values for all the meshes and calculating TempNormals for reflections */
    for (j=0; j<NUM_MESHES;j++)
	{
         for (i=0; i<Mesh[j].NumVertex; i++)
		 {
            (TempVert[j]+i)->fUOverW    =  (Mesh[j].TexMap) ? *(Mesh[j].UV+i*2+0) : 0;
            (TempVert[j]+i)->fVOverW    =  (Mesh[j].TexMap) ? *(Mesh[j].UV+i*2+1) : 0; 
            (TempVert[j]+i)->u32Colour  =  0xFFFFFF; 

			/* TempNormals are calculated with the normal and the position of each vertex */
            x =  (*(Mesh[j].Vertex+i*3+0) - Mesh[j].Center[0]);
            y =  (*(Mesh[j].Vertex+i*3+1) - Mesh[j].Center[1]);
            z =  (*(Mesh[j].Vertex+i*3+2) - Mesh[j].Center[2]);

            DX = sqrt (x*x+y*y+z*z);
                      
            *(TempNormals[j]+i*3+0) = ((*(Mesh[j].Normals+i*3+0) +x/DX)/2.0);
            *(TempNormals[j]+i*3+1) = ((*(Mesh[j].Normals+i*3+1) +y/DX)/2.0);
            *(TempNormals[j]+i*3+2) = ((*(Mesh[j].Normals+i*3+2) +z/DX)/2.0);
		 }
	}

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : UpdateVertex                                                     */ 
/*  Inputs          : Num (the mesh in the model)                                      */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : XAng, YAng                                                       */
/*  Description     : Turns vertices around two axes.                                  */
/*-------------------------------------------------------------------------------------*/
void UpdateVertex (int Num)
{
float CamFocus = 1000.0;
float CosX, SinX, CosY, SinY, x, z, y , CamZ;
sgl_vector Temp;
int i, j=0, k=0, l=0;

CosX = cos(XAng); SinX = sin(XAng);
CosY = cos(YAng); SinY = sin(YAng);
  
    for (i=0; i<Mesh[Num].NumVertex; i++)
	{
         x = *(Mesh[Num].Vertex+k++);
         y = *(Mesh[Num].Vertex+k++);
         z = *(Mesh[Num].Vertex+k++);

		  /* Temp is the outcome vertex after the rotation */
         Temp[0]  = x * CosY - z * SinY;
         Temp[2]  = z * CosY + x * SinY;

         z        = Temp[2];
         Temp[1]  = y * CosX - z * SinX;
         Temp[2]  = z * CosX + y * SinX + TPos;

         if (Temp[2] <=0.0) Temp[2] = 0.001f;
         
		 /* We store the SGL vertex in TempVert */
         CamZ = 1.0/(Temp[2]);
    	 (TempVert[Num]+i)->fX    =  CamFocus * CamZ * Temp[0] + 320;
         (TempVert[Num]+i)->fY    = -CamFocus * CamZ * Temp[1] + 240;
	     (TempVert[Num]+i)->fInvW =  CamZ;
    }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : Shading                                                          */ 
/*  Inputs          : Num                                                              */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Light1, MatInfo, Mesh, TempVert                                  */
/*  Description     : Shades a mesh.                                                   */
/*-------------------------------------------------------------------------------------*/
void Shading (int Num)
{
float CosX, SinX, CosY, SinY, x, z, y;
float Colour[3] = {0.2f, 0.5f, 0.9f}, TCo, Dir, LTemp[3],  Ligth1[3] = { -1, 1, -1};
register l=0, i, k=0, Val;
sgl_uint32 Col;

    /* We just rotate the light vector in the opposite direction instead of rotating all the normals */
    Dir = sqrt (Ligth1[0]*Ligth1[0]+Ligth1[1]*Ligth1[1]+Ligth1[2]*Ligth1[2]);
    x = Ligth1[0]/Dir; 
	y = Ligth1[1]/Dir; 
	z = Ligth1[2]/Dir;

    CosX = cos(-XAng); SinX = sin(-XAng);
    CosY = cos(-YAng); SinY = sin(-YAng);
    
    LTemp[1]  = y * CosX - z * SinX;
    LTemp[2]  = z * CosX + y * SinX; 
     
    z = LTemp[2];
    LTemp[0]  = x * CosY - z * SinY;
    LTemp[2]  = z * CosY + x * SinY;

    k = Mesh[Num].Material;

    for (i=0; i<Mesh[Num].NumVertex; i++){
    	x = *(Mesh[Num].Normals+l++);
        y = *(Mesh[Num].Normals+l++);
        z = *(Mesh[Num].Normals+l++);

		/* Val is a value from 0 to 255 depending on the angle between a normal */
		/* and the light direction.                                             */
		Val = (int) (127.0 * fabs( LTemp[0] * x + LTemp[1] * y + LTemp[2] * z + 1.0) );
      
        TCo = Shad[Val];
        Col = (int)(255*TCo); 
  
	    /* Setting vertex colour */
        (TempVert[Num]+i)->u32Colour  = RGBColour (Col,Col,Col);
    }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  UpdateReflection                                                */ 
/*  Inputs          :  Num                                                             */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, Mesh, TemVert                                       */
/*  Description     :  Changes UV values fixing their position when the mesh rotates.  */
/*                     So, it has to move all values in the opposite direction.        */
/*-------------------------------------------------------------------------------------*/	
void UpdateReflection (int Num)
{ 
int   i,  k=0;
float CosX, SinX, CosY, SinY, x, z, y, Temp[3];

CosX = cos(XAng); SinX = sin(XAng);
CosY = cos(YAng); SinY = sin(YAng);
  
    for (i=0; i<Mesh[Num].NumVertex; i++)
	{
         x = *(TempNormals[Num]+k++);
         y = *(TempNormals[Num]+k++);
         z = *(TempNormals[Num]+k++);

         Temp[0]  = x * CosY - z * SinY;
         Temp[2]  = z * CosY + x * SinY;

         z        = Temp[2];
         Temp[1]  = y * CosX - z * SinX;
         Temp[2]  = z * CosX + y * SinX ;
  

         Temp[2] = fabs(Temp[2])+0.01;
    
         /* Now we proyect the espherical coordinates to rectangular ones... */
         x = (PI + atan(Temp[0]/Temp[2]))/PI;
         y = (PI + atan(Temp[1]/Temp[2]))/PI;
    
		 /* ...and we have now our new UV values */
        (TempVert[Num]+i)->fUOverW =  x+0.5;
        (TempVert[Num]+i)->fVOverW =  y+0.5; 
   }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  MoveBalls                                                       */ 
/*  Inputs          :  None                                                            */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  frame, Mesh, Balls                                              */
/*  Description     :  Moves balls and stores their position for drawing them later.   */
/*-------------------------------------------------------------------------------------*/
void MoveBalls (void)
{
float x, y, z;
register i, j;

       /* Setting initials position values */
       if (frame == 0)
	   {
	      for (j=BALL; j<=BALL08; j++)
		  {
              x = 200-40*j - *(Mesh[j].Vertex+0) ;   
              y = (50.0*(float)rand())/RAND_MAX - *(Mesh[j].Vertex+1) ;   
              z = -300+j*10 -*(Mesh[j].Vertex+2);  
             for (i=0;i<Mesh[j].NumVertex;i++)
			 {
               *(Mesh[j].Vertex+i*3+0) += x;
               *(Mesh[j].Vertex+i*3+1) += y;
               *(Mesh[j].Vertex+i*3+2) += z;
             }
          }
       }
         
      /* Moving in a fancy way.  */
       for (j=BALL; j<=BALL08; j++)
	   {
            for (i=0; i<Mesh[j].NumVertex; i++)
			{
             (TempVert[j]+i)->fY +=  20.0*sin((j*15+frame/1.9)/ 30.3);
             (TempVert[j]+i)->fX +=  5.00*cos((j*15+frame)/ 15.3);
			}
       }
       
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  PutBallsOn                                                      */ 
/*  Inputs          :  None                                                            */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, Mesh, TemVert                                       */
/*  Description     :  Refreshing reflection map every frame.                          */
/*-------------------------------------------------------------------------------------*/
void PutBallsOn (void)
{
float x, y;
register i, j, k;
int cont = 0, cont2=0, Co;
char Alpha;

    /* Restore original pretty background */
    memcpy (BuffTex[0].pixels, BuffTex[5].pixels, 128*128*sizeof(sgl_map_pixel));

	/* Balls are setting on the background one by one */
    for (k=BALL; k<=BALL08; k++)
	{
       Co = Mesh[k].Material-1;
       /* Balls positions */
       x = (128.0 * TempVert[k]->fX )/640.0;
       y = (128.0 * (480-TempVert[k]->fY) )/480.0;
       cont2=0;
       cont = ((int)x+(int)y*128);
       for (i=0; i<20; i++) 
	   {
          for (j=0; j<20; j++)
		  {
			   Alpha = MCol[0][cont2++]; /* Color key for translucent */
               if (Alpha!=0 || y+i>128 || x+j>128 || y+i<0 || x+j<0) {cont2+=3; continue;}
               (BuffTex[0].pixels+cont+j)->red   = MCol[Co][cont2++]; 
               (BuffTex[0].pixels+cont+j)->green = MCol[Co][cont2++]; 
               (BuffTex[0].pixels+cont+j)->blue  = MCol[Co][cont2++]; 
           }
           cont +=128;
       }
	}
    /* Updating reflection texture */
    sgl_set_texture (Texture[0], FALSE,FALSE, &BuffTex[0], NULL);
}
/*--------------------------- End of File --------------------------------*/

