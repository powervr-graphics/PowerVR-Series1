/*****************************************************************************
  Name : SGLLogo.c
  Date : February 1998
  Platform : ANSI compatible

  SGLLogo.c is a scene file that is to be used with SGL Shell. 
  The scene file should be included in a project where the SGLShell.c and 
  SGLShell.h files are included. The SGL.LIB library file should of course
  be included in the project. Make sure your application include SGLShell.h 
  to have access to SGL Shell functions and flags.

  Basic functions have to be implemented to interact correctly with the SGL 
  Shell. A list of these functions is :

  
  *****************************
  ** void InitApplication(); **
  *****************************

  This function will be called only once by the SGL Shell before anything 
  happens, at the very beginning of the SGLShell WinMain() function. 
  This function enables the user to perform any initialisation before 
  the program is actually run.
  Could be used to load meshes and allocate memory for these, setup the
  SGL Context, load and allocate textures, etc...

  Within this function the user can call SGLShellSetPreferences(...) to set 
  the application preferences. For details of this function, see later
  in this document.

  - void QuitApplication();

  This function is used in conjunction with InitApplication(). Its purpose
  is to free and close all memory or instances allocated in InitApplication().
  This function is called when the user exits the application.

				***

  *****************************************************
  **  BOOL InitView(DWORD dwWidth, DWORD dwHeight);  **
  *****************************************************

  This function is called each time a rendering variable is changed in
  the SGLShell (switching from or to full screen, changing the resolution,
  changing the buffering mode and switching Display Info On or Off). 
  
  InitView(...) is the final function that gets called when rendering 
  variables are changed.
  InitView(...) lets the user create or initialise any new variables 
  corresponding to the new rendering parameters. 
  dwWidth and dwHeight are passed to your application and correspond to 
  the new Width and Height of the rendering surface. The user may need 
  these to create his/her viewport or centering the scene accordingly.
  This function should return TRUE(1) to tell SGLShell that the call was
  successful. If the function returns FALSE(0), then the execution will
  stop.

  ***************************
  **  void ReleaseView();  **
  ***************************

  This function is used in conjunction with InitView(...). Its purpose
  is to free and close all memory or instances allocated in InitView().

				***
  
  ***********************************************************************************
  **  void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);  **
  ***********************************************************************************

  This is the user window procedure. It is used as a normal WindowProc()
  function. This function is called before the SGLShell window procedure
  itself. It enables the user to retrieve menu choices, keystrokes or 
  other messages.
  SGLShell handles many messages which should not be handled by the user
  application. A list of these messages is :
  
  	WM_ENTERMENULOOP, WM_EXITMENULOOP,
	WM_ACTIVATEAPP,
	WM_SYSCOMMAND,
	WM_SIZE, WM_MOVE, WM_MOVING,
	WM_PAINT,
	WM_DESTROY, WM_QUIT

  Do NOT return DefWindowProc(...) in this function, as it will prevent
  SGLShell to handle messages by itself.

				***

  ***************************
  **  BOOL RenderScene();  **
  ***************************

  This is where the user does his/her rendering. Typically one would call
  sgltri_startofframe(...) and sgltri_render(...) in this function.
  The function should return TRUE to tell SGLShell that the call was
  successful. If the function returns FALSE, then the execution will stop.


  These 6 functions must exist, but you don't have to put any code in these. 
  For instance, if you don't want to deal with any user input, the
  UserWindowProc(...) function will typically be empty.  
  You might as well not want to make any use of ReleaseView(), or even 
  InitView(...). In that case, just put nothing in these.
  The most simple example of an application using SGLShell is the Triangle
  example (see below).


  -------------------------------------------------------------
  | READ SGLSHELL.TXT FOR FURTHER INFORMATION ABOUT SGLSHELL  |
  -------------------------------------------------------------


  Email any comments or feedback to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/


#include <windowsx.h>
#include <ddraw.h>
#include "sgl.h"		/* SGL library include */
#include "SGLShell.h"	/* SGLShell include */
#include "logo.h"		/* This is the file with 3D data */
#include "resource.h"	/* Resource include */
              
/* Disables float to double conversion warning */
#pragma warning (disable : 4244)  

/* Macros */
#define PI	3.14159f
#define RGBColour(r, g, b) ((sgl_uint32) (((sgl_uint32)(r&0x000000FF)<<16) | ((sgl_uint32)(g&0x000000FF) << 8) | (sgl_uint32)(b&0x000000FF)))


/* Global variables */
float			XAng = -PI/2, YAng = 0.0f, ZAng = 0.0f, XAng1 = 0.0f, YAng1 = -0.01f, ZAng1=0.0f;
static int		Device, Init = TRUE, Texture[10]; 
static float	*TempNormals[NUM_MESHES];
static float	Light1[3] = { -1, 1.5, -1.5};
static float	Shad[255];
static float	CamFocus = 600.0;
SGLVERTEX		*TempVert[NUM_MESHES];
SGLCONTEXT		SGLContext;


/* Added for SGLShell port */
static	DWORD	dwCurrentWidth;
static	DWORD	dwCurrentHeight;
HMENU			hMyMenu;
HACCEL			hMyAccel;
HICON			hMyIcon;


/* Prototypes */
static void SetupContext (void);
static void SetupTextures (void);
static void InitMeshes    (void);
static void DrawAll       (void);
static void UpdateVertex  (int Num);
static void Shading       (int Num);
static void UpdateReflection (int Num);



/* SGLShell Functions */


/* InitApplication() is called by SGLShell */
void InitApplication()
{
	/* Load menu from resource */
	hMyMenu=LoadMenu(NULL, MAKEINTRESOURCE(ID_PVRMENU));

	/* Load menu from resource */
	hMyAccel=LoadAccelerators(NULL, MAKEINTRESOURCE(ID_PVRACCELERATOR));
	
	/* Load icon from resouce */
	hMyIcon=LoadIcon(NULL, MAKEINTRESOURCE(ID_PVRICON));

	/* Set application name, pass menu, accelerator, Icon and flags */
	SGLShellSetPreferences("PowerVR logo", hMyMenu, hMyAccel, hMyIcon, DISABLE_VERYHIGHRES);
	
	/* Load textures */
	SetupTextures(); 

	/* Setup SGL context */
	SetupContext();

	/* Init meshes */
    InitMeshes();
}


/* InitApplication() is called by SGLShell */
void QuitApplication()
{
	int	i;

	/* sgl_delete_texture must be used to release texture created
	   with sgl_create_texture */
	for (i=0;i<10;i++)
	{
		if (Texture[i]) sgl_delete_texture(Texture[i]);
	}

	/* Free meshes memory */
	for (i=0;i<NUM_MESHES;i++)
	{
		if (TempNormals[i]) 
		{
			free(TempNormals[i]);
			TempNormals[i]=NULL;
		}
		if (TempVert[i]) 
		{
			free(TempVert[i]);
			TempVert[i]=NULL;
		}
	}
	Init = FALSE;
}


/* UserWindowProc() is called by SGLShell */
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/* Handle user messages */
	switch (message)
	{
		case WM_COMMAND:
			switch(GET_WM_COMMAND_ID(wParam,lParam))
			{
			case ID_MOTION_STOP :  XAng1=0.0f; YAng1=0.0f;
								   break;
			}
			break;
	
		case WM_KEYDOWN:
			switch(wParam)
			{
				case VK_RIGHT:	YAng1 += 0.01f; break;
				case VK_LEFT:  	YAng1 -= 0.01f; break;
				case VK_UP:     XAng1 += 0.01f; break;
				case VK_DOWN:   XAng1 -= 0.01f; break;    
          }
          break;
    }
}


/* InitView() is called by SGLShell */
BOOL InitView(DWORD dwWidth, DWORD dwHeight)
{
	/* Update new width and height */
	dwCurrentWidth=dwWidth;
	dwCurrentHeight=dwHeight;
	
	/* InitView OK */
	return TRUE;
}


/* RenderScene() is called by SGLShell */
BOOL RenderScene()
{
	/* SGL Render */
	sgltri_startofframe (&SGLContext);
	DrawAll ();
    sgltri_render (&SGLContext);

	/* RenderScene OK */
	return TRUE;
}


/* ReleaseView() is called by SGLShell */
void ReleaseView()
{
	/* Nothing to release */
}


/* Application functions */


/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  DrawAll                                                         */ 
/*  Inputs          :  None                                                            */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, XAng1, YAng1, SGLContext                            */
/*  Description     :  Updates and draws all the meshes in the model.                  */
/*  Note            :  The definition of Mesh[i] struct is in logo.h                   */
/*-------------------------------------------------------------------------------------*/		
void DrawAll(void)
{
register i;

    XAng += XAng1;   /* Scene angles are changed every frame */
    YAng += YAng1;   /* XAng1 and YAng1 are the speed */
  
    for (i=0; i<NUM_MESHES; i++)
	{
        UpdateVertex  (i); /* Recalculate SGL vertices for the new position */
                           
        if (i==REFLECT || i==REFLECT01 || i==REFLECT02)
		{
			UpdateReflection (i); 
		}
        else
		{
			Shading (i);  /* We do not want to shade a reflection mesh */
		}

		/* Updating texture parameters for each mesh of the model */
	    SGLContext.nTextureName = Texture[Mesh[i].Material];
        SGLContext.u32Flags = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
        /* No Texture */
		if (Mesh[i].TexMap == FALSE)  SGLContext.u32Flags = SGLTT_GOURAUD | SGLTT_BILINEAR; 
        
		/* Global Translucent */
        if (i==REFLECT || i==REFLECT01 || i==REFLECT02)
		{ 
           SGLContext.u32Flags       =  SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_GLOBALTRANS | SGLTT_BILINEAR;
           SGLContext.u32GlobalTrans =  32L;
        }

	   /* And now... triangles  */
       sgltri_triangles (&SGLContext, Mesh[i].NumFaces, (int(*)[3])Mesh[i].Faces, TempVert[i]);
   } 
}


/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupTextures                                                    */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : NumMaterials, Texture, MatInfo                                   */
/*  Description     : Loads BMP files getting the information from MatInfo struct      */
/*-------------------------------------------------------------------------------------*/	
void SetupTextures(void)
{
//sgl_intermediate_map BuffTex[NUM_MESHES];
register i;
	
   for (i=0;i<NumMaterials; i++)
   {
      if (*MatInfo[i].MatFile == 0) continue;
	  if (i==1) /* The material for the "PowerVR" word use alpha chanel */
	  {
          
		  //BuffTex[i] = ConvertBMPtoSGL   (MatInfo[i].MatFile, TRUE);
          //Texture[i] = sgl_create_texture( sgl_map_trans16, sgl_map_256x256,
		  //	                               FALSE, FALSE, &BuffTex[i],  NULL);
		  Texture[i]=SGLShellLoadBMP(MatInfo[i].MatFile, TRUE, FALSE);
		  if (Texture[i]<0)
		  {
			  OutputDebugString("Error in texture !!!\n");
		  }
      }
      else 
	  { 
         //BuffTex[i] = ConvertBMPtoSGL   (MatInfo[i].MatFile, FALSE);
         //Texture[i] = sgl_create_texture( sgl_map_16bit, sgl_map_256x256, 		
		 //				            	  FALSE, FALSE, &BuffTex[i],  NULL);
		 Texture[i]=SGLShellLoadBMP(MatInfo[i].MatFile, FALSE, FALSE);
		 if (Texture[i]<0)
		 {
			 OutputDebugString("Error in texture !!!\n");
		 }
      }
   }
}


/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupContext                                                     */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : SGLContext                                                       */
/*  Description     : Sets default values for the render context.                      */
/*-------------------------------------------------------------------------------------*/	
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 5;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = 0;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.RenderRegions        = 0;
    SGLContext.n32MipmapOffset      = 0;
    SGLContext.u32GlobalTrans       = 255;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}


/*-------------------------------------------------------------------------------------*/
/*  Function Name   : InitMeshes                                                       */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Shad, Mesh, TempVert, TempNormals                                */
/*  Description     : Sets initials values for meshes managing                         */
/*-------------------------------------------------------------------------------------*/	
void InitMeshes (void)
{
float x, z, y, Dx;
register i,j, k=0;

    /* This function is in logo.h and creates an array of structures with 3D data */
    CreateMeshesArray (); 
   
	/* Shad is a 255 values array whit information for smooth shading */
    for (i=0; i<120; i++) Shad[k++] = (float)(120-i)/960.0;
    for (i=0; i<100; i++) Shad[k++] = (float) i/100.0;
    for (i=0; i<35;  i++) Shad[k++] = 1.0f;

	/* Memory allocation for TempVert and TempNormals */ 
    for (i=0; i<NUM_MESHES; i++)
	{
         TempVert[i] = (SGLVERTEX *) malloc (Mesh[i].NumVertex*sizeof(SGLVERTEX));
         TempNormals[i]  = (float *) malloc (Mesh[i].NumVertex*sizeof(float)*3);
	}

	/* Setting UV values for all the meshes and calculating TempNormals for reflections */
    for (j=0; j<NUM_MESHES;j++)
	{
        for (i=0; i<Mesh[j].NumVertex; i++)
		{
            (TempVert[j]+i)->fUOverW    =  (Mesh[j].TexMap) ? *(Mesh[j].UV+i*2+0) : 0;
            (TempVert[j]+i)->fVOverW    =  (Mesh[j].TexMap) ? *(Mesh[j].UV+i*2+1) : 0; 

			/* TempNormals are calculated with the normal and the position of each vertex */
            x =  (*(Mesh[j].Vertex+i*3+0) - Mesh[j].Center[0]);
            y =  (*(Mesh[j].Vertex+i*3+1) - Mesh[j].Center[1]);
            z =  (*(Mesh[j].Vertex+i*3+2) - Mesh[j].Center[2]);

            if (j==REFLECT)   y +=50;
            if (j==REFLECT01) y += 50;
            if (j==REFLECT02) y -= 10;

            Dx = sqrt (x*x+y*y+z*z);
                      
            *(TempNormals[j]+i*3+0) = ((*(Mesh[j].Normals+i*3+0) + x/Dx)/2.0);
            *(TempNormals[j]+i*3+1) = ((*(Mesh[j].Normals+i*3+1) + y/Dx)/2.0);
            *(TempNormals[j]+i*3+2) = ((*(Mesh[j].Normals+i*3+2) + z/Dx)/2.0);
		}
    }
}


/*-------------------------------------------------------------------------------------*/
/*  Function Name   : UpdateVertex                                                     */ 
/*  Inputs          : Num (the mesh in the model)                                      */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : XAng, YAng                                                       */
/*  Description     : Turns vertices around two axes.                                  */
/*-------------------------------------------------------------------------------------*/	
void UpdateVertex (int Num)
{
float  CosX, SinX, CosY, SinY, CosZ, SinZ, x, z, y , CamZ;
int    i, j=0, k=0, l=0;
sgl_vector Temp;

    CosX = cos(XAng); SinX = sin(XAng);
    CosY = cos(YAng); SinY = sin(YAng);
    CosZ = cos(ZAng); SinZ = sin(ZAng);
  
    for (i=0; i<Mesh[Num].NumVertex; i++)
	{
         x = *(Mesh[Num].Vertex+k++) - GroupCenter[0];
         y = *(Mesh[Num].Vertex+k++) - GroupCenter[1];
         z = *(Mesh[Num].Vertex+k++) - GroupCenter[2];

         /* Temp is the outcome vertex after the rotation */
         Temp[0]  = x * CosY - z * SinY;
         Temp[2]  = z * CosY + x * SinY;

         z        = Temp[2];
         Temp[1]  = y * CosX - z * SinX;
         Temp[2]  = z * CosX + y * SinX + 500;

         if (Temp[2] <=0.0f) Temp[2] = 0.001f;
         
		 /* We store the SGL vertex in TempVert */
         CamZ = 1.0/(Temp[2]);
    	 (TempVert[Num]+i)->fX    =  CamFocus *  Temp[0] * CamZ + dwCurrentWidth/2;
         (TempVert[Num]+i)->fY    = -CamFocus *  Temp[1] * CamZ + dwCurrentHeight/2;
	     (TempVert[Num]+i)->fInvW =  CamZ;
   }
}


/*-------------------------------------------------------------------------------------*/
/*  Function Name   : Shading                                                          */ 
/*  Inputs          : Num                                                              */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Light1, MatInfo, Mesh, TempVert                                  */
/*  Description     : Shades a mesh.                                                   */
/*-------------------------------------------------------------------------------------*/	
void Shading (int Num)
{
register   l=0, i, Val;
unsigned   k=0;
float      CosX, SinX, CosY, SinY, x, z, y ;
float      TempCo[3], TCo, Dir, LTemp[3];
sgl_uint32 Col[3];

    /* We just rotate the light vector in the opposite direction instead of rotating all the normals */
    Dir = sqrt (Light1[0]*Light1[0]+Light1[1]*Light1[1]+Light1[2]*Light1[2]);
    x = Light1[0]/Dir;
	y = Light1[1]/Dir;
	z = Light1[2]/Dir;

    CosX = cos(-XAng); SinX = sin(-XAng);
    CosY = cos(-YAng); SinY = sin(-YAng);
     
    LTemp[1]  = y * CosX - z * SinX;
    LTemp[2]  = z * CosX + y * SinX; 
     
    z = LTemp[2];
    LTemp[0]  = x * CosY - z * SinY;
    LTemp[2]  = z * CosY + x * SinY;

    k = Mesh[Num].Material;

	/* This is the mesh colour */
    TempCo[0] = 255.0 * MatInfo[k].MatDiffuse[0];
    TempCo[1] = 255.0 * MatInfo[k].MatDiffuse[1];
    TempCo[2] = 255.0 * MatInfo[k].MatDiffuse[2];

    if (Mesh[Num].Material == NumMaterials) TempCo[0]=TempCo[1]=TempCo[2]=255; /* No material */

    for (i=0; i<Mesh[Num].NumVertex; i++)
	{
    	x = *(Mesh[Num].Normals+l++);
        y = *(Mesh[Num].Normals+l++);
        z = *(Mesh[Num].Normals+l++);

		/* Val is a value from 0 to 255 depending on the angle between a normal */
		/* and the light direction.                                             */
		Val = (int) (127.0 * fabs( LTemp[0] * x + LTemp[1] * y + LTemp[2] * z + 1.0) );
   
        TCo = Shad[Val];

        Col[0] = (int)(TempCo[0]*TCo); 
        Col[1] = (int)(TempCo[1]*TCo);
        Col[2] = (int)(TempCo[2]*TCo);

		/* Setting vertex colour */
        (TempVert[Num]+i)->u32Colour  = RGBColour (Col[0],Col[1],Col[2]);
    }

}


/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  UpdateReflection                                                */ 
/*  Inputs          :  Num                                                             */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, Mesh, TemVert                                       */
/*  Description     :  Changes UV values fixing their position when the mesh rotates.  */
/*                     So, it has to move all values in the opposite direction.        */
/*-------------------------------------------------------------------------------------*/	
void UpdateReflection (int Num)
{
int   i, j=0, k=0, k1=0, l=0;
float CosX, SinX, CosY, SinY, x, z, y;
float Temp[3];

CosX = cos(XAng); SinX = sin(XAng);
CosY = cos(YAng); SinY = sin(YAng);

    for (i=0; i<Mesh[Num].NumVertex; i++)
	{
         x = *(TempNormals[Num]+k++);
         y = *(TempNormals[Num]+k++);
         z = *(TempNormals[Num]+k++);

         Temp[0]  = x * CosY - z * SinY;
         Temp[2]  = z * CosY + x * SinY;

         z        = Temp[2];
         Temp[1]  = y * CosX - z * SinX;
         Temp[2]  = z * CosX + y * SinX ;
  

         Temp[2] = fabs(Temp[2])+0.01;

		 /* Now we proyect the espherical coordinates to rectangular ones... */
         x = (PI + atan(Temp[0]/Temp[2]))/PI;
         y = (PI + atan(Temp[1]/Temp[2]))/PI;
 
		 /* ...and we have now our new UV values */
        (TempVert[Num]+i)->fUOverW =  x+0.5;
        (TempVert[Num]+i)->fVOverW =  y+0.5; 
   }
}

