/*-----------------------------------------------------------------------------------
   Name   : SEALD  ( PowerVR SGL-Direct )                                                            
   Author : Carlos Sarria   - send comments to csarria@videologic.com                                                          
   Date   : March 1997                                                               
   Update : July  1997
   Project: seald.c + frontend.c + sgl.lib
                                                                                     
   Copyright : 1997 by VideoLogic Limited. All rights reserved.                       
 ------------------------------------------------------------------------------------*/

#include <math.h>
#include <ddraw.h>

#include "sgl.h"
#include "frontend.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */
#pragma warning (disable : 4056)

#define NAMED_ITEM  TRUE
#define UNAMED_ITEM FALSE

#define PI 3.142f
    
#define RGBColour(r, g, b) ((sgl_uint32) (((r) << 16) | ((g) << 8) | (b)))


/*------------------------------- Global Variables -----------------------------------*/

static sgl_colour  White = {0.9f,0.9f,0.9f};
static sgl_colour  Black = {0.0f,0.0f,0.0f};
static sgl_colour  Blue	 = {0.1f,0.4f,0.6f};
static sgl_colour  Grey  = {0.3f,0.3f,0.3f};

int Device;

int GroundTex, SkyTex, SeaTex, SealTex;
int Spd, Poll;

sgl_vector PetPath [20];
float PetTime  = 0.0f,  VelH = 0.3f;
float PetPosY  = 10.0f, dY   = 0.3f,   Radius = 50.0f,   TPet = 3.0f;
float SeaFrame = 10.0f, SF   = 1.0f;

sgl_colour PollCol[3] = {{0.1f,0.5f,0.7f},{0.1f,0.3f,0.5f},{0.1f,0.1f,0.1f}};
int        PollFog[3] = { 9, 10, 12}; 

sgl_vector LightDir = {0.0f, -100.0f,0.0f};

float CamFocus = 1500.0;

SGLCONTEXT SGLContext;
SGLVERTEX  SealVert  [20*10],   ShadowVert  [2*11];
int        SealFaces [20*9][4], ShadowFaces [11][4];


/*----------------------------  Routines Prototypes ---------------------------------*/

void SetupContext  (void),
     SetupPet      (void),
     SetupTextures (void);

void DrawGround    (void),
     DrawSky       (void),
     DrawSea       (void),
     MovePet       (void),
     DrawPet       (void);

void Perspect      (const sgl_vector Point3D, SGLVERTEX *Vert);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device                                                         */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                           */
/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
   
   Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, FALSE);
   if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

   SetCursor (NULL);   /* This hides the pointer */

   SetupTextures (); 
   SetupContext  ();
   SetupPet      ();
    
   return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContext                                                     */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame()
{
  sgltri_startofframe (&SGLContext);
    MovePet   ();
    DrawPet   ();
    DrawGround();
    DrawSky   ();
    DrawSea   ();
  sgltri_render (&SGLContext);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void Finish()
{
   FreeAllBMPTextures ();
   sgl_delete_device  (Device);	
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawGround                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Draws ground.                                                  */
/*-------------------------------------------------------------------------------------*/
void DrawGround()
{
SGLVERTEX  Vert[4];
int Face[1][4] = {0,1,2,3}, i;
/* Four points to set a big quad. */
sgl_vector Pnt[4]	=  {{-5000.0f,  -5.0f, -100.0f},           
                       {-5000.0f,  -5.0f, 5000.0f},
                       { 5000.0f,  -5.0f, 5000.0f},
                       { 5000.0f,  -5.0f, -100.0f}};	


    for (i=0; i<4; i++)
    {
      /* Translate from 3D to SGL-Direct coord. */
      Perspect (Pnt[i], &Vert[i]);                     
      /* Set the colour for each vertex. */
      Vert[i].u32Colour   = RGBColour (255,255,255);    
      Vert[i].u32Specular = RGBColour (255,255,255);
    }
   /* Set UV values for each textured vertex. */
   Vert[0].fUOverW = 0.0f;      Vert[0].fVOverW = 0.0f;          
   Vert[1].fUOverW = 0.0f;      Vert[1].fVOverW = 80.0f;
   Vert[2].fUOverW = 400.0f;    Vert[2].fVOverW = 80.0f;
   Vert[3].fUOverW = 400.0f;    Vert[3].fVOverW = 0.0f;
   /* Set a sigle textured quad to create the ground. */
   SGLContext.nTextureName = GroundTex;                 
   sgltri_quads (&SGLContext, 1, Face, Vert);           
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawSky                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Draws Sky. (The same as DrawGround)                            */
/*-------------------------------------------------------------------------------------*/
void DrawSky()
{
float Pos=0;
SGLVERTEX  Vert[4];
int Face[1][4] = {0,1,2,3}, i;
sgl_vector Pnt[4]	=   {{-5000.0f,100.0f, -100.0f}, 
                         {-5000.0f,100.0f, 5000.0f},
                         { 5000.0f,100.0f, 5000.0f},
                         { 5000.0f,100.0f, -100.0f}};	


    for (i=0; i<4; i++)
    { 
     Perspect (Pnt[i], &Vert[i]);
     Vert[i].u32Colour   = RGBColour (255,255,255);
     Vert[i].u32Specular = RGBColour (255,255,255);
    }

   /* Here the continous fluency of the sky.     */
   /* Note that I just move texture's UV values. */
   Pos =(float)SeaFrame/100.0;                            
   Vert[0].fUOverW =  0.0;  Vert[0].fVOverW = Pos+00.0;  
   Vert[1].fUOverW =  0.0;  Vert[1].fVOverW = Pos+20.0;
   Vert[2].fUOverW = 90.0;  Vert[2].fVOverW = Pos+20.0;
   Vert[3].fUOverW = 90.0;  Vert[3].fVOverW = Pos+00.0;


   SGLContext.nTextureName = SkyTex;
   sgltri_quads (&SGLContext, 1, Face, Vert);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawSea                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Draws Sea surface and its shadow.                              */
/*-------------------------------------------------------------------------------------*/
void DrawSea()
{
sgl_vector Move, Scale;
SGLVERTEX  Vert[4];
int Face[1][4] = {0,1,2,3}, i;
sgl_vector Pnt[4]	=   {{-100.0f, 50.0f, -100.0f}, 
                         {-5000.0f,50.0f, 5000.0f},
                         { 5000.0f,50.0f, 5000.0f},
                         { 100.0f, 50.0f, -100.0f}};	

     if (SeaFrame> 20000 || SeaFrame<1) SF = -SF;    
    /* SF is just a up-down step for SeaFrame          */
    /* to avoid a large integer part of this variable  */

   Move[0] = SeaFrame/20.0;
   Move[2] = 0.0;

   Scale[0] = 0.9 + sin(SeaFrame/32.0)/15.0;
   Scale[2] = 0.9 + sin(SeaFrame/64.0)/15.0;

   /* Here the sea stream.                    */
   /* Note that I just move the quad's vertex */
   for (i=0; i<4; i++)
   { 
   Pnt[i][0] *= Scale[0];                      
   Pnt[i][0] += Move[0];                     
   Pnt[i][2] *= Scale[2]; 
   Pnt[i][2] += Move[2];
	
   Perspect (Pnt[i], &Vert[i]);
   Vert[i].u32Colour   = RGBColour (255,255,255);
   Vert[i].u32Specular = RGBColour (255,255,255);
   }


   Vert[0].fUOverW =  -1.0;  Vert[0].fVOverW = -1.0;
   Vert[1].fUOverW = -40.0;  Vert[1].fVOverW = 40.0;
   Vert[2].fUOverW =  80.0;  Vert[2].fVOverW = 40.0;
   Vert[3].fUOverW =   1.0;  Vert[3].fVOverW = -1.0;

  /* Sea surface (transparent quad). */
   SGLContext.nTextureName = SeaTex;
   SGLContext.u32Flags = SGLTT_TEXTURE | SGLTT_GLOBALTRANS | SGLTT_BILINEAR;
   SGLContext.u32GlobalTrans = 170;
   sgltri_quads (&SGLContext, 1, Face, Vert);  
	
   /* Sea shadow (transparent quad). */
   for (i=0; i<4; i++){ Pnt[i][1]=-4.99f; Perspect (Pnt[i], &Vert[i]);}
   SGLContext.u32GlobalTrans = 90;
   sgltri_quads (&SGLContext, 1, Face, Vert); 

   /* Restore SGLContex */
   SetupContext ();                                 

   SeaFrame += SF;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   MovePet                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   PetPath, PetTime, PetPosY, VelH, Radius and TPet               */
/*  Description     :   Set a 10 points path for the seal's spine.                     */
/*-------------------------------------------------------------------------------------*/
void MovePet (void)
{
register i;

    for (i=0; i<11; i++)
    {
      PetPath[10-i][1] = PetPosY + sin((PetTime+i)/3.0)*3.0;
      PetPath[10-i][0] = cos ((PetTime+i)*(TPet/(Radius))) * Radius;
      PetPath[10-i][2] = sin ((PetTime+i)*(TPet/(Radius))) * Radius + 150;
    }
    PetTime += 1.0;
    PetPosY += VelH; 
    if (PetPosY < -0.0 || PetPosY > 50.0) VelH = -VelH;
}   
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawPet                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SealVerts, ShadowVerts, Sealfaces, ShadowFaces                 */
/*  Description     :   This routine draws our seal.                                   */
/*-------------------------------------------------------------------------------------*/
void DrawPet (void)
{
 sgl_vector pp, n, TempP, Shadow[10*2];
 register   i, j, pos;
 int        PperC = 10, NumL = 10;                     
 double     CosA, SinA, CosB, SinB, CosC, SenC;      
 double     LenXYZ, LenXY, p0, p1;


 for(j=0;j<NumL;j++)
    {
 
       n[0]=PetPath[j][0] - PetPath[j+1][0];
       n[2]=PetPath[j][2] - PetPath[j+1][2];
       n[1]=PetPath[j][1] - PetPath[j+1][1];
	    
       LenXY = sqrt(n[0]*n[0] + n[2]*n[2]);

       if (LenXY > 0.0) {CosA = n[0] / LenXY; SinA = n[2] / LenXY;}
       else             {CosA = 1.0;          SinA = 0.0;         }

       LenXYZ  = sqrt (n[0]*n[0] + n[2]*n[2] + n[1]*n[1]);

       CosB = n[1]  / LenXYZ;           SinB = LenXY / LenXYZ;
       CosC = cos ((2.0*PI)/(PperC-1)); SenC = sin ((2.0*PI)/(PperC-1));

       /* This sets a point pp(0, r, 0) */
       pp[0] =  pp[2]= 0.0;  pp[1] =  sin((float)j*(PI/8.0))*3.0 + 0.2;  
		
      /* This's the tail size */
      if (j==9) {pp[1] = 3.0;}                                          

     for (i=0; i<PperC; i++)
     {
	  /* Rotating pp around n (two consecutive spine points) */
        p0    =  CosA * pp[0] + SinA * pp[2];
        pp[2] = -SinA * pp[0] + CosA * pp[2];
        pp[0] =  p0;

        p1    =  CosB * pp[1] + SinB * pp[0];
        pp[0] = -SinB * pp[1] + CosB * pp[0];
        pp[1] =  p1;

        p0    =  CosC * pp[0] - SenC * pp[2];
        pp[2] =  SenC * pp[0] + CosC * pp[2];
        pp[0] =  p0;

        p1    =  CosB * pp[1] - SinB * pp[0];
        pp[0] =  SinB * pp[1] + CosB * pp[0];
        pp[1] =  p1;

        p0    =  CosA * pp[0] - SinA * pp[2];
        pp[2] =  SinA * pp[0] + CosA * pp[2];
        pp[0] =  p0;
        pos   = i+(j)*PperC;

        /* Seal vertex */
        TempP[0] = PetPath[j][0]-pp[0];
        TempP[1] = PetPath[j][1]-pp[1];
        TempP[2] = PetPath[j][2]-pp[2];

       /* Flatting the tail */
       if (j==9){ TempP[1] = PetPath[j][1]; }            

      /* Shadow vertex */
      if (i==2) {Shadow[j*2+0][0]=TempP[0];  Shadow[j*2+0][1]=-4.8f;  Shadow[j*2+0][2]=TempP[2];}
      if (i==7) {Shadow[j*2+1][0]=TempP[0];  Shadow[j*2+1][1]=-4.8f;  Shadow[j*2+1][2]=TempP[2];}

     Perspect (TempP, &SealVert[pos]);
     }
  }
    for (j=0;j<10;j++)
    {
    Perspect (Shadow[j*2+0], &ShadowVert[j*2+0]);
    Perspect (Shadow[j*2+1], &ShadowVert[j*2+1]);
    }

    SGLContext.nTextureName  = SealTex;
    /* Drawing seal mesh */
    sgltri_quads        (&SGLContext, 10*8, SealFaces,   SealVert);  
    /* Drawing seal's shadow mesh */
    sgltri_quads        (&SGLContext,    9, ShadowFaces, ShadowVert);   
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupPet                                                       */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SealVerts, ShadowVerts, Sealfaces, ShadowFaces                 */
/*  Description     :   Set a 10 points path for the seal's spine.                     */
/*-------------------------------------------------------------------------------------*/
void SetupPet (void)
{
unsigned char SealSh[] = {0, 56, 150, 255, 255,152, 56, 0, 0, 0}; 
register i, j;
int cont = 0;

    /* Seal vertex */
    for (j=0; j<10; j++)
    {
       for (i=0; i<10; i++)
       {
       /* Setting seal's smooth shadow colouring faces. */
       if (j==8) SealSh[i] = 0; if (j==9) SealSh[i]= 0;
       SealVert[cont].u32Colour   = RGBColour (SealSh[i], SealSh[i], SealSh[i]);
       SealVert[cont].u32Specular = RGBColour (0, 0, 0);
      /* U & V values for texture. */
      SealVert[cont].fUOverW     = (float)(i+1)/9.0;        
      SealVert[cont].fVOverW     = (float)(j)/11.0;          
      cont++;
      }
   }
 
    cont = 0;
   
   /* Seal faces */
   for (j=0;j<10;j++)
   {
    for (i=0;i<9;i++)
    {
    /* In a Quad the 3 first points must be not too much close. */
    /* I have separated the mesh in two parts to avoid the pointed nose effect. */ 
    if (j<5 || j==8){   
       SealFaces[cont][2] = i+(j)*10;      SealFaces[cont][3] = i+1+j*10; 
       SealFaces[cont][0] = i+1+(j+1)*10;  SealFaces[cont][1] = i+(j+1)*10;
    }
    else {
       SealFaces[cont][0] = i+(j)*10;      SealFaces[cont][1] = i+1+j*10; 
       SealFaces[cont][2] = i+1+(j+1)*10;  SealFaces[cont][3] = i+(j+1)*10;
    }
    cont++;
   }
  }

  cont = 0;

  /* Shadow vertex */
  for (j=0; j<10; j++)
  {
    for (i=0; i<2; i++)
    {
     ShadowVert[cont].u32Colour   = RGBColour (0,0,0);
     ShadowVert[cont].u32Specular = RGBColour (0,0,0);
     ShadowVert[cont].fUOverW     = 0.1f;
     ShadowVert[cont].fVOverW     = 0.1f;
     cont++;
     }
  }

 /* Shadow faces */
 for (j=0;j<9;j++)
 {
      ShadowFaces[j][0] = 1+j*2; ShadowFaces[j][1] = 0+j*2; 
      ShadowFaces[j][2] = 2+j*2; ShadowFaces[j][3] = 3+j*2;
 }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupTextures                                                  */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SeaTex, SealTex, GroundTex, SkyTex                             */
/*  Description     :   Loads all texture bitmaps.                                     */
/*-------------------------------------------------------------------------------------*/
void SetupTextures (void)
{
      SeaTex     = LoadBMPTexture ("Sea.bmp",    FALSE,  FALSE, TRUE);
      SealTex    = LoadBMPTexture ("Seal.bmp",   FALSE,  TRUE,  FALSE);
      GroundTex  = LoadBMPTexture ("Ground.bmp", FALSE,  TRUE,  FALSE);
      SkyTex     = LoadBMPTexture ("Sky.bmp",    FALSE,  TRUE,  FALSE);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupContex                                                    */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Setup SGLContex values.                                        */
/*-------------------------------------------------------------------------------------*/
void SetupContext (void)
{
    SGLContext.bFogOn               = TRUE;
    SGLContext.fFogR                = 0.1f;
    SGLContext.fFogG                = 0.3f;
    SGLContext.fFogB                = 0.5f;
    SGLContext.u32FogDensity        = 10;
    SGLContext.bCullBackfacing      = FALSE;
    SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
    SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.1f;
    SGLContext.cBackgroundColour[1] = 0.3f;
    SGLContext.cBackgroundColour[2] = 0.5f;
    SGLContext.eShadowLightVolMode  = NO_SHADOWS_OR_LIGHTVOLS;
    SGLContext.bFlipU               = FALSE;
    SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	 SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Perspect                                                       */ 
/*  Inputs          :   Point3D                                                        */  
/*  Outputs         :   Vert                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   None                                                           */
/*  Description     :   Calculates SGL-Direct coordinates from 3D coordenates.         */
/*-------------------------------------------------------------------------------------*/
void Perspect (const sgl_vector Point3D, SGLVERTEX *Vert)
{
const sgl_vector CamPos = { 0.0, 10.0, 150.0};
float x, y, z;

    x    =  Point3D[0] + CamPos[0];
    y    = -Point3D[1] + CamPos[1];
    z    = (Point3D[2] + CamPos[2]);

   Vert->fX    =  (CamFocus * x) / z + 320;
   Vert->fY    =  (CamFocus * y) / z + 240;

   /* The render uses fInvW (1/z) to set the Z-buffer */
   /* In this case I use it to set the fog effect as well */
   Vert->fInvW =  1.8f / z;                   
}
/*------------------------------------------------------------------------------------*/
/*--------------------------- End of File --------------------------------------------*/

 