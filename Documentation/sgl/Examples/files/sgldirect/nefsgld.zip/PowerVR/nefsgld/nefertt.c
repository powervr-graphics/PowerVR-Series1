#include <memory.h>
#include <math.h>
#include <stdio.h>
#include <float.h>
#include "ddraw.h"
#include "nefertt.h"
#include "transform.h"

#define RGBA(r, g, b, a)   ((sgl_uint32) (((a) << 24) | ((r) << 16) | ((g) << 8) | (b)))


typedef unsigned char BYTE;

#define PI				3.141593f/*3.15926f*/
#define ONEOVERTWOPI	(1.0f/(2.0f*PI))

void DoSphericalTextureMapping (int nVertices, sgl_vector Vertices[], sgl_2d_vec UVs[], sgl_vector Centre, float fU, float fV)
{
	int k;

	for (k = 0; k < nVertices; ++k)
	{
		float fX = Vertices[k][0] - Centre[0];

		UVs[k][0] = (((float) atan2 (Vertices[k][2] - Centre[2], fX) + PI) * ONEOVERTWOPI) * fU;
		UVs[k][1] = (((float) atan2 (Vertices[k][1] - Centre[1], fX) + PI) * ONEOVERTWOPI) * fV;
	}
}

void DoCylindricalTextureMapping (int nVertices, sgl_vector Vertices[], sgl_2d_vec UVs[], sgl_vector Centre, sgl_2d_vec CVec, float fU, float fV)
{
	int k;

	for (k = 0; k < nVertices; ++k)
	{
		float fX = Vertices[k][0] - Centre[0];
		float fY = Vertices[k][1] - Centre[1];
		float fZ = Vertices[k][2] - Centre[2];

		UVs[k][0] = (((float) atan2 (fZ, fX) + PI) * ONEOVERTWOPI) * fU;
		UVs[k][1] = fY * fV;
	}
}

void main ()
{
	int device;

    sgl_use_ddraw_mode (NULL, NULL);
	device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	
	if (device >= 0)
	{
		int 				k;
		float 				Theta;
		float 				OxDash, OyDash, SxDash, SyDash;
		TRANSFORM 			T;
		sgl_vector			Tra, Sca, Rot;
		static SGLVERTEX 	SGLVertices[NUM_VERTICES];
		static int	 		SGLFaces[NUM_FACES][3];
		static float		fDot[NUM_VERTICES];
		static SGLCONTEXT 	SGLContext;
		static sgl_2d_vec	UVs[NUM_VERTICES];
		sgl_vector  		LightDir = {0.6667f, 0.6667f, -0.6667f}; 
		sgl_vector  		LightLocal;
		sgl_vector  		MeshCentre = {0.0f, -2.0f, 4.0f};
		sgl_2d_vec  		MeshCVec = {0.0f, 0.0f};
		float 				f1OverLength;
		int					nFrames = 0;

		Tra[0] = 0.0f;
		Tra[1] = 200.0f;
		Tra[2] = 1600.0f;

		Sca[0] = 60.0f; /* 60 */
		Sca[1] = 60.0f;
		Sca[2] = 60.0f;

		Rot[0] = 0.333f;
		Rot[1] = 1.0f;
		Rot[2] = 0.667f;

		Theta = 0.35f;

		OxDash = 320.0f;		/* CamXCentre */
		OyDash = 240.0f;		/* CamYCentre */
		SxDash = 0.6f;			/* zoom factor * 0.5 * CamXSize */
		SyDash = -0.6f;			/* - zoom factor * 0.5 * CamYSize */

		/*
		// Context:
		*/

		SGLContext.bFogOn = FALSE;

		SGLContext.fFogR = 0.1f;
		SGLContext.fFogG = 0.3f;
		SGLContext.fFogB = 0.3f;

		SGLContext.u32FogDensity = 3;

		SGLContext.bCullBackfacing = FALSE;

/*		SGLContext.u32Flags = SGLTT_AVERAGECOLOUR | SGLTT_FACESIND3DFORMAT;
*/
		SGLContext.u32Flags = SGLTT_AVERAGECOLOUR;

		#if TEXTURED

			SGLContext.u32Flags |= SGLTT_TEXTURE;

		#endif

		#if SMOOTH_SHADED

			SGLContext.u32Flags |= SGLTT_GOURAUD;
		
		#endif

		#if TRANSLUCENT_TEXTURE
		
			SGLContext.nTextureName = LoadBMPTexture ("rivets.bmp", TRUE, TRUE, FALSE);
		
		#else
		
			SGLContext.nTextureName = LoadBMPTexture ("rivets.bmp", FALSE, TRUE, FALSE);
		
		#endif

		SGLContext.bDoClipping = TRUE;

		/*SGLContext.cBackgroundColour[0] = 0.5f;*/
		SGLContext.cBackgroundColour[1] = 0.0f;
		SGLContext.cBackgroundColour[2] = 0.0f;
		

		SGLContext.cBackgroundColour[0] = 0.0f;
		

		SGLContext.eShadowLightVolMode = ENABLE_SHADOWS/*NO_SHADOWS_OR_LIGHTVOLS*/;

		SGLContext.bFlipU = TRUE;
		SGLContext.bFlipV = TRUE;
		
		SGLContext.bDoUVTimesInvW = TRUE;

		if (SGLContext.eShadowLightVolMode == ENABLE_SHADOWS)
		{
			SGLContext.u.fShadowBrightness = 0.8f;
		}
		else
		{
			SGLContext.u.u32LightVolColour = 0x00FFFFFF;
		}

		#if GLOBAL_TRANSLUCENCY

			SGLContext.u32Flags |= SGLTT_GLOBALTRANS;
		
		#endif

		#if VERTEX_ALPHA
		
			SGLContext.u32Flags |= SGLTT_VERTEXTRANS;

		#endif

		/*SGLContext.RenderRegions = DONT_RENDER_EMPTY_REGIONS;  */

		for (k = 0; k < NUM_VERTICES; ++k)
		{
			f1OverLength =  1.0f / (float) sqrt (Normals[k][0]*Normals[k][0] + 
												 Normals[k][1]*Normals[k][1] + 
												 Normals[k][2]*Normals[k][2]);

			Normals[k][0] *= f1OverLength;
			Normals[k][1] *= f1OverLength;
			Normals[k][2] *= f1OverLength;
		}

		DoCylindricalTextureMapping (NUM_VERTICES, Vertices, UVs, MeshCentre, MeshCVec, 10.0f, 0.5f);
		
		do
		{
			float		*pV;
			SGLVERTEX	*pSV;
			float		fFogRescale = 1.05f;
		#if TWO_PASSES
			int 		nFaces;
		#endif
			++nFrames;
			
			sgltri_startofframe (&SGLContext);

			Theta += 0.05f;

			MatrixIdentity (&T);
			MatrixTranslate (&T, Tra);
			MatrixScale (&T, Sca);
			MatrixRotate (&T, sgl_y_axis /* Rot */, Theta);
	
			LightLocal[0] = LightDir[0]*T.Inverse[0][0] + LightDir[1]*T.Inverse[0][1] + LightDir[2]*T.Inverse[0][2];
			LightLocal[1] = LightDir[0]*T.Inverse[1][0] + LightDir[1]*T.Inverse[1][1] + LightDir[2]*T.Inverse[1][2];
			LightLocal[2] = LightDir[0]*T.Inverse[2][0] + LightDir[1]*T.Inverse[2][1] + LightDir[2]*T.Inverse[2][2];

			f1OverLength =  1.0f / (float) sqrt (LightLocal[0]*LightLocal[0] + 
												 LightLocal[1]*LightLocal[1] + 
												 LightLocal[2]*LightLocal[2]);

			LightLocal[0] *= f1OverLength;
			LightLocal[1] *= f1OverLength;
			LightLocal[2] *= f1OverLength;

			pSV = SGLVertices;
			pV = (float *) Vertices;

			for (k = 0; k < NUM_VERTICES; ++k, pV += 3, ++pSV)
			{
				float fXws;
				float fYws;
				float fZws;
				float f1OverZ;
				float fI;
				unsigned char u8Col[3];

				#if TWO_PASSES

					fDot[k] = 	T.Inverse[0][2]*Normals[k][0] + 
								T.Inverse[1][2]*Normals[k][1] + 
								T.Inverse[2][2]*Normals[k][2];
				
				#endif

				fXws = (pV[0] * T.Matrix[0][0] + pV[1] * T.Matrix[0][1] + pV[2] * T.Matrix[0][2] + T.Matrix[0][3]) * fFogRescale;
				fYws = (pV[0] * T.Matrix[1][0] + pV[1] * T.Matrix[1][1] + pV[2] * T.Matrix[1][2] + T.Matrix[1][3]) * fFogRescale;
				fZws = (pV[0] * T.Matrix[2][0] + pV[1] * T.Matrix[2][1] + pV[2] * T.Matrix[2][2] + T.Matrix[2][3]) * fFogRescale;

				fZws *= 1.0f / 2000.0f;
				f1OverZ = 1.0f / fZws;

				pSV->fX = (SxDash * fXws * f1OverZ) + OxDash;
				pSV->fY = (SyDash * fYws * f1OverZ) + OyDash;
				pSV->fZ = fZws;
				pSV->fInvW = SxDash * f1OverZ;

				fI = Normals[k][0]*LightLocal[0] + Normals[k][1]*LightLocal[1] + Normals[k][2]*LightLocal[2];

				if (fI < 0.0f)
				{
					fI = -fI;
				}
		
				if (fI > 1.0f)
				{
					fI = 1.0f;
				}

				fI *= 0.75f;
				fI += 0.25f;

  				u8Col[0] = (unsigned char) (fI*0.8549f*255.0f);
				u8Col[1] = (unsigned char) (fI*0.6667f*255.0f);
				u8Col[2] = (unsigned char) (fI*0.0f*255.0f);

				#if VERTEX_ALPHA
				{
					BYTE u8Alpha;
					float f;

					f = (float) cos ((nFrames * 0.1) + (fYws * 0.02)) + 1.0f;
					u8Alpha = (BYTE) (f * 127.5);
					pSV->u32Colour = RGBA (u8Col[0], u8Col[1], u8Col[2], u8Alpha);
				}
				#else
				
					pSV->u32Colour = RGBA (u8Col[0], u8Col[1], u8Col[2], 0);
				
				#endif
				
				pSV->fUOverW = UVs[k][0]; /* * pSV->fInvW; */
				pSV->fVOverW = UVs[k][1]; /* * pSV->fInvW; */
			}

			#if GLOBAL_TRANSLUCENCY
		
				SGLContext.u32GlobalTrans = 0x7F;/* nFrames & 0xFF;*/
						
			#endif

			#if TWO_PASSES

				nFaces = 0;

				for (k = 0; k < NUM_FACES; ++k)
				{
					if ((fDot[Faces[k][0]] + fDot[Faces[k][1]] + fDot[Faces[k][2]]) <= 0.0f)
					{
						SGLFaces[nFaces][0] = Faces[k][0];
						SGLFaces[nFaces][1] = Faces[k][1];
						SGLFaces[nFaces][2] = Faces[k][2];
						nFaces++;
					}
				}

				if (nFaces)
				{
					SGLContext.fTranslucentPassDepth = 1.0f;
					sgltri_triangles (&SGLContext, nFaces, SGLFaces, SGLVertices);
				}

				nFaces = 0;

				for (k = 0; k < NUM_FACES; ++k)
				{
					if ((fDot[Faces[k][0]] + fDot[Faces[k][1]] + fDot[Faces[k][2]]) > 0.0f)
					{
						SGLFaces[nFaces][0] = Faces[k][0];
						SGLFaces[nFaces][1] = Faces[k][1];
						SGLFaces[nFaces][2] = Faces[k][2];
						nFaces++;
					}
				}

				if (nFaces)
				{
					SGLContext.fTranslucentPassDepth = 0.0f;
					sgltri_triangles (&SGLContext, nFaces, SGLFaces, SGLVertices);
				}

			#else

				sgltri_triangles (&SGLContext, NUM_FACES, Faces, SGLVertices);

			#endif

			#if 1
			{
				float SV[8][3] =
				{
					{-1.0f,	-1.0f,	-1.0f},
					{-1.0f,	-1.0f,	1.0f},
					{1.0f,	-1.0f,	1.0f},
					{1.0f,	-1.0f,	-1.0f},
					{-1.0f,	1.0f,	-1.0f},
					{-1.0f,	1.0f,	1.0f},
					{1.0f,	1.0f,	1.0f},
					{1.0f,	1.0f,	-1.0f}
				};

				static int SF[6][3] =
				{
					{0, 4, 5},
					{1, 5, 6},
					{2, 6, 7},
					{3, 7, 4},
					{4, 7, 6},
					{3, 0, 1}
				};

				SGLVERTEX 	ShadowVertices[8];

				sgl_vector	SSca = {100.0f, 100.0f, 100.0f}; 
				sgl_vector	STra = {0.0f, 0.0f, 1600.0f};
				sgl_vector	SRot = {0.5f, 0.5f, 0.5f};

				MatrixIdentity (&T);
				MatrixTranslate (&T, STra);
				MatrixScale (&T, SSca);
				MatrixRotate (&T, SRot, Theta);

				for (k = 0; k < 8; ++k)
				{
					float f1OverZ, fX, fY, fZ;

					fX = (SV[k][0] * T.Matrix[0][0] + 
						  SV[k][1] * T.Matrix[0][1] + 
						  SV[k][2] * T.Matrix[0][2] + T.Matrix[0][3]) * fFogRescale;
					fY = (SV[k][0] * T.Matrix[1][0] + 
						  SV[k][1] * T.Matrix[1][1] + 
						  SV[k][2] * T.Matrix[1][2] + T.Matrix[1][3]) * fFogRescale;
					fZ = (SV[k][0] * T.Matrix[2][0] + 
						  SV[k][1] * T.Matrix[2][1] + 
						  SV[k][2] * T.Matrix[2][2] + T.Matrix[2][3]) * fFogRescale;

					fZ *= (1.0f / 2000.0f);
					f1OverZ = 1.0f / fZ;

					ShadowVertices[k].fX = (SxDash * fX * f1OverZ) + OxDash;
					ShadowVertices[k].fY = (SyDash * fY * f1OverZ) + OyDash;
					ShadowVertices[k].fZ = fZ;
					ShadowVertices[k].fInvW = SxDash * f1OverZ;
				}
	
				sgltri_shadow (&SGLContext, 6, SF, ShadowVertices, NULL);
			}
			#endif

			sgltri_render (&SGLContext);
	
		}
		while(TRUE);

		sgl_delete_device (device);
	}
}

/* end of file */
