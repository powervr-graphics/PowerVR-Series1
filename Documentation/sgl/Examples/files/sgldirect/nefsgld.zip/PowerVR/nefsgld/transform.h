#include "sgl.h"

typedef struct tagTRANSFORM
{
	float Matrix[3][4];
	float Inverse[3][4];
} TRANSFORM;

void MatrixIdentity  (TRANSFORM *);
void MatrixRotate    (TRANSFORM *, sgl_vector, float);
void MatrixScale     (TRANSFORM *, sgl_vector);
void MatrixTranslate (TRANSFORM *, sgl_vector);
