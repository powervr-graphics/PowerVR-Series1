/*----------------------------------------------------------------------------
   Name   : CiberKD (PowerVR SGL-Direct version).
   Author : Carlos Sarria     - send comments to csarria@videologic.com
   Date   : April 1997
   Update : July  1997
   Project: cyberkd.c + frontend.c + sgl.lib
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#define NK  15
#define LAP 7
#define TLP 0.3f

#define SHADOW FALSE

#include <math.h>
#include <time.h>
#include <ddraw.h>

#include "sgl.h"
#include "frontend.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */
#pragma warning (disable : 4056)

#define NAMED_ITEM	TRUE
#define UNAMED_ITEM	FALSE

#define PI 3.142f

#define RGBColour(r, g, b) ((sgl_uint32) (((r) << 16) | ((g) << 8) | (b)))

#define GRV   -9.81
#define HIGH  30.0

/*------------------------------- Global Variables -----------------------------------*/

static sgl_colour 	White   = {0.9f,0.9f,0.9f};
static sgl_colour 	Black   = {0.0f,0.0f,0.0f};
static sgl_colour 	Blue    = {0.1f,0.4f,0.6f};

static sgl_colour 	Yellow  = {0.7f,0.7f,0.3f};

static sgl_colour	Red     = {0.8f,0.1f,0.1f};
static sgl_colour	Grey    = {0.5f,0.5f,0.5f};


int Device;

int GroundTex, SkyTex, CyberKTex;
sgl_intermediate_map BuffTex[5];

int frame, Movement;

int NumMax[NK], LongK[NK], StateK[NK], TimerK[NK];

sgl_vector RotVecK[NK], PathK[NK][200];
float AngK[NK],MovAngK[NK];

sgl_vector p1[NK]={0.0,0.0,200.0}, p2[NK]={0.0,0.0,200.0};

float Sig[2] ={1.0, -1.0}, NewAng[50];

float CamFocus = 600.0f;
SGLCONTEXT SGLContext;

SGLVERTEX  PrismVect   [3][20], TopVect[3][10], BotVect[3][20], ReflectVect[3][20];
sgl_vector Prism3DVect [3][20];
 
int PrismFaces[][4] = { 
           {0,2,1,9},     {8,3,2,9},     {7,4,3,8},     {6,5,4,7},
           {0,1,11,10},   {1,2,12,11},   {2,3,13,12},   {3,4,14,13},   {4,5,15,14},
           {5,6,16,15},   {6,7,17,16},   {7,8,18,17},   {8,9,19,18},   {9,0,10,19},
           {10,12,11,19}, {18,13,12,19}, {17,14,13,18}, {16,15,14,17} };

sgl_uint32  PrismCol [NK][10];    

/*----------------------------  Routines Prototypes ---------------------------------*/

void SetupTextures   (void),
     SetupContext    (void),
     SetupPrism      (void);

void DrawGround      (void),
     DrawSky         (void),
     CreatePath      (int),
     NewPoint        (int),
     DrawCyberK      (int, int);

void Perspect (const sgl_vector, SGLVERTEX *);
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device                                                         */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
int SetupScene (int xsize, int ysize, int pixdepth)
{
int i;
   
     Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, FALSE);
     if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

     srand ((unsigned)time(NULL));
	 SetCursor (NULL);   /* This hides the pointer */

     SetupContext  ();
     SetupTextures ();
     SetupPrism    ();

     for (i=0; i<NK; i++){
         LongK[i] = 60.0;
         StateK[i] = i&3;
         p1[i][2]  = p2[i][2]= -170;
         NewAng[i] = (float)((char)(rand()))*(50.0/255.0);
         NewPoint     (i);
         CreatePath   (i);
     }

 frame = 0;
 return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContext, MovAngK, AngK, LongK, TimerK, StateK              */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame()
{
 register i;   

 sgltri_startofframe (&SGLContext);
      DrawGround();
      DrawSky   ();

      /* We have three diferent States: 0. Before jump (Only rotation)          */
      /*                                1. In the air. (Rotion and traslation)  */
      /*                                2. On the ground again (Only rotation)  */
      for (i=0; i<NK; i++){
         switch (StateK[i]){
               default:
               case 0: MovAngK[i]+=AngK[i]/LAP; LongK[i]+=3.3; DrawCyberK(0,i); 
                       if (TimerK[i]==LAP){TimerK[i]=-1; StateK[i]=1;}
                       break;
               case 1: MovAngK[i]-=(2.0*AngK[i])/NumMax[i]; LongK[i]=60; DrawCyberK(TimerK[i], i); 
                       if (TimerK[i]==NumMax[i]-1){TimerK[i]=-1; StateK[i]=2;}
                       break;
               case 2: MovAngK[i]+=AngK[i]/LAP; LongK[i]-=3.3;  DrawCyberK(NumMax[i]-1,i); 
                       if (TimerK[i]==LAP){TimerK[i]=-1; StateK[i]=0; NewPoint(i); CreatePath(i);}
                       break;
        }
     TimerK[i]++;
     }

  
sgltri_render (&SGLContext);

  frame++; 
  Movement++; if (Movement == 400) Movement = 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/				   
void Finish()
{
    FreeAllBMPTextures ();
    sgl_delete_device  (Device);	
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawGround                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Draw ground.                                                   */
/*-------------------------------------------------------------------------------------*/
void DrawGround()
{
SGLVERTEX  Vert[4];
int   Face[1][4] = {0,1,2,3}, i;
float Pos;
/* Four points to set a big quad. */
sgl_vector Pnt[4] =  {{-5000.0f,  -0.0f, -100.0f},           
                      {-5000.0f,  -0.0f, 8000.0f},
                      { 6000.0f,  -0.0f, 8000.0f},
                      { 6000.0f,  -5.0f, -100.0f}};	


    for (i=0; i<4; i++){
        /* Translate from 3D to SGL-Direct coord. */
        Perspect (Pnt[i], &Vert[i]);                     
        /* Set the colour for each vertex. */
        Vert[i].u32Colour   = RGBColour (255,255,255);    
        Vert[i].u32Specular = RGBColour (255,255,255);
   }

    /* Here the continous fluency of the ground.  */
    /* Note that I just move texture's UV values. */
    /* I don't move the camera.                   */
    Pos = Movement/50.0;
    
    /* Set UV values for each textured vertex. */
    Vert[0].fUOverW = 0.0f;    Vert[0].fVOverW = Pos + 0.0f;          
    Vert[1].fUOverW = 0.0f;    Vert[1].fVOverW = Pos + 30.0f;
    Vert[2].fUOverW = 35.0f;   Vert[2].fVOverW = Pos + 20.0f;
    Vert[3].fUOverW = 0.0f;    Vert[3].fVOverW = Pos + 0.0f;

    /* Set a sigle textured and transparent quad to create the ground. */
    SGLContext.nTextureName   = GroundTex;    
    SGLContext.u32Flags       = SGLTT_TEXTURE | SGLTT_GLOBALTRANS | SGLTT_BILINEAR;
    SGLContext.u32GlobalTrans = 160;
    SGLContext.bFlipU         = TRUE;

    sgltri_quads (&SGLContext, 1, Face, Vert);           

    SetupContext ();
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawSky                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Draw Sky. (The same as DrawGround)                             */
/*-------------------------------------------------------------------------------------*/
void DrawSky()
{
float Pos=0;
SGLVERTEX  Vert[4];
int Face[1][4] = {0,1,2,3}, i;
sgl_vector Pnt[4] = {{-4000.0f,600.0f, -100.0f}, 
                     {-4000.0f,600.0f, 50000.0f},
                     { 8000.0f,600.0f, 50000.0f},
                     { 8000.0f,600.0f, -100.0f}};	


    for (i=0; i<4; i++){ 
        Perspect (Pnt[i], &Vert[i]);
        Vert[i].u32Colour   = RGBColour (255,255,255);
        Vert[i].u32Specular = RGBColour (255,255,255);
    }
    
    /* Here the continous fluency of the sky.     */
    /* I just move texture's UV values.           */
    Pos = Movement/400.0; 

    Vert[0].fUOverW = 0.0;  Vert[0].fVOverW = Pos-0.0;  
    Vert[1].fUOverW = 0.0;  Vert[1].fVOverW = Pos+20.0;
    Vert[2].fUOverW = 10.0; Vert[2].fVOverW = Pos+5.0;
    Vert[3].fUOverW = 10.0; Vert[3].fVOverW = Pos+00.0;


    SGLContext.nTextureName = SkyTex;
    sgltri_quads (&SGLContext, 1, Face, Vert);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   CreatePath                                                     */ 
/*  Inputs          :   Num                                                            */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   PathK, p1, p2, RotVect, MovAngK, AngK                          */
/*  Description     :   Calculates a parabolic path (jump) for each CyberK             */
/*-------------------------------------------------------------------------------------*/
void CreatePath (int Num)
{
int i=0;
float dist, t=0, A, CosA, SinA, x, Vel, Lang;
sgl_vector End1, End2;

End1[0]=p1[Num][0];End1[2]=p1[Num][2]; End2[0]=p2[Num][0];End2[2]=p2[Num][2];

dist = sqrt ((End2[2]-End1[2])*(End2[2]-End1[2])+(End1[0]-End2[0])*(End1[0]-End2[0]));

RotVecK[Num][0] = (End2[2]-End1[2]);
RotVecK[Num][1] = 0.0;
RotVecK[Num][2] = (End1[0]-End2[0]);

if (fabs(RotVecK[Num][2]) < 0.1) RotVecK[Num][2] *= 10.0;
 
A = -atan ( (End1[2]-End2[2])/(End1[0]-End2[0]) );
CosA = (End1[0]<End2[0]) ?  cos(A) : -cos(A);
SinA = (End1[0]<End2[0]) ? -sin(A) :  sin(A);

MovAngK[Num] = 0.0;  Lang = atan (-4 * HIGH / dist);
AngK[Num]  = ((PI/2.0)+Lang)/1.2;
AngK[Num]  = (End1[0]<End2[0]) ? -AngK[Num]:AngK[Num];
Vel  = sqrt (GRV * dist / sin(2*Lang));

while (1){
      x = Vel * cos(Lang) * t;
      PathK[Num][i][1] = -Vel * sin (Lang) * t + GRV/2 * t*t;
      PathK[Num][i][0] = End1[0] + CosA*x;
      PathK[Num][i][2] = End1[2] + SinA*x;
      if (PathK[Num][i][1]<0.0 && i>1) break;
       t += TLP; i++;
      }

PathK[Num][i][0] = p2[Num][0];
PathK[Num][i][1] = p2[Num][1];
PathK[Num][i][2] = p2[Num][2];

NumMax[Num]=++i;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NewPoint                                                       */ 
/*  Inputs          :   Num                                                            */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   NewAng, p1, p2                                                 */
/*  Description     :   Calculates two end points for creating a new path (jump).      */
/*-------------------------------------------------------------------------------------*/
void NewPoint (int Num)
{
    NewAng[Num]+=((float)((char)(rand()))/255.0) * (2.5-Num*(2.0/50));

    p1[Num][0]=p2[Num][0]; p1[Num][2]=p2[Num][2];

    p2[Num][0] = 50*(Num/2.0+1)*cos(NewAng[Num]/2.0);
    p2[Num][2] = 50*(Num/2.0+1)*sin(NewAng[Num]/2.0) + 500 + frame*5;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupTextures                                                  */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SeaTex, SealTex, GroundTex, SkyTex                             */
/*  Description     :   Loads all texture bitmaps.                                     */
/*-------------------------------------------------------------------------------------*/
void SetupTextures (void)
{

    CyberKTex  = LoadBMPTexture ("CyberK.bmp", FALSE,  TRUE,  TRUE);
    GroundTex  = LoadBMPTexture ("Ground.bmp", FALSE,  FALSE, TRUE);
    SkyTex     = LoadBMPTexture ("Sky.bmp",    FALSE,  TRUE,  TRUE);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupContex                                                    */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Setup SGLContex values.                                        */
/*-------------------------------------------------------------------------------------*/
void SetupContext (void)
{
     SGLContext.bFogOn               = TRUE;
     SGLContext.fFogR                = 0.1f;
     SGLContext.fFogG                = 0.4f;
     SGLContext.fFogB                = 0.6f;
     SGLContext.u32FogDensity        = 7;
     SGLContext.bCullBackfacing      = FALSE;
     SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
     SGLContext.nTextureName         = 0;
     SGLContext.bDoClipping          = TRUE;
     SGLContext.cBackgroundColour[0] = 0.1f;
     SGLContext.cBackgroundColour[1] = 0.5f;
     SGLContext.cBackgroundColour[2] = 0.7f;
     SGLContext.eShadowLightVolMode  = NO_SHADOWS_OR_LIGHTVOLS;
     SGLContext.bFlipU               = FALSE;
     SGLContext.bFlipV               = FALSE;
     SGLContext.bDoUVTimesInvW       = TRUE;
	 SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Perspect                                                       */ 
/*  Inputs          :   Point3D                                                        */  
/*  Outputs         :   Vert                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   None                                                           */
/*  Description     :   Calculates SGL-Direct coordenates from 3D coordenates.         */
/*-------------------------------------------------------------------------------------*/
void Perspect (const sgl_vector Point3D, SGLVERTEX *Vert)
{
const sgl_vector CamPos = { 0.0, 40.0, 150.0};
float x, y, z;

    x    =  Point3D[0] + CamPos[0];
    y    = -Point3D[1] + CamPos[1];
    z    = (Point3D[2] + CamPos[2]) ;

    Vert->fX    =  (CamFocus * x) / z + 320;
    Vert->fY    =  (CamFocus * y) / z + 240;

    /* The render uses fInvW (1/z) to set the Z-buffer */
    /* In this case I use it to set the fog effect as well */
     Vert->fInvW =  1.8f / z;                   
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupPrisms                                                    */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Prism3DVert, PrismVert                                         */
/*  Description     :   Setup prisms vertex                                            */
/*-------------------------------------------------------------------------------------*/
void SetupPrism (void)
{
int Sh[] = {0, 150, 200, 255, 255, 200, 150, 85, 0, 0};
int ColR, ColG, ColB, ColRSh, ColGSh, ColBSh;
register i, j, k;
int cont = 0;

/* Here we set values for a default CyberK (3 prisms) */
for (j=0; j<2; j++){
   for (i=0; i<10; i++){
            for (k=0; k<3; k++) {
                Prism3DVect[k][cont][0]          = (2.0+k*4.0) * cos ((i*PI*2.0)/9.0);
                Prism3DVect[k][cont][1]          = j*20.0f;
                Prism3DVect[k][cont][2]          = (2.0+k*4.0) * sin ((i*PI*2.0)/9.0);
                PrismVect[k][cont].fUOverW       = (float)(i+2)/9.0;
                PrismVect[k][cont].fVOverW       = (float)(j)/0.95;
                ReflectVect[k][cont].fUOverW     = (float)(i+2)/9.0;
                ReflectVect[k][cont].fVOverW     = (float)(j)/0.95;
            }
       cont++;
   }
}

  /* Here we set the color and the shade for each vertex */
  for (i=0; i<NK; i++)
  {
    ColR = 50+(int)(rand() & 0x00FF)*200/255;
    ColB = 50+(int)(rand() & 0x00FF)*200/255;
    ColG = 50+(int)(rand() & 0x00FF)*200/255;

    for (j=0; j<10; j++){
        ColRSh = (ColR * Sh[j])/200; if (ColRSh > 255) ColRSh = 255;
        ColGSh = (ColG * Sh[j])/200; if (ColGSh > 255) ColGSh = 255;
        ColBSh = (ColB * Sh[j])/200; if (ColBSh > 255) ColBSh = 255;         
        PrismCol [i][j] = RGBColour (ColRSh, ColGSh, ColBSh);
    }
  }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawCyberK                                                     */ 
/*  Inputs          :   PNum                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Prism3DVert, PrismVert                                         */
/*  Description     :   Draw six prisms to build a CyberK and its reflection           */
/*-------------------------------------------------------------------------------------*/
void DrawCyberK (int Pos,int KNum)
{
register i, j, k, cont=0, Sign = TRUE;
float TempAng, xx, x, y, z;
sgl_vector TempVect;
float CosZ, SinZ, CosY, SinY, CurrentLong;

   if (PathK[KNum][Pos][2]-frame*5 < -210) return;

   TempAng = -atan ((RotVecK[KNum][0]/RotVecK[KNum][2]));

   if (RotVecK[KNum][0] < 0.0 || RotVecK[KNum][2] < 0.0) Sign = FALSE;

   CosZ = cos (MovAngK[KNum]);
   SinZ = sin (MovAngK[KNum]);
   CosY = cos (TempAng);
   SinY = sin (TempAng);
 
   for (k=0; k<3; k++)
   {
    CurrentLong =  k*((LongK[KNum])/3.0) - k*(60-LongK[KNum])/5.0;
    for (j=0; j<2; j++)
    {
      for (i=0; i<10; i++)
      {
         x =  Prism3DVect[k][cont][0];
         y =  Prism3DVect[k][cont][1];
         z =  Prism3DVect[k][cont][2];

         if (Sign) { x=-x;  z=-z;}
         
    /* VERTICAL TRANSLATION */
         y += CurrentLong;
    /* Z_AXIS ROTATION      */
         xx = x;
         x  = xx * CosZ - y  * SinZ;
         y  = y  * CosZ + xx * SinZ;
    /* Y_AXIS ROTATION      */
         xx = x;
         x  = xx * CosY - z  * SinY;
         z  = z  * CosY + xx * SinY;
    /* TRANSLATION          */
        TempVect[0] = x + PathK[KNum][Pos][0];
        TempVect[1] = y + PathK[KNum][Pos][1];
        TempVect[2] = z + PathK[KNum][Pos][2] - frame*5 + 100;

        Perspect (TempVect, &PrismVect[k][cont]);

        TempVect[1] = -TempVect[1];
        Perspect (TempVect, &ReflectVect[k][cont]);

    /* Setting smooth shading */
        PrismVect   [k][cont].u32Colour   = PrismCol[KNum][i];
        PrismVect   [k][cont].u32Specular = RGBColour (255, 255, 255);
        ReflectVect [k][cont].u32Colour   = PrismCol[KNum][i];
        ReflectVect [k][cont].u32Specular = RGBColour (255, 255, 255);;
   
       cont++;
       }
    }
    cont = 0;
    SGLContext.nTextureName  = CyberKTex;
    sgltri_quads   (&SGLContext, 14, &(PrismFaces[4]), PrismVect[k]);
    sgltri_quads   (&SGLContext, 14, &(PrismFaces[4]), ReflectVect[k]);
    
    /* We change the colour for simulating the shade on the bottom face */ 
    for (i=0; i<20; i++) 
    {
        PrismVect[k][i].u32Colour     = RGBColour ( 60, 60, 60);
        ReflectVect[k][i].u32Colour   = RGBColour ( 60, 60, 60);
    }
    sgltri_quads   (&SGLContext, 4, &(PrismFaces[0]),   PrismVect[k]);
    sgltri_quads   (&SGLContext, 4, &(PrismFaces[0]), ReflectVect[k]);
  } 
}
/*-------------------------------------------------------------------------------------*/
/*------------------------------------ End of File ------------------------------------*/

