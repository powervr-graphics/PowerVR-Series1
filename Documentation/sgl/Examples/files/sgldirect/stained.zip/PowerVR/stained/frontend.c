/*****************************************************************************
  Name : FRONTEND.C  (Reduced Version)
  Date : February 1997
  Platform : ANSI compatible

  Copyright : 1997 by VideoLogic Limited. All rights reserved.   
******************************************************************************/

#include <windows.h>
#include <mmsystem.h> 
#include <stdlib.h>

#include <ddraw.h>
#include <sgl.h>

#include "frontend.h" 

static HINSTANCE    hInst;
static HWND         hwnd;
static BOOL         bActive;
static DWORD        LastError;
static BOOL         bInfo=0;
static BOOL         bQuit = FALSE;
static BYTE         nStrictLocks = 0;
static BOOL         bDisplayFPS = FALSE;

extern float YAng, XAng;
extern int   TPos, UpVert;

static long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam);
static int  eor_callback (void);
static void GetStrictLocksFlag (void);

char Temp[200];
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   WinMain                                                        */ 
/*  Inputs          :   hInstance, hPrevInstance, lpszCmdParam, nCmdShow               */  
/*  Outputs         :   None                                                           */
/*  Returns         :   0 if successful                                                */
/*  Globals Used    :   hWnd, bActive, hInst, nStrictLocks                             */
/*  Description     :   This is the initialization of a Windows application.           */
/*                      This routine calls SetupScene(), NextFrame() and Finish()      */
/*-------------------------------------------------------------------------------------*/
int PASCAL WinMain ( HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
MSG         msg;
WNDCLASS    wndclass;
int         iret;
int         loopcount;

     hInst = hInstance;

     if (!hPrevInstance)	{
        wndclass.style = CS_HREDRAW | CS_VREDRAW;
        wndclass.lpfnWndProc = WndProc;
        wndclass.cbClsExtra = 0;
        wndclass.cbWndExtra = 0;
        wndclass.hInstance = hInstance;
        wndclass.hIcon = NULL;
        wndclass.hCursor = NULL;
        wndclass.hbrBackground = NULL;
        wndclass.lpszMenuName = NULL;
        wndclass.lpszClassName = "SGLClass";
        RegisterClass (&wndclass);
    }

    hwnd = CreateWindowEx(WS_EX_TOPMOST, "SGLClass", NULL, WS_POPUP|WS_VISIBLE, 0, 0, 
                          GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),
                          NULL, NULL, hInstance, NULL );

    if (hwnd == NULL) {LastError = GetLastError();	return FALSE;}
	
    Sleep(200);

    nStrictLocks=0;
     /*
      This function may be needed for maximun compatibility
       GetStrictLocksFlag ();
    */
    
	/* Put sgl into direct draw mode */
    iret =  sgl_use_ddraw_mode (hwnd, NULL); 

    if (iret != sgl_no_err){
       ShowWindow(hwnd,SW_HIDE);
       MessageBox (NULL,"ERROR : sgl_use_ddraw_mode failed",NULL,MB_OK);
       DestroyWindow(hwnd);
       return FALSE;
    }
	
    iret = SetupScene ();

    if (iret != sgl_no_err) {
       if (iret == ERR_CREATE_SCREEN_DEVICE)
          MessageBox(NULL,"sgl_create_screen_device\n\nERROR : Graphics device does not support required direct draw mode", NULL, MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
	
          if (iret == ERR_CREATE_VIEWPORT)
          MessageBox(NULL,"sgl_create_viewport\n\nERROR : Graphics device does not support required direct draw mode",NULL, MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
		

          DestroyWindow(hwnd);
          return FALSE;
       }
       bActive = TRUE;

      if (nStrictLocks) {
          loopcount = 100;

         while (loopcount--)  {
               if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE )){
                  if (!GetMessage( &msg, NULL, 0, 0 ))  return msg.wParam;

                      TranslateMessage(&msg); 
	  DispatchMessage(&msg);
	  }
	  }

	  iret = sgl_use_eor_callback(&eor_callback);

	   while (!bQuit)  NextFrame();
                       Sleep(100);
                       Finish();
                    }

                else{
                    while (1){
                          if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE )) {
                            if (!GetMessage( &msg, NULL, 0, 0 )) {Finish(); break;}
                               TranslateMessage(&msg); 
                               DispatchMessage(&msg);
                          }
                          else if (bActive) NextFrame();
                          else WaitMessage();
                     }
                   }

return 0;
}
/*----------------------------------------------------------------------------------------*/
/*  Function Name   :   eor_callback                                                      */ 
/*  Inputs          :   None                                                              */  
/*  Outputs         :   None                                                              */
/*  Returns         :   0 if successful                                                   */
/*  Globals Used    :   bActive                                                           */
/*  Description     :   End of render callback.                                           */
/*                      As soon as the buffer is unlocked then Windows can process        */
/*	                    it's message loop.                                                */
/*	                    If this were not done here then Windows would wait for the Direct */ 
/*	                    Draw unlock before updating it's display; and we wan't to remove  */
/*                      all wait states !                                                 */                  
/*----------------------------------------------------------------------------------------*/
int eor_callback (void)
{
MSG  msg;

    while(1)
    {
     if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE )){
        if (!GetMessage( &msg, NULL, 0, 0 )) { bQuit = TRUE;  return 1;}

        TranslateMessage(&msg); 
        DispatchMessage(&msg);
     }

	 // I have removed this delay. 
	 //Sleep(10); /* Allow the mouse some time to move */

      if (bActive) break; 
     }

 return 0; 
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   WndProc                                                        */ 
/*  Inputs          :   hwnd, message, wParam, lParam                                  */  
/*  Outputs         :   None                                                           */
/*  Returns         :   DefWindowProc ()                                               */
/*  Globals Used    :   hWnd, bActive, hInst                                           */
/*  Description     :   This is the control routine of this Windows application.       */
/*-------------------------------------------------------------------------------------*/
long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam)
{

switch (message){

    case WM_ACTIVATEAPP:
             bActive = (BOOL)wParam;
             break;
		
    case WM_CREATE:
            return 0;
		
    case WM_DESTROY:
            bQuit = TRUE;
            PostQuitMessage (0);
            return 0;
		
    case WM_KEYDOWN:
		UpVert = 1;
		switch(wParam){
             case VK_F12:
             case VK_ESCAPE:
                  bActive = FALSE;
                  Sleep(100);
                  PostMessage(hwnd, WM_CLOSE, 0, 0);
                  break;
             
             case VK_F1:  
				  TPos+=10; 
				  break;
             case VK_F2: 
				  if (TPos>-60)TPos-=10; 
				  break;	  
             case VK_RIGHT: 
				  YAng+=0.06f;
				  break;
			 case VK_LEFT: 
				  YAng-=0.06f;
				  break;
             case VK_UP:  
				  XAng+=0.06f;
				  break;
             case VK_DOWN: 
				  XAng-=0.06f;
				  break;
          }
          break;
    }

return DefWindowProc (hwnd, message, wParam, lParam);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   GetStrictLocksFlag                                             */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   nStrictLocks                                                   */
/*  Description     :   Reads the value of the StrictLocks flag.                       */
/*  Notes           :  -The StrictLock flag is in sglhw.ini if the driver is v4.0.0.29 */
/*                      or lower, otherwise the flag is in a Windows registry.         */
/*                     -If the version is 4.0.0.75 or higher use the SGL API call      */
/*                      sgl_get_ini_int (&nStrictLocks, 0, "Default","StrictLocks")    */
/*-------------------------------------------------------------------------------------*/
void GetStrictLocksFlag (void)
{
FARPROC pfn;
HINSTANCE hmodule;
HKEY hKey;
DWORD size=2;
register i = 0;
sgl_versions *Versions;
char Val=1, Tmp[200], buffer[500];
long SGLVer;
	
        Versions = sgl_get_versions(); /* Information about SGL driver */
     
        /* The version number is converted from a string to a long */
        while (Val != 0) 
        {
          Val = *(Versions->library++);
          if (Val>='0' && Val<='9') Tmp[i++] = Val;
        }
        SGLVer = (long)atol(Tmp);
         
        if (SGLVer >= 40075L)
        {
          /* If the version is 4.0.0.75 or higher use the SGL API call       */
	      hmodule = LoadLibrary("sgl.dll");
          pfn = GetProcAddress(hmodule, "sgl_get_ini_int"); 
          pfn (&nStrictLocks, 0, "Default","StrictLocks"); 
          FreeLibrary(hmodule);
       }
        else 
        if (SGLVer > 40029L)
        {
          /* Otherwise, read the Windows registry */ 
          RegOpenKeyEx (HKEY_LOCAL_MACHINE, 
			           "SOFTWARE\\VideoLogic\\PowerVR\\HWINI\\Defaults", 0,KEY_READ, &hKey);
          RegQueryValueEx (hKey, "StrictLocks", NULL, NULL, (LPBYTE)Tmp, (LPDWORD)&size);
          RegCloseKey  (hKey);
		  nStrictLocks = atoi(Tmp);
          OutputDebugString(buffer);
        }
        else
        {
          /* If the version is 4.0.0.29 or lower read "sglhw.ini" */ 
          nStrictLocks = GetPrivateProfileInt("Default","StrictLocks",0,"sglhw.ini");
        }  

}
/*-----------------------------------  END OF FILE ---------------------------------------*/
