/*-----------------------------------------------------------------------------
   Name   : STAINED  ( PowerVR SGL-Direct )
   Author : Carlos Sarria    - send comments to csarria@videologic.com       
   Date   : July 1997
   Project: stained.c + frontend.c + sgl.lib
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#include <math.h>
#include <malloc.h>
#include <windows.h>
#include <ddraw.h>

#include "sgl.h"
#include "frontend.h"
#include "stained.h"   /* This is the file with 3D data */
       
#pragma warning (disable : 4244) /* Disables float to double conversion warning */

#define PI	3.1416f

int   Device,  Init = TRUE,  frame,  TPos = 280,  UpVert=1;
int   Texture[100], PosX = 10; PosY = 10;
float Shad[255], GroundSh[1000];
float XAng1 = 0.00f,  YAng1 = 0.001f;
float XAng  = -6.3f,  YAng  =-18.85f;

SGLVERTEX  *TempVert[NUM_MESHES];
SGLCONTEXT SGLContext;
sgl_intermediate_map BuffTex[5];
sgl_uint32 GroundCo[1000][3], GCo[1000][3], Logo[50][50][3];

#define RGBColour(r, g, b) ((sgl_uint32) (((sgl_uint32)(r&0x000000FF)<<16) | ((sgl_uint32)(g&0x000000FF) << 8) | (sgl_uint32)(b&0x000000FF)))

void SetupContext   (void);
void SetupTextures  (void);
void InitMeshes     (void);
void DrawAll        (void);
void UpdateVertex   (int Num);
void Shading        (int Num);
void GroundColour   (void);
void CalculateLight (void);
void ShadingGround  (void);
void MoveLamp       (void);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device                                                         */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
    Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE); 
	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

    sgl_qual_texture_filter (sgl_tf_bilinear);
 
    SetupTextures (); 
	SetupContext  ();

    InitMeshes ();

    SetCursor (NULL);  /* This hides the pointer */

    return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContext                                                     */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame()
{
   sgltri_startofframe (&SGLContext);
	 DrawAll ();
   sgltri_render   (&SGLContext);

   frame++; 
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/						   
void Finish()
{
  FreeAllBMPTextures ();
  sgl_delete_device(Device);	
  Init = FALSE;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  DrawAll                                                         */ 
/*  Inputs          :  None                                                            */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, XAng1, YAng1, SGLContext                            */
/*  Description     :  Updates and draws all the meshes in the model.                  */
/*  Note            :  The definition of Mesh[i] struct is in logo.h                   */
/*-------------------------------------------------------------------------------------*/	
void DrawAll()
{
register i;

    MoveLamp();
    GroundColour ();  /* Calculates new colors */

    for (i=0; i<NUM_MESHES; i++){
               
		if(UpVert==1 || i==LIGHT) UpdateVertex (i); /* Only updates vertices if the scene has changed */
        if (i==NUM_MESHES-1) UpVert=0;
      
		/* Updating texture parameters for each mesh of the model */
	    SGLContext.nTextureName = Texture[Mesh[i].Material];
        SGLContext.u32Flags     = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
    
        /* Drawing triangles... */
        sgltri_triangles (&SGLContext, Mesh[i].NumFaces, (int(*)[3])Mesh[i].Faces, TempVert[i]);
    } 

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupTextures                                                    */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : NumMaterials, Texture, MatInfo                                   */
/*  Description     : Loads BMP files getting the information from MatInfo struct      */
/*-------------------------------------------------------------------------------------*/
void SetupTextures (void)
{
register i;

  for (i=0;i<NumMaterials; i++){
         if (*(MatInfo[i].MatFile) == 0) continue;
         BuffTex[i] = ConvertBMPtoSGL   (MatInfo[i].MatFile, FALSE);
         Texture[i] = sgl_create_texture( sgl_map_16bit, sgl_map_128x128, 		
						            	FALSE, FALSE, &BuffTex[i],  NULL);
      }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupContext                                                     */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : SGLContext                                                       */
/*  Description     : Sets default values for the render context.                      */
/*-------------------------------------------------------------------------------------*/	
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 5;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD |SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = ENABLE_SHADOWS;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.RenderRegions        = 0;
    SGLContext.n32MipmapOffset      = 0;
    SGLContext.u32GlobalTrans       = 255;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : InitMeshes                                                       */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Shad, Mesh, TempVert, TempNormals                                */
/*  Description     : Sets initials values for meshes managing                         */
/*-------------------------------------------------------------------------------------*/	
void InitMeshes (void)
{
register i,j, k=0;

    /* This function is in stained.h and creates an array of structures with 3D data */
    CreateMeshesArray ();

	/* Shad is a 255 values array with information for smooth shading */
    for (i=0; i<120; i++) Shad[k++] = (float)(120-i)/480.0;
    for (i=0; i<100; i++) Shad[k++] = (float) i/100.0;
    for (i=0; i<35;  i++) Shad[k++] = 1.0f;

	/* Memory allocation for TempVert */ 
    for (i=0; i<NUM_MESHES; i++) TempVert[i] = (SGLVERTEX *) malloc (Mesh[i].NumVertex*sizeof(SGLVERTEX));

	/* Calculate colour array */
    CalculateLight ();
   
	/* Setting UV values for all the meshes */
    for (j=0; j<NUM_MESHES;j++){
		 Shading (j);  /* setting vertices colour just once */
         for (i=0; i<Mesh[j].NumVertex; i++){
            (TempVert[j]+i)->fUOverW    =  (Mesh[j].TexMap==TRUE) ? *(Mesh[j].UV+i*2+0) : 0;
            (TempVert[j]+i)->fVOverW    =  (Mesh[j].TexMap==TRUE) ? *(Mesh[j].UV+i*2+1) : 0; 
       }
    }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : UpdateVertex                                                     */ 
/*  Inputs          : Num (the mesh in the model)                                      */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : XAng, YAng                                                       */
/*  Description     : Turns vertices around two axes.                                  */
/*-------------------------------------------------------------------------------------*/	
void UpdateVertex (int Num)
{
sgl_vector Temp;
int i, j=0, k=0, l=0;
float x, y, z, CosX, SinX, CosY, SinY, CamZ, CamFocus = 500.0f;

CosX = cos(XAng); SinX = sin(XAng);
CosY = cos(YAng); SinY = sin(YAng);

  
    for (i=0; i<Mesh[Num].NumVertex; i++){
 
         x = *(Mesh[Num].Vertex+k++)-GroupCenter[0];
         y = *(Mesh[Num].Vertex+k++)-GroupCenter[1];
         z = *(Mesh[Num].Vertex+k++)-GroupCenter[2];

         /* Temp is the outcome vertex after the rotation */
         Temp[0]  = x * CosY - z * SinY;
         Temp[2]  = z * CosY + x * SinY;

         z        = Temp[2];
         Temp[1]  = y * CosX - z * SinX;
         Temp[2]  = z * CosX + y * SinX + TPos;

         if (Temp[2] <=0.1) Temp[2] = 0.001f;

         /* We store the SGL vertex in TempVert */    
         CamZ = 1.0/(Temp[2]);
    	 (TempVert[Num]+i)->fX    =  CamFocus * CamZ * Temp[0] + 320;
         (TempVert[Num]+i)->fY    = -CamFocus * CamZ * Temp[1] + 240;
	     (TempVert[Num]+i)->fInvW =  CamZ;
               
   }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : Shading                                                          */ 
/*  Inputs          : Num                                                              */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Light1, MatInfo, Mesh, TempVert                                  */
/*  Description     : Shades a mesh.                                                   */
/*-------------------------------------------------------------------------------------*/	
void Shading (int Num)
{
float Light1[3] = { 0, 0.5, 1};
float TCo, Dir;
register l=0, i=0, k=0;
float Sh, LTemp[3], x, y, z;
sgl_uint32 Col;

    Dir = sqrt (Light1[0]*Light1[0]+Light1[1]*Light1[1]+Light1[2]*Light1[2]);
    LTemp[0] = Light1[0]/Dir;
	LTemp[1] = Light1[1]/Dir; 
	LTemp[2] = Light1[2]/Dir;

    k = Mesh[Num].Material;

    for (i=0; i<Mesh[Num].NumVertex; i++){
      
        x = *(Mesh[Num].Normals+l++);
        y = *(Mesh[Num].Normals+l++);
        z = *(Mesh[Num].Normals+l++);

		/* Sh is a value from 0.0 to 1.0 depending on the angle between a normal */
		/* and the light direction.                                              */
        Sh = fabs( LTemp[0] * x + LTemp[1] * y + LTemp[2] * z + 1.0);

        TCo = Shad[(int)(127.0*Sh)];
        Col = 255*TCo;

        if (Num==GROUND) GroundSh[i] = TCo; /* Original values */
        if (Num!=WALL) Col =255;
       
       (TempVert[Num]+i)->u32Colour  = RGBColour (Col,Col,Col);
    }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : GroundColour                                                     */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : GroundSh, TempVert, PosX, PosY                                   */
/*  Description     : Sets colours for lighted ground (colouring vertices).            */
/*-------------------------------------------------------------------------------------*/	
void GroundColour (void)
{
sgl_uint32 Col[3];
register i, j, cont = 0;

      
      for (j=0; j<31; j++)
	  { 
          for (i=0; i<31; i++)
		  {
			  /* Sets stained glass colours on the ground.   */
			  /* PosX and PosY have been calculated already. */
              if (i > PosX  && i<PosX+10 && j<15+PosY && j> PosY) 
			  {
                  GroundCo[i+j*31][0] = Logo[i-PosX][j-PosY][0];
                  GroundCo[i+j*31][1] = Logo[i-PosX][j-PosY][1];
                  GroundCo[i+j*31][2] = Logo[i-PosX][j-PosY][2];
              }
              else
			  {
				 /* Sets white light colour */
                 if (i>PosX+18) GroundCo[i+j*31][0] = GroundCo[i+j*31][1]= GroundCo[i+j*31][2] = 250.0;
				 /* Set shadow colour */
                 else           GroundCo[i+j*31][0] = GroundCo[i+j*31][1]= GroundCo[i+j*31][2] = 50.0;
              }
         }
     }

      /* Calculates average colour for each vertex */
      for (j=0; j<31; j++)
	  { 
          for (i=0; i<31; i++)
		  {
               GCo[cont][0] = GroundCo[cont][0];
               GCo[cont][1] = GroundCo[cont][1];
               GCo[cont][2] = GroundCo[cont][2];

              if (j>0 && i>0)
			  {
                 GCo[cont][0] =(GroundCo[cont][0]+GroundCo[cont-1][0]+GroundCo[cont+1][0]+GroundCo[cont-31][0]+GroundCo[cont+31][0])/5;
                 GCo[cont][1] =(GroundCo[cont][1]+GroundCo[cont-1][1]+GroundCo[cont+1][1]+GroundCo[cont-31][1]+GroundCo[cont+31][1])/5;
                 GCo[cont][2] =(GroundCo[cont][2]+GroundCo[cont-1][2]+GroundCo[cont+1][2]+GroundCo[cont-31][2]+GroundCo[cont+31][2])/5;
              }
              Col[0] = (int)(GCo[cont][0] * GroundSh[cont]); 
              Col[1] = (int)(GCo[cont][1] * GroundSh[cont]);
              Col[2] = (int)(GCo[cont][2] * GroundSh[cont]);
             
			  /* Sets the colour */
              (TempVert[GROUND]+cont)->u32Colour  = RGBColour (Col[0],Col[1],Col[2]);            
              cont++;
         }
     }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : CalculateLight                                                   */ 
/*  Inputs          : Nune                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Logo                                                             */
/*  Description     : Creates a 15x10 array with PVR Logo colours.                     */
/*-------------------------------------------------------------------------------------*/	
void CalculateLight (void)
{
unsigned long i, j, Pos;

  for (j=0; j<15; j++)
  {
    for (i=0; i<10; i++)
	{
		Pos = ((i*128)/10)*128 + ((j*128)/15);  
		/* BuffText[1] is the texture map of the stained glass */
       	Logo[i][j][0]  = (BuffTex[1].pixels+Pos)->red;
        Logo[i][j][1]  = (BuffTex[1].pixels+Pos)->green;
        Logo[i][j][2]  = (BuffTex[1].pixels+Pos)->blue;
	}
  }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : MoveLamp                                                         */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : frame, Mesh, PosX, PosY                                          */
/*  Description     : Up-down movement of the lamp.                                    */
/*-------------------------------------------------------------------------------------*/	
void MoveLamp (void)

{
static float TempL[20][3];
register i;
float LX = 0.0f , LY= 0.0f;

    /* Sets LTemp with the 3D vertices values just once. */
    if ( frame == 0)
	{
      for (i=0; i<Mesh[LIGHT].NumVertex; i++)
	  {
        TempL[i][0] = *(Mesh[LIGHT].Vertex+i*3+0);
        TempL[i][1] = *(Mesh[LIGHT].Vertex+i*3+1)+15;
        TempL[i][2] = *(Mesh[LIGHT].Vertex+i*3+2)+40;
	  }
	}

	/* Calculate light position on the ground and lamp position */
    PosX = (int)(13.0*sin(frame/20.0)+20.0);
    PosY = 7.5;

    LX = 7.5-PosY;
    LY = 15-PosX;

    /* Sets final values for 3D vertices of the lamp. */
    for (i=0; i<Mesh[LIGHT].NumVertex; i++)
	{
      *(Mesh[LIGHT].Vertex+i*3+0)  =  TempL[i][0]+LX;
      *(Mesh[LIGHT].Vertex+i*3+1)  =  TempL[i][1]+LY;
      *(Mesh[LIGHT].Vertex+i*3+2)  =  TempL[i][2];
    }
    
}
/*--------------------------- End of File --------------------------------*/

