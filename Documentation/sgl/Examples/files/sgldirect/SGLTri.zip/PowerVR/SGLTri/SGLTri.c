/*****************************************************************************
  Name : SGLTri.c
  Date : February 1998
  Platform : ANSI compatible

  SGLTri.c is the simplest scene file that make use of SGL Shell. 
  The scene file should be included in a project where the SGLShell.c and 
  SGLShell.h files are included. The SGL.LIB library file should of course
  be included in the project. Make sure your application include SGLShell.h 
  to have access to SGL Shell functions and flags.

  Basic functions have to be implemented to interact correctly with the SGL 
  Shell. A list of these functions is :

  
  *****************************
  ** void InitApplication(); **
  *****************************

  This function will be called only once by the SGL Shell before anything 
  happens, at the very beginning of the SGLShell WinMain() function. 
  This function enables the user to perform any initialisation before 
  the program is actually run.
  Could be used to load meshes and allocate memory for these, setup the
  SGL Context, load and allocate textures, etc...

  Within this function the user can call SGLShellSetPreferences(...) to set 
  the application preferences. For details of this function, see later
  in this document.

  - void QuitApplication();

  This function is used in conjunction with InitApplication(). Its purpose
  is to free and close all memory or instances allocated in InitApplication().
  This function is called when the user exits the application.

				***

  *****************************************************
  **  BOOL InitView(DWORD dwWidth, DWORD dwHeight);  **
  *****************************************************

  This function is called each time a rendering variable is changed in
  the SGLShell (switching from or to full screen, changing the resolution,
  changing the buffering mode and switching Display Info On or Off). 
  
  InitView(...) is the final function that gets called when rendering 
  variables are changed.
  InitView(...) lets the user create or initialise any new variables 
  corresponding to the new rendering parameters. 
  dwWidth and dwHeight are passed to your application and correspond to 
  the new Width and Height of the rendering surface. The user may need 
  these to create his/her viewport or centering the scene accordingly.
  This function should return TRUE(1) to tell SGLShell that the call was
  successful. If the function returns FALSE(0), then the execution will
  stop.

  ***************************
  **  void ReleaseView();  **
  ***************************

  This function is used in conjunction with InitView(...). Its purpose
  is to free and close all memory or instances allocated in InitView().

				***
  
  ***********************************************************************************
  **  void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);  **
  ***********************************************************************************

  This is the user window procedure. It is used as a normal WindowProc()
  function. This function is called before the SGLShell window procedure
  itself. It enables the user to retrieve menu choices, keystrokes or 
  other messages.
  SGLShell handles many messages which should not be handled by the user
  application. A list of these messages is :
  
  	WM_ENTERMENULOOP, WM_EXITMENULOOP,
	WM_ACTIVATEAPP,
	WM_SYSCOMMAND,
	WM_SIZE, WM_MOVE, WM_MOVING,
	WM_PAINT,
	WM_DESTROY, WM_QUIT

  Do NOT return DefWindowProc(...) in this function, as it will prevent
  SGLShell to handle messages by itself.

				***

  ***************************
  **  BOOL RenderScene();  **
  ***************************

  This is where the user does his/her rendering. Typically one would call
  sgltri_startofframe(...) and sgltri_render(...) in this function.
  The function should return TRUE to tell SGLShell that the call was
  successful. If the function returns FALSE, then the execution will stop.


  These 6 functions must exist, but you don't have to put any code in these. 
  For instance, if you don't want to deal with any user input, the
  UserWindowProc(...) function will typically be empty.  
  You might as well not want to make any use of ReleaseView(), or even 
  InitView(...). In that case, just put nothing in these.
  The most simple example of an application using SGLShell is the Triangle
  example (see below).


  -------------------------------------------------------------
  | READ SGLSHELL.TXT FOR FURTHER INFORMATION ABOUT SGLSHELL  |
  -------------------------------------------------------------


  Email any comments or feedback to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/


/* Includes */
#include <windows.h>
#include "sgl.h"		/* To use SGL.LIB */
#include "SGLShell.h"	/* SGLShell include */

/* Defines */
#define SGLRGB(r, g, b) ((sgl_uint32) (((r) << 16) | ((g) << 8) | (b)))

/* Global variables */
SGLCONTEXT     SGLContext;
SGLVERTEX      TriangleVertex[3] =	{

/*             x         y       z   (1/W)      col           spec.col     (u/W) (v/W) */

			{   0.0f, -100.0f, 0.0f, 0.1f, SGLRGB(0,0,255), SGLRGB(0,0,0), 0.0f, 0.0f},

			{ 100.0f,   33.0f, 0.0f, 0.8f, SGLRGB(0,0,255), SGLRGB(0,0,0), 0.0f, 0.0f},

		    {-100.0f,   33.0f, 0.0f, 0.1f, SGLRGB(0,0,255), SGLRGB(0,0,0), 0.0f, 0.0f}

							};

int		   TrianglesIndices[1][3] = {0,1,2};


/* Added for SGLShell port */
static	DWORD	dwCurrentWidth;
static	DWORD	dwCurrentHeight;


/* SGLShell Functions */


/* InitApplication() is called by SGLShell */
void InitApplication()
{
	/* Set application name, don't use a menu, accelerator or icon and pass parameters */
	SGLShellSetPreferences("SGL Triangle example for SGLShell", NULL, NULL, NULL, DISABLE_VERYHIGHRES);
}


/* InitApplication() is called by SGLShell */
void QuitApplication()
{
	/* Nothing to do */
}


/* UserWindowProc() is called by SGLShell */
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/* We don't handle user input */
}


/* InitView() is called by SGLShell */
BOOL InitView(DWORD dwWidth, DWORD dwHeight)
{
	/* Update new width and height */
	dwCurrentWidth=dwWidth;
	dwCurrentHeight=dwHeight;
	
	/* InitView OK */
	return TRUE;
}


/* ReleaseView() is called by SGLShell */
void ReleaseView()
{
	/* Nothing to release */
}


/* RenderScene() is called by SGLShell */
BOOL RenderScene()
{
	/* Update new triangle vertices to make it centered on the screen */
	TriangleVertex[0].fX=0.0f+(dwCurrentWidth/2);
	TriangleVertex[0].fY=-100.0f+(dwCurrentHeight/2);
	
	TriangleVertex[1].fX=100.0f+(dwCurrentWidth/2);
	TriangleVertex[1].fY=33.0f+(dwCurrentHeight/2);
	
	TriangleVertex[2].fX=-100.0f+(dwCurrentWidth/2);
	TriangleVertex[2].fY=33.0f+(dwCurrentHeight/2);
	
	
	/* Start a new frame */
	sgltri_startofframe(&SGLContext);

    /* Add triangles list */
	sgltri_triangles(&SGLContext, 1, TrianglesIndices, TriangleVertex);

    /* Kick off SGL render */
	sgltri_render(&SGLContext);

	/* RenderScene OK */
	return TRUE;
}





