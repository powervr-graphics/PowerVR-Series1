/*****************************************************************************
  Name : SGLShell.c v1.1.4
  Date : March 1998
  Platform : ANSI compatible

  Build info : SGLShell.c + SGLShell.h

  SGLShell is a program that enables you to run your SGL Direct-based
  application under a safe Windows environment. SGLShell lets you control
  the "environment" of your application : FullScreen, Windowed mode,
  Buffering mode and resolution selection are the features that are
  proposed in this program.
  Thanks to this shell, you should only take care of your SGLD application
  itself, without losing time writing the user interface.

  SGLShell consists of only 2 files (SGLShell.c and SGLShell.h). It does NOT
  require a resource file of any kind. Thus, when creating your SGL application,
  you just have to link your files with these two and include 
  the SGLShell header (SGLShell.h) in your application.

  The user is only responsible of creating all SGL variables that will be
  needed at rendering time.
  The user can choose preferences thanks to the SGLShellSetPreferences()
  function.
  A list of flags that can be passed to this function can be found in the
  SGLShell.h file.
  
  For a list of functions that the user has to use to interact with the
  SGL Shell, see the SGLShell.h file.

   
  * Screen capture

  During execution, a screen capture can be performed by pressing F12.
  The current contents of the back buffer will be saved as a .BMP file
  named ScreenXX.bmp. 
  
  
  *	Helper Functions :

  One helper function has also been added to the SGL Shell :

  SGLShellSetDisplayText(char *pszText, int nX, int nY)
  ->This function will display a text on the screen at the nX, nY position.
    Up to 50 strings can be displayed at the same time.
	You can use this function in the InitView or RenderScene function.

  SGLShellLoadBMP(char *lpName, BOOL bTranslucent, BOOL bMipmap)
  ->Loads a texture from disk or resource.


  * Things to do :

  - Use a PolyText function instead of a GDI blit.
    
			  
  * Current bugs :
  
  - The SGL Shell seems to have problems with the GrafixStar 700 graphic card.
    When quitting the shell from a FullSCreen mode, it may result with garbage
	on your desktop. If anyone knows how to fix this problem or experienced
	the same kind of problem, please let me know.

  - In 1024x768 Double buffer mode, there is a white vertical line
    flashing on the right side of the screen.

  
  Please report any bugs or comments to me. If, for any reason, you need to
  modify the SGL Shell, please report to me so I can do the modifications
  myself.

  
  * LATEST CHANGES :
  - 15/05/98 : - Added texture loading function. 
				Versioning to 1.1.4.

  - 14/04/98 : - Removed the Change3DMode() function call after the DisplayInfo 
			   menu choice in WindowProc. It was useless to recreate variables 
			   just for that feature turned On or Off.
			   - The value used to enable a resolution or not is now the
			   *exact* video memory reported. The value is not
			   averaged anymore because of some graphics cards not having
			   a fixed amount of physical video memory (GrafixStar 600
			   has 2.25 Mb of video memory, for instance).
			   - Add proper exit to failing functions in WinMain().
			   Versioning to 1.1c.

  - 19/03/98 : - Added code that supports StrictLocks. 
			   - Modified the screen capture function to handle pitches that
			   don't correspond to width*bpp/8. 
			   Versioning to 1.1b.
	
  - 16/03/98 : - Added a screen capture feature. 
			   Versioning to 1.1.

  
  -------------------------------------------------------------
  | READ SGLSHELL.TXT FOR FURTHER INFORMATION ABOUT SGLSHELL  |
  -------------------------------------------------------------


  Email any comments or feedback to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/
#ifndef INITGUID
#define INITGUID			/* Must be set up before everything */
#endif

/* Includes */
#include <windowsx.h>
#include <stdio.h>
#include <ddraw.h>

/* SGL include */
#include "SGL.h"

/* SGLShell include */
#include "SGLShell.h"

/* DirectDraw errors 
   This header can be included (and linked with the 
   DDError.c file) to report DirectDraw errors */
/*#include "DDError.h"*/

#ifndef DDERROR_H
#define DisplayHRESULTInDebug(x)	
#define ASSERT(x)					
#endif


/************************* 
**		Menu defines    **
*************************/
/*  These values are "weird" numbers on purpose, as we don't want
    to have duplicate menu items IDs from the Application own menu */
#define MAINMENU                        19101
#define ID_FILE                         19801
#define ID_FILE_SCREENCAPTURE			19802
#define ID_FILE_DISPLAYINFO				19803
#define ID_FILE_QUIT					19804
#define ID_BUFFERING_SINGLEBUFFER		39820
#define ID_BUFFERING_DOUBLEBUFFER		39821
#define ID_BUFFERING_TRIPLEBUFFER		39822
#define ID_MODES						49801
#define ID_MODES_FULLSCREEN				49809
#define ID_MODES_RES0                   49810
#define ID_MODES_RES1                   49811
#define ID_MODES_RES2                   49812
#define ID_MODES_RES3                   49813
#define ID_MODES_RES4                   49814
#define ID_MODES_RES5                   49815
#define ID_MODES_RES6                   49816
#define ID_MODES_RES7                   49817
#define ID_MODES_RES8                   49818
#define ID_MODES_RES9                   49819
#define ID_MODES_RES10                  49820
#define ID_MODES_RES11                  49821
#define ID_MODES_RES12                  49822
#define ID_MODES_RES13                  49823
#define ID_MODES_RES14                  49824
#define ID_MODES_RES15                  49825
#define ID_MODES_RES16                  49826
#define ID_MODES_RES17                  49827
#define ID_MODES_RES18                  49828
#define ID_MODES_RES19                  49829
#define ID_MODES_RES20                  49830
#define ID_MODES_RES21                  49831
#define ID_MODES_RES22                  49832
#define ID_MODES_RES23                  49833
#define ID_MODES_RES24                  49834
#define ID_MODES_RES25                  49835
#define ID_MODES_RES26                  49836
#define ID_MODES_RES27                  49837
#define ID_MODES_RES28                  49838
#define ID_MODES_RES29                  49839


/* Max values defines */
#define MAX_NUMBER_OF_ACCELERATORS		10		/* Maximum number of accelerators */
#define MAX_NUMBER_OF_STRINGS			50		/* Maximum number of strings */
#define DD_MAXDISPLAYMODES				30		/* Maximum DD display modes we ever expect to find */

#define TIMER_PERIOD					3000	/* Frame rate will be computed every 3 s */


/* Macros */
#ifndef DEBUG
#define DEBUG(x) OutputDebugString(x)
#endif

#undef RELEASE
#define RELEASE(x)	if (x) { x->lpVtbl->Release(x); x=NULL; }


/* Typedefs */
typedef HRESULT (WINAPI *DDCREATE) (GUID FAR *, LPDIRECTDRAW FAR *, IUnknown FAR *);

typedef struct _DDDisplayModeInfo
{
	DWORD			dwWidth;					/* Width (in pixels) of display mode */
	DWORD			dwHeight;					/* Height (in pixels) of display mode */
	DWORD			dwBPP;						/* Display mode colour depth */
} DDDisplayModeInfo;

typedef struct _SGLFEVariables
{
	/* DirectDraw variables */
	LPDIRECTDRAW            lpDD;					/* DirectDraw object */
	LPDIRECTDRAWSURFACE     lpDDSPrimary;			/* DirectDraw primary surface */
	LPDIRECTDRAWSURFACE     lpDDSBack;				/* DirectDraw back surface */
	LPDIRECTDRAWCLIPPER		lpClipper;				/* DirectDraw clipper */
	HINSTANCE				hInstDD;				/* Instance of DDRAW.DLL */
	DDCREATE				FnDirectDrawCreate;		/* Pointer of DirectDrawCreate() function */
		
	/* SGL variables */
	int						nLogicalDevice;			/* SGL Logical device */
	
	/* Window management variables */
	MSG						msg;					/* WindowProc messages */
	HWND					hwnd;					/* window handle */
	WNDCLASS				wndclass;				/* window class */
	HICON					hIcon;					/* Application icon */
	DWORD					dwGDIWidth;				/* GDI screen width */
	DWORD					dwGDIHeight;			/* GDI screen height */
	DWORD					dwGDIBPP;				/* GDI screen colour depth */
	
	/* Window information variables */
	DWORD					dwWindowStyle;			/* Style of window */
	DWORD					dwWindowPositionX;		/* Window position (X) */
	DWORD					dwWindowPositionY;		/* Window position (Y) */
	DWORD					dwWindowWidth;			/* Window width */
	DWORD					dwWindowHeight;			/* Window height */
	DWORD					dwWindowFramePositionX;	/* Window frame position (X) */
	DWORD					dwWindowFramePositionY;	/* Window frame position (Y) */
	DWORD					dwWindowFrameWidth;		/* Window frame width */
	DWORD					dwWindowFrameHeight;	/* Window frame height */
	DWORD					dwWindowSpaceX;			/* Total space between window frame width and client area width */
	DWORD					dwWindowSpaceY;			/* Total space between window frame height and client area height */
	DWORD					dwMaxWindowWidth;		/* Max window width */
	DWORD					dwMaxWindowHeight;		/* Max window height */
	DWORD					dwMinWindowWidth;		/* min Window width */
	DWORD					dwMinWindowHeight;		/* Min window height */
	
	/* Menu variables */
	HMENU					hMenu;					/* Main menu handle */
	HMENU					hFileMenu;				/* File menu handle */
	HMENU					hBufferingMenu;			/* Renderer menu handle */
	HMENU					hModesMenu;				/* Modes menu handle */
	HMENU					hUserMenu;				/* User menu handle */
	ACCEL					Accel[MAX_NUMBER_OF_ACCELERATORS];		/* Accelerator table */
	HACCEL					hAccel;					/* Accelerator table handle */
	
	/* Booleans */
	BOOL					bPaused;				/* FrontEnd paused ? */
	BOOL					bMinimized;				/* FrontEnd minimized ? */
	BOOL					bRenderingReady;		/* Are all the variables set up and ready to render ? */
	BOOL					bIgnoreWM_SIZE;			/* Ignore the WM_SIZE window message ? */
	BOOL					bFullScreen;			/* Are we in FullScreen mode ? */
	BOOL					bShowInfoBuffer;		/* Do we want to display the Info Buffer ? */
			
	/* Rendering variables */
	DWORD					dwPhysicalVideoMemory;	/* Physical amount of video memory */
	DWORD					dwTotalMemoryForWindow;	/* Total video memory to create window */
	int						nBufferingMode;			/* Single buffer, Double buffer(default) or triple buffer */
	int						nPrimaryBitDepth;		/* Bit depth of primary surface */

	/* Text display variables */
	HFONT					hTextFont;				/* Handle of text font */
	char					pszDisplayText[100];	/* String to display */
	DWORD					dwFrameRate;			/* Current frame rate */
	DWORD					dwFramesElapsed;		/* Number of frames elapsed in TIMER_PERIOD ms */
	
	/* User variables */
	DWORD					dwUserPreferences;		/* Flag to retrieve user preferences */
	char					pszFrontEndTitle[100];	/* Title of application */
	int						nNumberOfUserString;	/* Number of user text strings to display */
	char					pszUserText[MAX_NUMBER_OF_STRINGS][100];	/* User text to display on screen */
	int						nUserTextPositionX[MAX_NUMBER_OF_STRINGS];	/* Position of user text (X) */
	int						nUserTextPositionY[MAX_NUMBER_OF_STRINGS];	/* Position of user text (Y) */
} SGLFEVariables;


/*************************
**		  Globals	    **
*************************/

/* SGL Shell variables */
static SGLFEVariables		SGLFE;

/* Display mode enumeration variables */
static DDDisplayModeInfo	DDDisplayMode[DD_MAXDISPLAYMODES];	/* Array to store all Display modes */
static int					nDDNumDisplayModes=0;				/* Total number of display modes supported by Direct Draw driver */
static int					nSafeDisplayModeNumber=-1;			/* Number of "safe" display mode (usually 640x480x16) */
static int					nCurrentResolution=-1;				/* Number of current display mode */

/* SGL Variables */
static CALLBACK_SURFACE_PARAMS	CallbackSurfaceInfo;
static volatile	DWORD			*pStatus;
static WORD						*pMem;
static WORD						wStride;


int		nStrictLocks=0;
BOOL	bBufferLocked=FALSE;
BOOL	bStrictLocksQuit=FALSE;


/* Debug purpose */
static char					pszTmp[300];

/* SGLShell functions */
static void				SGLFEInitFrontEnd();
static void				SGLFEFinish();
static void				SGLFEReleaseAll();
static BOOL				SGLFECheckForLostSurfaces();
static BOOL				SGLFEInitDirectDrawForSGL();
static BOOL				SGLFEInitWindow();
static BOOL				SGLFEInitFullScreen();
static void				SGLFEChangeMode(int nRes, BOOL bScreenModeSelected);
static BOOL				SGLFERender();
static int				SGLFEEndOfRenderCallback();
static int				SGLFERenderCallback(P_CALLBACK_ADDRESS_PARAMS lpRenderParams);
static BOOL				SGLFEGetRenderPointers(HWND hWnd, LPWORD *pMem, LPWORD pStride);
static HRESULT	WINAPI	SGLFEEnumDisplayModesCallback(LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext);
static BOOL				SGLFEListDisplayModes(LPDIRECTDRAW lpLocalDD);
static void				SGLFECreateAccelerators();
static BOOL				SGLFEBuildMenus();
static void				SGLFEUpdateMenus();
static DWORD			SGLFEFreeVideoMemoryInfo(DWORD dwCaps);
static DWORD			SGLFETotalVideoMemoryInfo(DWORD dwCaps);
static void				SGLFEHandleWM_PAINT(HWND hWindow);
static BOOL				SGLFEHandleWM_SIZE(LRESULT *lresult, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
static void				SGLFEDisplayText();
static void				SGLFEMouseVisible(BOOL bVisible);
static int				SGLFEGetSurfaceBitsPerPixel(LPDIRECTDRAWSURFACE pSurface);
static long CALLBACK	SGLFEWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
static BOOL				SGLFEScreenCapture();
static void				CALLBACK SGLFETimerProc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime);
int	WINAPI				WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow);


/* User functions */
void			SGLShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel, 
									   HICON hUserIcon, enum SGLShellPrefs dwFlags);
void			SGLShellSetDisplayText(char *pszText, int nX, int nY);
int				SGLShellLoadBMP(char *lpName, BOOL bTranslucent, BOOL bMipmap);



/**************************************************************
************************** FUNCTIONS **************************
**************************************************************/


/*******************************************************************************
 * Function Name  : SGLFEInitFrontEnd
 * Returns        : Nothing
 * Global Used    : SGLFE
 * Description    : Perform variables initialisation
 *******************************************************************************/
void SGLFEInitFrontEnd()
{
	/* Init DirectDraw variables */
	SGLFE.lpDD=NULL;				
	SGLFE.lpDDSPrimary=NULL;
	SGLFE.lpDDSBack=NULL;	
	SGLFE.lpClipper=NULL;
	SGLFE.hInstDD=NULL;
	SGLFE.FnDirectDrawCreate=NULL;
	
	/* Window management variables */
	SGLFE.hIcon=NULL;
	
	/* Init window variables */
	SGLFE.dwWindowStyle=0;
	SGLFE.dwWindowWidth=640;
	SGLFE.dwWindowHeight=480;
	SGLFE.dwMaxWindowWidth=1024;
	SGLFE.dwMaxWindowHeight=768;
	SGLFE.dwMinWindowWidth=320;
	SGLFE.dwMinWindowHeight=200;

	/* Init Booleans */
	SGLFE.bPaused=TRUE;
	SGLFE.bIgnoreWM_SIZE=TRUE;
	SGLFE.bMinimized=FALSE;
	SGLFE.bRenderingReady=FALSE;
	SGLFE.bFullScreen=FALSE;
	SGLFE.bShowInfoBuffer=TRUE;
		
	/* Init menu variables */
	SGLFE.hMenu=NULL;
	SGLFE.hFileMenu=NULL;
	SGLFE.hBufferingMenu=NULL;
	SGLFE.hModesMenu=NULL;
	SGLFE.hUserMenu=NULL;
	SGLFE.hAccel=NULL;

	/* Init rendering variables */
	SGLFE.dwTotalMemoryForWindow=0;
	SGLFE.nBufferingMode=2;				/* Double buffering by default */
	SGLFE.nPrimaryBitDepth=0;

	/* User rendering variables */
	SGLFE.dwUserPreferences=0;
	strcpy(SGLFE.pszFrontEndTitle, "SGL Shell");
	SGLFE.nNumberOfUserString=0;
	SGLFE.dwFrameRate=0;
	SGLFE.dwFramesElapsed=0;
}


/*******************************************************************************
 * Function Name  : SGLFEFinish
 * Returns        : Nothing
 * Global Used    : SGLFE
 * Description    : Quit program :
 *	
 *******************************************************************************/
void SGLFEFinish()
{
	HRESULT	hres;
	
	/* Set status of render */
	SGLFE.bPaused=TRUE;
	SGLFE.bRenderingReady=FALSE;
	if (nStrictLocks)
	{
		bStrictLocksQuit=TRUE;
	}

	/* Restore display mode to avoid messing up the GDI screen */
	if (SGLFE.lpDD && SGLFE.bFullScreen)
	{
		/* Restore display mode for windowed mode */
		SGLFE.bIgnoreWM_SIZE=TRUE;
		hres=SGLFE.lpDD->lpVtbl->RestoreDisplayMode(SGLFE.lpDD);
		SGLFE.bIgnoreWM_SIZE=FALSE;
		if (hres!=DD_OK)
		{
			DEBUG("RestoreDisplayMode() failed in WinMain()\n");
			DisplayHRESULTInDebug(hres);
		}
	}
	
	/* Send a WM_DESTROY message to the event loop */
	DestroyWindow(SGLFE.hwnd);		
}


/*******************************************************************************
 * Function Name  : SGLFEReleaseAll
 * Returns        : Nothing
 * Global Used    : SGLFE
 * Description    : Release all variables
 *******************************************************************************/
void SGLFEReleaseAll()
{
	/* Release user variables */
	ReleaseView();
		
	/* Release DirectDraw variables */
	RELEASE(SGLFE.lpClipper);
	RELEASE(SGLFE.lpDDSBack);
	RELEASE(SGLFE.lpDDSPrimary);
	RELEASE(SGLFE.lpDD);

	/* Delete SGL device */
	sgl_delete_device(SGLFE.nLogicalDevice);
}


/*******************************************************************************
 * Function Name  : SGLFECheckForLostSurfaces
 * Returns        : TRUE or FALSE
 * Global Used    : SGLFE
 * Description    : Restore surfaces that might have been lost
 *******************************************************************************/
BOOL SGLFECheckForLostSurfaces()
{
	HRESULT hres;
	BOOL	bInFlag=TRUE;
	
	/* Check if Primary surface is lost 
	   If back buffer(s) have been created through the primary surface by use
	   of the DDSCAPS_COMPLEX flag, then the(se) back buffer(s) will be
	   automatically restored when the primary surface is restored */
	if (SGLFE.lpDDSPrimary) 
	{
		if (SGLFE.lpDDSPrimary->lpVtbl->IsLost(SGLFE.lpDDSPrimary)==DDERR_SURFACELOST)
		{
			hres=SGLFE.lpDDSPrimary->lpVtbl->Restore(SGLFE.lpDDSPrimary);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore primary surface\n");
				DisplayHRESULTInDebug(hres);
				bInFlag=FALSE;
			}
		}
	}
	
	/* If we are in Window mode, then back buffer has been created
	   separately from the primary surface, so restore it as well */
	if (SGLFE.lpDDSBack && !SGLFE.bFullScreen)
	{
		/* Restore back buffer */
		if (SGLFE.lpDDSBack->lpVtbl->IsLost(SGLFE.lpDDSBack)==DDERR_SURFACELOST)
		{
			hres=SGLFE.lpDDSBack->lpVtbl->Restore(SGLFE.lpDDSBack);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore back buffer surface\n");
				DisplayHRESULTInDebug(hres);
				bInFlag=FALSE;
			}
		}
	}

	/* Return status */
	return (bInFlag);
}


/*******************************************************************************
 * Function Name  : SGLFEInitDirectDrawForSGL
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE, 
 *					nCurrentResolution, nDDNumDisplayModes, DDDisplayMode[]
 * Description    : Initialise directdraw for SGL use :
 *					- Load DDraw.DLL
 *					- Retrieve a pointer to DirectDrawCreate function
 *					- Create SGLFE.lpDD
 *
 *******************************************************************************/
BOOL SGLFEInitDirectDrawForSGL()
{
	HRESULT			hres;
	int				nNewWindowResolution;
	RECT			Rect;
	
	/* Update sglhw.ini file */
	WritePrivateProfileString("LastError", "Error", "None", "sglhw.ini");
	
	/* Get DirectDraw services by loading DDRAW.DLL and retrieving the address of DirectDrawCreate */
	SGLFE.hInstDD=LoadLibrary("DDraw.dll");
	if (SGLFE.hInstDD==NULL)
	{
		/* If Instance of DD library is still NULL, then an error occured when loading DLL */
		DEBUG("Error when loading DDraw.dll\n");
		MessageBox(NULL, "DDRAW.DLL not found", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
		return FALSE;
	}
	
	/* Retrieve address of DirectDrawCreate function */
	SGLFE.FnDirectDrawCreate=(DDCREATE)GetProcAddress(SGLFE.hInstDD, "DirectDrawCreate");
	if (SGLFE.FnDirectDrawCreate==NULL)
	{
		/* If FnDirectDrawCreate could not be created, then report the error */
		DEBUG("GetProcAddress() failed in SGLFEInitDirectDrawForSGL()\n");
		MessageBox(NULL, "Unable to retrieve function address", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
		return FALSE;
	}
		
	/* Create a DirectDraw Object */
	hres=SGLFE.FnDirectDrawCreate(NULL, (LPDIRECTDRAW FAR *)&SGLFE.lpDD, NULL);
	if (hres!=DD_OK)
	{
		DEBUG("FnDirectDrawCreate() failed in SGLFEInitDirectDrawForSGL\n");
		DisplayHRESULTInDebug(hres);
		MessageBox(NULL, "Unable to create DirectDraw object", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
		SGLFE.lpDD=NULL;
		return FALSE;
	}

	/* List all display modes */
	if (!SGLFEListDisplayModes(SGLFE.lpDD))
	{
		DEBUG("SGLFEListDisplayModes() failed in SGLFEInitDirectDrawForSGL\n");
		MessageBox(NULL, "SGLFEListDisplayModes() failed", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
		RELEASE(SGLFE.lpDD);
		return FALSE;
	}

	/* Get video memory available for Window mode */
	SGLFE.dwTotalMemoryForWindow=SGLFEFreeVideoMemoryInfo(DDSCAPS_PRIMARYSURFACE);
	sprintf(pszTmp, "Memory for window mode = %u\n", SGLFE.dwTotalMemoryForWindow);
	DEBUG(pszTmp);

	/* Check if GDI memory is enough to support current window size */
	if (!SGLFE.bFullScreen)
	{
		nNewWindowResolution=nSafeDisplayModeNumber;
		while ( (SGLFE.dwWindowWidth*SGLFE.dwWindowHeight*SGLFE.dwGDIBPP/8>SGLFE.dwTotalMemoryForWindow)
			     && !SGLFE.bFullScreen )
		{
			nNewWindowResolution++;
			if (nNewWindowResolution<nDDNumDisplayModes)
			{
				SGLFE.dwWindowWidth=(DWORD)DDDisplayMode[nNewWindowResolution].dwWidth;
				SGLFE.dwWindowHeight=(DWORD)DDDisplayMode[nNewWindowResolution].dwHeight;
			}
			sprintf(pszTmp, "new window width = %u  height = %u\n", SGLFE.dwWindowWidth, SGLFE.dwWindowHeight);
			DEBUG(pszTmp);
			if (SGLFE.dwWindowWidth<SGLFE.dwMinWindowWidth || 
				SGLFE.dwWindowHeight<SGLFE.dwMinWindowHeight ||
				nNewWindowResolution>=nDDNumDisplayModes)
			{
				SGLFE.dwWindowWidth=SGLFE.dwMinWindowWidth;
				SGLFE.dwWindowHeight=SGLFE.dwMinWindowHeight;
				sprintf(pszTmp, "Not enough GDI memory to support\nthe minimum window size (%d*%d)\nSwitching to FullScreen", 
								 SGLFE.dwWindowWidth, SGLFE.dwWindowHeight);
				MessageBox(SGLFE.hwnd, pszTmp, SGLFE.pszFrontEndTitle, MB_OK | MB_ICONWARNING);
				SGLFE.dwUserPreferences|=FORCE_FULLSCREEN;
				SGLFE.bFullScreen=TRUE;
			}
		}
		/* If there is enough GDI memory to support a smaller window, 
		   calculate new window coordinates */
		if (!SGLFE.bFullScreen)
		{
			/* Compute new window position (screen centre) */
			SGLFE.dwWindowPositionX=(SGLFE.dwGDIWidth-SGLFE.dwWindowWidth)/2;
			SGLFE.dwWindowPositionY=(SGLFE.dwGDIHeight-SGLFE.dwWindowHeight)/2;
	
			/* Compute new window size corresponding to client area size */
			SetRect(&Rect,  SGLFE.dwWindowPositionX, SGLFE.dwWindowPositionY, 
							SGLFE.dwWindowWidth+SGLFE.dwWindowPositionX-1, SGLFE.dwWindowHeight+SGLFE.dwWindowPositionY-1);
			AdjustWindowRect(&Rect, SGLFE.dwWindowStyle, TRUE);

			/* Set window frame values */
			SGLFE.dwWindowFramePositionX=Rect.left;
			SGLFE.dwWindowFramePositionY=Rect.top;
			SGLFE.dwWindowFrameWidth=(Rect.right-Rect.left)+1;
			SGLFE.dwWindowFrameHeight=(Rect.bottom-Rect.top)+1;
	
			/* Compute window space between client and window */
			SGLFE.dwWindowSpaceX=SGLFE.dwWindowFrameWidth-SGLFE.dwWindowWidth;
			SGLFE.dwWindowSpaceY=SGLFE.dwWindowFrameHeight-SGLFE.dwWindowHeight;

			/* Resize window to its new size */
			SGLFE.bIgnoreWM_SIZE=TRUE;
			SetWindowPos(SGLFE.hwnd, NULL, 
						 SGLFE.dwWindowFramePositionX, SGLFE.dwWindowFramePositionY, 
						 SGLFE.dwWindowFrameWidth, SGLFE.dwWindowFrameHeight, 
						 SWP_NOZORDER | SWP_SHOWWINDOW);
			SGLFE.bIgnoreWM_SIZE=FALSE;
		}
	}

	/* Build SGLShell menus */
	if (!SGLFEBuildMenus())
	{
		DEBUG("SGLFEBuildMenus() failed in SGLFEInitDirectDrawForSGL\n");
		MessageBox(NULL, "Unable to build menus", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
		RELEASE(SGLFE.lpDD);
		return FALSE;
	}

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFEInitWindow
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE, DDDisplayMode[], nDDNumDisplayModes
 * Description    : Initialise Window mode for SGL use :
 *					- Create SGL screen device
 *					- Set the cooperative level to NORMAL
 *					- Create primary and back buffer surfaces
 *					- Create clipper
 *					- Get render pointers
 *
 *******************************************************************************/
BOOL SGLFEInitWindow()
{
	HRESULT			hres;
	DDSURFACEDESC	ddsd;
	int				i;

	/* Create SGL screen device */
	SGLFE.nLogicalDevice=sgl_create_screen_device(0, SGLFE.dwWindowWidth, SGLFE.dwWindowHeight, 
												  SGLFE.dwGDIBPP==16 ? sgl_device_16bit : sgl_device_24bit, 0);
	if (SGLFE.nLogicalDevice<0)
	{
		DEBUG("sgl_create_screen_device() failed in SGLFEInitWindow()\n");
		return FALSE;
	}
	
	/* Window stuff */
	/* Set cooperative level for window mode */
	hres=SGLFE.lpDD->lpVtbl->SetCooperativeLevel(SGLFE.lpDD, SGLFE.hwnd, DDSCL_NORMAL);
	if (hres!=DD_OK)
	{
	 	DEBUG("SetCooperativeLevel() failed in SGLFEInitWindow\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Create primary surface */
	
	/* Fill DDSURFACEDESC structure */
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS;
	ddsd.ddsCaps.dwCaps=DDSCAPS_VIDEOMEMORY | DDSCAPS_PRIMARYSURFACE;
	
	hres=SGLFE.lpDD->lpVtbl->CreateSurface(SGLFE.lpDD, &ddsd, &SGLFE.lpDDSPrimary, NULL);
	if (hres!=DD_OK)
	{
		if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY)
		{
			MessageBox(SGLFE.hwnd, "Not enough memory to create primary surface\nPlease restart the program with a lower window size", 
								SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		else
		{
			MessageBox(SGLFE.hwnd, "Failed to create primary surface for Window mode\nExiting program", 
								SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		DEBUG("CreateSurface failed (SGLFE.lpDDSPrimary) in SGLFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Create back buffer */

	/* Fill DDSURFACEDESC structure */
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	ddsd.dwWidth=SGLFE.dwWindowWidth;
	ddsd.dwHeight=SGLFE.dwWindowHeight;
	ddsd.ddsCaps.dwCaps=DDSCAPS_VIDEOMEMORY | DDSCAPS_OFFSCREENPLAIN;
	
	/* Create back buffer as an OffScreen surface */
	hres=SGLFE.lpDD->lpVtbl->CreateSurface(SGLFE.lpDD, &ddsd, &SGLFE.lpDDSBack, NULL);
	if (hres!=DD_OK)
	{
		if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY)
		{
			MessageBox(SGLFE.hwnd, "Not enough memory to create back buffer surface\nPlease restart the program with a lower window size", 
								SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		else
		{
			MessageBox(SGLFE.hwnd, "Failed to create back buffer surface for Window mode\nExiting program", 
								SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		}
		DEBUG("CreateSurface failed (SGLFE.lpDDSBack) in SGLFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Create a clipper and attach it to our window */
	hres=SGLFE.lpDD->lpVtbl->CreateClipper(SGLFE.lpDD, 0, &SGLFE.lpClipper, NULL);
	if (hres!=DD_OK)
	{
		DEBUG("CreateClipper failed in SGLFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		MessageBox(SGLFE.hwnd, "Failed to create Clipper\nExiting program", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}
		
	/* Sets the window handle that will obtain the clipping information */
	hres=SGLFE.lpClipper->lpVtbl->SetHWnd(SGLFE.lpClipper, 0, SGLFE.hwnd);
	if (hres!=DD_OK)
	{
		DEBUG("SetHWnd failed in SGLFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		MessageBox(SGLFE.hwnd, "Failed to set window handle for clipping\nExiting program", 
							SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Assign clipper to front buffer */
	SGLFE.lpDDSPrimary->lpVtbl->SetClipper(SGLFE.lpDDSPrimary, SGLFE.lpClipper);
	if (hres!=DD_OK)
	{
		DEBUG("SetClipper failed in SGLFEInitWindow()\n");	
		DisplayHRESULTInDebug(hres);
		MessageBox(SGLFE.hwnd, "Failed to assign Clipper to Front Buffer\nExiting program", 
							SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Get Render pointers */
	if (!SGLFEGetRenderPointers(SGLFE.hwnd, &pMem, &wStride))
	{
		DEBUG("SGLFEGetRenderPointers() failed in SGLFEInitWindow()\n");
		MessageBox (NULL, "SGLFEGetRenderPointers() failed", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
	}

	/* Unlock in strictlocks case */
	if (nStrictLocks && bBufferLocked)
	{
		hres=SGLFE.lpDDSBack->lpVtbl->Unlock(SGLFE.lpDDSBack, NULL);		
		if (hres!=DD_OK)
		{
			OutputDebugString("Unlock() failed in SGLFEInitWindow\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
		bBufferLocked=FALSE;
	}

	/* Get pixel format of surface */
	SGLFE.nPrimaryBitDepth=SGLFEGetSurfaceBitsPerPixel(SGLFE.lpDDSBack);
	
	/* Check if screen mode can be supported (memory) */
	for (i=0; i<nDDNumDisplayModes; i++)
	{
		EnableMenuItem(SGLFE.hModesMenu, ID_MODES_RES0+i, MF_ENABLED);
		if (SGLFE.nBufferingMode*DDDisplayMode[i].dwWidth*DDDisplayMode[i].dwHeight*DDDisplayMode[i].dwBPP/8
			>SGLFE.dwPhysicalVideoMemory)
		{
			/* This resolution is not supported in the selected Buffering mode */
			/* Disable menu item */
			EnableMenuItem(SGLFE.hModesMenu, ID_MODES_RES0+i, MF_GRAYED);
		}
	}

	/* Show mouse cursor for Window */
	SGLFEMouseVisible(TRUE);

	/* Set states */
	SGLFE.bRenderingReady=TRUE;
	SGLFE.bPaused=FALSE;
	
	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFEInitFullScreen
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE, 
 *					nCurrentResolution, DDDisplayMode[], nDDNumDisplayModes
 * Description    : Initialise FullScreen mode :
 *					- Create SGL screen device
 *					- Set the cooperative level to FULLSCREEN EXCLUSIVE
 *					- Create front and back buffers if needed
 *					- Get render pointers
 *
 *******************************************************************************/
BOOL SGLFEInitFullScreen()
{
	HRESULT			hres;
	DDSURFACEDESC	ddsd;
	DDSCAPS         ddscaps;
	int				i;

	/* Create SGL screen device */
	SGLFE.nLogicalDevice=sgl_create_screen_device(0, DDDisplayMode[nCurrentResolution].dwWidth, 
													 DDDisplayMode[nCurrentResolution].dwHeight,
													 DDDisplayMode[nCurrentResolution].dwBPP==16 ? sgl_device_16bit : sgl_device_24bit, 
													 0);
	if (SGLFE.nLogicalDevice<0)
	{
		DEBUG("sgl_create_screen_device() failed in SGLFEInitFullScreen()\n");
		return FALSE;
	}
	
	/* Set cooperative level for FullScreen mode */
	SGLFE.bIgnoreWM_SIZE=TRUE;
	hres=SGLFE.lpDD->lpVtbl->SetCooperativeLevel(SGLFE.lpDD, SGLFE.hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);
	SGLFE.bIgnoreWM_SIZE=FALSE;
	if (hres!=DD_OK)
	{
	 	SGLFEMouseVisible(TRUE);
		DEBUG("SetCooperativeLevel() failed in SGLFEInitFullScreen\n");
		MessageBox(SGLFE.hwnd, "SetCooperativeLevel() failed in SGLFEInitFullScreen", 
										SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Debug output */
	sprintf(pszTmp, "Switching to %ux%ux%u\n",  DDDisplayMode[nCurrentResolution].dwWidth, 
												DDDisplayMode[nCurrentResolution].dwHeight, 
												DDDisplayMode[nCurrentResolution].dwBPP);
	DEBUG(pszTmp);

	/* Set the video mode to current resolution */
	SGLFE.bIgnoreWM_SIZE=TRUE;
	hres=SGLFE.lpDD->lpVtbl->SetDisplayMode(SGLFE.lpDD, DDDisplayMode[nCurrentResolution].dwWidth,
											DDDisplayMode[nCurrentResolution].dwHeight, 
											DDDisplayMode[nCurrentResolution].dwBPP);
	SGLFE.bIgnoreWM_SIZE=FALSE;
	if (hres!=DD_OK)
	{
	    SGLFEMouseVisible(TRUE);
		DEBUG("SetDisplayMode failed\n");
		DisplayHRESULTInDebug(hres);
		sprintf(pszTmp, "Unable to set display mode to %ux%ux%u\nExiting program", 
						 DDDisplayMode[nCurrentResolution].dwWidth,
						 DDDisplayMode[nCurrentResolution].dwHeight, 
						 DDDisplayMode[nCurrentResolution].dwBPP);
		MessageBox(SGLFE.hwnd, pszTmp, SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	/* Fill DDSURFACEDESC structure */
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	
	/* Handle Single buffering or n-buffering */
	if (SGLFE.nBufferingMode>1)
	{
		/* Double or triple buffer mode */
		ddsd.dwFlags=DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
		ddsd.ddsCaps.dwCaps =	DDSCAPS_PRIMARYSURFACE | 
								DDSCAPS_FLIP |
								DDSCAPS_3DDEVICE |
								DDSCAPS_COMPLEX |
								DDSCAPS_VIDEOMEMORY;
		ddsd.dwBackBufferCount=SGLFE.nBufferingMode-1;
		hres=SGLFE.lpDD->lpVtbl->CreateSurface(SGLFE.lpDD, &ddsd, &SGLFE.lpDDSPrimary, NULL);
		if (hres!=DD_OK)
		{
			SGLFEMouseVisible(TRUE);
			if (hres==DDERR_OUTOFVIDEOMEMORY)
			{
				MessageBox(SGLFE.hwnd, "Not enough video memory to create primary surface\nPlease restart the program with a lower window size", 
									SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			else
			{
				MessageBox(SGLFE.hwnd, "Failed to create primary surface for FullScreen mode\nExiting program", 
									SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			DEBUG("CreateSurface failed (SGLFE.lpDDSPrimary) in SGLFEInitFullScreen()\n");	
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
	
		/* Retrieve variable to back buffer */
		ddscaps.dwCaps=DDSCAPS_BACKBUFFER;
		hres=SGLFE.lpDDSPrimary->lpVtbl->GetAttachedSurface(SGLFE.lpDDSPrimary, &ddscaps, &SGLFE.lpDDSBack);
		if(hres!=DD_OK)
		{
			SGLFEMouseVisible(TRUE);
			DEBUG("GetAttachedSurface() failed in SGLFEInitFullScreen()\n");
			DisplayHRESULTInDebug(hres);
			MessageBox(SGLFE.hwnd, "Unable to retrieve variable to back buffer", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			return FALSE;
		}

		if (SGLFE.nBufferingMode==2)
		{
			DEBUG("Double buffer initialised\n");
		}
		else
		{
			DEBUG("Triple buffer initialised\n");
		}
	}
	else
	{
		/* Single buffer mode */
		ddsd.dwFlags=DDSD_CAPS;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE | DDSCAPS_3DDEVICE | DDSCAPS_VIDEOMEMORY;
		hres=SGLFE.lpDD->lpVtbl->CreateSurface(SGLFE.lpDD, &ddsd, &SGLFE.lpDDSPrimary, NULL);
		if (hres!=DD_OK)
		{
			SGLFEMouseVisible(TRUE);
			if (hres==DDERR_OUTOFVIDEOMEMORY || hres==DDERR_OUTOFMEMORY)
			{
				MessageBox(SGLFE.hwnd, "Not enough memory to create primary surface\nPlease restart the program with a lower window size", 
									SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			else
			{
				MessageBox(SGLFE.hwnd, "Failed to create primary surface for FullScreen mode\nExiting program", 
									SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
			}
			DEBUG("CreateSurface failed (SGLFE.lpDDSPrimary) in SGLFEInitFullScreen()\n");	
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
		DEBUG("Single buffer initialised\n");
	}

	/* Get Render pointers */
	if (!SGLFEGetRenderPointers(SGLFE.hwnd, &pMem, &wStride))
	{
		SGLFEMouseVisible(TRUE);
		DEBUG("SGLFEGetRenderPointers() failed in SGLFEInitDirectDrawForSGL\n");
		MessageBox (NULL, "SGLFEGetRenderPointers() failed", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
		return FALSE;
	}

	/* Unlock in strictlocks case */
	if (nStrictLocks && bBufferLocked)
	{
		/* Surface locked was primary if single buffer, and back
		   buffer if double or triple buffer */
		if (SGLFE.nBufferingMode==1)
		{
			hres=SGLFE.lpDDSPrimary->lpVtbl->Unlock(SGLFE.lpDDSPrimary, NULL);		
		}
		else
		{
			hres=SGLFE.lpDDSBack->lpVtbl->Unlock(SGLFE.lpDDSBack, NULL);		
		}
		if (hres!=DD_OK)
		{
			OutputDebugString("Unlock() failed in SGLFEInitFullScreen()\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
		bBufferLocked=FALSE;
	}

	/* Get pixel format of surface */
	SGLFE.nPrimaryBitDepth=SGLFEGetSurfaceBitsPerPixel(SGLFE.lpDDSPrimary);

	/* Check if screen mode can be supported (memory) */
	for (i=0; i<nDDNumDisplayModes; i++)
	{
		EnableMenuItem(SGLFE.hModesMenu, ID_MODES_RES0+i, MF_ENABLED);
		if (SGLFE.nBufferingMode*DDDisplayMode[i].dwWidth*DDDisplayMode[i].dwHeight*DDDisplayMode[i].dwBPP/8
			>SGLFE.dwPhysicalVideoMemory)
		{			
			/* This resolution is not supported in the selected Buffering mode */
			/* Disable menu item */
			EnableMenuItem(SGLFE.hModesMenu, ID_MODES_RES0+i, MF_GRAYED);
		}
	}

	/* Hide mouse cursor for FullScreen */
	SGLFEMouseVisible(FALSE);

	/* Set states */
	SGLFE.bRenderingReady=TRUE;
	SGLFE.bPaused=FALSE;

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFEChangeMode
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE,
 *					DDDisplayMode[], nCurrentResolution, nDDNumDisplayModes
 * Description    : Change mode (FullScreen, window, buffering modes...)
 *
 *******************************************************************************/
void SGLFEChangeMode(int nRes, BOOL bScreenModeSelected)
{
	HRESULT		hres;
	DWORD		dwRenderWidth, dwRenderHeight;
	
	/* Check if the same resolution is selected */
	if (bScreenModeSelected)
	{
		if (SGLFE.bFullScreen)
		{
			if (nRes==nCurrentResolution)
			{
				/* We already are in this resolution, exit */
				return;
			}
		}
		else
		{
			if (SGLFE.dwWindowWidth==DDDisplayMode[nRes].dwWidth &&
				SGLFE.dwWindowHeight==DDDisplayMode[nRes].dwHeight &&
				SGLFE.dwGDIBPP==DDDisplayMode[nRes].dwBPP)
			{	
				/* The window already has these dimensions, exit */
				return;
			}
		}
	}

	/* Pause SGLShell */
	SGLFE.bPaused=TRUE;
	
	/* If we are in Window mode, first check if required resolution is available 
	   for Window mode */
	if (!SGLFE.bFullScreen && bScreenModeSelected)
	{
		/* First check colour depth */
		if (DDDisplayMode[nRes].dwBPP!=SGLFE.dwGDIBPP)
		{
			sprintf(pszTmp, "Your current GDI colour depth is %u bpp\nand does not correspond to the selected resolution.\nTherefore you can not set this resolution in Window Mode.\nSelect OK to set this resolution in FullScreen mode.", SGLFE.dwGDIBPP);
			if (MessageBox(SGLFE.hwnd, pszTmp, SGLFE.pszFrontEndTitle, MB_OKCANCEL | MB_ICONWARNING)==IDOK)
			{
				/* Ok for this resolution in FullScreen */
				SGLFE.bFullScreen=TRUE;
			}
			else
			{
				/* Keep current window size */
				SGLFE.bPaused=FALSE;
				return;
			}
		} 
		else
		{
			/* Then check if GDI memory is enough to support this resolution in window mode */
			if (DDDisplayMode[nRes].dwWidth*DDDisplayMode[nRes].dwHeight*SGLFE.dwGDIBPP/8<SGLFE.dwTotalMemoryForWindow &&
				DDDisplayMode[nRes].dwWidth<=SGLFE.dwMaxWindowWidth && DDDisplayMode[nRes].dwHeight<=SGLFE.dwMaxWindowHeight)
			{
				/* Selected mode supported */
				SGLFE.dwWindowWidth=DDDisplayMode[nRes].dwWidth;
				SGLFE.dwWindowHeight=DDDisplayMode[nRes].dwHeight;
				SGLFE.dwWindowFrameWidth=SGLFE.dwWindowWidth+SGLFE.dwWindowSpaceX;
				SGLFE.dwWindowFrameHeight=SGLFE.dwWindowHeight+SGLFE.dwWindowSpaceY;
				SGLFE.bFullScreen=FALSE;	/* Just to be sure */
			}
			else
			{
				/* This resolution is not supported in Window Mode : ask for FullScreen mode */
				sprintf(pszTmp, "Your current GDI memory is not enough to set this window size.\nSelect OK to enter FullScreen mode.");
				if (MessageBox(SGLFE.hwnd, pszTmp, SGLFE.pszFrontEndTitle, MB_OKCANCEL | MB_ICONWARNING)==IDOK)
				{
					/* Ok for this resolution in FullScreen */
					SGLFE.bFullScreen=TRUE;
				}
				else
				{
					/* Keep current window size */
					SGLFE.bPaused=FALSE;
					return;
				}
			}
		}
	}

	/* We are about to recreate all SGL variables, so set the Rendering state to FALSE */
	SGLFE.bRenderingReady=FALSE;
	
	/* Release user variables */
	ReleaseView();
	
	/* Release variables */
	RELEASE(SGLFE.lpClipper);
	RELEASE(SGLFE.lpDDSBack);
	RELEASE(SGLFE.lpDDSPrimary);
	sgl_delete_device(SGLFE.nLogicalDevice);
	if (nStrictLocks)
	{
		Sleep(100);
	}

	/* Init FullScreen or Window */	
	if (SGLFE.bFullScreen)
	{
		/* Current Resolution = submitted resolution */
		nCurrentResolution=nRes;	
		
		/* FullScreen mode */
		if (!SGLFEInitFullScreen())
		{
			SGLFEMouseVisible(TRUE);
			DEBUG("SGLFEInitFullScreen() failed in SGLFEChangeMode\n");
			SGLFEFinish();
			return;
		}
		/* Get render dimensions for InitView(...) */
		dwRenderWidth=DDDisplayMode[nCurrentResolution].dwWidth;
		dwRenderHeight=DDDisplayMode[nCurrentResolution].dwHeight;
	}
	else
	{
		/* Restore display mode for windowed mode */
		SGLFE.bIgnoreWM_SIZE=TRUE;
		hres=SGLFE.lpDD->lpVtbl->RestoreDisplayMode(SGLFE.lpDD);
		SGLFE.bIgnoreWM_SIZE=FALSE;
		if (hres!=DD_OK)
		{
			SGLFEMouseVisible(TRUE);
			DEBUG("RestoreDisplayMode() failed in SGLFEChangeMode()\n");
			SGLFEFinish();
			return;
		}

		/* Resize window to its size because window size information might 
		have been lost when switching back from FullScreen mode */
		SGLFE.bIgnoreWM_SIZE=TRUE;
		SetWindowPos(SGLFE.hwnd, NULL, 
					 SGLFE.dwWindowFramePositionX, SGLFE.dwWindowFramePositionY, 
					 SGLFE.dwWindowFrameWidth, SGLFE.dwWindowFrameHeight, 
					 SWP_NOZORDER | SWP_SHOWWINDOW);
		SGLFE.bIgnoreWM_SIZE=FALSE;
				
		/* Window mode */
		if (!SGLFEInitWindow())
		{
			SGLFEMouseVisible(TRUE);
			DEBUG("SGLFEInitWindow() failed in SGLFEChangeMode\n");
			SGLFEFinish();
			return;
		}
		/* Get render dimensions for InitView(...) */
		dwRenderWidth=SGLFE.dwWindowWidth;
		dwRenderHeight=SGLFE.dwWindowHeight;
	}

	/* Call user scene initialisation */
	if (!InitView(dwRenderWidth, dwRenderHeight))
	{
		SGLFEMouseVisible(TRUE);
		DEBUG("InitView() failed in SGLFEChangeMode\n");
		MessageBox(SGLFE.hwnd, "InitView() failed in SGLFEChangeMode", SGLFE.pszFrontEndTitle, 
								MB_OKCANCEL | MB_ICONWARNING);
		SGLFEFinish();
		return;
	}

	/* Update menus */
	SGLFEUpdateMenus();
}


/*******************************************************************************
 * Function Name  : SGLFERender
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE
 * Description    : Render next scene :
 *					- Check for lost surfaces
 *					- Call user RenderScene() function
 *					- Display Info on the frame buffer if requested
 *
 *******************************************************************************/
BOOL SGLFERender()
{	
	DWORD	dwW, dwH, dwBPP;

	/* Check for lost surfaces */
	if (!SGLFECheckForLostSurfaces())
	{
		DEBUG("CheckForLostSurfaces() failed in SGLFERender()\n");
		return FALSE;
	}
	
	/* Call user's RenderScene */
	if (!RenderScene())
	{
		DEBUG("RenderScene() failed in SGLFERender()\n");
	}

	/* Increase the number of frames */
	SGLFE.dwFramesElapsed++;	
	
	/* Get render surface dimensions */
	if (SGLFE.bFullScreen)
	{
		dwW=DDDisplayMode[nCurrentResolution].dwWidth;
		dwH=DDDisplayMode[nCurrentResolution].dwHeight;
		dwBPP=DDDisplayMode[nCurrentResolution].dwBPP;
	}
	else
	{
		dwW=SGLFE.dwWindowWidth;
		dwH=SGLFE.dwWindowHeight;
		dwBPP=SGLFE.dwGDIBPP;
	}

	/* Create display string */
	sprintf(SGLFE.pszDisplayText, "%ux%ux%u  %s   %d fps", dwW, dwH, dwBPP, 
			(!SGLFE.bFullScreen) ? "" : SGLFE.nBufferingMode==1 ? "SB" : SGLFE.nBufferingMode==2 ? "DB" : "TB", 
			SGLFE.dwFrameRate);

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFEEndOfRenderCallback
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE
 * Description    : SGL calls this callback during sgl_render when the previous 
 *					frame has completed, that is to say at end of render.
 *					This is an important event if we are implenemting strict
 *					locking because we must unlock the surface as soon as possible
 *					and allow Windows to do it's message loop processing and 
 *					update its display.
 *					This callback is used to update the display by :
 *					* Doing a Blit from back buffer surface to Render surface
 *					  in Window mode.
 *					* Doing a Flip between back buffer and front buffer in
 *					  FullScreen mode (if back buffer(s) exist)
 *
 *******************************************************************************/
int SGLFEEndOfRenderCallback()
{
	RECT	SrcRect, DstRect;
	LPPOINT	lpPoint;
	HRESULT	hres;
	
	/* Unlock in strictlocks case */
	if (nStrictLocks && bBufferLocked)
	{
		/* Surface locked was primary if single buffer, and back
		   buffer if double or triple buffer */
		if (SGLFE.nBufferingMode==1 && SGLFE.bFullScreen)
		{
			hres=SGLFE.lpDDSPrimary->lpVtbl->Unlock(SGLFE.lpDDSPrimary, NULL);		
		}
		else
		{
			hres=SGLFE.lpDDSBack->lpVtbl->Unlock(SGLFE.lpDDSBack, NULL);		
		}
		if (hres!=DD_OK)
		{
			OutputDebugString("Unlock() failed in SGLFEEndOfRenderCallback()\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
		bBufferLocked=FALSE;
	}

	/* If we asked to quit, then don't go further */
	if (bStrictLocksQuit)
	{
		return 0;
	}
	
	/* Display text if required */
	if (SGLFE.bShowInfoBuffer || (SGLFE.nNumberOfUserString>0))
	{
		SGLFEDisplayText();
	}
	
	/* Handle Window mode */
	if (!SGLFE.bFullScreen)
	{
		/* Initialize parameters */
		SrcRect.top=0;
		SrcRect.left=0;
		SrcRect.right=SGLFE.dwWindowWidth;	
		SrcRect.bottom=SGLFE.dwWindowHeight;

		DstRect=SrcRect;
		
		/* Convert to screen coordinates : DstRect will contain the screen 
		   rectangle to blit onto */
		lpPoint=(LPPOINT)&DstRect;
		ClientToScreen(SGLFE.hwnd, lpPoint);
		lpPoint=(LPPOINT)&DstRect.right;
		ClientToScreen(SGLFE.hwnd, lpPoint);
	
		/* Blit the back buffer surface to the primary surface */
		hres=SGLFE.lpDDSPrimary->lpVtbl->Blt(SGLFE.lpDDSPrimary, &DstRect, SGLFE.lpDDSBack, &SrcRect, 0, NULL);
		if (hres!=DD_OK)
		{
			DEBUG("Blt() failed in SGLFERender()\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
	}
	else
	{
		/* Handle FullScreen mode */
		/* If at least 2 surfaces (front and back buffers) */
		if (SGLFE.nBufferingMode>1)
		{
			/* Update the primary surface by performing a flip */
			hres=SGLFE.lpDDSPrimary->lpVtbl->Flip(SGLFE.lpDDSPrimary, NULL, DDFLIP_WAIT);
			if (hres!=DD_OK)
			{
				DEBUG("Flip() failed in SGLFERender()\n");
				DisplayHRESULTInDebug(hres);
				return FALSE;
			}
		}
	}

	/* Do message loop here for strictlocks */
	if (nStrictLocks)
	{
		int idle, done=0;
		
		while (!done)
		{   
			idle = TRUE;
			while (PeekMessage(&SGLFE.msg, NULL, 0, 0, PM_REMOVE))
			{
				idle=FALSE;
				if (SGLFE.msg.message==WM_QUIT)
				{	
					done=TRUE;
					SGLFE.bPaused=TRUE;
					SGLFE.bRenderingReady=FALSE;
					bStrictLocksQuit=TRUE;
					return 1;
				}
				if (!TranslateAccelerator(SGLFE.hwnd, SGLFE.hAccel, &SGLFE.msg))
				{
					TranslateMessage(&SGLFE.msg);
					DispatchMessage(&SGLFE.msg);
				}
			}
			
			/* Give time to Windows for moving mouse */
			Sleep(2);

			if (!SGLFE.bPaused)
			{
				break;
			}
		}
	}

	/* Callback OK */
	return 0;
}


/*******************************************************************************
 * Function Name  : SGLFERenderCallback
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE
 * Description    : This function will be called during each render 
 *					to retrieve the rendering pointers.
 *
 *******************************************************************************/
int SGLFERenderCallback(P_CALLBACK_ADDRESS_PARAMS lpRenderParams)
{
	BOOL	bRet;
		
	/* Retrieve memory pointer to which SGL render to */
	if (!bStrictLocksQuit)
	{
		bRet=SGLFEGetRenderPointers(SGLFE.hwnd, &pMem, &wStride);
		if (!bRet)
		{
			DEBUG("SGLFEGetRenderPointers() failed in SGLFERenderCallback\n");
			SGLFE.bPaused=TRUE;
			MessageBox (NULL, "SGLFEGetRenderPointers() failed", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND | MB_SYSTEMMODAL);
			return 1;
		}
	
		/* Copy pointers to P_CALLBACK_ADDRESS_PARAMS structure */
		lpRenderParams->pMem=pMem;
		lpRenderParams->wStride=wStride;
		lpRenderParams->bBitsPerPixel=SGLFE.nPrimaryBitDepth;
	}

	/* Callback OK ; return 0 */
	return 0;
}


/*******************************************************************************
 * Function Name  : SGLFEGetRenderPointers
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE
 * Description    : Retrieve render buffer pointer in order for SGL to
 *					render to the surface pointed by this pointer.
 *
 *******************************************************************************/
BOOL SGLFEGetRenderPointers(HWND hWnd, WORD **pLocalMem, WORD *pLocalStride)
{
	HRESULT				hres;
	DDSURFACEDESC		ddsd;
	LPDIRECTDRAWSURFACE	lpSurface;
	
	/* Initialise ddsd */
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	
	/* Handle FullScreen modes */
	if (SGLFE.bFullScreen && SGLFE.nBufferingMode==1)
	{
		/* Primary surface is the only rendering surface for single-buffer mode */
		lpSurface=SGLFE.lpDDSPrimary;
	}
	else
	{
		/* Surface to lock is Back surface for both Window and FullScreen modes */
		lpSurface=SGLFE.lpDDSBack;
	}
	
	/* Check for lost surfaces */
	if (!SGLFECheckForLostSurfaces())
	{
		DEBUG("SGLFECheckForLostSurfaces() failed in SGLFEGetRenderPointers\n");
	}
	
	/* Lock surface */
	hres=lpSurface->lpVtbl->Lock(lpSurface, NULL, &ddsd, DDLOCK_WAIT, NULL);				
	if (hres!=DD_OK)
	{
		DEBUG("Lock() failed in SGLFEGetRenderPointers()\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}
	
	/* Get pointers */
	*pLocalMem=(WORD *)ddsd.lpSurface;
	*pLocalStride=(WORD)ddsd.lPitch;

	/* DWORD-align buffer pointer for Window mode */
	if (!SGLFE.bFullScreen)
	{
		(DWORD)(*pLocalMem)&=(DWORD)0xFFFFFFFC;
	}

	/* If StrictLocks, assert state of render surface */
	if (nStrictLocks)
	{
		bBufferLocked=TRUE;
	}
	
	/* Unlock render surface */
	/* Don't unlock render surface yet for strictlocks cards */
	if (!nStrictLocks)
	{
		hres=lpSurface->lpVtbl->Unlock(lpSurface, NULL);		
		if (hres!=DD_OK)
		{
			OutputDebugString("Unlock() failed in SGLFEGetRenderPointers\n");
			DisplayHRESULTInDebug(hres);
			return FALSE;
		}
	}
		
	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFEEnumDisplayModesCallback
 * Description    : Callback function which enumerates all available display
 *					modes for a DirectDraw device.
 *
 ******************************************************************************/
HRESULT WINAPI SGLFEEnumDisplayModesCallback(LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext)
{
	/* If the user asked for it, disable resolutions above 1024x768 */
	if (SGLFE.dwUserPreferences & DISABLE_VERYHIGHRES)
	{
		if (lpDDSurfaceDesc->dwWidth>1024)
		{
			return DDENUMRET_OK;
		}
	}

	/* If the resolution colour depth is below 16 or above 24, then discard it */
	if (lpDDSurfaceDesc->ddpfPixelFormat.dwRGBBitCount<16 || lpDDSurfaceDesc->ddpfPixelFormat.dwRGBBitCount>24)
	{
		return DDENUMRET_OK;
	}

	/* Fill DDDisplayMode structure with this resolution */
	DDDisplayMode[nDDNumDisplayModes].dwWidth=lpDDSurfaceDesc->dwWidth;
	DDDisplayMode[nDDNumDisplayModes].dwHeight=lpDDSurfaceDesc->dwHeight;
	DDDisplayMode[nDDNumDisplayModes].dwBPP=lpDDSurfaceDesc->ddpfPixelFormat.dwRGBBitCount;
	
	/* Increase number of display modes found */
	nDDNumDisplayModes++;
	if (nDDNumDisplayModes>DD_MAXDISPLAYMODES)
	{
		DEBUG("Reached maximum number of display modes\n\n");
		return DDENUMRET_CANCEL;
	}

	/* Continue enumeration */
	return DDENUMRET_OK;
}


/*******************************************************************************
 * Function Name  : SGLFEListDisplayModes
 * Returns        : TRUE if no error occured
 * Global Used    : SGLFE,
 *					DDDisplayMode[], nDDNumDisplayModes, nSafeDisplayModeNumber, 
 *					nCurrentDDDriver
 * Description    : List all display modes available for the current device.
 *					Also calculate the amount of physical video memory installed
 *					by reporting the highest amount of memory used for a video
 *					mode for the primary device.
 *******************************************************************************/
BOOL SGLFEListDisplayModes(LPDIRECTDRAW lpLocalDD)
{
	HRESULT				hres;
	int					i, BackCount=0;
	BOOL				Swap=FALSE;
	DDDisplayModeInfo	Dummy;
	DWORD				dwMaxVideoMemory=0;

	/* Setting first display mode to 0 */
	nDDNumDisplayModes=0;

	/* Call display mode callback */
	hres=lpLocalDD->lpVtbl->EnumDisplayModes(lpLocalDD, 0, NULL, NULL, SGLFEEnumDisplayModesCallback);
	if (hres!=DD_OK)
	{
		DEBUG("Problem with EnumDisplayModes\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Test if any display modes were found */
	if (nDDNumDisplayModes==0)
	{
		DEBUG("No display modes were found\n");
		return FALSE;
	}

	/* Sort all the display mode. That's a crap sorting method (bubble sort), 
	   but for a small amount of numbers it's all right, so who cares ?! */
	do
	{
		Swap=FALSE;
		BackCount++;
		for (i=0;i<nDDNumDisplayModes-BackCount;i++)
		{
			if (1000*DDDisplayMode[i].dwBPP+DDDisplayMode[i].dwWidth+DDDisplayMode[i].dwHeight<
				1000*DDDisplayMode[i+1].dwBPP+DDDisplayMode[i+1].dwWidth+DDDisplayMode[i+1].dwHeight)
			{
				/* Swap required */
				Dummy=DDDisplayMode[i+1];
				DDDisplayMode[i+1]=DDDisplayMode[i];
				DDDisplayMode[i]=Dummy;
				Swap=TRUE;
			}
		}
	}
	while (Swap && BackCount<nDDNumDisplayModes);
	
	/* Calculate video card physical memory */
	dwMaxVideoMemory=SGLFETotalVideoMemoryInfo(DDSCAPS_PRIMARYSURFACE);

	/* Add memory taken by GDI */
	dwMaxVideoMemory+=SGLFE.dwGDIWidth*SGLFE.dwGDIHeight*SGLFE.dwGDIBPP/8;
		
	/* Find closest Meg-approximation of video memory retrieved */
	/*
	SGLFE.dwPhysicalVideoMemory=128*1024*1024;	// 128 Megs card at most !!! 
	if (dwMaxVideoMemory<=16*1024*1024)		SGLFE.dwPhysicalVideoMemory=16*1024*1024;	// 16 Megs card
	if (dwMaxVideoMemory<=8*1024*1024)		SGLFE.dwPhysicalVideoMemory=8*1024*1024;	// 8 Megs card
	if (dwMaxVideoMemory<=6*1024*1024)		SGLFE.dwPhysicalVideoMemory=6*1024*1024;	// 6 Megs card
	if (dwMaxVideoMemory<=4*1024*1024)		SGLFE.dwPhysicalVideoMemory=4*1024*1024;	// 4 Megs card
	if (dwMaxVideoMemory<=3*1024*1024)		SGLFE.dwPhysicalVideoMemory=3*1024*1024;	// 3 Megs card
	if (dwMaxVideoMemory<=2*1024*1024)		SGLFE.dwPhysicalVideoMemory=2*1024*1024;	// 2 Megs card
	if (dwMaxVideoMemory<=1*1024*1024)		SGLFE.dwPhysicalVideoMemory=1*1024*1024;	// 1 Meg card
	if (dwMaxVideoMemory<=512*1024)			SGLFE.dwPhysicalVideoMemory=512*1024;		// 512K card or less (!)
	*/

	SGLFE.dwPhysicalVideoMemory=dwMaxVideoMemory;

	/* Debug output */
	sprintf(pszTmp, "Video card memory : %.2f Megs\n", (float)SGLFE.dwPhysicalVideoMemory/(1024.0f*1024.0f));
	DEBUG(pszTmp);

	/* Find display mode number corresponding to 640x480x16 */
	for (i=0;i<nDDNumDisplayModes;i++)
	{
		if (DDDisplayMode[i].dwWidth==640 && DDDisplayMode[i].dwHeight==480 && DDDisplayMode[i].dwBPP==16)
		{
			nSafeDisplayModeNumber=i;
		}
	}

	/* New resolution is safe resolution */
	nCurrentResolution=nSafeDisplayModeNumber;

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFECreateAccelerators
 * Global Used    : SGLFE
 * Description    : Create menus and accelerators
 *******************************************************************************/
void SGLFECreateAccelerators()
{
	int	nNumberOfAccel=4;
	int nNumberOfUserAccel=0;
	
	/* If a user accelerator table has been submitted */
	if (SGLFE.hAccel)
	{
		/* Retrieve number of accelerators from user table */
		nNumberOfUserAccel=CopyAcceleratorTable(SGLFE.hAccel, NULL, 0);

		/* Test if number of accelerators exceeds maximum */
		if (nNumberOfAccel+nNumberOfUserAccel>MAX_NUMBER_OF_ACCELERATORS)
		{
			DEBUG("Number of accelerators is too high : disabling user accelerators\n");
			nNumberOfUserAccel=0;
		}
		else
		{
			/* Copy user table into SGLFE.Accel */
			CopyAcceleratorTable(SGLFE.hAccel, &SGLFE.Accel[0], nNumberOfUserAccel);
		}
	}

	/* Compute total number of accelerators */
	nNumberOfAccel+=nNumberOfUserAccel;
	
	/* Assign ALT+RETURN for FullScreen */
	SGLFE.Accel[nNumberOfUserAccel].fVirt=FALT | FVIRTKEY;
	SGLFE.Accel[nNumberOfUserAccel].key=VK_RETURN;
	SGLFE.Accel[nNumberOfUserAccel].cmd=ID_MODES_FULLSCREEN;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign ESCAPE for quit */
	SGLFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	SGLFE.Accel[nNumberOfUserAccel].key=VK_ESCAPE;
	SGLFE.Accel[nNumberOfUserAccel].cmd=ID_FILE_QUIT;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign TAB for DispayInfo */
	SGLFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	SGLFE.Accel[nNumberOfUserAccel].key=VK_TAB;
	SGLFE.Accel[nNumberOfUserAccel].cmd=ID_FILE_DISPLAYINFO;

	/* Increase count */
	nNumberOfUserAccel++;

	/* Assign Ctrl+C for Screen Capture */
	SGLFE.Accel[nNumberOfUserAccel].fVirt=FVIRTKEY;
	SGLFE.Accel[nNumberOfUserAccel].key=VK_F12;
	SGLFE.Accel[nNumberOfUserAccel].cmd=ID_FILE_SCREENCAPTURE;

	/* CreateAccelerator Table */
	SGLFE.hAccel=CreateAcceleratorTable(SGLFE.Accel, nNumberOfAccel);
}


/*******************************************************************************
 * Function Name  : SGLFEBuildMenus
 * Returns		  : TRUE if no problem occurs.
 * Global Used    : SGLFE
 * Description    : Build all menus to be used in the SGL Shell
 *******************************************************************************/
BOOL SGLFEBuildMenus()
{
	int		i;
	char	pszString[100];

	/*********************** Create main menu ************************/
	if (SGLFE.hMenu)
	{
		DestroyMenu(SGLFE.hMenu);
	}
	SGLFE.hMenu=CreateMenu();
	if (SGLFE.hMenu==NULL)
	{
		DEBUG("Failed to create main menu in BuildMenus()\n");
	}
	

	/*********************** Create File menu ************************/
	if (SGLFE.hFileMenu)
	{
		DeleteMenu(SGLFE.hMenu, (UINT)SGLFE.hFileMenu, MF_BYCOMMAND);
	}
	SGLFE.hFileMenu=CreatePopupMenu();
	if (SGLFE.hFileMenu==NULL)
	{
		DEBUG("Failed to create File menu in BuildMenus()\n");
	}

	/* Attach File menu to main menu */
	AppendMenu(SGLFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)SGLFE.hFileMenu, "&File");

	/* Add Screen capture menu item */
	AppendMenu(SGLFE.hFileMenu, MF_STRING | MF_ENABLED, ID_FILE_SCREENCAPTURE, "&Screen capture\tF12");

	/* Draw separator */
	AppendMenu(SGLFE.hFileMenu, MF_SEPARATOR, 0, 0);
	
	/* Add Display Info menu item */
	AppendMenu(SGLFE.hFileMenu, MF_STRING | MF_ENABLED, ID_FILE_DISPLAYINFO, "&Display Info\tTAB");

	/* Draw separator */
	AppendMenu(SGLFE.hFileMenu, MF_SEPARATOR, 0, 0);
	
	/* Add Quit menu item */
	AppendMenu(SGLFE.hFileMenu, MF_STRING | MF_ENABLED, ID_FILE_QUIT, "&Quit\t<Esc>");
	

	/********************* Create Buffering menu ***********************/
	if (!(SGLFE.dwUserPreferences & (FORCE_SINGLEBUFFER | FORCE_DOUBLEBUFFER | FORCE_TRIPLEBUFFER)))
	{
		if (SGLFE.hBufferingMenu)
		{
			DeleteMenu(SGLFE.hMenu, (UINT)SGLFE.hBufferingMenu, MF_BYCOMMAND);
		}
		SGLFE.hBufferingMenu=CreatePopupMenu();
		if (SGLFE.hBufferingMenu==NULL)
		{
			DEBUG("Failed to create Buffering Menu menu in SGLFEBuildMenus()\n");
		}

		/* Attach Buffering menu to main menu */
		AppendMenu(SGLFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)SGLFE.hBufferingMenu, "&Buffering");
		
		/* Add buffering modes */
		/* If user has chosen a Buffering mode, then do not display Buffering modes choices */
		if (SGLFE.dwUserPreferences & FORCE_SINGLEBUFFER) 
		{
			SGLFE.nBufferingMode=1;
		}
		else if (SGLFE.dwUserPreferences & FORCE_DOUBLEBUFFER) 
		{
			SGLFE.nBufferingMode=2;
		}
		else if (SGLFE.dwUserPreferences & FORCE_TRIPLEBUFFER) 
		{
			SGLFE.nBufferingMode=3;
		}
		else
		{
			/* Display Buffering Modes choices */
			/* Display Single Buffer menu item if not disabled */
			if (!(SGLFE.dwUserPreferences & DISABLE_SINGLEBUFFER))
			{
				AppendMenu(SGLFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_SINGLEBUFFER, "&Single Buffer");
			}
			/* Always display Double Buffer menu item (no option to disable it) */
			AppendMenu(SGLFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_DOUBLEBUFFER, "&Double Buffer");
			/* Display Triple Buffer menu item if not disabled */
			if (!(SGLFE.dwUserPreferences & DISABLE_TRIPLEBUFFER))
			{
				AppendMenu(SGLFE.hBufferingMenu, MF_ENABLED, ID_BUFFERING_TRIPLEBUFFER, "&Triple Buffer");
			}
		}
	}


	/*********************** Create Modes menu ************************/
	if (SGLFE.hModesMenu)
	{
		DeleteMenu(SGLFE.hMenu, (UINT)SGLFE.hModesMenu, MF_BYCOMMAND); 
	}
	SGLFE.hModesMenu=CreatePopupMenu();
	if (SGLFE.hModesMenu==NULL)
	{
		DEBUG("Failed to create Screen menu in SGLFEBuildMenus()\n");
	}

	/* Attach Modes menu to main menu */
	AppendMenu(SGLFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)SGLFE.hModesMenu, "&Modes");

	/* Create FullScreen choice if permitted */
	if (!(SGLFE.dwUserPreferences & FORCE_FULLSCREEN))
	{
		/* Create FullScreen choice */
		AppendMenu(SGLFE.hModesMenu, MF_ENABLED, ID_MODES_FULLSCREEN, "&Full Screen\t<Alt+Enter>");
	
		/* Draw separator */
		AppendMenu(SGLFE.hModesMenu, MF_SEPARATOR, 0, 0);
	}

	/* Create menu items corresponding to screen resolutions */
	for (i=0;i<nDDNumDisplayModes;i++)
	{
		sprintf(pszString, "%ux%ux%u", DDDisplayMode[i].dwWidth, DDDisplayMode[i].dwHeight, DDDisplayMode[i].dwBPP);
		AppendMenu(SGLFE.hModesMenu, MF_ENABLED, ID_MODES_RES0+i, pszString);
		if (DDDisplayMode[i].dwWidth==640 && DDDisplayMode[i].dwHeight==480 && DDDisplayMode[i].dwBPP==16)
		{
			nSafeDisplayModeNumber=i;
		}
	}


	/*********************** Create User menu ************************/
	/* If user menu has been submitted, then append it to the FrontEnd menu */
	if (SGLFE.hUserMenu)
	{
		for (i=0; i<GetMenuItemCount(SGLFE.hUserMenu); i++)
		{
			GetMenuString(SGLFE.hUserMenu, i, pszString, 100, MF_BYPOSITION);
			AppendMenu(SGLFE.hMenu, MF_STRING | MF_ENABLED | MF_POPUP, (UINT)GetSubMenu(SGLFE.hUserMenu, i), pszString);
		}
	}
	
	/* Attach menu to window */
	SGLFE.bIgnoreWM_SIZE=TRUE;
	SetMenu(SGLFE.hwnd, SGLFE.hMenu);
	DrawMenuBar(SGLFE.hwnd);
	SGLFE.bIgnoreWM_SIZE=FALSE;

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFEUpdateMenus
 * Global Used    : SGLFE, 
 *					DDDisplayMode[], nDDNumDrivers, nDDNumDisplayModes
 * Description    : Check availability of choices in menu by graying or enabling
 *					menu items. Update check boxes on menu items.
 *******************************************************************************/
void SGLFEUpdateMenus()
{
	int		i;
	DWORD	dwMemory=0;

	/* Asserts */
	ASSERT(nDDNumDisplayModes>0);
	ASSERT(SGLFE.hModesMenu!=NULL);
	
	/* Update menu item corresponding to "Display Info" */
	if (SGLFE.bShowInfoBuffer)
	{
		CheckMenuItem(SGLFE.hFileMenu, ID_FILE_DISPLAYINFO, MF_CHECKED);
	}
	else
	{
		CheckMenuItem(SGLFE.hFileMenu, ID_FILE_DISPLAYINFO, MF_UNCHECKED);
	}
	
	/* Buffering modes */
	/* First uncheck them all */
	if (SGLFE.hBufferingMenu)
	{
		CheckMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_UNCHECKED);
		CheckMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_UNCHECKED);
		CheckMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_UNCHECKED);

		/* Check current buffering mode */
		EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_ENABLED);
		EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_ENABLED);
		EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_ENABLED);
		switch (SGLFE.nBufferingMode)
		{
		case	1	:	CheckMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_CHECKED); break;
		case	2	:	CheckMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_CHECKED); break;
		case	3	:	CheckMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_CHECKED); break;
		default : DEBUG("Incorrect value for Buffering Mode\n"); break;
		}
	
		if (SGLFE.bFullScreen)
		{
			/* Gray buffering modes or not corresponding to the current resolution
			   eg if you are in 1024x768x24 in single buffering mode you should not be
			   able to select double or triple buffering if you don't have the video
			   memory for it */
			dwMemory=SGLFE.dwPhysicalVideoMemory;
			if (2*DDDisplayMode[nCurrentResolution].dwWidth*
				DDDisplayMode[nCurrentResolution].dwHeight*
				DDDisplayMode[nCurrentResolution].dwBPP/8 > dwMemory)
			{
				EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_GRAYED);
			}
			if (3*DDDisplayMode[nCurrentResolution].dwWidth*
				DDDisplayMode[nCurrentResolution].dwHeight*
				DDDisplayMode[nCurrentResolution].dwBPP/8	> dwMemory)
			{
				EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_GRAYED);
			}
		}
		else
		{
			/* In Window mode gray all buffering modes menu items */
			EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_SINGLEBUFFER, MF_GRAYED);
			EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_DOUBLEBUFFER, MF_GRAYED);
			EnableMenuItem(SGLFE.hBufferingMenu, ID_BUFFERING_TRIPLEBUFFER, MF_GRAYED);
		}
	}
	
	/* Uncheck all resolutions in Screen menu */
	for (i=0;i<nDDNumDisplayModes;i++)
	{
		CheckMenuItem(SGLFE.hModesMenu, ID_MODES_RES0+i, MF_UNCHECKED);
	}

	/* FullScreen or not */
	if (SGLFE.bFullScreen)
	{
		CheckMenuItem(SGLFE.hModesMenu, ID_MODES_FULLSCREEN, MF_CHECKED);
		/* Check current resolution */
		CheckMenuItem(SGLFE.hModesMenu, ID_MODES_RES0+nCurrentResolution, MF_CHECKED);
	}
	else
	{
		/* Not in FullScreen mode -> Uncheck item */
		CheckMenuItem(SGLFE.hModesMenu, ID_MODES_FULLSCREEN, MF_UNCHECKED);
	}
}


/*******************************************************************************
 * Function Name  : SGLFEFreeVideoMemoryInfo
 * Returns		  :	Amount of free video memory
 * Global Used    : SGLFE
 * Description    : Returns amount of free video memory that can be used by
 *					a surface
 *******************************************************************************/
DWORD SGLFEFreeVideoMemoryInfo(DWORD dwCaps)
{
	DDSCAPS			ddsCaps;
	HRESULT			hres;
	DWORD			dwTotal=0;
	DWORD			dwFree=0;
	LPDIRECTDRAW2	lpLocalDD2;

	/* If no memory check is specified, return max value for video memory */
	if (SGLFE.dwUserPreferences & NO_MEMORY_CHECK)
	{
		return 16*1024*1024;
	}

	/* If SGLFE.lpDD2 has not yet been created, return max value */
	if (!SGLFE.lpDD) 
	{
		return 16*1024*1024;
	}

	/* Query interface for DirectDraw 2 */
	hres=SGLFE.lpDD->lpVtbl->QueryInterface(SGLFE.lpDD, &IID_IDirectDraw2, &lpLocalDD2);
	if (hres!=DD_OK)
	{
		DEBUG("QueryInterface for DirectDraw2 failed in SGLFETotalVideoMemoryInfo()\n");
		DisplayHRESULTInDebug(hres);
		return 16*1024*1024;
	}
	
	/* Call this function to retrieve the amount of video memory */
	ddsCaps.dwCaps=dwCaps;
	hres=lpLocalDD2->lpVtbl->GetAvailableVidMem(lpLocalDD2, &ddsCaps, &dwTotal, &dwFree);
	if (hres!=DD_OK)
	{
		DEBUG("GetAvailableVidMem() failed in FreeVideoMemoryInfo()\n");
		DisplayHRESULTInDebug(hres);
	}

	/* Release memory */
	RELEASE(lpLocalDD2);
	
	/* Return free video memory */
	return dwFree;
}


/*******************************************************************************
 * Function Name  : SGLFETotalVideoMemoryInfo
 * Returns		  :	Amount of total video memory
 * Global Used    : SGLFE
 * Description    : Returns amount of total video memory that can be used by
 *					a surface
 *******************************************************************************/
DWORD SGLFETotalVideoMemoryInfo(DWORD dwCaps)
{
	DDSCAPS			ddsCaps;
	HRESULT			hres;
	DWORD			dwTotal=0;
	DWORD			dwFree=0;
	LPDIRECTDRAW2	lpLocalDD2;

	/* If no memory check is specified, return max value for video memory */
	if (SGLFE.dwUserPreferences & NO_MEMORY_CHECK) 
	{
		return 16*1024*1024;
	}
	
	/* If SGLFE.lpDD has not yet been created, return max value */
	if (!SGLFE.lpDD) return 16*1024*1024;

	/* Query interface for DirectDraw 2 */
	hres=SGLFE.lpDD->lpVtbl->QueryInterface(SGLFE.lpDD, &IID_IDirectDraw2, &lpLocalDD2);
	if (hres!=DD_OK)
	{
		DEBUG("QueryInterface for DirectDraw2 failed in SGLFETotalVideoMemoryInfo()\n");
		DisplayHRESULTInDebug(hres);
		return 16*1024*1024;
	}

	/* Call this function to retrieve the amount of video memory */
	ddsCaps.dwCaps=dwCaps;
	hres=lpLocalDD2->lpVtbl->GetAvailableVidMem(lpLocalDD2, &ddsCaps, &dwTotal, &dwFree);
	if (hres!=DD_OK)
	{
		DEBUG("GetAvailableVidMem() failed in TotalVideoMemoryInfo()\n");
		DisplayHRESULTInDebug(hres);
	}

	/* Release memory */
	RELEASE(lpLocalDD2);
		
	/* Return total video memory */
	return dwTotal;
}


/*******************************************************************************
 * Function Name  : SGLFEHandleWM_PAINT
 * Global Used    : SGLFE
 * Description    : Paint the window when paused
 *******************************************************************************/
void SGLFEHandleWM_PAINT(HWND hWindow)
{
    HPEN		hOldPen;
    HBRUSH		hOldBrush;
    COLORREF	crOldTextColor;
    INT			oldMode;
	HDC			hdc;
    INT			x;
    INT			y;
    SIZE		size;
    RECT		rect;
    INT			nStrLen;
	char		pszPaused[50];
	RECT		SrcRect, DstRect;
	POINT		pt;
	HRESULT		hres;

	/* If SGL init is already set up, blit back buffer on screen */
	if (SGLFE.bRenderingReady && SGLFE.lpDDSBack && SGLFE.lpDDSBack->lpVtbl->IsLost(SGLFE.lpDDSBack)==DD_OK)
	{
		/* Windowed mode : perform a blit from back buffer to front buffer */
		
		/* SrcRect is relative to back buffer */
		GetClientRect(hWindow, &SrcRect);

		/* DstRect is relative to screen space so needs translation */
		pt.x=0;
		pt.y=0;
		ClientToScreen(hWindow, &pt);
		DstRect=SrcRect;
		DstRect.left+=pt.x;
		DstRect.right+=pt.x;
		DstRect.top+=pt.y;
		DstRect.bottom+=pt.y;

		/* Perform the blit from backbuffer to primary, using src_rect and dst_rect */
		hres=SGLFE.lpDDSPrimary->lpVtbl->Blt(SGLFE.lpDDSPrimary, &DstRect, SGLFE.lpDDSBack, &SrcRect, DDBLT_WAIT, 0);
		if (hres==DDERR_SURFACELOST)
		{
			hres=SGLFE.lpDDSPrimary->lpVtbl->Restore(SGLFE.lpDDSPrimary);
			if (hres!=DD_OK)
			{
				DEBUG("Failed to restore primary surface\n");
			}
		}
		else
		if (hres!=DD_OK)
		{
			DEBUG("A problem occured while blitting\n");
			DisplayHRESULTInDebug(hres);
		}
	}
	else
	{
		/* Display black screen + "Paused" message */
		strcpy(pszPaused, "Paused");
    
		hdc=GetDC(hWindow);

		/* Black background */
		hOldPen=(HPEN)SelectObject (hdc, GetStockObject (NULL_PEN));
		hOldBrush=(HBRUSH)SelectObject (hdc, GetStockObject (BLACK_BRUSH));

		/* White text */
		oldMode=SetBkMode (hdc, TRANSPARENT);
		crOldTextColor=SetTextColor (hdc, RGB(255, 255, 255));

		/* Get client area */
		GetClientRect(hWindow, &rect);

		/* Clear the client area */
	    Rectangle(hdc, rect.left, rect.top, rect.right + 1, rect.bottom + 1);

		/* Draw the string centered in the client area */
	    nStrLen=strlen(pszPaused);
		GetTextExtentPoint32(hdc, pszPaused, nStrLen, &size);
		x=(rect.right  - size.cx) / 2;
		y=(rect.bottom - size.cy) / 2;
		TextOut (hdc, x, y, pszPaused, nStrLen);

		/* Cleanup */
		SetTextColor(hdc, crOldTextColor);
		SetBkMode(hdc, oldMode);

		SelectObject(hdc, hOldBrush);
		SelectObject(hdc, hOldPen);

		ReleaseDC(hWindow, hdc);
	}
}


/*******************************************************************************
 * Function Name  : SGLFEHandleWM_SIZE
 * Global Used    : SGLFE
 * Description    : Handle the WM_SIZE message from the window loop.
 *					Deal with minimising and unminimising initialisations in both 
 *					window and FullScreen mode, and resizing in window mode.
 *******************************************************************************/
BOOL SGLFEHandleWM_SIZE(LRESULT *lresult, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/* If we have minimized, take note and call the default window proc */
    if (wParam==SIZE_MINIMIZED) 
	{
        SGLFE.bMinimized=TRUE;
        *lresult=DefWindowProc(hWnd, message, wParam, lParam);
        return TRUE;
    }

    /* If we are minimized, this is the un-minimized size message */
    if (SGLFE.bMinimized)									 
	{
		DEBUG("Restoring screen...\n");
		SGLFE.bMinimized=FALSE;
        *lresult=DefWindowProc(hWnd, message, wParam, lParam);
		return TRUE;
    }
}


/*******************************************************************************
 * Function Name  : SGLFEDisplayText
 * Global Used    : SGLFE
 * Description    : Function used to display text on screen
 *					
 *******************************************************************************/
void SGLFEDisplayText()
{
	HRESULT	hres;
	HDC		hdc;
	int		i;
		
	/* If a back buffer exists, display text on it
	   Otherwise use front buffer */
	if (SGLFE.bFullScreen && SGLFE.nBufferingMode==1)
	{
		/* Retrieve a device context for the front buffer in single buffer mode */
		hres=SGLFE.lpDDSPrimary->lpVtbl->GetDC(SGLFE.lpDDSPrimary, &hdc);
		if (hres!=DD_OK)
		{
			DEBUG("Unable to get DC for front buffer in SGLFEDisplayText()\n");
			DisplayHRESULTInDebug(hres);
			SGLFE.nNumberOfUserString=0;
			/* Not a critical error so just quit the function */
			return;
		}
	}
	else
	{
		/* Retrieve a device context for the back buffer */
		hres=SGLFE.lpDDSBack->lpVtbl->GetDC(SGLFE.lpDDSBack, &hdc);
		if (hres!=DD_OK)
		{
			DEBUG("Unable to get DC for back buffer in SGLFEDisplayText()\n");
			DisplayHRESULTInDebug(hres);
			SGLFE.nNumberOfUserString=0;
			/* Not a critical error so just quit the function */
			return;
		}
	}

	/* Select text preferences */
	SetBkMode(hdc, TRANSPARENT);
	SelectObject(hdc, SGLFE.hTextFont);
	SetTextColor(hdc, RGB(255, 255, 0));

	/* Display info text */
	if (SGLFE.bShowInfoBuffer)
	{
		TextOut(hdc, 10, SGLFE.bFullScreen ? DDDisplayMode[nCurrentResolution].dwHeight-22 : SGLFE.dwWindowHeight-22, 
				SGLFE.pszDisplayText, strlen(SGLFE.pszDisplayText));
	}

	/* Display user text */
	if (SGLFE.nNumberOfUserString>0)
	{
		for (i=0;i<SGLFE.nNumberOfUserString;i++)
		{
			TextOut(hdc, SGLFE.nUserTextPositionX[i], SGLFE.nUserTextPositionY[i], 
				SGLFE.pszUserText[i], strlen(SGLFE.pszUserText[i]));
		}
	}

	/* Release DC */
	if (SGLFE.bFullScreen && SGLFE.nBufferingMode==1)
	{
		SGLFE.lpDDSPrimary->lpVtbl->ReleaseDC(SGLFE.lpDDSPrimary, hdc);
	}
	else
	{
		SGLFE.lpDDSBack->lpVtbl->ReleaseDC(SGLFE.lpDDSBack, hdc);
	}

	/* Reset number of user strings to 0 */
	SGLFE.nNumberOfUserString=0; 
}


/*******************************************************************************
 * Function Name  : SGLFEMouseVisible
 * Global Used    : None
 * Description    : Simple function which makes the mouse cursor visible or not
 *******************************************************************************/
void SGLFEMouseVisible(BOOL bVisible)
{
	static BOOL	bMouseVisible=TRUE;

	if (bVisible)
	{
		/* We want the mouse visible */
		/* We call ShowCursor(TRUE) only if mouse was invisible before */
		if (!bMouseVisible)
		{
			ShowCursor(TRUE);
			bMouseVisible=TRUE;
		}
	}
	else
	{	
		/* We want the mouse invisible */
		/* We call ShowCursor(FALSE) only if mouse was visible before */
		if (bMouseVisible)
		{
			ShowCursor(FALSE);
			bMouseVisible=FALSE;
		}
	}
}


/*******************************************************************************
 * Function Name  : SGLFEGetSurfaceBitsPerPixel
 * Returns        : TRUE if no error occured
 * Global Used    : None
 * Description    : Returns 15 16 24 or 32. 0 if unsupported format
 *
 *******************************************************************************/
int SGLFEGetSurfaceBitsPerPixel(LPDIRECTDRAWSURFACE pSurface)
{
	DDPIXELFORMAT	ddpf;
	int				nBitsPerPix=0;
	HRESULT			hres;
	
	/* Get pixel format of primary surface */
	ZeroMemory(&ddpf, sizeof(ddpf));
	ddpf.dwSize=sizeof(ddpf);
	hres=pSurface->lpVtbl->GetPixelFormat(pSurface, &ddpf);
	if (hres!=DD_OK)
	{
	 	DEBUG("GetPixelFormat failed in GetSurfaceBitsPerPixel\n");
		DisplayHRESULTInDebug(hres);
		return 0;
	}
	
	if (ddpf.dwFlags & DDPF_RGB)
	{
		switch (ddpf.dwRGBBitCount) /* 4 8 16 24 or 32 */
		{
			case 16:
			{
				if (ddpf.dwGBitMask & 0x0400)
				{
					/* 565 */
					nBitsPerPix = 16;
				}
				else
				{
					/* Bit 15 not red implies 555 */
					nBitsPerPix = 15;
				}
				break;
			}
			
			case 24:
			case 32:
			{
				nBitsPerPix=ddpf.dwRGBBitCount;
				break;
			}
		}
	}
		
	/* Return the number of bits per pixel */
	return nBitsPerPix;
}


/*******************************************************************************
 * Function Name  : SGLFEWindowProc
 * Description    : Messages handling function
 *******************************************************************************/
long CALLBACK SGLFEWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	RECT			Rectangle;
	LRESULT			lresult;
	
	/* Let the user process window message (menus and keystrokes) */
	UserWindowProc(hWnd, message, wParam, lParam);
	
	/* FrontEnd window messages */
	switch(message)
    {
	case	WM_ENTERMENULOOP :	SGLFE.bPaused=TRUE;
								if (SGLFE.bFullScreen)
								{
									/* Allow SGL to finish rendering (only useful for single buffer) */
									Sleep(50);
									DrawMenuBar(SGLFE.hwnd);
									SGLFEMouseVisible(TRUE);
								}
								break;

	case	WM_EXITMENULOOP :	SGLFE.bPaused=FALSE;
								if (SGLFE.bFullScreen)
								{
									SGLFEMouseVisible(FALSE);
								}
								break;

	case	WM_ACTIVATEAPP :    /* Used to disable rendering if window is not activated */
								if (SGLFE.bRenderingReady)
								{
									if (!(BOOL)wParam)
									{
										SGLFE.bPaused=TRUE;
									}
									else
									{
										SGLFE.bPaused=FALSE;
									}
								}
						        break;

	case	WM_SYSCOMMAND :	    switch (wParam & 0xFFF0)
								{
									/* Close Window */
									case SC_CLOSE:	DestroyWindow(SGLFE.hwnd);
													break;
									
									/* Disable Screen saver */	
									case SC_SCREENSAVE:

									/* Disable monitor power down */
									case SC_MONITORPOWER:	return 0; break;

									/* Minimize has been selected */
									case SC_MINIMIZE :		SGLFE.bMinimized=TRUE; break;

									default : break;
								}
								return (DefWindowProc(hWnd, message, wParam, lParam));
								break;	
	
	case	WM_SIZE :			/* Only handle minimising message */
								if (!SGLFE.bIgnoreWM_SIZE) 
								{		
									SGLFE.bPaused=TRUE;
									SGLFEHandleWM_SIZE(&lresult, hWnd, message, wParam, lParam);
									SGLFE.bPaused=FALSE;
									return 0;
								}
								break;

	case	WM_MOVE :			/* Update window position information after a move */
								if (!SGLFE.bFullScreen && !SGLFE.bMinimized && !SGLFE.bIgnoreWM_SIZE && !SGLFE.bPaused)
								{
									GetWindowRect(hWnd, &Rectangle);
									SGLFE.dwWindowFramePositionX=Rectangle.left; 
									SGLFE.dwWindowFramePositionY=Rectangle.top;
								}
								break;
	
								/* Prevent the window from moving in fullscreen */
	case	WM_MOVING	:		if (SGLFE.bFullScreen) 
								{
									GetWindowRect(hWnd, (LPRECT)lParam);
									return 0;								
								}
								break;

	case	WM_PAINT :			/* Handle WM_PAINT messages when paused */
								if (SGLFE.bPaused)
								{
									SGLFEHandleWM_PAINT(hWnd);
								}
								return (DefWindowProc(hWnd, message, wParam, lParam));
								break;
	
	case	WM_DESTROY :		/* Handle window destroying */
								PostQuitMessage(0);
								break;

	case	WM_QUIT :			/* Quit program */
								DEBUG("Quitting SGL Shell\n");
								break;

	/* Handle FrontEnd menu messages */
	case	WM_COMMAND : 
		
		switch(GET_WM_COMMAND_ID(wParam,lParam))
		{
			/* Handle FILE menu message */
			case	ID_FILE_SCREENCAPTURE :	DEBUG("Screen capture occuring\n"); 
											SGLFEScreenCapture();
											break;
			
			case	ID_FILE_DISPLAYINFO	:	if (SGLFE.bShowInfoBuffer)
											{
												SGLFE.bShowInfoBuffer=FALSE;
											}
											else
											{
												SGLFE.bShowInfoBuffer=TRUE;
											}
											SGLFEUpdateMenus();
											break;
			
			case	ID_FILE_QUIT : 	if (nStrictLocks)
									{
										PostQuitMessage(0);
										return 0;
									}
									SGLFE.bPaused=TRUE;
									if (SGLFE.bFullScreen)
									{
										SGLFEFinish();
									}
									else  
									{
										/* In window mode, ask the user for confirmation */
										SGLFEMouseVisible(TRUE);
										if (MessageBox(hWnd, "Are you sure you want to quit ?", SGLFE.pszFrontEndTitle, MB_YESNO | MB_ICONINFORMATION)==IDYES)
										{
											SGLFEFinish();
										}
									}
									SGLFE.bPaused=FALSE;
									if (SGLFE.bFullScreen) 
									{
										SGLFEMouseVisible(FALSE);
									}
									break;
	
			/* Handle BUFFERING menu message */
			case	ID_BUFFERING_SINGLEBUFFER :	if (SGLFE.nBufferingMode!=1)
												{
													SGLFE.nBufferingMode=1;
													SGLFEChangeMode(nCurrentResolution, FALSE);
												}
												break;

			case	ID_BUFFERING_DOUBLEBUFFER :	if (SGLFE.nBufferingMode!=2)
												{
													SGLFE.nBufferingMode=2;
													SGLFEChangeMode(nCurrentResolution, FALSE);
												}
												break;

			case	ID_BUFFERING_TRIPLEBUFFER :	if (SGLFE.nBufferingMode!=3)
												{
													SGLFE.nBufferingMode=3;
													SGLFEChangeMode(nCurrentResolution, FALSE);
												}
												break;
			  
			/* Handle MODES menu messages */
			case	ID_MODES_FULLSCREEN	:	if ((!(SGLFE.dwUserPreferences & FORCE_FULLSCREEN)) && SGLFE.bRenderingReady)
											{
												if (SGLFE.bFullScreen==TRUE) 
												{
													SGLFE.bFullScreen=FALSE;
												}
												else 
												{
													nCurrentResolution=nSafeDisplayModeNumber;
													SGLFE.bFullScreen=TRUE;
												}
												SGLFEChangeMode(nCurrentResolution, FALSE);
											}
											break;
											
			case	ID_MODES_RES0  :			SGLFEChangeMode(0, TRUE);	break;
			case	ID_MODES_RES1  :			SGLFEChangeMode(1, TRUE);	break;
			case	ID_MODES_RES2  :			SGLFEChangeMode(2, TRUE);	break;
			case	ID_MODES_RES3  :			SGLFEChangeMode(3, TRUE);	break;
			case	ID_MODES_RES4  :			SGLFEChangeMode(4, TRUE);	break;
			case	ID_MODES_RES5  :			SGLFEChangeMode(5, TRUE);	break;
			case	ID_MODES_RES6  :			SGLFEChangeMode(6, TRUE);	break;
			case	ID_MODES_RES7  :			SGLFEChangeMode(7, TRUE);	break;
			case	ID_MODES_RES8  :			SGLFEChangeMode(8, TRUE);	break;
			case	ID_MODES_RES9  :			SGLFEChangeMode(9, TRUE);	break;					
			case	ID_MODES_RES10 :			SGLFEChangeMode(10, TRUE);	break;
			case	ID_MODES_RES11 :			SGLFEChangeMode(11, TRUE);	break;
			case	ID_MODES_RES12 :			SGLFEChangeMode(12, TRUE);	break;
			case	ID_MODES_RES13 :			SGLFEChangeMode(13, TRUE);	break;
			case	ID_MODES_RES14 :			SGLFEChangeMode(14, TRUE);	break;
			case	ID_MODES_RES15 :			SGLFEChangeMode(15, TRUE);	break;
			case	ID_MODES_RES16 :			SGLFEChangeMode(16, TRUE);	break;
			case	ID_MODES_RES17 :			SGLFEChangeMode(17, TRUE);	break;
			case	ID_MODES_RES18 :			SGLFEChangeMode(18, TRUE);	break;
			case	ID_MODES_RES19 :			SGLFEChangeMode(19, TRUE);	break;
			case	ID_MODES_RES20 :			SGLFEChangeMode(20, TRUE);	break;
			case	ID_MODES_RES21 :			SGLFEChangeMode(21, TRUE);	break;
			case	ID_MODES_RES22 :			SGLFEChangeMode(22, TRUE);	break;
			case	ID_MODES_RES23 :			SGLFEChangeMode(23, TRUE);	break;
			case	ID_MODES_RES24 :			SGLFEChangeMode(24, TRUE);	break;
			case	ID_MODES_RES25 :			SGLFEChangeMode(25, TRUE);	break;
			case	ID_MODES_RES26 :			SGLFEChangeMode(26, TRUE);	break;
			case	ID_MODES_RES27 :			SGLFEChangeMode(27, TRUE);	break;
			case	ID_MODES_RES28 :			SGLFEChangeMode(28, TRUE);	break;
			case	ID_MODES_RES29 :			SGLFEChangeMode(29, TRUE);	break;
			
			default : return DefWindowProc(hWnd, message, wParam, lParam);
		 }
		 break;

    default:	return DefWindowProc(hWnd, message, wParam, lParam);
    }

    return 0;
}


/*******************************************************************************
 * Function Name  : WinMain 
 * Description    : Main function of the program
 *******************************************************************************/
int WINAPI WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	BOOL		idle, done = FALSE;
	static int	nRenderFailed=0;
	RECT		Rect;
	HDC			hdc;
	DWORD		dwRenderWidth, dwRenderHeight;

	/* Initialise SGL Shell variables */
	SGLFEInitFrontEnd();

	/* Set up and register window class */
	if (!hPrevInstance)	
	{
		SGLFE.wndclass.style=CS_BYTEALIGNCLIENT;
		SGLFE.wndclass.lpfnWndProc=(WNDPROC)SGLFEWindowProc;
		SGLFE.wndclass.cbClsExtra=0;
		SGLFE.wndclass.cbWndExtra=0;
		SGLFE.wndclass.hInstance=hInstance;
		SGLFE.wndclass.hIcon=SGLFE.hIcon;
		SGLFE.wndclass.hCursor=LoadCursor(NULL, IDC_ARROW);
		SGLFE.wndclass.hbrBackground=NULL; 
		SGLFE.wndclass.lpszMenuName=NULL;
		SGLFE.wndclass.lpszClassName="SGLShellClass";
		RegisterClass(&SGLFE.wndclass);
	}

	/* First call InitApplication() to retrieve user choices */
	InitApplication();

	/* Compute Window style */
	SGLFE.dwWindowStyle=WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;

	/* Get Screen default dimensions and bpp */
	SGLFE.dwGDIWidth=GetSystemMetrics(SM_CXSCREEN);
	SGLFE.dwGDIHeight=GetSystemMetrics(SM_CYSCREEN);
	hdc=GetDC(NULL);
	SGLFE.dwGDIBPP=GetDeviceCaps(hdc, BITSPIXEL);
	ReleaseDC(NULL, hdc);

	/* Update maximum width and height of window */
	if (SGLFE.dwGDIWidth<SGLFE.dwMaxWindowWidth)
	{
		SGLFE.dwMaxWindowWidth=SGLFE.dwGDIWidth;
	}
	if (SGLFE.dwGDIHeight<SGLFE.dwMaxWindowHeight)
	{
		SGLFE.dwMaxWindowHeight=SGLFE.dwGDIHeight;
	}

	/* Check if colour depth is at least 16 bpp */
	if (SGLFE.dwGDIBPP<16)
	{
		DEBUG("Color depth is lower than 16 BPP\n");
		sprintf(pszTmp, "Can not run program with a color depth of %u\nColor depth must be at least 16 bpp", SGLFE.dwGDIBPP);
		MessageBox(NULL, pszTmp, SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();	/* To release any memory allocated by application */
		return 0;
	}

	/* Check if colour depth is no more than 24 bpp */
	if (SGLFE.dwGDIBPP>24)
	{
		DEBUG("Color depth is above 24 BPP\n");
		MessageBox(NULL, "Can not run program with a color depth above 24 bpp", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();	/* To release any memory allocated by application */
		return 0;
	}
	
	/* Compute window position (screen centre) */
	SGLFE.dwWindowPositionX=(SGLFE.dwGDIWidth-SGLFE.dwWindowWidth)/2;
	SGLFE.dwWindowPositionY=(SGLFE.dwGDIHeight-SGLFE.dwWindowHeight)/2;
	
	/* Compute window size corresponding to client area size */
	SetRect(&Rect,  SGLFE.dwWindowPositionX, SGLFE.dwWindowPositionY, 
					SGLFE.dwWindowWidth+SGLFE.dwWindowPositionX-1, SGLFE.dwWindowHeight+SGLFE.dwWindowPositionY-1);
	AdjustWindowRect(&Rect, SGLFE.dwWindowStyle, TRUE);

	/* Set window frame values */
	SGLFE.dwWindowFramePositionX=Rect.left;
	SGLFE.dwWindowFramePositionY=Rect.top;

	SGLFE.dwWindowFrameWidth=(Rect.right-Rect.left)+1;
	SGLFE.dwWindowFrameHeight=(Rect.bottom-Rect.top)+1;
	
	/* Compute window space between client and window */
	SGLFE.dwWindowSpaceX=SGLFE.dwWindowFrameWidth-SGLFE.dwWindowWidth;
	SGLFE.dwWindowSpaceY=SGLFE.dwWindowFrameHeight-SGLFE.dwWindowHeight;

	/* Create the window */
    SGLFE.hwnd = CreateWindowEx(0,
								"SGLShellClass",
								SGLFE.pszFrontEndTitle,
								SGLFE.dwWindowStyle,
								SGLFE.dwWindowFramePositionX,
								SGLFE.dwWindowFramePositionY,
								SGLFE.dwWindowFrameWidth,
								SGLFE.dwWindowFrameHeight,
								NULL,
								SGLFE.hMenu,
								hInstance,
								NULL );

	/* If window could not be created */
    if (SGLFE.hwnd==NULL)
    {
        DEBUG("Window could not be created\n");
		MessageBox(NULL, "Unable to create window", SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
		QuitApplication();	/* To release any memory allocated by application */
		return 0;
    }

	/* Debug output */
	sprintf(pszTmp, "Window position = %d %d %d %d\nWindow frame position = %d %d %d %d\nWindow space = %d %d\n",
			SGLFE.dwWindowPositionX, SGLFE.dwWindowPositionY, SGLFE.dwWindowWidth, SGLFE.dwWindowHeight,
			SGLFE.dwWindowFramePositionX, SGLFE.dwWindowFramePositionY, SGLFE.dwWindowFrameWidth, SGLFE.dwWindowFrameHeight,
			SGLFE.dwWindowSpaceX, SGLFE.dwWindowSpaceY);
	DEBUG(pszTmp);

	/* Create font */
	SGLFE.hTextFont=CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
							   ANSI_CHARSET,
							   OUT_DEFAULT_PRECIS,
							   CLIP_DEFAULT_PRECIS,
							   DEFAULT_QUALITY,
							   VARIABLE_PITCH,
							   "Arial" );
	
	/* Set up cursor */
	SetCursor(SGLFE.wndclass.hCursor);
	SGLFEMouseVisible(TRUE);

	/* Create accelerator table */
	SGLFECreateAccelerators();
	
	/* Show and update window */
    ShowWindow(SGLFE.hwnd, nCmdShow);
    UpdateWindow(SGLFE.hwnd);
		
	/* Detect if current card support strictlocks */
    sgl_get_ini_int(&nStrictLocks, 0, "Default", "StrictLocks");
    
	/* Debug stuff */
	sprintf(pszTmp, "Strictlocks %s\n", nStrictLocks ? "enabled : safe (and slow) mode." : "disabled : normal mode");
	DEBUG(pszTmp);
	if (nStrictLocks)
	{
		if (MessageBox(NULL, "2D/3D Acceleration is set to Standard in the PowerVR control panel.\nStrictlocks support is now enabled : safe (and slow) mode.\n\nPress OK to continue or Cancel to exit", 
						  SGLFE.pszFrontEndTitle, MB_OKCANCEL | MB_ICONWARNING)==IDCANCEL)
		{
			/* Exiting SGL Shell */
			DestroyAcceleratorTable(SGLFE.hAccel);
			return FALSE;
		}
	}
		
	/* Use SGL address mode */
	sgl_use_address_mode(&SGLFERenderCallback, (DWORD **)&pStatus);

	/* Use End Of Render callback */
	sgl_use_eor_callback(&SGLFEEndOfRenderCallback);
	
	/* Initialise DirectDraw for use with SGL */
	if (!SGLFEInitDirectDrawForSGL())
	{
		DEBUG("SGLFEInitDirectDrawForSGL() failed in WinMain()\n");
		MessageBox (NULL, "SGLFEInitDirectDrawForSGL() failed in WinMain()", 
								SGLFE.pszFrontEndTitle, MB_OK | MB_ICONHAND);
		QuitApplication();	/* To release any memory allocated by application */
		return 0;
	}

	/* Perform FullScreen or windowed initialisation */
	if (SGLFE.bFullScreen)
	{
		/* FullScreen mode */
		if (!SGLFEInitFullScreen())
		{
			DEBUG("SGLFEInitFullScreen() failed in WinMain()\n");
			SGLFEReleaseAll();
			QuitApplication();
			return 0;
		}
	}
	else
	{
		/* Window mode */
		if (!SGLFEInitWindow())
		{
			DEBUG("SGLFEInitWindow() failed in WinMain()\n");
			SGLFEReleaseAll();
			QuitApplication();
			return 0;
		}
	}

	/* Update menus */
	SGLFEUpdateMenus();

	/* Get render dimensions for InitView(...) */
	if (SGLFE.bFullScreen)
	{
		dwRenderWidth=DDDisplayMode[nCurrentResolution].dwWidth;
		dwRenderHeight=DDDisplayMode[nCurrentResolution].dwHeight;
	}
	else
	{
		dwRenderWidth=SGLFE.dwWindowWidth;
		dwRenderHeight=SGLFE.dwWindowHeight;
	}
	
	/* Set up the SGL scene */
	InitView(dwRenderWidth, dwRenderHeight);

	/* Create a timer used to calculate frame rate. Use 99 for the timer ID
	   because we don't want the user to use the same timer ID ! */
	SetTimer(SGLFE.hwnd, 99, TIMER_PERIOD, (TIMERPROC)SGLFETimerProc);

	/* Message loop */
	if (!nStrictLocks)
	{
		while (!done)
		{   
			idle = TRUE;
			while (PeekMessage(&SGLFE.msg, NULL, 0, 0, PM_REMOVE))
			{
				idle=FALSE;
				if (SGLFE.msg.message==WM_QUIT)
				{	
					done=TRUE;
					break;
				}
				if (!TranslateAccelerator(SGLFE.hwnd, SGLFE.hAccel, &SGLFE.msg))
				{
					TranslateMessage(&SGLFE.msg);
					DispatchMessage(&SGLFE.msg);
				}
			}
		
			/* If we are not minimised nor paused and the rendering is ready */
			if (!SGLFE.bMinimized && !SGLFE.bPaused && SGLFE.bRenderingReady)
			{
				/* Call the rendering routine */
				if (!SGLFERender())
				{
					DEBUG("SGLFERender() failed\n");
					if (++nRenderFailed>10)
					{
						SGLFE.bRenderingReady=FALSE;
						SGLFE.bPaused=TRUE;
						SGLFEMouseVisible(TRUE);
						DEBUG("Rendering has failed more than 10 times ! Aborting program\n");
						MessageBox(SGLFE.hwnd, "Rendering has failed too many times\nAborting program", 
												SGLFE.pszFrontEndTitle, MB_OK | MB_ICONERROR);
						SGLFEFinish();
					}
				}
			}
		}
	}
	else
	{
		/* StrictLocks stuff */
		while (SGLFERender() && !bStrictLocksQuit);
		DEBUG("StrictLocks : quit\n");
		
		SGLFE.bRenderingReady=FALSE;
		SGLFE.bPaused=TRUE;
		SGLFEMouseVisible(TRUE);
	}

	/* Releasing memory */
	DEBUG("Releasing memory\n");
	
	/* Release all variables */
	SGLFEReleaseAll();
	
	/* Release application memory */
	QuitApplication();
		
	/* If Instance exists, then release it */
	if (SGLFE.hInstDD)
	{
		FreeLibrary(SGLFE.hInstDD);
	}

	/* Clean everything */
	DestroyAcceleratorTable(SGLFE.hAccel);
	Sleep(200);

	DEBUG("End of program\n");

	/* Return error code */
	return SGLFE.msg.wParam;
}


/*******************************************************************************
 * Function Name  : SGLShellSetPreferences
 * Global Used    : SGLFE
 * Description    : Function called by the user to submit a menu and set
 *					preferences.
 *******************************************************************************/
void SGLShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel, 
							HICON hUserIcon, enum SGLShellPrefs dwFlags)
{
	/* If the user has submitted a name for his/her application */
	if (pszApplicationName)
	{
		strcpy(SGLFE.pszFrontEndTitle, pszApplicationName);
	}
	
	/* If the user has submitted a menu */
	if (hUserMenuID)
	{
		SGLFE.hUserMenu=hUserMenuID;
	}

	/* If the user has submitted an accelator table */
	if (hUserAccel)
	{
		SGLFE.hAccel=hUserAccel;
	}

	/* If the user has submitted an icon */
	if (hUserIcon)
	{
		SGLFE.hIcon=hUserIcon;
	}
	
	/* Retrieve user's preferences */
	SGLFE.dwUserPreferences=dwFlags;

	/* Set buffering mode if forced On */
	if (SGLFE.dwUserPreferences & FORCE_SINGLEBUFFER)
	{
		SGLFE.nBufferingMode=1;
	}
	if (SGLFE.dwUserPreferences & FORCE_DOUBLEBUFFER)
	{
		SGLFE.nBufferingMode=2;
	}
	if (SGLFE.dwUserPreferences & FORCE_TRIPLEBUFFER)
	{
		SGLFE.nBufferingMode=3;
	}
	
	/* Set the fullscreen flag if required */
	if (SGLFE.dwUserPreferences & FORCE_FULLSCREEN)
	{
		SGLFE.bFullScreen=TRUE;
	}

	/* If FullScreen as been chosen as a default, enable it */
	if (SGLFE.dwUserPreferences & DEFAULT_FULLSCREEN)
	{
		SGLFE.bFullScreen=TRUE;
	}
}


/*******************************************************************************
 * Function Name  : SGLShellSetDisplayText
 * Inputs		  : pszText, nX, nY
 * Global Used    : SGLFE
 * Description    : Function called by the user to display a text onto the screen.
 *					Works in both FullScreen mode and Window mode.
 *******************************************************************************/
void SGLShellSetDisplayText(char *pszText, int nX, int nY)
{
	/* Record user text and text position */
	strcpy(SGLFE.pszUserText[SGLFE.nNumberOfUserString], pszText);
	SGLFE.nUserTextPositionX[SGLFE.nNumberOfUserString]=nX;
	SGLFE.nUserTextPositionY[SGLFE.nNumberOfUserString]=nY;

	/* Increment number of user text string */
	SGLFE.nNumberOfUserString++;
}


/*******************************************************************************
 * Function Name  : SGLShellLoadBMP
 * Returns		  : Texture number
 * Inputs		  : lpName, bTranslucent, bMipmap
 * Global Used    : SGLFE
 * Description    : Simple texture loading function which loads 24-bit BMP 
 *					textures from a resource or file.
 *					If bTranslucent is TRUE, then the texture t+lpName is loaded
 *					and the red channel is used for the opacity (255=fully
 *					transparent and 0=fully opaque).
 *					If bMipmap is TRUE, then Mipmap levels are created for that
 *					texture.
 *					RGB and OS/2 formats are supported. RLE encoded format 
 *					is NOT supported by this function.
 *					A future version of SGLShell might have better texture
 *					loading facilities.
 *******************************************************************************/
int SGLShellLoadBMP(char *lpName, BOOL bTranslucent, BOOL bMipmap)
{
	sgl_intermediate_map	IMap;
	sgl_map_pixel			*pPixel;
	sgl_map_types			TextureType;
	sgl_map_sizes			TextureSize;
	int						nTextureNumber;
	HBITMAP					Bitmap, BitmapTrans;
	BITMAP					bm, bmTrans;
	DWORD					x, y;
	DWORD					dwTextureMemory;
	DWORD					dwMemoryUsedByTexture;
	DWORD					i, j;
	unsigned				Cont = 0;
	char					*pLineBuffer, *pLineBufferTrans;
	BOOL					bGenerateMipmap;
	char					pszString[300];
			
	/* Load texture : first try to load from resource */
	Bitmap=(HBITMAP)LoadImage(GetModuleHandle(NULL), lpName, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
    if (Bitmap==NULL)
	{
		/* Load from file */
		Bitmap=(HBITMAP)LoadImage(NULL, lpName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
		if (Bitmap==NULL)
		{
			DEBUG("File not found : ");
			DEBUG(lpName);
			DEBUG("\n");
			return sgl_err_bad_parameter;
		}
		DEBUG("\nLoading from file\n");
	}
	else
	{
		DEBUG("\nLoading from resource\n");
	}

	/* If translucent, then also read the file t+lpName */
	if (bTranslucent)
	{
		/* Translucent file name = t+lpName */
		sprintf (pszString, "t%s", lpName);
	
		/* Load translucent texture : first try to load from resource */
		BitmapTrans=(HBITMAP)LoadImage(GetModuleHandle(NULL), pszString, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
		if (BitmapTrans==NULL)
		{
			/* Load from file */
			BitmapTrans=(HBITMAP)LoadImage(NULL, pszString, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
			if (BitmapTrans==NULL)
			{
				DEBUG("File not found : ");
				DEBUG(pszString);
				DEBUG("\n");
				DeleteObject(Bitmap);
				return sgl_err_bad_parameter;
			}
		}
	}
	
	/* At this point we have a bitmap loaded */
	
	/* Get bitmap description */
    GetObject(Bitmap, sizeof(bm), &bm);

	/* Get bitmap description for alpha channel if required */
	if (bTranslucent)
	{
		GetObject(BitmapTrans, sizeof(bmTrans), &bmTrans);
	}
	
	/* If translucent texture has also been loaded, check that both 
	   widths and heights are equal */
	if (bTranslucent)
	{
		if (bm.bmWidth!=bmTrans.bmWidth || bm.bmHeight!=bmTrans.bmHeight)
		{
			/* Dimensions are not the same : abort */
			DEBUG("Dimensions of texture and translucent texture do not match.\n");
			DeleteObject(Bitmap);
			DeleteObject(BitmapTrans);
			return sgl_err_bad_parameter;
		}
	}

	/* Get width and height of bitmap */
	x=bm.bmWidth;
	y=bm.bmWidth;

	/* Debug output */
	sprintf(pszString, "Loading texture : %s%s (%u*%u)\n", bTranslucent ? "(t)" : "", lpName, x, y);
	DEBUG(pszString);

	/* Check texture dimensions */
	if ( ((x+y)!=64) && ((x+y)!=128) && ((x+y)!=256) && ((x+y)!=512) )
	{
		/* Debug Output and exit */
		DEBUG("Texture dimensions not supported.\nRequired size = 32x32, 64x64, 128x128 or 256x256\n");
		DeleteObject(Bitmap);
		if (bTranslucent)
		{
			DeleteObject(BitmapTrans);
		}
		return sgl_err_bad_parameter;
	}

	/* Fill fields in intermediate map structure */
	strcpy(IMap.id, "IMAP");
	IMap.x_dim=x;
	IMap.y_dim=y;

	/* Compute texture type and size */
	if (bMipmap)
	{
		DEBUG("Mipmap levels automatically generated\n");
		bGenerateMipmap=TRUE;
		if (bTranslucent)
		{
			TextureType=sgl_map_trans16_mm;
		}
		else
		{
			TextureType=sgl_map_16bit_mm;
		}
	}
	else
	{
		bGenerateMipmap=FALSE;
		if (bTranslucent)
		{
			TextureType=sgl_map_trans16;
		}
		else
		{
			TextureType=sgl_map_16bit;
		}
	}
	switch(x)
	{
	case 32 :	TextureSize=sgl_map_32x32; break;
	case 64 :	TextureSize=sgl_map_64x64; break;
	case 128 :	TextureSize=sgl_map_128x128; break;
	case 256 :	TextureSize=sgl_map_256x256; break;
	}

	/* Allocate memory for pixel data */
	IMap.pixels=(sgl_map_pixel *)malloc(IMap.x_dim*IMap.y_dim*sizeof(sgl_map_pixel));
	if (!IMap.pixels)
	{
		/* Debug Output and exit */
		DEBUG("Not enough memory to create intermediate map\n");
		DeleteObject(Bitmap);
		if (bTranslucent)
		{
			DeleteObject(BitmapTrans);
		}
		return sgl_err_no_mem;
	}

	/* Calculate memory used by texture */
	dwMemoryUsedByTexture=x*y*2;	/* Only 16 bit textures in PCX */
	
	/* Get free texture memory */
	dwTextureMemory=sgl_get_free_texture_mem();
	
	/* See if there is enough video texture memory to load this texture */
	if (dwMemoryUsedByTexture>dwTextureMemory)
	{
		/* Debug Output and exit */
		DEBUG("Not enough memory to load texture.\n");
		free(IMap.pixels);
		DeleteObject(Bitmap);
		if (bTranslucent)
		{
			DeleteObject(BitmapTrans);
		}
		return sgl_err_texture_memory_full;
	}
	
	/* Allocate memory so that we can read data */
	pLineBuffer=(char *)malloc(bm.bmWidthBytes*sizeof(char));
	pLineBufferTrans=(char *)malloc(bm.bmWidthBytes*sizeof(char));
	if (!pLineBuffer || !pLineBufferTrans)
	{
		/* Not enough memory */
		DEBUG("Not enough memory to allocate pLineBuffer or pLineBufferTrans\n");
		free(IMap.pixels);
		DeleteObject(Bitmap);
		if (bTranslucent)
		{
			DeleteObject(BitmapTrans);
		}
		return sgl_err_no_mem;
	}


	/* Display texture format used */
	switch(TextureType)
	{
	case sgl_map_16bit :
	case sgl_map_16bit_mm : DEBUG("Format used for this texture (16 bits) = 555\n"); break;
	case sgl_map_trans16 :
	case sgl_map_trans16_mm :	DEBUG("Format used for this texture (16 bits) = 4444\n"); break;
	}

	/* Fill pixel data */
	for (i=0; i<y; i++)
	{
		/* Assign pixel counter */
		pPixel=(sgl_map_pixel *)(IMap.pixels + x*i);

		/* Copy the current line from the bitmap to pLineBuffer */
		memcpy(pLineBuffer, ((char *)bm.bmBits+i*bm.bmWidthBytes), bm.bmWidthBytes);
		if (bTranslucent)
		{
			/* Copy the current line from the transparent bitmap to pLineBuffer */
			memcpy(pLineBufferTrans, ((char *)bmTrans.bmBits+i*bmTrans.bmWidthBytes), bmTrans.bmWidthBytes);
		}

        /* Width count is 0 */
		Cont=0;
		
		/* Filling loop */
		for (j=0; (DWORD)j<x; j++)
		{ 
			pPixel->blue=	*(pLineBuffer+Cont++) & 255;
			pPixel->green=	*(pLineBuffer+Cont++) & 255;
			pPixel->red=	*(pLineBuffer+Cont++) & 255;
																	
			/* If translucent, then assert Alpha value */
			if (bTranslucent)
			{
				pPixel->alpha=*(pLineBufferTrans+Cont-1) & 255;
			}

			/* Increment pixel counter */
			pPixel++;
		}
	}

	/* Call sgl_create_texture with Intermediate Map data */
	nTextureNumber=sgl_create_texture(TextureType, TextureSize, bGenerateMipmap, FALSE, &IMap, NULL);
	if (nTextureNumber<0)
	{
		DEBUG("Error when calling sgl_create_texture\n");
	}

	/* Debug output */
	sprintf(pszString, "Memory used by texture = %u\n", dwTextureMemory-sgl_get_free_texture_mem());
	DEBUG(pszString);
		
	/* Free memory */
	free(pLineBufferTrans);
	free(pLineBuffer);
	free(IMap.pixels);
	
	DeleteObject(Bitmap);
	if (bTranslucent) 
	{
		DeleteObject(BitmapTrans);
	}

	/* Debug output */
	sprintf(pszString, "Free Texture memory = %u\n", sgl_get_free_texture_mem());
	DEBUG(pszString);

	/* Returns texture number */
	return(nTextureNumber);
}


/*******************************************************************************
 * Function Name  : SGLFEScreenCapture
 * Inputs		  : 
 * Global Used    : SGLFE
 * Description    : Copy the current contents of the back buffer to a BMP file.
 *******************************************************************************/
BOOL SGLFEScreenCapture()
{
	HRESULT				hres;
	DDSURFACEDESC		ddsd;
	LPDIRECTDRAWSURFACE	lpDDS;
	WORD				*pWord;
	unsigned char		*pByte;
	DWORD				Pitch;
	char				pszString[100];
	BITMAPFILEHEADER	BitmapFileHeader;
	BITMAPINFO			BitmapInfo;
	DWORD				dwWidth, dwHeight, dwBPP;
	DWORD				BMPHeaderSize=54;
	FILE				*f;
	unsigned char		*pByteLineBuffer;
	WORD				*pWordLineBuffer;
	unsigned char		Red, Green, Blue;
	static int			nScreenshotCount=0;
	char				pszScreenshotName[20];
	int					i;
	DWORD				j;
	DWORD				m;
	DWORD				dwRedBits=0, dwGreenBits=0, dwBlueBits=0;

	/* In single buffer mode (Fullscreen mode), use front buffer
	   to perform screenshot */
	if (SGLFE.nBufferingMode==1 && SGLFE.bFullScreen)
	{
		/* Surface to capture is front buffer */
		lpDDS=SGLFE.lpDDSPrimary;
	}
	else
	{
		/* Surface to capture is back buffer */
		lpDDS=SGLFE.lpDDSBack;
	}

	/* Initialise ddsd */
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	
	/* Get description of surface */
	hres=lpDDS->lpVtbl->GetSurfaceDesc(lpDDS, &ddsd);
	if (hres!=DD_OK)
	{
		DEBUG("GetSurfaceDesc() failed in SGLFEScreenCapture()\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Assigning values */
	dwWidth=ddsd.dwWidth;
	dwHeight=ddsd.dwHeight;
	dwBPP=ddsd.ddpfPixelFormat.dwRGBBitCount;
	
	/* Debug output */
	sprintf(pszString, "Width=%u  Height=%u  bpp=%u\n", dwWidth, dwHeight, dwBPP);
	DEBUG(pszString);
	
	/* Test if capture is valid */
	if (dwBPP!=16 && dwBPP!=24)
	{
		DEBUG("Don't support screen capture for 8 or 32-bit surfaces\n");
		return FALSE;
	}
	
	/* Lock surface */
	hres=lpDDS->lpVtbl->Lock(lpDDS, NULL, &ddsd, DDLOCK_WAIT, NULL);				
	if (hres!=DD_OK)
	{
		DEBUG("Lock() failed in SGLFEScreenCapture()\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* For StrictLocks */
	bBufferLocked=TRUE;
	
	/* Get pointers */
	if (dwBPP==16)
	{
		/* 16-bit surface */
		pWord=(WORD *)ddsd.lpSurface;
		Pitch=(WORD)ddsd.lPitch;
	}
	else
	{
		/* 24-bit surface */
		pByte=(unsigned char *)ddsd.lpSurface;
		Pitch=(WORD)ddsd.lPitch;
	}

	/* Unlock render surface */
	hres=lpDDS->lpVtbl->Unlock(lpDDS, NULL);		
	if (hres!=DD_OK)
	{
		OutputDebugString("Unlock() failed in SGLFEScreenCapture\n");
		DisplayHRESULTInDebug(hres);
		return FALSE;
	}

	/* Debug output */
	sprintf(pszString, "Surface pointer=%X\nPitch=%u\n", dwBPP==16 ? (unsigned char *)pWord : pByte, Pitch);
	DEBUG(pszString);

	/* Allocate memory for Read buffer */
	if (dwBPP==16)
	{
		pWordLineBuffer=(WORD *)malloc(Pitch*sizeof(WORD)/2);
	}
	else
	{
		pByteLineBuffer=(unsigned char *)malloc(Pitch*sizeof(unsigned char));
	}

	/* Fill BITMAPFILEHEADER structure */
	BitmapFileHeader.bfType='MB';
	BitmapFileHeader.bfSize=BMPHeaderSize+(dwWidth*dwHeight*3);
	BitmapFileHeader.bfReserved1=0;
	BitmapFileHeader.bfReserved2=0;
	BitmapFileHeader.bfOffBits=BMPHeaderSize;

	/* Fill BITMAPINFO structure */
	/* Fill BITMAPINFOHEADER structure inside BITMAPINFO structure */
	BitmapInfo.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
	BitmapInfo.bmiHeader.biWidth=dwWidth;
	BitmapInfo.bmiHeader.biHeight=dwHeight;
	BitmapInfo.bmiHeader.biPlanes=1;
	BitmapInfo.bmiHeader.biBitCount=24;		/* Image will always be saved as 24-bit BMP */
	BitmapInfo.bmiHeader.biCompression=BI_RGB;
	BitmapInfo.bmiHeader.biSizeImage=dwWidth*dwHeight*3;
	BitmapInfo.bmiHeader.biXPelsPerMeter=0;
	BitmapInfo.bmiHeader.biYPelsPerMeter=0;
	BitmapInfo.bmiHeader.biClrUsed=0;
	BitmapInfo.bmiHeader.biClrImportant=0;

	/* Compute file name */
	sprintf(pszScreenshotName, "Screen%02d.bmp", nScreenshotCount);
	if ( !(f=fopen(pszScreenshotName, "wb")) )
	{
		sprintf(pszString, "Unable to write %s\n", pszScreenshotName);
		DEBUG(pszString);
	}

	/* Write BitmapFileheader */
	if (fwrite(&BitmapFileHeader, sizeof(BITMAPFILEHEADER), 1, f)<1)
	{
		sprintf(pszString, "Error in writing BITMAPFILEHEADER in %s\n", pszScreenshotName);
		DEBUG(pszString);
		fclose(f);
		DeleteFile(pszScreenshotName);
		return FALSE;
	}

	/* Write BitmapInfoHeader */
	if (fwrite(&BitmapInfo.bmiHeader, sizeof(BITMAPINFOHEADER), 1, f)<1)
	{
		sprintf(pszString, "Error in writing BITMAPINFOHEADER in %s\n", pszScreenshotName);
		DEBUG(pszString);
		fclose(f);
		DeleteFile(pszScreenshotName);
		return FALSE;
	}

	// Find number of bits for each channel
	m=ddsd.ddpfPixelFormat.dwRBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) dwRedBits++;
	}
	m=ddsd.ddpfPixelFormat.dwGBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) dwGreenBits++;
	}
	m=ddsd.ddpfPixelFormat.dwBBitMask; 
	for (i=0; i<32; i++) 
	{
		if ((1<<i) & m ) dwBlueBits++;
	}

	sprintf(pszString, "Surface format : %d %d %d\nBit mask : %02X %02X %02X\n", 
						dwRedBits, dwGreenBits, dwBlueBits,
						ddsd.ddpfPixelFormat.dwRBitMask, ddsd.ddpfPixelFormat.dwGBitMask, ddsd.ddpfPixelFormat.dwBBitMask);
	DEBUG(pszString);
	
	/* Write bitmap data */
	
	/* 16-bit surface */
	if (dwBPP==16)
	{
		WORD	ReadWord;
		WORD	*pWordCounter;

		/* Read all lines from bottom to top */
		for (i=dwHeight-1; i>=0; i--)
		{
			memcpy(pWordLineBuffer, pWord+((i*Pitch)/2), Pitch);
			pWordCounter=pWordLineBuffer;

			for (j=0; j<dwWidth; j++)
			{
				/* Read next word in surface */
				ReadWord=*pWordCounter++;
				
				/* Get red, green, blue channels */
				Blue=(unsigned char)(ReadWord & ddsd.ddpfPixelFormat.dwBBitMask);
				Green=(unsigned char)((ReadWord & ddsd.ddpfPixelFormat.dwGBitMask)>>dwBlueBits);
				Red=(unsigned char)((ReadWord & ddsd.ddpfPixelFormat.dwRBitMask)>>(dwBlueBits+dwGreenBits));
								
				/* Set the colour channels to 8 bits each because picture is saved as 24 bpp */
				Blue<<=(8-dwBlueBits);
				Green<<=(8-dwGreenBits);
				Red<<=(8-dwRedBits);
				
				/* Write colour channels */
				if (fwrite(&Blue, sizeof(unsigned char), 1, f)<1)
				{
					sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
					DEBUG(pszString);
					fclose(f);
					DeleteFile(pszScreenshotName);
					return FALSE;
				}
				if (fwrite(&Green, sizeof(unsigned char), 1, f)<1)
				{
					sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
					DEBUG(pszString);
					fclose(f);
					DeleteFile(pszScreenshotName);
					return FALSE;
				}
				if (fwrite(&Red, sizeof(unsigned char), 1, f)<1)
				{
					sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
					DEBUG(pszString);
					fclose(f);
					DeleteFile(pszScreenshotName);
					return FALSE;
				}
			}
		}
	}
	else
	{
		/* 24-bit surface */
		/* Read and write all lines from bottom to top */
		for (i=dwHeight-1; i>=0; i--)
		{
			if (fwrite(pByte+(i*Pitch), Pitch*sizeof(unsigned char), 1, f)<1)
			{
				sprintf(pszString, "Error in writing %s\n", pszScreenshotName);
				DEBUG(pszString);
				fclose(f);
				DeleteFile(pszScreenshotName);
				return FALSE;
			}
		}
	}

	/* Close file */
	if (fclose(f)!=0)
	{
		sprintf(pszString, "Error in closing %s\n", pszScreenshotName);
		DEBUG(pszString);
	}

	/* Free memory */
	if (dwBPP==16)
	{
		free(pWordLineBuffer);
	}
	else
	{
		free(pByteLineBuffer);
	}

	/* Increase number of screen shot (maximum 100) */
	if (++nScreenshotCount>99)
	{
		nScreenshotCount=0;
	}

	/* Beep = screen capture OK */
	MessageBeep(MB_OK);
	DEBUG("Screen capture successful\n");

	/* No problem occured */
	return TRUE;
}


/*******************************************************************************
 * Function Name  : SGLFETimerProc
 * Inputs		  : hwnd, uMsg, idEvent, dwTime
 * Global Used    : SGLFE
 * Description    : Timer callback procedure
 *******************************************************************************/
void CALLBACK SGLFETimerProc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	/* Compute frame rate if ready */
	if (SGLFE.bRenderingReady && !SGLFE.bPaused && !SGLFE.bMinimized)
	{
		SGLFE.dwFrameRate=(SGLFE.dwFramesElapsed * 1000) / TIMER_PERIOD;
		SGLFE.dwFramesElapsed=0;
	}
	else
	{
		SGLFE.dwFrameRate=0;
		SGLFE.dwFramesElapsed=0;
	}
}


