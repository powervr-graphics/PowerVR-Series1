/*-----------------------------------------------------------------------------
   Name   : FIRE  ( PowerVR SGL-Direct )   
   Author : Carlos Sarria      - send comments to csarria@videologic.com        
   Date   : July 1997
   Project: fire.c + frontend.c + sgl.lib

   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#include <math.h>
#include <malloc.h>
#include <ddraw.h>

#include "sgl.h"
#include "frontend.h"
#include "fire.h"  /* This is the file with 3D data */
                 
#pragma warning (disable : 4244)  /* Disables float to double conversion warning */

#define PI	3.1416f

static int   Device, Init = TRUE, frame = 0, Texture[100];
static float GlassRefect[4], Ligth1[3], Shad[255], CamFocus = 500.0;
static float XAng = 0.0 , YAng = 0.0;
extern float XAng1 = 0.0 , YAng1 = 0.0, LH=20.0;

SGLCONTEXT SGLContext;
SGLVERTEX  *TempVert[NUM_MESHES];
SGLVERTEX  Fire[4][4];

#define RGBColour(r, g, b) ((sgl_uint32) (((sgl_uint32)(r&0x000000FF)<<16) | ((sgl_uint32)(g&0x000000FF) << 8) | (sgl_uint32)(b&0x000000FF)))

void SetupTextures (void);
void SetupContext  (void);
void InitMeshes    (void);
void DrawAll       (void);
void UpdateVertex  (int Num);
void Shading       (int Num);
void CreateFire    (void);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device                                                         */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
    Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE); 
  	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

    SetupTextures (); 
	SetupContext  ();

    InitMeshes ();

    SetCursor (NULL);   /* This hides the pointer */

	return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContext                                                     */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame()
{
   sgltri_startofframe (&SGLContext);
	 DrawAll ();
   sgltri_render   (&SGLContext);

   frame++; 
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/							   
void Finish()
{
		FreeAllBMPTextures ();
		sgl_delete_device(Device);	
		Init = FALSE;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :  DrawAll                                                         */ 
/*  Inputs          :  None                                                            */  
/*  Outputs         :  None                                                            */
/*  Returns         :  None                                                            */
/*  Globals Used    :  XAng, YAng, XAng1, YAng1, SGLContext                            */
/*  Description     :  Updates and draws all the meshes in the model.                  */
/*  Note            :  The definition of Mesh[i] struct is in logo.h                   */
/*-------------------------------------------------------------------------------------*/
void DrawAll()
{
register i;

    XAng += XAng1;     /* Scene angles are changed every frame */
    YAng += YAng1;     /* XAng1 and YAng1 are the speed */

    for (i=0; i<NUM_MESHES; i++){

        UpdateVertex (i);   /* Recalculate SGL vertices for the new position */
        Shading      (i);   /* Smooth shading */

		/* Updating texture parameters for each mesh of the model */
        SGLContext.nTextureName = Texture[Mesh[i].Material];
        SGLContext.u32Flags = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
              
		/* Draws everything */
        if (i==FIRE) CreateFire();
	    else sgltri_triangles (&SGLContext, Mesh[i].NumFaces, (int(*)[3])Mesh[i].Faces, TempVert[i]);
    } 
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupTextures                                                    */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : NumMaterials, Texture, MatInfo                                   */
/*  Description     : Loads BMP files getting the information from MatInfo struct      */
/*-------------------------------------------------------------------------------------*/	
void SetupTextures (void)
{
register i;

  for (i=0;i<NumMaterials; i++)
  {
      if (i==MFIRE) Texture[i]  = LoadBMPTexture (MatInfo[i].MatFile, TRUE , FALSE, FALSE);
	  else          Texture[i]  = LoadBMPTexture (MatInfo[i].MatFile, FALSE, FALSE, FALSE);
  }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : SetupContext                                                     */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : SGLContext                                                       */
/*  Description     : Sets default values for the render context.                      */
/*-------------------------------------------------------------------------------------*/
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 5;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = NO_SHADOWS_OR_LIGHTVOLS;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.RenderRegions        = 0;
    SGLContext.n32MipmapOffset      = 0;
    SGLContext.u32GlobalTrans       = 255;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : InitMeshes                                                       */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Shad, Mesh, TempVert, GlassReflect                               */
/*  Description     : Sets initials values for meshes managing                         */
/*-------------------------------------------------------------------------------------*/
void InitMeshes (void)
{
float Col;
register i,j, k=0;

    /* This function is in logo.h and creates an array of structures with 3D data */
    CreateMeshesArray ();
   
    /* Shad is a 255 values array with information for smooth shading */
    for (i=0; i<120; i++) { Col = (float)(120-i)/4; Shad[k++] = 0;}
    for (i=0; i<100; i++) { Col=(float)(i*255)/100; Shad[k++] = (float) i/100.0;}
    for (i=0; i<35;  i++)                    Shad[k++] = 1.0f;

    /* Memory allocation for TempVert and TempNormals */
    for (i=0; i<NUM_MESHES; i++) TempVert[i] = (SGLVERTEX *) malloc (Mesh[i].NumVertex*sizeof(SGLVERTEX));

	/* Setting UV values for all the meshes*/
    for (j=0; j<NUM_MESHES;j++)
	{
            for (i=0; i<Mesh[j].NumVertex; i++)
			{
               (TempVert[j]+i)->fUOverW    =  (Mesh[j].TexMap) ? *(Mesh[j].UV+i*2+0) : 0;
               (TempVert[j]+i)->fVOverW    =  (Mesh[j].TexMap) ? *(Mesh[j].UV+i*2+1) : 0; 
            }
       
    }
 
   /* Reference position for glasses reflection */
   for (i=0;i<4;i++) GlassRefect[i] = *(Mesh[REFLECTION].Vertex+i*3+2);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : UpdateVertex                                                     */ 
/*  Inputs          : Num (the mesh in the model)                                      */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : XAng, YAng                                                       */
/*  Description     : Turns vertices around two axes.                                  */
/*-------------------------------------------------------------------------------------*/
void UpdateVertex (int Num)
{
sgl_vector Temp;
int i, j=0, k=0, l=0;
float x, y, z, CosX, SinX, CosY, SinY, CamZ;

CosX = cos(XAng); SinX = sin(XAng);
CosY = cos(YAng); SinY = sin(YAng);
  
    for (i=0; i<Mesh[Num].NumVertex; i++){
   
		 x = *(Mesh[Num].Vertex+k++)-GroupCenter[0];
         y = *(Mesh[Num].Vertex+k++)-GroupCenter[1];
         z = *(Mesh[Num].Vertex+k++)-GroupCenter[2];

		 /* Temp is the outcome vertex after the rotation */
         Temp[0]  = x * CosY - z * SinY;
         Temp[2]  = z * CosY + x * SinY;

         z        = Temp[2];
         Temp[1]  = y * CosX - z * SinX;
         Temp[2]  = z * CosX + y * SinX + 800;

         if (Temp[2] <=0.0) Temp[2] = 0.001f;

		  /* We store the SGL vertex in TempVert */
         CamZ = 1.0/(Temp[2]);
         (TempVert[Num]+i)->fX    =  CamFocus * CamZ * Temp[0] + 320;
         (TempVert[Num]+i)->fY    = -CamFocus * CamZ * Temp[1] + 240;
	     (TempVert[Num]+i)->fInvW =  CamZ;
   }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : Shading                                                          */ 
/*  Inputs          : Num                                                              */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : Light1, Mesh, TempVert                                           */
/*  Description     : Shades a mesh.                                                   */
/*-------------------------------------------------------------------------------------*/	
void Shading (int Num)
{
float TempCo, TCo, Dir;
float Sh, LTemp[3], sl, x,y,z;
register l=0, i;
unsigned k=0;
sgl_uint32 Col;


    /* We move the position for simulating a dinamic light */
    if (Num != FIRER) { Ligth1[0] = 1; Ligth1[2]=0.2 + 0.1*sin(frame/1.5); Ligth1[1] = 0;}
    else              { Ligth1[0] = 0; Ligth1[1]=1; Ligth1[2] = 0;}

    if (Num == FIRE) return;

    /* We just rotate the light vector in the opposite direction instead of rotating all the normals */
    Dir = sqrt (Ligth1[0]*Ligth1[0]+Ligth1[1]*Ligth1[1]+Ligth1[2]*Ligth1[2]);
    LTemp[0] = Ligth1[0]/Dir; 
	LTemp[1] = Ligth1[1]/Dir; 
	LTemp[2] = Ligth1[2]/Dir;


    k = Mesh[Num].Material;

    sl = LH/60.0;

    TempCo = 255.0 * sl; 

    if (Num == REFLECTION){
       if (LH<20) sl = 20.0f/60.0f;
       TempCo = 255.0*sl; 
    }

    for (i=0; i<Mesh[Num].NumVertex; i++){

        x = *(Mesh[Num].Normals+l++);
        y = *(Mesh[Num].Normals+l++);
        z = *(Mesh[Num].Normals+l++);

		/* Sh is a value from 0.0 to 1.0 depending on the angle between a normal */
		/* and the light direction.                                              */
        Sh = fabs( LTemp[0] * x + LTemp[1] * y + LTemp[2] * z + 1.0);
       
        TCo = Shad[(int)(127.0*Sh)];

        Col = (int)(TempCo*TCo); 

        /* Setting vertex colour */
        (TempVert[Num]+i)->u32Colour  = RGBColour (Col, Col, Col);
    }

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   : CreateFire                                                       */ 
/*  Inputs          : None                                                             */  
/*  Outputs         : None                                                             */
/*  Returns         : None                                                             */
/*  Globals Used    : TempVert, SGLContext, LH                                         */
/*  Description     : Creates fire poligons and shows the front face always.           */
/*-------------------------------------------------------------------------------------*/
void CreateFire (void)
{
register i,j, k;
float Ax, Ay, Bx, By, Bz, Sh, Ch, h, w;
float UVFire[][2] = {{ 1.000000f, 1.000000f },   { 0.000000f, 1.000000f },
                     { 0.000000f, 0.000000f },   { 1.000000f, 0.000000f } };
int   FFire []    = {0, 1, 2, 3};


    for (k=0; k<1; k++)
	{
        for (j=0; j<4; j++)
		{
            Ax = (TempVert[FIRE]+j+4)->fX; 
            Ay = (TempVert[FIRE]+j+4)->fY;

            Bx = (TempVert[FIRE]+j+0)->fX; 
            By = (TempVert[FIRE]+j+0)->fY;
            Bz = (TempVert[FIRE]+j+0)->fInvW;
 
	        /* Growing up and down the flames (LH is the value)*/
            Sh = LH*(By-Ay)/5.0;  
            Ch = 200.0*Bz*LH;
            /* Moving vertices a little bit to simulating dinamic light */
            h =  Sh + (Sh/8.0) * sin((j/2+k*2+frame)/1.0);
            w =  Ch + (Ch/4.0) * cos((k*4+frame)/1.0);

	       /* Building 4 poligons (4 flames) */
           for (i=0; i<4; i++)
		   {
               Fire[j][i].fUOverW    =  UVFire[i][0];
               Fire[j][i].fVOverW    =  UVFire[i][1]; 
               Fire[j][i].u32Colour  =  0xFFFFFF; 
               Fire[j][i].fUOverW    =  UVFire[i][0];
               Fire[j][i].fVOverW    =  UVFire[i][1];
               Fire[j][i].fInvW      =  (TempVert[FIRE]+j)->fInvW;
		   }
   
           Fire[j][0].fX =  Ax - w;
           Fire[j][0].fY =  Ay - h;

           Fire[j][1].fX =  Ax + w;
           Fire[j][1].fY =  Ay - h;

           Fire[j][2].fX =  Bx + w;
           Fire[j][2].fY =  By;

           Fire[j][3].fX =  Bx -w;
           Fire[j][3].fY =  By;

          /* Drawing quads... */
          sgltri_quads (&SGLContext, 1, &FFire, Fire[j]);
		}

	}

	/* Updating the reflection on the glasses */
    for (i=0;i<4;i++)
    {
	  *(Mesh[REFLECTION].Vertex+i*3+2) = GlassRefect[i]-(float)cos((double)YAng)*40.0;
	}

    (TempVert[REFLECTION]+0)->fVOverW = *(Mesh[REFLECTION].UV+0+1)- (LH-30)/550;
    (TempVert[REFLECTION]+1)->fVOverW = *(Mesh[REFLECTION].UV+2+1)- (LH-30)/550;
    (TempVert[REFLECTION]+2)->fVOverW = *(Mesh[REFLECTION].UV+4+1)+ 0.01*sin((j*8.0+frame)/1.5)-(LH-30)/1520;
    (TempVert[REFLECTION]+3)->fVOverW = *(Mesh[REFLECTION].UV+6+1)+ 0.01*sin((j*8.0+frame)/1.5)-(LH-30)/1520;
}
/*--------------------------- End of File --------------------------------*/
