/*****************************************************************************
  Name : SGLTools.h
  Date : March 1998
  Platform : ANSI compatible
 
  Description : Header file of Easy3D.c.
				Contains structure definitions and prototypes 
				of all functions in Easy3D.c
  
  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/

#ifndef _EASY3D_H_
#define _EASY3D_H_


/************
** Defines **
************/
#ifndef PI
#define PI 3.14159f
#endif

/* Colour macros */
#define MAKE_RGB(R,G,B)		((DWORD)( ((R)<<16) | ((G)<<8) | (B) ))
#define MAKE_RGBA(R,G,B,A)	((DWORD)( ((A)<<24) | ((R)<<16) | ((G)<<8) | (B) ))
#define GET_ALPHA(Colour)	((BYTE)( (Colour & 0xFF000000)>>24 ))
#define GET_RED(Colour)		((BYTE)( (Colour & 0x00FF0000)>>16 ))
#define GET_GREEN(Colour)	((BYTE)( (Colour & 0x0000FF00)>>8 ))
#define GET_BLUE(Colour)	((BYTE)(Colour & 0x000000FF))


/*************
** Typedefs **
*************/
/* MATRIX type */
typedef struct _MATRIX {
    float _11, _12, _13, _14;
    float _21, _22, _23, _24;
    float _31, _32, _33, _34;
    float _41, _42, _43, _44;
} MATRIX, *LPMATRIX;


/***************
** Prototypes **
***************/
/* Matrix functions */
void	ResetMatrix(MATRIX *pMatrix);
void	MultiplyMatrix(MATRIX *pResultMatrix, const MATRIX *pMatrixA, const MATRIX *pMatrixB);
void	TranslateMatrix(MATRIX *pMatrix, const float fX, const float fY, const float fZ);
void	ScaleMatrix(MATRIX *pMatrix, const float fFactor);
void	RotateMatrix(MATRIX *pMatrix, const float fXAngle, const float fYAngle, const float fZAngle);
void	InverseMatrix(MATRIX *pMatrix);
void	CopyMatrix(MATRIX *pDstMatrix, const MATRIX *pSrcMatrix);
void	DisplayMatrixInDebug(const MATRIX *pMatrix);

/* Vector functions */
float	DotProduct(const sgl_vector VectorA, const sgl_vector VectorB);
void	CrossProduct(sgl_vector ResultVector, const sgl_vector VectorA, const sgl_vector VectorB);
void	Normalize(sgl_vector Vector);

/* Mapping function */
void	MapUV(int nNumberOfVertices, float *pUV, SGLVERTEX *pTLVertex);

/* Transformation function */
void TransformAndProjectVertices(MATRIX *pWorldMatrix, 
								 int nNumberOfVertices, float *pVertex, SGLVERTEX *pTLVertex,
								 int nViewportWidth, int nViewportHeight);

/* Lighting functions */
void SmoothShade(MATRIX *pMatrix, 
				 int nNumberOfVertices, float *pNormals, SGLVERTEX *pTLVertex, 
				 sgl_vector LightVector, DWORD dwLightColour);






#endif

