/*****************************************************************************
  Name : SGLShell.h v1.1c
  Date : March 1998
  Platform : ANSI compatible

  Header file to be used with SGLShell.c

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/

#ifndef SGLSHELL_H
#define SGLSHELL_H

/* C++ compiling ? */
#ifdef __cplusplus
extern "C" {
#endif

/* Enum */
enum _SGLShellPrefs
{
	FORCE_SINGLEBUFFER		=0x00000001,	/* Single Buffer will be forced On and will not appear in the menu */
	FORCE_DOUBLEBUFFER		=0x00000002,	/* Double Buffer will be forced On and will not appear in the menu */
	FORCE_TRIPLEBUFFER		=0x00000004,	/* Triple Buffer will be forced On and will not appear in the menu */
	FORCE_FULLSCREEN		=0x00000008,	/* FullScreen mode will be used all the time (Unable to got to Window mode) */
	DISABLE_SINGLEBUFFER	=0x00000010,	/* Single Buffer choice will not appear in the menu */
	DISABLE_TRIPLEBUFFER	=0x00000020,	/* Triple Buffer choice will not appear in the menu */
	DISABLE_VERYHIGHRES		=0x00000040,	/* Disable resolution above 1024x768. This flag should be specified if the target hardware is a first generation PowerVR board (PCX1, PCX2) */
	DEFAULT_FULLSCREEN		=0x00000080,	/* Application will start FullScreen by default */
	NO_MEMORY_CHECK			=0x00000100 	/* Video memory will not be checked, thus attempting to create all variables without checking if there is enough memory for them */
} SGLShellPrefs;

/* SGL Shell helper functions declarations */

/* This function is used to pass preferences to the SGL Shell */
void SGLShellSetPreferences(char	*pszApplicationName,		/* Application name */
							HMENU	hUserMenuID,				/* Handle of user menu */
							HACCEL	hUserAccel,					/* Handle of accelerator table */
							HICON	hUserIcon,					/* Handle of user icon */
							enum SGLShellPrefs	dwFlags);		/* Flags */

/* This function enables the user to display text on screen */
void SGLShellSetDisplayText(char *pszText, int nX, int nY);

/* This function loads a texture from a resource or disk */
int	SGLShellLoadBMP(char *lpName, BOOL bTranslucent, BOOL bMipmap);


/*******************************
** User interaction functions **
*******************************/

/* These functions have to exist in the scene file (e.g. scene.c).
   They are used to interract with the SGL Shell */

void	InitApplication();
/*
InitApplication()
  
This function will be called by the SGL Shell before anything happens, at the very
beginning of the SGLShell WinMain() function. That's the only time this function
will be called. This function enables the user to perform any initialisation before 
the program is actually run.
From this function the user can call SGLShellSetPreferences() to set default
values or submit a menu to the SGL Shell. A prototype of the function is :
	
void SGLShellSetPreferences(char *pszApplicationName, HMENU hUserMenuID, HACCEL hUserAccel, 
							HICON hUserIcon, enum SGLShellPrefs dwFlags);

A list of flags and their functions can be found in the SGLShell.h file.
*/


void QuitApplication();
/*
QuitApplication()

This function will be called by the SGL Shell just before finishing the program.
It enables the user to release any memory allocated before.
*/


void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
/*
UserWindowProc(hWnd, message, wParam, lParam)

This function is the user Window Procedure function. It enables the user to retrieve
menu choices, keystrokes or other messages (WM_TIMER for instance).
If you don't want to use this function, put nothing in it :
    
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Nothing !
}

The SGL Shell processes many window messages. If the user needs to 
process these messages in his/her application, he/she should make sure
NOT to return DefWindowProc() as it will prevent the SGL Shell WindowProc
to do its own processing for these messages.
The window messages processed by the SGL Shell are :

WM_ENTERMENULOOP, WM_EXITMENULOOP,
WM_ACTIVATEAPP,
WM_SYSCOMMAND,
WM_SIZE, WM_MOVE, WM_MOVING,
WM_PAINT,
WM_DESTROY, WM_QUIT

Note : do NOT process the VK_ESCAPE key, as it is already used by the 
  	   SGL Shell to quit the application.
*/


BOOL RenderScene();
/*
RenderScene()

That's the main user function in which you have to do your own rendering.
Typically, you would have to call sgltri_startofframe(...) and 
sgltri_render(...) SGL functions.
Be sure to make this function return TRUE if the rendering has gone OK.
*/


BOOL InitView(DWORD dwWidth, DWORD dwHeight);
/*
BOOL InitView(dwWidth, dwHeight)

This function enables the user to set up his/her rendering variables and
to prepare the scene. Typically, you will create your textures, set up your
context, etc... in this function.
InitView(dwWidth, dwHeight) will be called each time the whole rendering 
environment has to be changed (switching from Window to Fullscreen, changing 
the resolution, changing the buffering mode, etc... 
InitView(dwWidth, dwHeight) passes the current Width and Height of the 
rendering surface, so the user can adjust the scene geometry corresponding 
to these dimensions.
Be sure to make this function return TRUE if the initialisation has gone OK.
*/


void ReleaseView();
/*
ReleaseView()

This function enables the user to free any memory or variables allocated
in InitView().
*/

#ifdef __cplusplus
}
#endif

#endif
