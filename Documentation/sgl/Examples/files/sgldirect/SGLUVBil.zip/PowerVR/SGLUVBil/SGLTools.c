/*****************************************************************************
  Name : SGLTools.c
  Date : May 1998
  Platform : ANSI compatible
 
  Description : some helper functions dealing with 3D transformations and
				matrices for SGL Direct.

  
  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/
#include <windows.h>
#include <math.h>
#include <stdio.h>
#include "sgl.h"
#include "SGLTools.h"


// Temp
char pszTmp[300];



/*******************************************************************************
 * Function Name  : ResetMatrix
 * Inputs		  : *pMatrix
 * Globals used   : None
 * Description    : Reset matrix to identity matrix.
 *
 *******************************************************************************/
void ResetMatrix(MATRIX *pMatrix)
{
	pMatrix->_11=1.0f;		pMatrix->_12=0.0f;		pMatrix->_13=0.0f;		pMatrix->_14=0.0f;	
	pMatrix->_21=0.0f;		pMatrix->_22=1.0f;		pMatrix->_23=0.0f;		pMatrix->_24=0.0f;	
	pMatrix->_31=0.0f;		pMatrix->_32=0.0f;		pMatrix->_33=1.0f;		pMatrix->_34=0.0f;	
	pMatrix->_41=0.0f;		pMatrix->_42=0.0f;		pMatrix->_43=0.0f;		pMatrix->_44=1.0f;	
}


/*******************************************************************************
 * Function Name  : MultiplyMatrix
 * Inputs		  : *pMatrixA, *pMatrixB
 * Output		  : *pResultMatrix
 * Globals used   : None
 * Description    : Multiply pMatrixA by pMatrixB and assign the result
 *					in pResultMatrix (pResultMatrix = pMatrixA * pMatrixB)
 *
 *******************************************************************************/
void MultiplyMatrix(MATRIX *pResultMatrix, const MATRIX *pMatrixA, const MATRIX *pMatrixB)  
{
    MATRIX ret;
	
	/* Perform calculation on a dummy matrix (ret) */
	ret._11 = pMatrixA->_11*pMatrixB->_11 + pMatrixA->_12*pMatrixB->_21 + pMatrixA->_13*pMatrixB->_31 + pMatrixA->_14*pMatrixB->_41;
	ret._12 = pMatrixA->_11*pMatrixB->_12 + pMatrixA->_12*pMatrixB->_22 + pMatrixA->_13*pMatrixB->_32 + pMatrixA->_14*pMatrixB->_42;
	ret._13 = pMatrixA->_11*pMatrixB->_13 + pMatrixA->_12*pMatrixB->_23 + pMatrixA->_13*pMatrixB->_33 + pMatrixA->_14*pMatrixB->_43;
	ret._14 = pMatrixA->_11*pMatrixB->_14 + pMatrixA->_12*pMatrixB->_24 + pMatrixA->_13*pMatrixB->_34 + pMatrixA->_14*pMatrixB->_44;

	ret._21 = pMatrixA->_21*pMatrixB->_11 + pMatrixA->_22*pMatrixB->_21 + pMatrixA->_23*pMatrixB->_31 + pMatrixA->_24*pMatrixB->_41;
	ret._22 = pMatrixA->_21*pMatrixB->_12 + pMatrixA->_22*pMatrixB->_22 + pMatrixA->_23*pMatrixB->_32 + pMatrixA->_24*pMatrixB->_42;
	ret._23 = pMatrixA->_21*pMatrixB->_13 + pMatrixA->_22*pMatrixB->_23 + pMatrixA->_23*pMatrixB->_33 + pMatrixA->_24*pMatrixB->_43;
	ret._24 = pMatrixA->_21*pMatrixB->_14 + pMatrixA->_22*pMatrixB->_24 + pMatrixA->_23*pMatrixB->_34 + pMatrixA->_24*pMatrixB->_44;

	ret._31 = pMatrixA->_31*pMatrixB->_11 + pMatrixA->_32*pMatrixB->_21 + pMatrixA->_33*pMatrixB->_31 + pMatrixA->_34*pMatrixB->_41;
	ret._32 = pMatrixA->_31*pMatrixB->_12 + pMatrixA->_32*pMatrixB->_22 + pMatrixA->_33*pMatrixB->_32 + pMatrixA->_34*pMatrixB->_42;
	ret._33 = pMatrixA->_31*pMatrixB->_13 + pMatrixA->_32*pMatrixB->_23 + pMatrixA->_33*pMatrixB->_33 + pMatrixA->_34*pMatrixB->_43;
	ret._34 = pMatrixA->_31*pMatrixB->_14 + pMatrixA->_32*pMatrixB->_24 + pMatrixA->_33*pMatrixB->_34 + pMatrixA->_34*pMatrixB->_44;

	ret._41 = pMatrixA->_41*pMatrixB->_11 + pMatrixA->_42*pMatrixB->_21 + pMatrixA->_43*pMatrixB->_31 + pMatrixA->_44*pMatrixB->_41;
	ret._42 = pMatrixA->_41*pMatrixB->_12 + pMatrixA->_42*pMatrixB->_22 + pMatrixA->_43*pMatrixB->_32 + pMatrixA->_44*pMatrixB->_42;
	ret._43 = pMatrixA->_41*pMatrixB->_13 + pMatrixA->_42*pMatrixB->_23 + pMatrixA->_43*pMatrixB->_33 + pMatrixA->_44*pMatrixB->_43;
	ret._44 = pMatrixA->_41*pMatrixB->_14 + pMatrixA->_42*pMatrixB->_24 + pMatrixA->_43*pMatrixB->_34 + pMatrixA->_44*pMatrixB->_44;

	/* Copy result in pResultMatrix */
	pResultMatrix->_11=ret._11;
	pResultMatrix->_12=ret._12;
	pResultMatrix->_13=ret._13;
	pResultMatrix->_14=ret._14;

	pResultMatrix->_21=ret._21;
	pResultMatrix->_22=ret._22;
	pResultMatrix->_23=ret._23;
	pResultMatrix->_24=ret._24;

	pResultMatrix->_31=ret._31;
	pResultMatrix->_32=ret._32;
	pResultMatrix->_33=ret._33;
	pResultMatrix->_34=ret._34;

	pResultMatrix->_41=ret._41;
	pResultMatrix->_42=ret._42;
	pResultMatrix->_43=ret._43;
	pResultMatrix->_44=ret._44;
}   


/*******************************************************************************
 * Function Name  : TranslateMatrix
 * Input/Output	  : *pMatrix
 * Inputs		  : fX, fY, fZ
 * Globals used   : None
 * Description    : Translate matrix pMatrix by fX, fY and fZ.
 *
 *******************************************************************************/
void TranslateMatrix(MATRIX *pMatrix, const float fX, const float fY, const float fZ)
{
	pMatrix->_41+=fX;
	pMatrix->_42+=fY;
	pMatrix->_43+=fZ;				
}   


/*******************************************************************************
 * Function Name  : RotateMatrix
 * Input/Output	  : *pMatrix
 * Input		  : fXAngle, fYAngle, fZAngle
 * Globals used   : None
 * Description    : Apply rotations to matrix pMatrix
 *
 *******************************************************************************/
void RotateMatrix(MATRIX *pMatrix, const float fXAngle, const float fYAngle, const float fZAngle)
{
	MATRIX rot;
	float  cosine, sine;

	/* X Rotation */

    /* Precompute cos and sin */
	cosine=(float)cos(fXAngle);
    sine=(float)sin(fXAngle);
    
	/* Create the trigonometric matrix corresponding to X Rotation */
	rot._11=1.0f;			rot._12=0.0f;		rot._13=0.0f;			rot._14=0.0f;	
	rot._21=0.0f;			rot._22=cosine;		rot._23=sine;			rot._24=0.0f;	
	rot._31=0.0f;			rot._32=-sine;		rot._33=cosine;			rot._34=0.0f;	
	rot._41=0.0f;			rot._42=0.0f;		rot._43=0.0f;			rot._44=1.0f;	

	/* Multiply the given matrix with this trigonometric matrix */
	MultiplyMatrix(pMatrix, pMatrix, &rot);

	/* Y Rotation */

	/* Precompute cos and sin */
	cosine=(float)cos(fYAngle);
    sine=(float)sin(fYAngle);
    
	/* Create the trigonometric matrix corresponding to Y Rotation */
	rot._11=cosine;			rot._12=0.0f;		rot._13=-sine;			rot._14=0.0f;	
	rot._21=0.0f;			rot._22=1.0f;		rot._23=0.0f;			rot._24=0.0f;	
	rot._31=sine;			rot._32=0.0f;		rot._33=cosine;			rot._34=0.0f;	
	rot._41=0.0f;			rot._42=0.0f;		rot._43=0.0f;			rot._44=1.0f;	

	/* Multiply the given matrix with this trigonometric matrix */
	MultiplyMatrix(pMatrix, pMatrix, &rot);

	/* Z Rotation */
	
	/* Precompute cos and sin */
	cosine=(float)cos(fZAngle);
    sine=(float)sin(fZAngle);
    
	/* Create the trigonometric matrix corresponding to Z Rotation */
	rot._11=cosine;			rot._12=sine;		rot._13=0.0f;			rot._14=0.0f;	
	rot._21=-sine;			rot._22=cosine;		rot._23=0.0f;			rot._24=0.0f;	
	rot._31=0.0f;			rot._32=0.0f;		rot._33=1.0f;			rot._34=0.0f;	
	rot._41=0.0f;			rot._42=0.0f;		rot._43=0.0f;			rot._44=1.0f;	

	/* Multiply the given matrix with this trigonometric matrix */
	MultiplyMatrix(pMatrix, pMatrix, &rot);
}


/*******************************************************************************
 * Function Name  : ScaleMatrix
 * Input/Output	  : *pMatrix
 * Input		  : fFactor
 * Globals used   : None
 * Description    : Scale matrix pMatrix by the homogeneous factor fFactor.
 *
 *******************************************************************************/
void ScaleMatrix(MATRIX *pMatrix, const float fFactor)
{
	pMatrix->_11*=fFactor;	pMatrix->_12*=fFactor;	pMatrix->_13*=fFactor;		
	pMatrix->_21*=fFactor;	pMatrix->_22*=fFactor;	pMatrix->_23*=fFactor;
	pMatrix->_31*=fFactor;	pMatrix->_32*=fFactor;	pMatrix->_33*=fFactor;
	pMatrix->_41*=fFactor;	pMatrix->_42*=fFactor;	pMatrix->_43*=fFactor;
}


/*******************************************************************************
 * Function Name  : InverseMatrix
 * Input/Output	  : *pMatrix
 * Globals used   : None
 * Description    : Compute the inverse matrix of pMatrix.
 *					The matrix must be of the form :  
 * 					A 0
 *					C 1 
 *					Where A is a 3x3 matrix and C is a 1x3 matrix.
 *
 *******************************************************************************/
void InverseMatrix(MATRIX *pMatrix)
{
	MATRIX		DummyMatrix;
	double		det_1;
	double		pos, neg, temp;

    /* Calculate the determinant of submatrix A and determine if the
     * the matrix is singular as limited by the double precision
     * floating-point data representation. */
    pos = neg = 0.0;
    temp =  pMatrix->_11 * pMatrix->_22 * pMatrix->_33;
    if (temp >= 0.0) pos += temp; else neg += temp;
    temp =  pMatrix->_12 * pMatrix->_23 * pMatrix->_31;
    if (temp >= 0.0) pos += temp; else neg += temp;
    temp =  pMatrix->_13 * pMatrix->_21 * pMatrix->_32;
    if (temp >= 0.0) pos += temp; else neg += temp;
    temp = -pMatrix->_13 * pMatrix->_22 * pMatrix->_31;
    if (temp >= 0.0) pos += temp; else neg += temp;
    temp = -pMatrix->_12 * pMatrix->_21 * pMatrix->_33;
    if (temp >= 0.0) pos += temp; else neg += temp;
    temp = -pMatrix->_11 * pMatrix->_23 * pMatrix->_32;
    if (temp >= 0.0) pos += temp; else neg += temp;
    det_1 = pos + neg;

    /* Is the submatrix A singular? */
    if ((det_1 == 0.0) || (fabs(det_1 / (pos - neg)) < 1.0e-15)) 
	{
        /* Matrix M has no inverse */
        OutputDebugString("Matrix has no inverse : singular matrix\n");
        return;
    }
    else 
	{
        /* Calculate inverse(A) = adj(A) / det(A) */
        det_1 = 1.0 / det_1;
        DummyMatrix._11 =   ( pMatrix->_22 * pMatrix->_33 - pMatrix->_23 * pMatrix->_32 ) * (float)det_1;
        DummyMatrix._21 = - ( pMatrix->_21 * pMatrix->_33 - pMatrix->_23 * pMatrix->_31 ) * (float)det_1;
        DummyMatrix._31 =   ( pMatrix->_21 * pMatrix->_32 - pMatrix->_22 * pMatrix->_31 ) * (float)det_1;
        DummyMatrix._12 = - ( pMatrix->_12 * pMatrix->_33 - pMatrix->_13 * pMatrix->_32 ) * (float)det_1;
        DummyMatrix._22 =   ( pMatrix->_11 * pMatrix->_33 - pMatrix->_13 * pMatrix->_31 ) * (float)det_1;
        DummyMatrix._32 = - ( pMatrix->_11 * pMatrix->_32 - pMatrix->_12 * pMatrix->_31 ) * (float)det_1;
        DummyMatrix._13 =   ( pMatrix->_12 * pMatrix->_23 - pMatrix->_13 * pMatrix->_22 ) * (float)det_1;
        DummyMatrix._23 = - ( pMatrix->_11 * pMatrix->_23 - pMatrix->_13 * pMatrix->_21 ) * (float)det_1;
        DummyMatrix._33 =   ( pMatrix->_11 * pMatrix->_22 - pMatrix->_12 * pMatrix->_21 ) * (float)det_1;

        /* Calculate -C * inverse(A) */
        DummyMatrix._41 = - ( pMatrix->_41 * DummyMatrix._11 + pMatrix->_42 * DummyMatrix._21 + pMatrix->_43 * DummyMatrix._31 );
        DummyMatrix._42 = - ( pMatrix->_41 * DummyMatrix._12 + pMatrix->_42 * DummyMatrix._22 + pMatrix->_43 * DummyMatrix._32 );
        DummyMatrix._43 = - ( pMatrix->_41 * DummyMatrix._13 + pMatrix->_42 * DummyMatrix._23 + pMatrix->_43 * DummyMatrix._33 );

        /* Fill in last column */
        DummyMatrix._14 = DummyMatrix._24 = DummyMatrix._34 = 0.0f;
        DummyMatrix._44 = 1.0f;
	}

   	/* Copy contents of dummy matrix in pMatrix */
	CopyMatrix(pMatrix, &DummyMatrix);
}


/*******************************************************************************
 * Function Name  : CopyMatrix
 * Input		  : *pSrcMatrix
 * Output		  : *pDstMatrix
 * Globals used   : None
 * Description    : Copy matrix pSrcMatrix into pDstMatrix
 *
 *******************************************************************************/
void CopyMatrix(MATRIX *pDstMatrix, const MATRIX *pSrcMatrix)
{
	pDstMatrix->_11=pSrcMatrix->_11;
	pDstMatrix->_12=pSrcMatrix->_12;
	pDstMatrix->_13=pSrcMatrix->_13;
	pDstMatrix->_14=pSrcMatrix->_14;

	pDstMatrix->_21=pSrcMatrix->_21;
	pDstMatrix->_22=pSrcMatrix->_22;
	pDstMatrix->_23=pSrcMatrix->_23;
	pDstMatrix->_24=pSrcMatrix->_24;

	pDstMatrix->_31=pSrcMatrix->_31;
	pDstMatrix->_32=pSrcMatrix->_32;
	pDstMatrix->_33=pSrcMatrix->_33;
	pDstMatrix->_34=pSrcMatrix->_34;

	pDstMatrix->_41=pSrcMatrix->_41;
	pDstMatrix->_42=pSrcMatrix->_42;
	pDstMatrix->_43=pSrcMatrix->_43;
	pDstMatrix->_44=pSrcMatrix->_44;
}


/*******************************************************************************
 * Function Name  : DisplayMatrixInDebug
 * Input		  : *pMatrix
 * Globals used   : None
 * Description    : Display matrix in debug output.
 *
 *******************************************************************************/
void DisplayMatrixInDebug(const MATRIX *pMatrix)
{
	char	pszString[300];
	
	/* Format string */
	sprintf(pszString, "%f	%f	%f	%f\n%f	%f	%f	%f\n%f	%f	%f	%f\n%f	%f	%f	%f\n",
	pMatrix->_11, pMatrix->_12, pMatrix->_13, pMatrix->_14, 
	pMatrix->_21, pMatrix->_22, pMatrix->_23, pMatrix->_24, 
	pMatrix->_31, pMatrix->_32, pMatrix->_33, pMatrix->_34,
	pMatrix->_41, pMatrix->_42, pMatrix->_43, pMatrix->_44);

	/* Display string */
	OutputDebugString(pszString);
}


/*******************************************************************************
 * Function Name  : DotProduct
 * Inputs		  : VectorA, VectorB
 * Globals used   : None
 * Returns		  : float
 * Description    : Returns the dot product between vector pVectorA and pVectorB
 *
 *******************************************************************************/
float DotProduct(const sgl_vector VectorA, const sgl_vector VectorB)
{
	return (VectorA[0]*VectorB[0] + VectorA[1]*VectorB[1] + VectorA[2]*VectorB[2]);
}


/*******************************************************************************
 * Function Name  : CrossProduct
 * Inputs		  : *pVectorA, *pVectorB
 * Output		  : *pResultVector
 * Globals used   : None
 * Description    : Compute the cross product between pVectorA and pVectorB and
 *					assign the resulting vector in pResultVector.
 *
 *******************************************************************************/
void CrossProduct(sgl_vector ResultVector, const sgl_vector VectorA, const sgl_vector VectorB)
{
    sgl_vector result;

	/* Perform calculation on a dummy VECTOR (result) in case of ResultVector also used as Vector A or B */
    result[0] = VectorA[1] * VectorB[2] - VectorA[2] * VectorB[1];
    result[1] = VectorA[2] * VectorB[0] - VectorA[0] * VectorB[2];
    result[2] = VectorA[0] * VectorB[1] - VectorA[1] * VectorB[0];
    
	/* Copy result in pResultVector */
	ResultVector[0]=result[0];
	ResultVector[1]=result[1];
	ResultVector[2]=result[2];
}


/*******************************************************************************
 * Function Name  : Normalize
 * Input/Output	  : Vector
 * Globals used   : None
 * Description    : Normalize vector Vector.
 *
 *******************************************************************************/
void Normalize(sgl_vector Vector)
{
    float	fVx, fVy, fVz, fInvMod;

    /* Assign temporary variables */
	fVx=Vector[0];	
    fVy=Vector[1];
    fVz=Vector[2];
 
	/* If vector is not null, then perform normalization */
	if ((fVx==0) && (fVy==0) && (fVz==0))
	{
		/* Null vector, keep it unchanged */
		return;
	}
	
	/* Normalize */
	fInvMod=(float)(1.0f/sqrt(fVx*fVx + fVy*fVy + fVz*fVz));
	Vector[0]=fVx*fInvMod;
	Vector[1]=fVy*fInvMod;
	Vector[2]=fVz*fInvMod;
}


/*******************************************************************************
 * Function Name  : MapUV
 * Inputs		  : nNumberOfVertices, *pUV
 * Output		  : *pTLVertex
 * Globals used   : None
 * Description    : Read an array of UV values and assign them to pTLVertex
 *
 *******************************************************************************/
void MapUV(int nNumberOfVertices, float *pUV, SGLVERTEX *pTLVertex)
{
	int			i;
	SGLVERTEX	*pVertexPointer;
	float		*pUVPointer;

	/* Assign count pointers */
	pVertexPointer=&pTLVertex[0];
	pUVPointer=(float *)&pUV[0];

	/* Main loop */
	for (i=0;i<nNumberOfVertices;i++)
	{
		/* Assign values */
		pVertexPointer->fUOverW=*pUVPointer++;
		pVertexPointer->fVOverW=*pUVPointer++;
		
		/* Increment pointers */
		pVertexPointer++;
	}
}



/*******************************************************************************
 * Function Name  : TransformAndProjectVertices
 * Inputs		  : pMatrix, nNumberOfVertices, pVertex, 
 *					nViewportWidth, nViewportHeight
 * Output		  : pTLVertex
 * Globals used   : None
 * Description    : Transform and project all vertices in pVertex and store them 
 *					in pTLVertex.
 *					This is a simple function, as it does not perform clipping and
 *					the camera is always at (0, 0, -100.0f), looking at (0, 0, 1).
 *					However it is pretty straighforward to modify this function
 *					so it can accept a camera position and angle.
 *
 *
 *******************************************************************************/
void TransformAndProjectVertices(MATRIX *pWorldMatrix, 
								 int nNumberOfVertices, float *pVertex, SGLVERTEX *pTLVertex,
								 int nViewportWidth, int nViewportHeight)
{
	int			i;
	MATRIX		TransformationMatrix;
	MATRIX		ProjectionMatrix;
	DWORD		dwHalfWidth;
	DWORD		dwHalfHeight;
	sgl_vector	CameraPosition={ 0, 0, -100.0f };
	sgl_vector	*pVectorPointer;

	/* First modify the matrix so that the whole world is moved forward by the z value of CameraPosition (View matrix) */
	CopyMatrix(&TransformationMatrix, pWorldMatrix);
	TranslateMatrix(&TransformationMatrix, -CameraPosition[0], -CameraPosition[1], -CameraPosition[2]);

	/* Compute projection matrix */
	ZeroMemory(&ProjectionMatrix, sizeof(MATRIX));
	ProjectionMatrix._11=1.0f;
	ProjectionMatrix._22=(float)nViewportWidth/nViewportHeight;
	ProjectionMatrix._34=1.0f;
	ProjectionMatrix._43=1.0f;		/* Should be 1.0f/d but assuming d=1.0f */

	/* Transformation matrix is the multiplation of World matrix (including view) and Projection matrix */
	MultiplyMatrix(&TransformationMatrix, &TransformationMatrix, &ProjectionMatrix);

	/* Getting vector pointer */
	pVectorPointer=(sgl_vector *)&pVertex[0];

	/* Transform all vertices with TransformationMatrix */
	for (i=0; i<nNumberOfVertices; i++)
	{
		pTLVertex[i].fX =	pVectorPointer[i][0]*TransformationMatrix._11 +
							pVectorPointer[i][1]*TransformationMatrix._21 +
							pVectorPointer[i][2]*TransformationMatrix._31 +
							TransformationMatrix._41;
		pTLVertex[i].fY =	pVectorPointer[i][0]*TransformationMatrix._12 +
							pVectorPointer[i][1]*TransformationMatrix._22 +
							pVectorPointer[i][2]*TransformationMatrix._32 +
							TransformationMatrix._42;
		/* No need to compute z, as it will always be equal to 1.0f after projection matrix
		   (Anyway SGL Direct does not use the Z value)
		pTLVertex[i].fZ =	pVectorPointer[i][0]*TransformationMatrix._13 +
							pVectorPointer[i][1]*TransformationMatrix._23 +
							pVectorPointer[i][2]*TransformationMatrix._33 +
							TransformationMatrix._43;
		*/
		pTLVertex[i].fInvW= pVectorPointer[i][0]*TransformationMatrix._14 +
							pVectorPointer[i][1]*TransformationMatrix._24 +
							pVectorPointer[i][2]*TransformationMatrix._34 +
							TransformationMatrix._44;
		/* Crap Z clipping ! */
		/*
		if (pTLVertex[i].fInvW<1.0f)
		{
			pTLVertex[i].fInvW=1.0f;
		}*/
	}

	/* At this point, all vertices are projected and homogeneous (clipping coordinates) */

	/* Getting middle coordinate of viewport */
	dwHalfWidth=nViewportWidth>>1;
	dwHalfHeight=nViewportHeight>>1;
	
	/* Calculating screen coordinates in one go */
	for (i=0; i<nNumberOfVertices; i++)
	{
		pTLVertex[i].fX =	(pTLVertex[i].fX/pTLVertex[i].fInvW)*dwHalfWidth+dwHalfWidth;
		pTLVertex[i].fY =	-(pTLVertex[i].fY/pTLVertex[i].fInvW)*dwHalfHeight+dwHalfHeight;
		//pTLVertex[i].fZ =	1.0f-(1.0f/pTLVertex[i].fInvW);	Z is not used in SGL Direct
		pTLVertex[i].fInvW = 1.0f/pTLVertex[i].fInvW;
	}
}


/*******************************************************************************
 * Function Name  : SmoothShade
 * Inputs		  : *pMatrix, nNumberOfVertices, *pNormals, 
 *					LightVector, dwLightColour
 * Output		  : *pTLVertex
 * Globals used   : None
 * Description    : Smooth shade vertices.
 *					The WORLD matrix is passed as a parameter (pMatrix) and the
 *					inverse matrix is computed in the function to perform the
 *					shading.
 *					The resulting colour and specular are asserted in the
 *					pTLVertex array.
 *					Of course normal vectors must be normalised.
 *					You can set the Alpha value of the vertices by passing
 *					dwLightColour with an ALPHA component.
 *					Vertex fog is set to 0.
 *
 *******************************************************************************/
void SmoothShade(MATRIX *pMatrix, 
				 int nNumberOfVertices, float *pNormals, SGLVERTEX *pTLVertex, 
				 sgl_vector LightVector, DWORD dwLightColour)
{
	MATRIX		Inverse;
	sgl_vector	TLightVector;
	sgl_vector	*pNormalPointer;
	SGLVERTEX	*pTLVertexPointer;
	BYTE		Red, Green, Blue, Alpha;
	BYTE		r, g, b;
	float		fCosine;
	int			i;

	/* Copy world matrix and compute inverse matrix */
	CopyMatrix(&Inverse, pMatrix);
	InverseMatrix(&Inverse);

	/* Normalize light vector in case it is not */
	Normalize(LightVector);

	/* Transform the light vector with inverse world matrix.
	   Note : Don't include Inverse._4X because LightVector = TO - FROM. 
	   FROM is always (0, 0, 0), so transformed FROM would be equal to
	   (Inverse._41, Inverse._42, Inverse._43). Thus by doing TO - FROM, Inverse._4X
	   would be subtracted with themselves, hence yielding zero */
	TLightVector[0]=LightVector[0]*Inverse._11 + 
					LightVector[1]*Inverse._21 +
					LightVector[2]*Inverse._31;

	TLightVector[1]=LightVector[0]*Inverse._12 + 
					LightVector[1]*Inverse._22 +
					LightVector[2]*Inverse._32;

	TLightVector[2]=LightVector[0]*Inverse._13 + 
					LightVector[1]*Inverse._23 +
					LightVector[2]*Inverse._33;

	/* Get Red, Green and Blue components of light */
	Red=GET_RED(dwLightColour);
	Green=GET_GREEN(dwLightColour);
	Blue=GET_BLUE(dwLightColour);
	Alpha=GET_ALPHA(dwLightColour);

	/* Get pointers */
	pNormalPointer=(sgl_vector *)&pNormals[0];
	pTLVertexPointer=&pTLVertex[0];
	
	/* Compute dot product for each vertex */
	for (i=0; i<nNumberOfVertices; i++)
	{
		/* fCosine = angle cosinus between light vector and normal vector */
		fCosine=DotProduct(pNormalPointer[i], TLightVector);
						
		/* If colour is negative, then make it 0 */
		if (fCosine<0) fCosine=0;

		/* Compute Red, Green and Blue colour values */
		r=(BYTE)(fCosine*Red);
		g=(BYTE)(fCosine*Green);
		b=(BYTE)(fCosine*Blue);

		/* Diffuse colour */
		pTLVertex->u32Colour=MAKE_RGBA(r, g, b, Alpha);

		/* Compute highlight : set highlight to 0 for any intensity value below 240 */
		pTLVertex->u32Specular=MAKE_RGB( (r>240) ? (r-240)<<4 : 0, (g>240) ? (g-240)<<4 : 0, (b>240) ? (b-240)<<4 : 0);
		
		/* Increase vertex count */
		pTLVertex++;
	}
}







