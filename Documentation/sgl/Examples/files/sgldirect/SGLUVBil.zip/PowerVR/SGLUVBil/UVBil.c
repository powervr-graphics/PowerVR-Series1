/*****************************************************************************
  Name : UVBil.c
  Date : May 1998
  Platform : ANSI compatible

  UVBil.c is a scene file that is to be used with SGL Shell. 
  The scene file should be included in a project where the SGLShell.c and 
  SGLShell.h files are included. The SGL.LIB library file should of course
  be included in the project. Make sure your application include SGLShell.h 
  to have access to SGL Shell functions and flags.

  Basic functions have to be implemented to interact correctly with the SGL 
  Shell. A list of these functions is :

  
  *****************************
  ** void InitApplication(); **
  *****************************

  This function will be called only once by the SGL Shell before anything 
  happens, at the very beginning of the SGLShell WinMain() function. 
  This function enables the user to perform any initialisation before 
  the program is actually run.
  Could be used to load meshes and allocate memory for these, setup the
  SGL Context, load and allocate textures, etc...

  Within this function the user can call SGLShellSetPreferences(...) to set 
  the application preferences. For details of this function, see later
  in this document.

  - void QuitApplication();

  This function is used in conjunction with InitApplication(). Its purpose
  is to free and close all memory or instances allocated in InitApplication().
  This function is called when the user exits the application.

				***

  *****************************************************
  **  BOOL InitView(DWORD dwWidth, DWORD dwHeight);  **
  *****************************************************

  This function is called each time a rendering variable is changed in
  the SGLShell (switching from or to full screen, changing the resolution,
  changing the buffering mode and switching Display Info On or Off). 
  
  InitView(...) is the final function that gets called when rendering 
  variables are changed.
  InitView(...) lets the user create or initialise any new variables 
  corresponding to the new rendering parameters. 
  dwWidth and dwHeight are passed to your application and correspond to 
  the new Width and Height of the rendering surface. The user may need 
  these to create his/her viewport or centering the scene accordingly.
  This function should return TRUE(1) to tell SGLShell that the call was
  successful. If the function returns FALSE(0), then the execution will
  stop.

  ***************************
  **  void ReleaseView();  **
  ***************************

  This function is used in conjunction with InitView(...). Its purpose
  is to free and close all memory or instances allocated in InitView().

				***
  
  ***********************************************************************************
  **  void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);  **
  ***********************************************************************************

  This is the user window procedure. It is used as a normal WindowProc()
  function. This function is called before the SGLShell window procedure
  itself. It enables the user to retrieve menu choices, keystrokes or 
  other messages.
  SGLShell handles many messages which should not be handled by the user
  application. A list of these messages is :
  
  	WM_ENTERMENULOOP, WM_EXITMENULOOP,
	WM_ACTIVATEAPP,
	WM_SYSCOMMAND,
	WM_SIZE, WM_MOVE, WM_MOVING,
	WM_PAINT,
	WM_DESTROY, WM_QUIT

  Do NOT return DefWindowProc(...) in this function, as it will prevent
  SGLShell to handle messages by itself.

				***

  ***************************
  **  BOOL RenderScene();  **
  ***************************

  This is where the user does his/her rendering. Typically one would call
  sgltri_startofframe(...) and sgltri_render(...) in this function.
  The function should return TRUE to tell SGLShell that the call was
  successful. If the function returns FALSE, then the execution will stop.


  These 6 functions must exist, but you don't have to put any code in these. 
  For instance, if you don't want to deal with any user input, the
  UserWindowProc(...) function will typically be empty.  
  You might as well not want to make any use of ReleaseView(), or even 
  InitView(...). In that case, just put nothing in these.
  The most simple example of an application using SGLShell is the Triangle
  example (see below).


  -------------------------------------------------------------
  | READ SGLSHELL.TXT FOR FURTHER INFORMATION ABOUT SGLSHELL  |
  -------------------------------------------------------------


  Email any comments or feedback to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/
#include <windowsx.h>
#include <math.h>
#include <ddraw.h>
#include "sgl.h"		/* SGL library include */
#include "SGLShell.h"	/* SGLShell include */
#include "SGLTools.h"
#include "resource.h"	/* Resource include */
              

/* Macros */
#define SWAP(x)		if (x) { x=FALSE; } else x=TRUE


/* Global variables */

/* Debug string */
char	pszTmp[300];

/* Background vertices */
SGLVERTEX	BackgroundTLVertices[4]={
    { 	 0.0f,	   0.0f, 0.999f, 0.001f, MAKE_RGB(255, 255, 255), MAKE_RGB(0, 0, 0), 0.0f, 1.0f },
	{  256.0f,	   0.0f, 0.999f, 0.001f, MAKE_RGB(255, 255, 255), MAKE_RGB(0, 0, 0), 1.0f, 1.0f },
	{  256.0f,	 256.0f, 0.999f, 0.001f, MAKE_RGB(255, 255, 255), MAKE_RGB(0, 0, 0), 1.0f, 0.0f },
	{    0.0f,	 256.0f, 0.999f, 0.001f, MAKE_RGB(255, 255, 255), MAKE_RGB(0, 0, 0), 0.0f, 0.0f }	};
	

/* Background triangles */
int	BackgroundTriangles[2][3]={
	{ 0, 3, 2 }, {0, 2, 1}  };


/* Variables */
float		fScaleFactor=0.88f;
BOOL		bBilinearOn=TRUE;
BOOL		bTextOn=TRUE;
BOOL		bMaxUV=TRUE;
int			nBackgroundTexture[2][3];
int			nTextTexture;
SGLCONTEXT	SGLContext;


/* Added for SGLShell port */
static	DWORD	dwCurrentWidth;
static	DWORD	dwCurrentHeight;
HICON			hMyIcon;


/* Prototypes */
static void SetupContext (void);


/* SGLShell Functions */


/* InitApplication() is called by SGLShell */
void InitApplication()
{
	/* Load icon from resouce */
	hMyIcon=LoadIcon(NULL, MAKEINTRESOURCE(ID_PVRICON));

	/* Set application name, no menu, no accelerator, User Icon and flags */
	SGLShellSetPreferences("Bilinear Offset in UV texturing", NULL, NULL, hMyIcon, DISABLE_VERYHIGHRES);
	
	/* Load textures from resource */
	nBackgroundTexture[0][0]=SGLShellLoadBMP("SAND1-1", FALSE, FALSE);
	nBackgroundTexture[0][1]=SGLShellLoadBMP("SAND1-2", FALSE, FALSE);
	nBackgroundTexture[0][2]=SGLShellLoadBMP("SAND1-3", FALSE, FALSE);
	nBackgroundTexture[1][0]=SGLShellLoadBMP("SAND2-1", FALSE, FALSE);
	nBackgroundTexture[1][1]=SGLShellLoadBMP("SAND2-2", FALSE, FALSE);
	nBackgroundTexture[1][2]=SGLShellLoadBMP("SAND2-3", FALSE, FALSE);
	nTextTexture=SGLShellLoadBMP("TEXT", TRUE, FALSE);
	
	/* Setup SGL context */
	SetupContext();
}


/* QuitApplication() is called by SGLShell */
void QuitApplication()
{
	/* Free texture */
	sgl_delete_texture(nBackgroundTexture[0][0]);
	sgl_delete_texture(nBackgroundTexture[0][1]);
	sgl_delete_texture(nBackgroundTexture[0][2]);
	sgl_delete_texture(nBackgroundTexture[1][0]);
	sgl_delete_texture(nBackgroundTexture[1][1]);
	sgl_delete_texture(nBackgroundTexture[1][2]);
	sgl_delete_texture(nTextTexture);
	
	OutputDebugString("Application memory released\n");
}


/* UserWindowProc() is called by SGLShell */
void UserWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/* Handle user messages */
	
	switch(message)
	{
		case WM_KEYDOWN:	switch(wParam)
							{
								case 'U' :		SWAP(bMaxUV); break;
								case 'F' :		SWAP(bBilinearOn); break;
								
								case VK_UP :
								case VK_ADD :	fScaleFactor+=0.01f; break;
								case VK_DOWN :
								case VK_SUBTRACT :	if (fScaleFactor>0.01f) fScaleFactor-=0.01f; break;
								
								case VK_F1 :	SWAP(bTextOn); break;
							}
							break;
	}
}


/* InitView() is called by SGLShell */
BOOL InitView(DWORD dwWidth, DWORD dwHeight)
{
	/* Update new width and height */
	dwCurrentWidth=dwWidth;
	dwCurrentHeight=dwHeight;

	/* InitView OK */
	return TRUE;
}


/* RenderScene() is called by SGLShell */
BOOL RenderScene()
{
	static float		rX=0.0f;
	static float		rY=0.0f;
	static float		rZ=0.0f;
	static float		l=0.0f;
	static float		fNewTextureSize;
	float				fBilinearOffset;
	
	/* Compute new texture size (normal size is 256) */
	fNewTextureSize=fScaleFactor*256.0f;

	/* Compute bilinear offset */
	fBilinearOffset=1.0f/256.0f;
	
	/* Text display */
	if (bTextOn)
	{
		sprintf(pszTmp, "Scale factor : %.2f", fScaleFactor);
		SGLShellSetDisplayText(pszTmp, 10, 10);
		sprintf(pszTmp, "Bilinear (F)iltering %s", bBilinearOn ? "On" : "Off");
		SGLShellSetDisplayText(pszTmp, 10, 30);
		sprintf(pszTmp, "(U)V Values : %s", bMaxUV ? "Maximum (0.0f and 1.0f)" : "Bilinear special (0.0f+X, 1.0f-X)");
		SGLShellSetDisplayText(pszTmp, 10, 50);
		if (bMaxUV)
		{
			SGLShellSetDisplayText("Press U to fix the lines problem !", 10, 90);
		}
	}

	/* What UV values are we going to use ? */
	if (bMaxUV)
	{
		BackgroundTLVertices[0].fUOverW=0.0f;
		BackgroundTLVertices[0].fVOverW=1.0f;
		BackgroundTLVertices[1].fUOverW=1.0f;
		BackgroundTLVertices[1].fVOverW=1.0f;
		BackgroundTLVertices[2].fUOverW=1.0f;
		BackgroundTLVertices[2].fVOverW=0.0f;
		BackgroundTLVertices[3].fUOverW=0.0f;
		BackgroundTLVertices[3].fVOverW=0.0f;
	}
	else
	{
		BackgroundTLVertices[0].fUOverW=0.0f+fBilinearOffset;
		BackgroundTLVertices[0].fVOverW=1.0f-fBilinearOffset;
		BackgroundTLVertices[1].fUOverW=1.0f-fBilinearOffset;;
		BackgroundTLVertices[1].fVOverW=1.0f-fBilinearOffset;;
		BackgroundTLVertices[2].fUOverW=1.0f-fBilinearOffset;;
		BackgroundTLVertices[2].fVOverW=0.0f+fBilinearOffset;
		BackgroundTLVertices[3].fUOverW=0.0f+fBilinearOffset;
		BackgroundTLVertices[3].fVOverW=0.0f+fBilinearOffset;
	}

	/* SGL Render */
	sgltri_startofframe (&SGLContext);

	/* Draw background as 6 different textured polygons */

	/* Background tile 1-1 : */
	BackgroundTLVertices[0].fX=0.0f;
	BackgroundTLVertices[0].fY=0.0f;
	BackgroundTLVertices[1].fX=fNewTextureSize;
	BackgroundTLVertices[1].fY=0.0f;
	BackgroundTLVertices[2].fX=fNewTextureSize;
	BackgroundTLVertices[2].fY=fNewTextureSize;
	BackgroundTLVertices[3].fX=0.0f;
	BackgroundTLVertices[3].fY=fNewTextureSize;

	SGLContext.nTextureName = nBackgroundTexture[0][0];

	SGLContext.u32Flags=SGLTT_GOURAUD | SGLTT_TEXTURE;
	SGLContext.eFilterType=sgl_tf_point_sample;
	if (bBilinearOn)
	{
		SGLContext.u32Flags|=SGLTT_BILINEAR;
		SGLContext.eFilterType=sgl_tf_bilinear;
	}
	sgltri_triangles (&SGLContext, 2, (int(*)[3])BackgroundTriangles, BackgroundTLVertices);

	/* Background tile 1-2 : */
	BackgroundTLVertices[0].fX=fNewTextureSize;
	BackgroundTLVertices[0].fY=0.0f;
	BackgroundTLVertices[1].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].fY=0.0f;
	BackgroundTLVertices[2].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].fY=fNewTextureSize;
	BackgroundTLVertices[3].fX=fNewTextureSize;
	BackgroundTLVertices[3].fY=fNewTextureSize;

	SGLContext.nTextureName = nBackgroundTexture[0][1];

	SGLContext.u32Flags=SGLTT_GOURAUD | SGLTT_TEXTURE;
	SGLContext.eFilterType=sgl_tf_point_sample;
	if (bBilinearOn)
	{
		SGLContext.u32Flags|=SGLTT_BILINEAR;
		SGLContext.eFilterType=sgl_tf_bilinear;
	}
	sgltri_triangles (&SGLContext, 2, (int(*)[3])BackgroundTriangles, BackgroundTLVertices);

	/* Background tile 1-3 : */
	BackgroundTLVertices[0].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[0].fY=0.0f;
	BackgroundTLVertices[1].fX=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].fY=0.0f;
	BackgroundTLVertices[2].fX=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].fY=fNewTextureSize;
	BackgroundTLVertices[3].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].fY=fNewTextureSize;

	SGLContext.nTextureName = nBackgroundTexture[0][2];

	SGLContext.u32Flags=SGLTT_GOURAUD | SGLTT_TEXTURE;
	SGLContext.eFilterType=sgl_tf_point_sample;
	if (bBilinearOn)
	{
		SGLContext.u32Flags|=SGLTT_BILINEAR;
		SGLContext.eFilterType=sgl_tf_bilinear;
	}
	sgltri_triangles (&SGLContext, 2, (int(*)[3])BackgroundTriangles, BackgroundTLVertices);

	/* Background tile 2-1 : */
	BackgroundTLVertices[0].fX=0.0f;
	BackgroundTLVertices[0].fY=fNewTextureSize;
	BackgroundTLVertices[1].fX=fNewTextureSize;
	BackgroundTLVertices[1].fY=fNewTextureSize;
	BackgroundTLVertices[2].fX=fNewTextureSize;
	BackgroundTLVertices[2].fY=fNewTextureSize+fNewTextureSize;;
	BackgroundTLVertices[3].fX=0.0f;
	BackgroundTLVertices[3].fY=fNewTextureSize+fNewTextureSize;;

	SGLContext.nTextureName = nBackgroundTexture[1][0];

	SGLContext.u32Flags=SGLTT_GOURAUD | SGLTT_TEXTURE;
	SGLContext.eFilterType=sgl_tf_point_sample;
	if (bBilinearOn)
	{
		SGLContext.u32Flags|=SGLTT_BILINEAR;
		SGLContext.eFilterType=sgl_tf_bilinear;
	}
	sgltri_triangles (&SGLContext, 2, (int(*)[3])BackgroundTriangles, BackgroundTLVertices);

	/* Background tile 2-2 : */
	BackgroundTLVertices[0].fX=fNewTextureSize;
	BackgroundTLVertices[0].fY=fNewTextureSize;
	BackgroundTLVertices[1].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].fY=fNewTextureSize;
	BackgroundTLVertices[2].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].fY=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].fX=fNewTextureSize;
	BackgroundTLVertices[3].fY=fNewTextureSize+fNewTextureSize;

	SGLContext.nTextureName = nBackgroundTexture[1][1];

	SGLContext.u32Flags=SGLTT_GOURAUD | SGLTT_TEXTURE;
	SGLContext.eFilterType=sgl_tf_point_sample;
	if (bBilinearOn)
	{
		SGLContext.u32Flags|=SGLTT_BILINEAR;
		SGLContext.eFilterType=sgl_tf_bilinear;
	}
	sgltri_triangles (&SGLContext, 2, (int(*)[3])BackgroundTriangles, BackgroundTLVertices);

	/* Background tile 2-3 : */
	BackgroundTLVertices[0].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[0].fY=fNewTextureSize;
	BackgroundTLVertices[1].fX=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[1].fY=fNewTextureSize;
	BackgroundTLVertices[2].fX=fNewTextureSize+fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[2].fY=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].fX=fNewTextureSize+fNewTextureSize;
	BackgroundTLVertices[3].fY=fNewTextureSize+fNewTextureSize;

	SGLContext.nTextureName = nBackgroundTexture[1][2];

	SGLContext.u32Flags=SGLTT_GOURAUD | SGLTT_TEXTURE;
	SGLContext.eFilterType=sgl_tf_point_sample;
	if (bBilinearOn)
	{
		SGLContext.u32Flags|=SGLTT_BILINEAR;
		SGLContext.eFilterType=sgl_tf_bilinear;
	}
	sgltri_triangles (&SGLContext, 2, (int(*)[3])BackgroundTriangles, BackgroundTLVertices);

	/* Display text */
	BackgroundTLVertices[0].fX=(float)dwCurrentWidth-256.0f;
	BackgroundTLVertices[0].fY=0.0f;
	BackgroundTLVertices[1].fX=(float)dwCurrentWidth;
	BackgroundTLVertices[1].fY=0.0f;
	BackgroundTLVertices[2].fX=(float)dwCurrentWidth;
	BackgroundTLVertices[2].fY=0.0f+256.0f;
	BackgroundTLVertices[3].fX=(float)dwCurrentWidth-256.0f;
	BackgroundTLVertices[3].fY=0.0f+256.0f;

	SGLContext.nTextureName = nTextTexture;
	SGLContext.u32Flags=SGLTT_GOURAUD | SGLTT_TEXTURE;
	SGLContext.eFilterType=sgl_tf_point_sample;
	if (bBilinearOn)
	{
		SGLContext.u32Flags|=SGLTT_BILINEAR;
		SGLContext.eFilterType=sgl_tf_bilinear;
	}
	sgltri_triangles (&SGLContext, 2, (int(*)[3])BackgroundTriangles, BackgroundTLVertices);
	
	/* Render ! */
	sgltri_render (&SGLContext);

	/* RenderScene OK */
	return TRUE;
}


/* ReleaseView() is called by SGLShell */
void ReleaseView()
{
	/* Nothing to release */
}


/* Application functions */


/*******************************************************************************
 * Function Name  : SetupContext
 * Inputs		  : None
 * Output		  : None
 * Globals used	  : SGLContext
 * Description    : Sets default values for the render context.
 *
 *******************************************************************************/
void SetupContext ()
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 5;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = 0;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.RenderRegions        = 0;
    SGLContext.n32MipmapOffset      = 0;
    SGLContext.u32GlobalTrans       = 255;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}


