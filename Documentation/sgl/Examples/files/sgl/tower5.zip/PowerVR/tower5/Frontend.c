/*
// FRONTEND.C
//
// The distance units used in this file are supposed to approximate metres.
//
// The initial lighting is sunlight (not headlight).
//
// Strange results may occur if Windows has been running for 50 days due to
// clock wraparound.
*/

/********** usage : adding command line 'overlay' uses overlay ************/
/********** but must be in 800x600x16 bit graphics mode with 2 meg card ***/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <windows.h>
#include <mmsystem.h> 

#include "ddraw.h"
#include "sgl.h"

#include "config.h"
#include "frontend.h"
#include "resource.h"
#include "textower.h"

#include "ddmem.h"


/*
// ============================================================================
// 									GLOBALS
// ============================================================================
*/

GLOBALVARS 			globalVars;
static HINSTANCE  	hInst;
static HWND  		hWnd;
BOOL				bActive;
DWORD 				LastError;
BOOL 				bInfo=0;
sgl_versions*		versions;
sgl_win_versions*	w32versions;
int					nBitsPerPixel;
int					count;
volatile LPDWORD	pStatus;
LPWORD				pMem;
WORD				wStride;

BOOL				bInitStartTime=TRUE;
BOOL				bQuit=FALSE;
int					nStrictLocks;
BOOL				bDisplayFPS=FALSE;

BOOL				bBufferLocked=FALSE;
int					nPrimaryBitDepth=0;

/* Callback prototype */
int sgl_render_callback(P_CALLBACK_ADDRESS_PARAMS lpRenderParams) ;
void DDUnlockFrontBuffer();
int eor_callback();
void ReportSglError(int errorNo);


/******************************************************************************
 * WinMain()
 *****************************************************************************/
int PASCAL WinMain ( HANDLE hInstance,
					 HANDLE hPrevInstance,
					 LPSTR  lpszCmdParam,
					 int    nCmdShow )
{
	static char szAppName[] = "SGLFrontEnd";
	MSG         msg;
	WNDCLASS    wndclass;
	HMENU       hMenu;
	LOGBRUSH    brush;
	int			nRet;
	HDC			hDC;
	int			loopcount;

	/* Get Version info */
	versions = sgl_get_versions();
	w32versions = sgl_get_win_versions();

	/* Check that we are in a 16 or 24 bit display mode */
	hDC = GetDC(NULL);

	if (hDC)
	{
		nBitsPerPixel = GetDeviceCaps (hDC, BITSPIXEL);	
		ReleaseDC(NULL, hDC);

		switch(nBitsPerPixel)
		{
			case 16:
			case 24:
			case 32:
			{
				break;
			}

			default:
			{
				MessageBox (NULL,
					"Error - incompatible graphics mode",
				 	NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
				return 0;
			}
		}
	}
	else
	{
		MessageBox (NULL,
				"Error - can't get display device context",
				 NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
		return 0;
	}

	/* setup inital values */
	hInst = hInstance;

	brush.lbStyle = BS_SOLID;
	brush.lbColor = PALETTEINDEX(DEFAULT_KEY_COLOUR);

	/* set the key value for overlay */
	globalVars.hBrush    = CreateBrushIndirect(&brush);
	globalVars.keyColour = DEFAULT_KEY_COLOUR;
	

	/*
	// =========================
	// WINDOWS APPLICATION STUFF
	// =========================
	*/
	if (!hPrevInstance)
	{
		wndclass.style = CS_BYTEALIGNCLIENT;
	    wndclass.lpfnWndProc = WndProc;
	    wndclass.cbClsExtra = 0;
	    wndclass.cbWndExtra = 0;
	    wndclass.hInstance = hInstance;
	    wndclass.hIcon = LoadIcon( hInstance, IDI_APPLICATION );
	    wndclass.hCursor = LoadCursor( NULL, IDC_ARROW );
	    wndclass.hbrBackground = NULL;
	    wndclass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	    wndclass.lpszClassName = NAME;
		RegisterClass (&wndclass);
	}

	hMenu = LoadMenu(hInstance,MAKEINTRESOURCE(IDR_MENU1));

    hWnd = CreateWindow(  NAME,
				    TITLE,
				    WS_OVERLAPPED | WS_SYSMENU | WS_VISIBLE,
				    50,  50,
				    644, 534,
				    NULL,
				    hMenu,
				    hInstance,
				    NULL );

	if (hWnd == NULL)
	{
		LastError = GetLastError();
		return FALSE;
	}

	/* When launching from 16 bit program manager we need this delay */
	Sleep(100);

	BringWindowToTop (hWnd);

	nRet = sgl_use_address_mode (&sgl_render_callback, (LPDWORD *)&pStatus);
	
	if (nRet)
	{
		MessageBox (NULL, "sgl_use_address_mode() failed", NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
		DDEnd;
		return 0;
	}

	bBufferLocked = FALSE;
	nRet = DDrawInit(hWnd);

	if (nRet)
	{
		MessageBox (NULL, "DDrawInit() failed", NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
		return 0;
	}

	nPrimaryBitDepth = GetPrimaryBitsPerPixel();
	
	nRet = DDGetWindowInfo(hWnd,&pMem,&wStride);
	DDUnlockFrontBuffer();
	bBufferLocked = FALSE;

	if (nRet)
	{
		MessageBox (NULL, "DDGetWindowInfo() failed", NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
		DDEnd;
		return 0;
	}

		nStrictLocks=0;
    /*
      This function may be needed for maximun compatibility
       sgl_get_ini_int (&nStrictLocks, 0, "Default","StrictLocks");
    */

	/*
	   Set up the SGL scene
	*/
	SetupScene(hWnd, (WORD)globalVars.keyColour);

	BringWindowToTop (hWnd);

	bActive = TRUE;

	if (nStrictLocks)
	{
		nRet = sgl_use_eor_callback(&eor_callback);

		loopcount = 100;

		/* Init sequence */
		while (loopcount--)
	    {
	      	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	        {
	            if (!GetMessage( &msg, NULL, 0, 0 ))
	            {
					Finish();
					DDEnd();
	                return msg.wParam;
	            }

	            TranslateMessage(&msg); 
	            DispatchMessage(&msg);
	        }
	    }

		BringWindowToTop (hWnd);

		nRet = DDGetWindowInfo(hWnd,&pMem,&wStride); /* Lock */
		bBufferLocked = TRUE;

		if (nRet)
		{
			DDUnlockFrontBuffer();
			bBufferLocked = FALSE;
			MessageBox (NULL, "DDGetWindowInfo() failed", NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
		}

		/* Render sequence */
		while (!bQuit)
		{
		   	nRet = NextFrame(); /* Do message loop inside the callback */

			if (nRet)
			{
				Sleep(100);
				bQuit = TRUE;
			}
		}

	}

	else
	{
		/* Strict locking is off, so speed things up */
		while (1)
	    {
	      	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	        {
	            if (!GetMessage( &msg, NULL, 0, 0 ))
	            {
					break;
	            }

	            TranslateMessage(&msg); 
	            DispatchMessage(&msg);
	        }
	        else if (bActive)
	        {
	            nRet = NextFrame();

				if (nRet)
				{
					Sleep(100);
					bQuit = TRUE;
					break;
				}
	        }
			else
			{
				WaitMessage();
			}
	    }
	}

	Sleep(100);
	Finish();
	Sleep(100);
	DDEnd();
	Sleep(100);

	if (nRet)
	{
		ReportSglError(nRet);
	}

	return 0;

}/*WinMain*/

/*
	SGL makes this callback during sgl_render when the previous frame
	has completed, that is to say at end of render.
	This is an important event if we are implenemting strict
	locking because we must unlock the surface as soon as possible
	and allow Windows to do it's message loop processing and update it's
	display.
*/
int eor_callback()
{
	MSG         msg;

	/* Unlock the front buffer */

	if (bBufferLocked)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
	}

	while(1)
	{
	  	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	    {
	        if (!GetMessage( &msg, NULL, 0, 0 ))
	        {
				bQuit = TRUE;
	            return 1; /* Prevent sgl from rendering */
	        }

	        TranslateMessage(&msg); 
	        DispatchMessage(&msg);
	    }

		Sleep(2); /* Allow the mouse to move */

		if (bActive)
		{
			break; /* If active then continue to render */	
		}
	}

	return 0; /* Continue with sgl_render */

}/*eor_callback*/


/*
// =======
// WndProc
// =======
*/
long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam)
{
 	FARPROC     lpfnProc;

	switch (message)
	{
	    case WM_ACTIVATEAPP:
		{
			if (wParam)
			{
				Sleep(500); /* Don't restart until Windows has tidied up */
		        bActive = TRUE;
			}
			else
			{
		        bActive = FALSE;
			}
	        break;
		}

		case WM_ACTIVATE:
		{
			if (LOWORD(wParam) == WA_INACTIVE)
			{
		        bActive = FALSE;
			}
			else
			{
				Sleep(500); /* Don't restart until Windows has tidied up */
		        bActive = TRUE;
			}
	        break;
		}
		
		case WM_CREATE:
		{
			return 0;
		}

		case WM_DESTROY:
		{
			bActive = FALSE;
			bQuit = TRUE;
			Sleep(100); /* Wait for end of render before destroying the window */
			PostQuitMessage (0);
			return 0;
		}

	    case WM_KEYDOWN:
		{
	        switch(wParam)
	        {
				/* f12 to quit */
		        case VK_F12:
				{
					bActive = FALSE;

					/* Wait for main message loop to see bActive going low */
					Sleep(100);
							
		            PostMessage(hWnd, WM_CLOSE, 0, 0);
		            break;
				}

				/* f2  */
		        case VK_F2:
				{
					bDisplayFPS = !bDisplayFPS;
					SetWindowText(hWnd,TITLE);
		            break;
				}
	        }
	        break;
		}

		case WM_COMMAND :
		{
			switch (wParam)
			{
				case ID_HELP_ABOUT:
				{
					bActive = FALSE;
					lpfnProc = MakeProcInstance((FARPROC)AboutMsgProc, hInst);
					DialogBox(hInst, MAKEINTRESOURCE(IDD_HELP_ABOUT_DIALOG),
					  hwnd, lpfnProc);
					FreeProcInstance(lpfnProc);
					return 0;
				}
			}
			break;
		}
	}

	return DefWindowProc (hwnd, message, wParam, lParam);
}


int sgl_render_callback(P_CALLBACK_ADDRESS_PARAMS lpRenderParams)
{
	int nRet;
	DWORD				dwNowTime;
	DWORD				dwRunTime;
	float				fFrameRate;
	static DWORD		dwStartTime;
	char szText[80];

	dwNowTime = timeGetTime();

	if (bInitStartTime)
	{
		dwStartTime = dwNowTime;
		bInitStartTime = FALSE;
		count=1;
	}
	else
	{
		count++;

		/* Update fps every 40 frames */
		if (!(count % 40))
		{
			dwRunTime = dwNowTime - dwStartTime;

			if (dwRunTime)
			{
				fFrameRate 	= ((float)count * 1000.0f) / (float) dwRunTime;
			}

			if (bDisplayFPS)
			{
				sprintf(szText,TITLE"  %.1f FPS",fFrameRate);
				SetWindowText(hWnd,szText);
			}
			else
			{
				SetWindowText(hWnd,TITLE);
			}
		}
	}

	if (bBufferLocked)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
	}

	nRet = DDGetWindowInfo(hWnd,&pMem,&wStride);
	bBufferLocked = TRUE;

	if (nRet)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
		MessageBox (NULL, "DDGetWindowInfo() failed", NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
	}

	lpRenderParams->pMem = pMem;
	lpRenderParams->wStride = wStride;
	lpRenderParams->bBitsPerPixel = nPrimaryBitDepth;

	if (!nStrictLocks)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
	}

	return nRet;

}/*sgl_render_callback*/


/*
// AboutMsgProc()
*/
BOOL FAR PASCAL AboutMsgProc( HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{
	switch(Message)
	{
		case WM_CLOSE:
		{
			bInitStartTime = TRUE;
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
			break;
		}
      	
		case WM_COMMAND:
		{
			switch(wParam)
			{
				case IDOK:
				{
					bInitStartTime = TRUE;
					EndDialog(hWndDlg, TRUE);
				}
				break;
			}
			break;
		}

		case WM_INITDIALOG:
		{
			/* Get Version info */
			versions = sgl_get_versions();
			w32versions = sgl_get_win_versions();

			SetDlgItemText (hWndDlg, idc_sgl_dll_version, versions->library);
			SetDlgItemText (hWndDlg, idc_sgl_api_version, versions->required_header);
			SetDlgItemText (hWndDlg, idc_sgl_vxd_rev, w32versions->sgl_vxd_rev);
			SetDlgItemText (hWndDlg, idc_sgl_win32_api_version, w32versions->required_sglwin32_header);
			SetDlgItemText (hWndDlg, idc_pci_bridge_vendor_id, w32versions->pci_bridge_vendor_id);
			SetDlgItemText (hWndDlg, idc_pci_bridge_device_id, w32versions->pci_bridge_device_id);
			SetDlgItemText (hWndDlg, idc_pci_bridge_rev, w32versions->pci_bridge_rev);
			SetDlgItemText (hWndDlg, idc_pci_bridge_irq, w32versions->pci_bridge_irq);
			SetDlgItemText (hWndDlg, idc_pci_bridge_io_base, w32versions->pci_bridge_io_base);
			SetDlgItemText (hWndDlg, idc_tsp_rev, w32versions->tsp_rev);
			SetDlgItemText (hWndDlg, idc_tsp_mem_size, w32versions->tsp_mem_size);
			SetDlgItemText (hWndDlg, idc_isp_rev, w32versions->isp_rev);
			SetDlgItemText (hWndDlg, idc_mode, w32versions->mode);
			SetDlgItemText (hWndDlg, idc_status, w32versions->status);
			SetDlgItemText (hWndDlg, idc_build_info, w32versions->build_info);
			break;
		}

		default:
		{
			return FALSE;
		}
	}
	return TRUE;
}


#define TEXT_ERR(x) case x : szErrorText = #x; break;

void ReportSglError(int errorNo)
{
	char* szErrorText;
	char szErrorBuffer[80];

	/* Test for Direct Draw error codes in ddraw.h */
	switch (errorNo)
	{
		TEXT_ERR(sgl_err_no_mem)
		TEXT_ERR(sgl_err_no_name)
		TEXT_ERR(sgl_err_bad_name)
		TEXT_ERR(sgl_err_bad_parameter)
		TEXT_ERR(sgl_err_cyclic_reference)
		TEXT_ERR(sgl_err_list_too_deep)
		TEXT_ERR(sgl_err_too_many_planes)
		TEXT_ERR(sgl_err_no_convex)
		TEXT_ERR(sgl_err_no_mesh)
		TEXT_ERR(sgl_err_bad_index)
		TEXT_ERR(sgl_err_failed_init)
		TEXT_ERR(sgl_err_bad_device)
		TEXT_ERR(sgl_err_texture_memory_full)
		TEXT_ERR(sgl_err_colinear_plane_points)
		TEXT_ERR(sgl_err_ddraw_not_available)
		TEXT_ERR(sgl_err_mode_already_defined)
		TEXT_ERR(sgl_err_insufficient_surface_memory)
		TEXT_ERR(sgl_err_graphics_not_capable)
		TEXT_ERR(sgl_err_display_mode_not_supported)
		TEXT_ERR(sgl_err_illegal_address)
		TEXT_ERR(sgl_err_bad_hwnd)
		TEXT_ERR(sgl_err_bad_ddraw_vblank)
		TEXT_ERR(sgl_err_bad_ddraw_flip_status)
		TEXT_ERR(sgl_err_bad_ddraw_flip)
		TEXT_ERR(sgl_err_bad_ddraw_vblank_status)
		TEXT_ERR(sgl_err_bad_ddraw_vblank_wait)
		TEXT_ERR(sgl_err_bad_ddraw_restore)
		TEXT_ERR(sgl_err_bad_ddraw_lock)
		TEXT_ERR(sgl_err_bad_ddraw_unlock)
		TEXT_ERR(sgl_err_bad_ddraw_bltfill)
		TEXT_ERR(sgl_err_bad_ddraw_close)
		TEXT_ERR(sgl_err_bad_ddraw_getcaps)
		TEXT_ERR(sgl_err_bad_ddraw_cooperate)
		TEXT_ERR(sgl_err_bad_ddraw_modechange)
		TEXT_ERR(sgl_err_in_address_callback)
		TEXT_ERR(sgl_err_graphics_locked_out)
		TEXT_ERR(sgl_err_pixel_format_not_supported)

		default :
		{
			sprintf (szErrorBuffer,"Error not recognised : 0x%08Xl\n", errorNo);
			szErrorText = szErrorBuffer;
		}
	}

	MessageBox (NULL, szErrorText, NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);

}

/* EOF */
