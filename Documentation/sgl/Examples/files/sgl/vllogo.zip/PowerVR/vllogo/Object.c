/*****************************************************************************
 *;++
 * Name           : $RCSfile: object.c $
 * Title          : DLOBJECT.C
 * C Author       : Jim Page, Edward Forde
 * Created        : 21/04/95
 *
 * Copyright      : 1995 by VideoLogic Limited. All rights reserved.
 *                  No part of this software, either material or conceptual 
 *                  may be copied or distributed, transmitted, transcribed,
 *                  stored in a retrieval system or translated into any 
 *                  human or computer language in any form by any means,
 *                  electronic, mechanical, manual or other-wise, or 
 *                  disclosed to third parties without the express written
 *                  permission of VideoLogic Limited, Unit 8, HomePark
 *                  Industrial Estate, King's Langley, Hertfordshire,
 *                  WD4 8LZ, U.K.
 *
 * Description    :     SGL predefined 3d primitive objects
 *                   
 * Program Type   :     C (SGL cross-platform)
 *
 * History		  :
 *
 * $Log:	object.c $
 * Revision 1.1  96/11/15  09:32:51  EdwardForde
 * Initial revision
 * 
 * 
 *;--
 *****************************************************************************/
/*
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * ++	                           includes                                      ++
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 */     

#include <math.h>
#include <malloc.h>
#include "sgl.h"

#define PI				3.141592f
#define TWOPI			(2.0f * PI)
#define ONEOVERTWOPI	(1.0f / TWOPI)

int create_rectprism (	float x, float y, float z, sgl_bool bName, sgl_bool bTexture, sgl_bool bHidden);
int create_prism (		float height, float radius, int num_sides, sgl_bool bName, 
						sgl_bool bSmoothShade, sgl_bool bTexture);
int create_sphere (		int sph_type, float radius, int num_sides, sgl_bool bName, 
						sgl_bool bSmoothShade, sgl_bool bTexture);
int create_extruded_poly (int numpoints, float point_list[][2], float depth, sgl_bool bName,
						sgl_bool bSmoothShade, sgl_bool bTexture);
static void vCircumCentre(sgl_2d_vec centre, sgl_2d_vec P1, sgl_2d_vec P2, sgl_2d_vec P3);
static void vCircumNormal(sgl_vector normal, sgl_vector point, int i, int nopoints, 
sgl_2d_vec *circ_cent);
static float fAngle(sgl_2d_vec P, sgl_2d_vec R, sgl_2d_vec Q);
static float fBoundingCircle(sgl_2d_vec centre, sgl_2d_vec *pt, int npts);
static float fCircAngle(float x, float y);



/*
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * ++	                		SGL internal entry points	                     ++
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 */	

/* U value is the angle  around the x-y circle */
static float fCalcU(sgl_vector x)
{
	float ans;

	ans = (float) (atan2(x[1], x[0]) / TWOPI);
	if(ans < 0.0f) /* make answer between 0 and 2PI rather than -PI and PI */
	{
		ans+=1.0f;
	}
	return (1.0f-ans); 
}

/*===========================================
 * Function:	sgl_create_rectprism
 *===========================================
 *
 * Scope:		SGL
 * Authors:		Jim Page (initial code)
 *			Paul Hurley (Texturing)
 *
 * Purpose:		Creates a rectangular prism using top-level SGL commands
 *
 * Params:		float x, y, z: dimensions
 *			sgl_bool bName: TRUE if object is to have a name, FALSE if anonymous
 *			sgl_bool bTexture: TRUE then the rectprism will be textured
 *
 * Return:		+ve name or -ve error
 *
 * Globals accessed:   none
 *========================================================================================*/
int create_rectprism (float x, float y, float z, sgl_bool bName, sgl_bool bTexture, sgl_bool bHidden)
{
	int nErr;

	if (x <= 0.0f)
	{
		nErr = sgl_err_bad_parameter;
	}
	else if (y <= 0.0f)
	{
		nErr = sgl_err_bad_parameter;
	}
	else if (z <= 0.0f)
	{
		nErr = sgl_err_bad_parameter;
	}
	else
	{
		sgl_vector rep_pt;

		/* Check is hidden convex required.
		 */
		if (bHidden)
			nErr = sgl_create_hidden_convex (bName);
		else
			nErr = sgl_create_convex (bName);
		
		if (nErr < 0)
		{
			nErr;
		}
		else
			if( bTexture )
			{
			sgl_vector v2, v3;
			sgl_2d_vec 	rep_pt_uv={0.5f, 0.5f}, 
					v2_uv={0.0f, 0.0f}, 
					v3_uv={0.0f, 1.0f};

			/* front plane */
			rep_pt[0]=0.0f;
			rep_pt[1]=0.0f;
			rep_pt[2]=-0.5f*z;
			v2[0]=-0.5f*x;
			v2[1]=-0.5f*y;
			v2[2]=-0.5f*z;
			v3[0]=-0.5f*x;
			v3[1]=0.5f*y;
			v3[2]=-0.5f*z;
			sgl_add_plane(rep_pt, v2, v3, FALSE, NULL,NULL,NULL, rep_pt_uv, v2_uv, v3_uv);

			/* back plane */
			rep_pt[2]=0.5f*z;
			v2[2]=0.5f*z;
			v3[2]=0.5f*z;
			v2_uv[0]=1.0f;
			v3_uv[0]=1.0f;
			sgl_add_plane(rep_pt, v3, v2, FALSE, NULL,NULL,NULL, rep_pt_uv, v3_uv, v2_uv);

			/* top plane */
			rep_pt[0]=0.0f; 
			rep_pt[1]=0.5f*y;
			rep_pt[2]=0.0f;
			v2[0]=0.5f*x;
			v2[1]=0.5f*y;
			v2[2]=-0.5f*z;
			v3[0]=-0.5f*x;
			v3[1]=0.5f*y;
			v3[2]=-0.5f*z;
			rep_pt_uv[1]=0.5f;
			v2_uv[1]=0.0f;
			v3_uv[1]=0.0f;
			rep_pt_uv[0]=fCalcU(rep_pt);
			v2_uv[0]=fCalcU(v2);
			v3_uv[0]=fCalcU(v3);
			sgl_add_plane(rep_pt, v2, v3, FALSE, NULL,NULL,NULL, rep_pt_uv, v2_uv, v3_uv);

			/* bottom plane */ 
			rep_pt[1]=-0.5f*y;
			v2[1]=-0.5f*y;
			v3[1]=-0.5f*y;
			rep_pt_uv[0]=fCalcU(rep_pt);
			v2_uv[0]=fCalcU(v2);
			v3_uv[0]=fCalcU(v3);
			sgl_add_plane(rep_pt, v3, v2, FALSE, NULL,NULL,NULL, rep_pt_uv, v3_uv, v2_uv);

			/* left plane */
			rep_pt[0]=-0.5f*x; 
			rep_pt[1]=0.0f;
			rep_pt[2]=0.0f;
			v2[0]=-0.5f*x;
			v2[1]=-0.5f*y;
			v2[2]=0.5f*z;
			v3[0]=-0.5f*x;
			v3[1]=0.5f*y;
			v3[2]=0.5f*z;
			rep_pt_uv[1]=0.5f;
			v2_uv[1]=1.0f;
			v3_uv[1]=1.0f;
			rep_pt_uv[0]=fCalcU(rep_pt);
			v2_uv[0]=fCalcU(v2);
			v3_uv[0]=fCalcU(v3);
			sgl_add_plane(rep_pt, v2, v3, FALSE, NULL,NULL,NULL, rep_pt_uv, v2_uv, v3_uv);

			/* right plane */
			rep_pt[0]=0.5f*x; 
			v2[0]=0.5f*x;
			v3[0]=0.5f*x;
			rep_pt_uv[0]=fCalcU(rep_pt);
			v2_uv[0]=fCalcU(v2);
			v3_uv[0]=fCalcU(v3);
			sgl_add_plane(rep_pt, v3, v2, FALSE, NULL,NULL,NULL, rep_pt_uv, v3_uv, v2_uv);
			}
			else
			{
				/*
				// define the normals for the rectangular prism
				*/
				sgl_vector normals[6] = {{ 1.0f, 0.0f, 0.0f},
									 	{-1.0f, 0.0f, 0.0f},
										{ 0.0f, 1.0f, 0.0f},
										{ 0.0f,-1.0f, 0.0f},
									 	{ 0.0f, 0.0f, 1.0f},
									 	{ 0.0f, 0.0f,-1.0f}};
				int i;
				int surface;
		
				/*
				// The sizes packed into one array, for programming convenience
				*/
				sgl_vector	xyz;
#if 0
				if(bTexture)  shrink wrap object - note this has not been tested!*/
				{
					sgl_set_omap(sgl_omap_inter_normal,0);

					sgl_set_smap(sgl_smap_cylinder,1.0f,1.0f,0.0f,0.0f,0.5f*sqrt(z*z+x*x));
				}
#endif
				/*
				// get half the dimensions
				*/
				xyz[0] = x * 0.5f;
				xyz[1] = y * 0.5f;
				xyz[2] = z * 0.5f;

				/*
				// Process all the surfaces
				*/
				for(surface = 0; surface < 6; surface ++)
				{
					/*
					// Copy the surfaces normals, and calculate the surface rep point
					*/
					for(i = 0; i < 3; i++)
					{
						/*
						// The following is a little inefficient - but who cares..
						*/
						rep_pt[i] = normals[surface][i] * xyz[i];
					}
		
					sgl_add_simple_plane (rep_pt, normals[surface], FALSE);
				}
			}
		}

	return (nErr);
}

/*===========================================
 * Function:	sgl_create_prism
 *===========================================
 *
 * Scope:		SGL
 *
 * Authors:		Jim Page (initial code)
 *				Paul Hurley (smooth shading and texturing)
 *
 * Purpose:		Generates a prism with given radius and height, and with the
 *				given number of sides using top level SGL calls. The axis of
 *				the prism lies on the y axis.
 *
 * Params:		float 		height, radius: dimensions
 * 				int			num_sides: dimensions
 *				sgl_bool 	bName: TRUE if object is to have a name, FALSE if anonymous
 *				sgl_bool bSmoothShade: TRUE if to smooth shade the prism
 *				sgl_bool bTexture: TRUE then the prism is textured.
 *
 * Return:		+ve name or -ve error
 *
 * Globals accessed:   none
 *========================================================================================*/
int create_prism (float height, float radius, int num_sides, sgl_bool bName, 
  sgl_bool bSmoothShade, sgl_bool bTexture)
{
	int nErr;

	if (height <= 0.0f)
	{
		nErr = sgl_err_bad_parameter;
	}
	else if (radius <= 0.0f)
	{
		nErr = sgl_err_bad_parameter;
	}
	else if (num_sides < 3)
	{
		nErr = sgl_err_bad_parameter;
	}
	else
	{
		int i;  /* to count through number of sides */
	
		sgl_vector end_normals[2] = {{ 0.0f, 1.0f, 0.0f},
									 { 0.0f,-1.0f, 0.0f}};
	
		/*
		// Arrays of plane data that are passed to the add_planes routine
		*/
		sgl_vector normal;
		sgl_vector rep_pt;
	
		float angle;
	
		nErr = sgl_create_convex (bName);
		
		if (nErr < 0)
		{
			nErr;
		}
		else 
		{
			sgl_vector prev,curr;
			sgl_2d_vec prev_uv, curr_uv, rep_pt_uv;
			/*
			// do the sides - y component of normal is 0.0
			*/
			normal[1] = 0.0f;
			rep_pt[1] = height/2.0f;
			curr[1]=0.0f; 
			prev[1]=0.0f;

			angle = (TWOPI * (num_sides-1) ) / num_sides;
			prev[0]= (float) (cos(angle)*radius);
			prev[2]= (float) (sin(angle)*radius);

			prev_uv[0]=((float) (num_sides-1))/num_sides;
			prev_uv[1]=0.5f;
			curr_uv[1]=0.5f;
			rep_pt_uv[1]=1.0f;
		
			for(i = 0; i < num_sides; i++)
			{
				angle = (TWOPI * i) / num_sides;
				if (bSmoothShade || bTexture)
				{
					curr[0]= (float) (cos(angle)*radius);
					curr[2]= (float) (sin(angle)*radius);
					curr_uv[0]=((float) i)/num_sides;

					rep_pt[0]=(curr[0]+prev[0])/2.0f;
					rep_pt[2]=(curr[2]+prev[2])/2.0f;
					rep_pt_uv[0]=(curr_uv[0]+prev_uv[0])/2.0f;

					if (bSmoothShade)
					{
						if (bTexture)
						{
							sgl_add_plane(rep_pt, curr, prev, FALSE,
							  rep_pt,curr,prev, rep_pt_uv,curr_uv,prev_uv);
						}
						else
						{
							sgl_add_plane(rep_pt, curr, prev, FALSE,
							  rep_pt,curr,prev, NULL,NULL,NULL);
						}
					}
					else
					{
						/* bTexture must be TRUE */
						sgl_add_plane(rep_pt, curr, prev, FALSE,
						  NULL,NULL,NULL, rep_pt_uv,curr_uv,prev_uv);
					}

					prev[0]=curr[0];
					prev[2]=curr[2];
					prev_uv[0]=curr_uv[0];
				}
				else
				{
					/*
					// Calculate the normal
					*/
					normal[0] = (float) cos(angle);
					normal[2] = (float) sin(angle);
	
					rep_pt[0] = normal[0] * radius;
					rep_pt[2] = normal[2] * radius;
					sgl_add_simple_plane (rep_pt, normal, FALSE);
				}
			}

			/*
			// Do the top
			*/
			rep_pt[0] = 0.0f;
			rep_pt[1] = height / 2.0f;
			rep_pt[2] = 0.0f;
		
			if(bTexture)
			{
				curr[0]=0.0f;
				curr[1]=height/2.0f; 
				curr[2]=radius;

				prev[0]=radius;
				prev[1]=height/2.0f;
				prev[2]=0.0f;

				rep_pt_uv[0]=0.5f;
				rep_pt_uv[1]=0.5f;

				curr_uv[0]=0.5f;
				curr_uv[1]=1.0f;

				prev_uv[0]=1.0f;
				prev_uv[1]=0.5f;
	
				sgl_add_plane(rep_pt,curr,prev, FALSE, NULL,NULL,NULL,
				  rep_pt_uv,curr_uv,prev_uv);

				/* now do the bottom */

				rep_pt[1]*=-1.0f;
				curr[1]*=-1.0f;
				prev[1]*=-1.0f;
				sgl_add_plane(rep_pt,prev,curr, FALSE, NULL,NULL,NULL,
				  rep_pt_uv,curr_uv,prev_uv);
			}
			else
			{
				sgl_add_simple_plane (rep_pt, end_normals[0], FALSE);
				/*
				// Do the bottom
				*/
				rep_pt[1] *= -1;
		
				sgl_add_simple_plane (rep_pt, end_normals[1], FALSE);
			}
		
			
		}
	}

	return (nErr);
}

/*===========================================
 * Function:	sgl_create_sphere
 *===========================================
 *
 * Scope:		SGL
 * Author:		Jim Page
 *
 *
 * Purpose:		Generates a sphere with given radius, and with the
 *				given number of sides (for quarter of equator).
 *				The axis of the sphere lies on the y axis.
 *
 * Params:		int 		sph_type:	if TRUE generates sphere with decreasing
 *										faces towards sphere poles.
 *				float 		radius,
 *				int 		num_sides
 *				sgl_bool 	bName: TRUE if object is to have a name, FALSE if anonymous
 *				sgl_bool 	bSmoothShade: TRUE to smooth shade, FALSE to flat shade
 *				sgl_bool 	bTexture: TRUE to texture
 *
 * Return:		+ve name or -ve error
 *
 * Globals accessed:   none
 *========================================================================================*/
int create_sphere (int sph_type, float radius, int num_sides, sgl_bool bName, 
  sgl_bool bSmoothShade, sgl_bool bTexture)
{
	int nErr;

	if (radius <= 0.0f)
	{
		nErr = sgl_err_bad_parameter;
	}
	else if (num_sides < 1)
	{
		nErr = sgl_err_bad_parameter;
	}
	else
	{
		#if 1
		
		nErr = sgl_create_convex (bName);
		
		if (nErr < 0)
		{
			nErr;
		}
		else
		{
			float ang_step, half_step, cur_ang, up_ang, up_ang_step,
				    up_half_step;
			int curside, upside, versides, n_sides;
			
			versides = num_sides;

			n_sides = 4*num_sides;
		
   			up_ang_step = TWOPI / n_sides;
	   		up_half_step = up_ang_step * 0.5f;
		
			for (upside = 0; upside < versides; upside++)
			{
   				up_ang = up_ang_step * upside;

				for (curside = 0; curside < n_sides; curside++)
				{
		   			ang_step = TWOPI / n_sides;
	  		 		half_step = ang_step * 0.5f;
		
					cur_ang = ang_step * curside;
		
					if (bSmoothShade || bTexture)
					{
						sgl_vector s[4];
						sgl_2d_vec u[4];

						/* make up 3 points on the sphere facet */
												
						s[0][0] = (float) (radius * cos (cur_ang) * cos (up_ang + up_ang_step));
						s[0][2] = (float) (radius * sin (cur_ang) * cos (up_ang + up_ang_step));
						s[0][1] = (float) (radius * sin (up_ang + up_ang_step));

						s[1][0] = (float) (radius * cos (cur_ang + ang_step) * cos (up_ang + up_ang_step));
						s[1][2] = (float) (radius * sin (cur_ang + ang_step) * cos (up_ang + up_ang_step));
						s[1][1] = (float) (radius * sin (up_ang + up_ang_step));

						s[2][0] = (float) (radius * cos (cur_ang) * cos (up_ang));
						s[2][2] = (float) (radius * sin (cur_ang) * cos (up_ang));
						s[2][1] = (float) (radius * sin (up_ang));

						s[3][0] = (float) (radius * cos (ang_step + cur_ang) * cos (up_ang));
						s[3][2] = (float) (radius * sin (ang_step + cur_ang) * cos (up_ang));
						s[3][1] = (float) (radius * sin (up_ang));
						
						if(s[0][1]!=s[1][1]) 
						{
							s[1][0] *= 0.95f;
							s[1][1] *= 0.95f;
							s[1][2] *= 0.95f;
							s[2][0] *= 0.95f;
							s[2][1] *= 0.95f;
							s[2][2] *= 0.95f;
						}
						
						u[0][0] = (float) (ONEOVERTWOPI * (cur_ang));
						u[0][1] = (float) (0.5f * (1.0f + (sin (up_ang + up_ang_step))));

						u[1][0] = (float) (ONEOVERTWOPI * (cur_ang + ang_step));
						u[1][1] = (float) (0.5f * (1.0f + (sin (up_ang + up_ang_step))));

						u[2][0] = (float) (ONEOVERTWOPI * (cur_ang));
						u[2][1] = (float) (0.5f * (1.0f + (sin (up_ang))));

						u[3][0] = (float) (ONEOVERTWOPI * (cur_ang + ang_step));
						u[3][1] = (float) (0.5f * (1.0f + (sin (up_ang))));

						/* top hemisphere ... */
						
						if (bSmoothShade)
						{
							if (bTexture)
							{
								sgl_add_plane (s[0],s[1],s[2], FALSE,
								  s[0],s[1],s[2], u[0],u[1],u[2]);
							}
							else
							{
								sgl_add_plane (s[0],s[1],s[2], FALSE,
								  s[0],s[1],s[2], NULL,NULL,NULL);
							}
						}
						else
						{
							/* bTexture must be TRUE */
							sgl_add_plane (s[0],s[1],s[2], FALSE,
							  NULL,NULL,NULL, u[0],u[1],u[2]);
						}
			 			
						if (s[0][1] != s[1][1])
						{
							if (bSmoothShade)
							{
								if (bTexture)
								{
				 					sgl_add_plane (s[1],s[3],s[2], FALSE,
									  s[1],s[3],s[2], u[1],u[3],u[2]);
								}
								else
								{
									sgl_add_plane (s[1],s[3],s[2], FALSE,
									  s[1],s[3],s[2], NULL,NULL,NULL);
								}
							}
							else
							{
								/* bTexture must be TRUE */
								sgl_add_plane (s[1],s[3],s[2], FALSE,
								  NULL,NULL,NULL, u[1],u[3],u[2]);
							}
						}

						/* bottom hemisphere. Don't forget to reverse the direction of the face */
						s[0][1] = -s[0][1];
						s[1][1] = -s[1][1];
						s[2][1] = -s[2][1];
						s[3][1] = -s[3][1];

						u[0][1] = - u[0][1];
						u[1][1] = - u[1][1];
						u[2][1] = - u[2][1];
						u[3][1] = - u[3][1];

						if (bSmoothShade)
						{
							if (bTexture)
							{
								sgl_add_plane (s[0],s[2],s[1], FALSE,
								  s[0],s[2],s[1], u[0],u[2],u[1]);
							}
							else
							{
								sgl_add_plane (s[0],s[2],s[1], FALSE,
								  s[0],s[2],s[1], NULL,NULL,NULL);
							}
						}
						else
						{
							/* bTexture must be TRUE */
							sgl_add_plane (s[0],s[2],s[1], FALSE,
							  NULL,NULL,NULL, u[0],u[2],u[1]);
						}

						if (s[0][1]!=s[1][1]) 
						{
							if (bSmoothShade)
							{
								if (bTexture)
								{
				 					sgl_add_plane (s[1],s[2],s[3], FALSE,
									  s[1],s[2],s[3], u[1],u[2],u[3]);
								}
								else
								{
									sgl_add_plane (s[1],s[2],s[3], FALSE,
									  s[1],s[2],s[3], NULL,NULL,NULL);
								}
							}
							else
							{
								/* bTexture must be TRUE */
								sgl_add_plane (s[1],s[2],s[3], FALSE,
								  NULL,NULL,NULL, u[1],u[2],u[3]);
							}
						}
					}
					else
					{
						sgl_vector  domeside;
	
						domeside[0] = (float) (radius * cos (half_step + cur_ang) * cos (up_half_step + up_ang));
						domeside[2] = (float) (radius * sin (half_step + cur_ang) * cos (up_half_step + up_ang));
						domeside[1] = (float) (radius * sin (up_half_step + up_ang));
			
						sgl_add_simple_plane (domeside, domeside, FALSE);
						
						domeside[1] = -domeside[1];                      
			
						sgl_add_simple_plane (domeside, domeside, FALSE);
					}
				}

	     		if (sph_type)
				{
	            	n_sides-=4;
				}
			}
    	}
		#else

		sgl_vector *vVertices;
		int nArraySize = 2 + (((num_sides * 2) - 1) * num_sides * 4);

		vVertices = malloc (nArraySize * sizeof (sgl_vector));
		
		if (vVertices)
		{
			int j, k;
			int	nF;
			int num_horz_sides = num_sides * 4;
			int num_vert_sides = (num_sides * 2) - 1;
			float ang, up_ang, ang_step = TWOPI / (4.0f * num_sides);
						
			nF = 0;
			
			vVertices[0][0] = 0;
			vVertices[0][1] = -radius;
			vVertices[0][2] = 0;

			vVertices[nArraySize - 1][0] = 0;
			vVertices[nArraySize - 1][1] = radius;
			vVertices[nArraySize - 1][2] = 0;

			nF++;

			up_ang = ang_step - PI;
			
			for (j = 0; j < num_vert_sides; ++j)
			{
				float CosUpAng = cos (up_ang);
				float SinUpAng = sin (up_ang);

				ang = 0.0f;
				
				for (k = 0; k < num_horz_sides; ++k)
				{
					float CosAng = cos (ang);
					float SinAng = sin (ang);

					vVertices[nF][0] = radius * CosAng * CosUpAng;
					vVertices[nF][1] = radius * SinUpAng;
					vVertices[nF][2] = radius * SinAng * CosUpAng;

					nF++;

					ang += ang_step;
				}

				up_ang += ang_step;
			}
			
			ASSERT (nF == nArraySize - 1);
			
			nErr = sgl_create_mesh (bName);

			if (nErr >= sgl_no_err)
			{
				sgl_add_vertices (nArraySize, vVertices, vVertices, NULL);
			}

			for (j = 0; j < num_vert_sides; ++j)
			{
				for (k = 0; k < num_horz_sides; ++k)
				{
					int vFace[4];
					int nRowPos = (j * num_horz_sides) + 1;

					if (j == 0)
					{
						vFace[0] = 0;
						vFace[1] = nRowPos + k;
						vFace[2] = (k == num_horz_sides - 1) ? nRowPos : nRowPos + k + 1;
						sgl_add_face (3, vFace);
					}
					else if (j == num_vert_sides - 1)
					{
						vFace[0] = (k == num_horz_sides - 1) ? nRowPos - num_horz_sides : (nRowPos - num_horz_sides) + k + 1;
						vFace[1] = vFace[0] - 1;
						vFace[2] = nArraySize - 1;
						sgl_add_face (3, vFace);
					}
				}
			}

			free (vVertices);
		}
		else
		{
			nErr = sgl_err_no_mem;
		}
		
		#endif
	}
	
	return (nErr);
}   

/*===========================================
 * Function:	vCircumCentre
 *===========================================
 *
 * Scope:		static to this module
 * Author:		Paul Hurley
 *															 
 * Purpose:		calculates the circumcentre of a 2-d triangle describe by the vertices P1P2P3.
 *				The algorithm is obtained from p.22 of Graphic Gems I. The circumcentre is the 
 *				point that is equidistant from all 3 points of the triangle.
 *
 * Params:		sgl_2d_vec centre - the resultant centre is stored here.
 *				sgl_2d_vec P1,P2,P3 - the three points that make up the triangle and will 
 *				thus lie on the circle.		
 *
 * Return:		the radius of the resultant circle.
 *
 * Globals accessed:   none
 *========================================================================================*/
static void vCircumCentre(sgl_2d_vec centre, sgl_2d_vec P1, sgl_2d_vec P2, sgl_2d_vec P3)
{
	float d1,d2,d3,c1,c2,c3,c_2;

	/* d1= (P3-P1).(P2-P1) */
	d1= (P3[0]-P1[0])*(P2[0]-P1[0])+(P3[1]-P1[1])*(P2[1]-P1[1]);
	/* d2= (P3-P2).(P1-P2) */
	d2= (P3[0]-P2[0])*(P1[0]-P2[0])+(P3[1]-P2[1])*(P1[1]-P2[1]);
	/* d3= (P1-P3).(P2-P3) */
	d3= (P1[0]-P3[0])*(P2[0]-P3[0])+(P1[1]-P3[1])*(P2[1]-P3[1]);
	c1=d2*d3; /* c1=d2d3 */
	c2=d3*d1; /* c2=d3d1 */
	c3=d1*d2; /* c3=d1d2 */
	
	c_2=0.5f/(c1+c2+c3); /* 1/(2c) where c=c1+c2+c3; */

	/* centre=1/(2c)*((c2+c3)P1+(c3+c1)P2+(c1+c2)P3) */
	centre[0]=c_2*((c2+c3)*P1[0]+(c3+c1)*P2[0]+(c1+c2)*P3[0]);
	centre[1]=c_2*((c2+c3)*P1[1]+(c3+c1)*P2[1]+(c1+c2)*P3[1]);
} 


/*===========================================
 * Function:	vCircumNormal
 *===========================================
 *
 * Scope:		static to this module
 * Author:		Paul Hurley
 *															 
 * Purpose:		
 *
 * Params:		sgl_vector normal: 
 * 				sgl_vector point
 * 				int i
 *				int nopoints
 *				sgl_2d_vec *circ_cent
 *
 * Return:		
 *
 * Globals accessed:   none
 *========================================================================================*/
static void vCircumNormal(sgl_vector normal, sgl_vector point, int i, int nopoints, 
sgl_2d_vec *circ_cent)
{
 	if(i%2!=0) /* if an odd vertex then it must lie in the centre of one of our triangles */
	{
		/* 
		// normal is vector from circum centre to point 
		*/
		normal[0]=point[0]-circ_cent[(i-1)/2][0];
		normal[1]=point[1]-circ_cent[(i-1)/2][1];
	}
	else
	{
		/* 
		// normal is average of the 2 unit vectors from the two circumcircles that the point is in.
		*/
		sgl_2d_vec v;
		float len[2];

		int nPrev= (i==0) ? (nopoints-1)/2:i/2-1;
		
		v[0]=point[0]-circ_cent[nPrev][0];
		v[1]=point[1]-circ_cent[nPrev][1];
		len[0]=(float) (1/sqrt(v[0]*v[0]+v[1]*v[1]));
		v[0]=point[0]-circ_cent[i/2][0];
		v[1]=point[1]-circ_cent[i/2][1];
		len[1]=(float) (1/sqrt(v[0]*v[0]+v[1]*v[1]));

		normal[0]=0.5f*((len[0]+len[1])*point[0]-
		  (len[0]*circ_cent[nPrev][0]+len[1]*circ_cent[i/2][0]));
		normal[1]=0.5f*((len[0]+len[1])*point[1]-
		  (len[0]*circ_cent[nPrev][1]+len[1]*circ_cent[i/2][1]));	
	}
}

/*===========================================
 * Function:	fAngle
 *===========================================
 *
 * Scope:		static to this module
 * Author:		Paul Hurley
 *															 
 * Purpose:		Determines the angle PRQ using Cos theta= PR.QR / |PR||QR|. Note that another
 * 				way (not used here) to get the angle is that 
 *				Tan theta= (m1-m2)/(1+m1m2) where m1,m2 are slopes of the lines PR and RQ.
 *
 * Params:		sgl_2d_vec P, R, Q - the 3 2-D points, with the angle at R.
 *
 * Return:		the resultant angle in radians.
 *
 * Globals accessed:   none
 *========================================================================================*/
static float fAngle(sgl_2d_vec P, sgl_2d_vec R, sgl_2d_vec Q)
{
	sgl_2d_vec PR,QR;
	float fLen,ans;

	/* determine vectors PR and PQ */
	PR[0]=R[0]-P[0]; PR[1]=R[1]-P[1];
	QR[0]=R[0]-Q[0]; QR[1]=R[1]-Q[1];
	   
	fLen= (float) sqrt((PR[0]*PR[0]+PR[1]*PR[1])*(QR[0]*QR[0]+QR[1]*QR[1]));

	if( fLen==0 ) /* P=R or R=Q */
	{
		/* angle is 180 degrees */
		return PI;
	}

	/* note no divide by zero since fLen!=0 by above P=R/R=Q check */
	ans=(float) acos((PR[0]*QR[0]+PR[1]*QR[1])/fLen);
	return ans;
}

/*===========================================
 * Function:	fBoundingCircle
 *===========================================
 *
 * Scope:		static to this module
 * Author:		Paul Hurley
 *															 
 * Purpose:		For a given number of 2-d Points, the smallest bounding circle is obtained. 
 *				See Graphics Gems II p.14 for details of the algorithm used. 
 *
 * Params:		sgl_2d_vec centre - the resultant centre of the bounding circle is stored here.
 *				sgl_2d_vec *pt - the 2-D points.
 				int npts - the number of 2-D points
 *
 * Return:		the radius of the resultant circle.
 *
 * Globals accessed:   none
 *========================================================================================*/
static float fBoundingCircle(sgl_2d_vec centre, sgl_2d_vec *pt, int npts)
{
	/* A bounding circle is obtained from two or three points. These store the possible points */
	sgl_2d_vec P,Q,R;

	int i; /* counter */

	float fMinAngle, fCurAngle;
	
	/* determine P - the point with minimum x coordinate */
	P[0]=pt[0][0]; P[1]=pt[0][1]; /* let P=1st point */
	for(i=1;i<npts;i++)
	{
		if(pt[i][0]<P[0]) /* if x-coord is smaller */
		{
			P[0]=pt[i][0]; /* then it become the new 'P' */
			P[1]=pt[i][1];
		}
	}

	/* 
	// determine Q - the point such that the angle of PQ with x-axis is minimal 
	// angle with x axis is given by arctan(m) where m is the slope of the line PQ 
	// being careful not to calculate the slope of 0/0 
	*/
	Q[0]=pt[0][0]; Q[1]=pt[0][1]; /* let Q=1st point */

	if(Q[1]==P[1] && Q[0]==P[0]) /* if Q=P */
	{
		fMinAngle=1000.0f; /* just make it too large */
	}
	else
	{
		fMinAngle=(float) atan2(Q[1]-P[1],Q[0]-P[0]); /* slope of QP */
	}

	for(i=1;i<npts;i++)
	{
		if(pt[i][1]!=P[1] || pt[i][0]!=P[0]) /* only proceed if pt[i]!=P */
		{
			fCurAngle= (float) atan2(pt[i][1]-P[1],pt[i][0]-P[0]); 
			if(fCurAngle<fMinAngle) /* angle is smaller */
			{
				Q[0]=pt[i][0]; /* so pt[i] become the new 'Q' */
				Q[1]=pt[i][1];
				fMinAngle=fCurAngle;
			}
		}
	}

#define SGL_IS_BUGGED	TRUE

	while( SGL_IS_BUGGED ) /* infinite loop */
	{
		/* determine R - the point such that the abs value of the angle PRQ is minimal */
		R[0]=pt[0][0]; R[1]=pt[0][1]; /* let R=1st point */
		fMinAngle= (float) fabs(fAngle(P,R,Q)); /* |angle PRQ| */
		for(i=1;i<npts;i++)
		{
			fCurAngle= (float) fabs(fAngle(P,pt[i],Q));
	
			if(fCurAngle<fMinAngle) /* if |angle| is smaller */
			{
				R[0]=pt[i][0]; /* pt[i] become the new R */
				R[1]=pt[i][1];
				fMinAngle=fCurAngle;
			}
		}

		/* if angle PRQ is obtuse */
		if( (fAngle(P,R,Q)) > PI/2 ) /* being quite lazy by recalculating angle */
		{																	  
			/* bounding circle is given by 2 points P and Q. R isn't involved. */
			centre[0]=(P[0]+Q[0])/2;
			centre[1]=(P[1]+Q[1])/2;
			break; /* we're done */
		}
		/* else if angle PQR is obtuse */
		else if( fAngle(P,Q,R) > PI/2 )
		{
			/* replace Q by R and look for a new R (by repeating loop) */
			Q[0]=R[0]; Q[1]=R[1];
		}
		/* else if angle RPQ is obtuse */
		else if( fAngle(R,P,Q) > PI/2 ) /* being incredibily lazy and not just subtracting the */
		{								/* previous 2 angles from PI */
			/* replace P by R and look for a new R */
			P[0]=R[0]; P[1]=R[1];
		}
		/* else PQR triangle has all acute angles */
		else
		{
			/* now know that triangle PQR forms the bounding circle 
			   so obtain the triangle's circumcentre */
			vCircumCentre(centre,P,Q,R);
			break; /* and we're out of here */
		}
  	} /* end while */

	/* returning the radius of the bounding circle */
	return (float) (sqrt( 0.5f*((P[0]-Q[0])*(P[0]-Q[0])+(P[1]-Q[1])*(P[1]-Q[1]))));
}

/* returns the arctan of x/y between 0 and TWOPI
 */
static float fCircAngle(float x, float y)
{
	float at;

	if ((x == 0.0f) || (y == 0.0f))
		at = 0.0f;
	else
	{
		at = (float) atan2(x, y);
		if(at < 0)
			at+=TWOPI;
	}
	return at;
}

/*===========================================
 * Function:	sgl_create_extruded_poly
 *===========================================
 *
 * Scope:		SGL
 * Authors:		Jim Page (initial code)
 *		   		Paul Hurley (smooth shading and texturing)
 *
 * Purpose:		Generates a prism  that is the extrusion of the supplied polygon. The
 *				polygon lies in the xy plane and is extruded back in z. The format of
 *				the list of points is simply an array of xy coordinates,
 *				specified as floats. IT IS ASSUMED THAT THE POINTS ARE SUPPLIED IN
 *				CLOCKWISE ORDER. There must be at least 3 points. NOTE: Currently the
 *				polygon MUST BE CONVEX.
 *
 * Params:		int 		numpoints	
 *				float 		point_list[][2]
 *				float		depth
 *				sgl_bool 	bName: TRUE if object is to have a name, FALSE if anonymous
 *				sgl_bool	bSmoothShade: if TRUE generates smooth normals
 *				sgl_bool 	bTexture: TRUE to texture
 *
 * Return:		+ve name or -ve error
 *
 * Globals accessed:   none
 *========================================================================================*/
int create_extruded_poly (int numpoints, float point_list[][2], float depth, sgl_bool bName,
  sgl_bool bSmoothShade, sgl_bool bTexture)
{
	int nErr;

	if (numpoints < 3)
	{
		nErr = sgl_err_bad_parameter;
	}
	else if (depth <= 0.0f)
	{
		nErr = sgl_err_bad_parameter;
	}
	else if (!point_list)
	{
		nErr = sgl_err_bad_parameter;
	}
	else
	{
		nErr = sgl_create_convex (bName);
		
		if (nErr < 0)
		{
			nErr;
		}
		else
		{
			sgl_2d_vec *c;
			/*
			// Arrays of plane data that are passed to the add_planes routine
			*/
			sgl_vector normal;
			sgl_vector rep_pt, rep_pt_smoothnormal;	
		
			sgl_vector prev, curr, prev_normal, curr_normal;
			sgl_2d_vec polyC, prev_uv, curr_uv, rep_pt_uv;

			float fPolyRadius;
		
			int i;

			/*
			// get the coords of the last point
			*/
			prev[0] = point_list[numpoints -1][0];    
			prev[1] = point_list[numpoints -1][1];

			/*
			// set the z-coords
			*/
			prev[2] = 0.0f;
			curr[2]	= 0.0f;

			fPolyRadius=fBoundingCircle(polyC, point_list, numpoints);				

			if(bTexture || bSmoothShade)
			{
				/*//// 
				// texturing system is as follows:
				// if it's not a flat plane then u is the angle the vector makes with the horizontal of the
				//	centre of the polygon and v represents the depth into the extruded polygon.
				// if it is a flat plane (i.e. front and back plane) then (u,v)=(0.5,0.5) at the polygon centre and
				//	all other points are adjusted accordingly.
				/// */
				curr_uv[1]=prev_uv[1]=0.0f;
				rep_pt_uv[1]=0.5f;   
				prev_uv[0]=ONEOVERTWOPI*fCircAngle(prev[0]-polyC[0],prev[1]-polyC[1]);

				/*////
				// set the z smooth normal's to zero
				/// */
				rep_pt_smoothnormal[2]=0.0f;
				prev_normal[2] = 0.0f;
				curr_normal[2] = 0.0f;
			
				/*////
				// there are 2 types of smooth shading available. Spherical smooth shading is the default.
				// 1. 'Circumcentre' smooth shading: Here the circumcentre of every 2 edges is calculated. Then
				// the normal is the distance from this centre. At the corners the normal is averaged. This shading
				// might reflect the polygon shape better than spherical type.
				// 2. 'Spherical' smooth shading: The normals are the vector of the point from the centre of the 
				// polygon.
				// See function vCircumNormal for more details.
				/// */
				if(bSmoothShade==2)
				{
					/* TODO: avoid the need for this memory allocation by having a c_prev and a c_curr! */
					c= (sgl_2d_vec *) calloc((numpoints+1)/2, sizeof(sgl_2d_vec));
					if(!c)
					{
						return sgl_err_no_mem;
					}
	
					/* calculate the circumcentre for each edge */
					for(i=0;i<numpoints;i+=2)
					{
						vCircumCentre(c[i/2], point_list[i], point_list[(i+1)%numpoints],
					  	point_list[(i+2)%numpoints]);
					}

					/* calculate prev's normal */
					vCircumNormal(prev_normal, prev, numpoints-1, numpoints,c);
				}
				else if( bSmoothShade )
				{
					/* prev's normal is it's vector from the polygon centre (i.e. spherical shading) */
					prev_normal[0]=prev[0]-polyC[0];
					prev_normal[1]=prev[1]-polyC[1];
				}					 
			}
  	
			/*
			// Step through all the points generating
			// the planes that make up the edges
			*/
			for(i = 0; i < numpoints; i++)
			{
				curr[0] = point_list[i][0];
				curr[1] = point_list[i][1];

				/*
				// Choose a representative point
				*/
				rep_pt[0] = (prev[0] + curr[0]) * 0.5f;
				rep_pt[1] = (prev[1] + curr[1]) * 0.5f;
				rep_pt[2] = depth * 0.5f;

				if(bSmoothShade || bTexture)
				{
					curr_uv[0]=ONEOVERTWOPI*fCircAngle(curr[0]-polyC[0],curr[1]-polyC[1]);
					rep_pt_uv[0]=ONEOVERTWOPI*fCircAngle(rep_pt[0]-polyC[0],rep_pt[1]-polyC[1]);
						
					if (bSmoothShade==2)
					{
						vCircumNormal(curr_normal, curr, i, numpoints, c);
						rep_pt_smoothnormal[0]=rep_pt[0]-c[i/2][0];
						rep_pt_smoothnormal[1]=rep_pt[1]-c[i/2][1];
					}
					else if(bSmoothShade)
					{
						curr_normal[0]=curr[0]-polyC[0];
						curr_normal[1]=curr[1]-polyC[1];

						rep_pt_smoothnormal[0]=rep_pt[0]-polyC[0];
						rep_pt_smoothnormal[1]=rep_pt[1]-polyC[1];
					}

					if (bSmoothShade)
					{
						if (bTexture)
						{
							sgl_add_plane(rep_pt, curr, prev, FALSE,
							  rep_pt_smoothnormal, curr_normal, prev_normal,
							  rep_pt_uv, curr_uv, prev_uv);
						}
						else
						{
							sgl_add_plane(rep_pt, curr, prev, FALSE,
							  rep_pt_smoothnormal, curr_normal, prev_normal,
							  NULL,NULL,NULL);
						}
					}
					else
					{
						/* bTexture must be TRUE */
						sgl_add_plane(rep_pt, curr, prev, FALSE,
						  NULL,NULL,NULL,
						  rep_pt_uv, curr_uv, prev_uv);
					}

					/*
					// Update the previous point's smooth shading normal and uv
					*/
					prev_normal[0] = curr_normal[0];
					prev_normal[1] = curr_normal[1];
					prev_uv[0] = curr_uv[0];
				}
				else
				{
					/*
					// calculate the normal
					*/
					normal[0] = prev[1] - curr[1];
					normal[1] = curr[0] - prev[0];
					normal[2] = 0.0f;

					sgl_add_simple_plane (rep_pt, normal, FALSE);
				}
	
				/*
				// Update the previous point
				*/
				prev[0] = curr[0];
				prev[1] = curr[1];
	
			} /*end for*/
		
			/*////
			// the representative point for the ends is the bounding circle centre (=poly centre)
			/// */
			rep_pt[0] = polyC[0];
			rep_pt[1] = polyC[1];
			rep_pt[2] = 0.0f;
	
			/*////
			// Add the front and back planes (different method if no texturing)
			/// */
			if(bTexture)
			{
				/* flat shade but texture */
				curr[0]=point_list[0][0];
				curr[1]=point_list[0][1];
				prev[0]=point_list[1][0];
				prev[1]=point_list[1][1];

				curr_uv[0]=((curr[0]-polyC[0])/fPolyRadius + 1)/2;
				curr_uv[1]=((curr[1]-polyC[1])/fPolyRadius + 1)/2;

				prev_uv[0]=((prev[0]-polyC[0])/fPolyRadius + 1)/2;
				prev_uv[1]=((prev[1]-polyC[1])/fPolyRadius + 1)/2;

				rep_pt_uv[0]=0.5f;
				rep_pt_uv[1]=0.5f;

				/*////
				// Add front plane
				/// */
				sgl_add_plane(rep_pt, curr, prev, FALSE, NULL,NULL,NULL,
				  rep_pt_uv, curr_uv, prev_uv);

				rep_pt[2] = curr[2] = prev[2] = depth;

				/* flip the u- coordinates for the back plane */
				prev_uv[0]=1.0f-prev_uv[0];
				curr_uv[0]=1.0f-curr_uv[0];
				
				/*////
				// Add back plane
				/// */
				sgl_add_plane(rep_pt, prev, curr, FALSE, NULL,NULL,NULL,
				  rep_pt_uv, prev_uv, curr_uv);
			}
			else
			{
				normal[0] =  0.0f;
				normal[1] =  0.0f;
				normal[2] = -1.0f;
				sgl_add_simple_plane (rep_pt, normal, FALSE);

				/*////
				// Add bottom plane
				/// */
				rep_pt[2] = depth;

				normal[0] =  0.0f;
				normal[1] =  0.0f;
				normal[2] =  1.0f;
				sgl_add_simple_plane (rep_pt, normal, FALSE);
			}

			if(bSmoothShade==2) /* used circumcentre shading - return memory */
			{
				free(c);
			}	
		}
	
	}

	return (nErr);
}

