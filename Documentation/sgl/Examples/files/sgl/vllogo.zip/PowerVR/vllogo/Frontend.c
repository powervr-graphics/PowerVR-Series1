/********************************************************************************************
 *	Name		:	frontend.c
 *	Title		:	Windows '95 handler for SGL Test Harness System
 *	Author		:	VideoLogic Limited
 *	Created		:	20/09/1996
 *
 *	Copyright 	:	1995 by VideoLogic Limited. All rights reserved.
 *					No part of this software, either material or conceptual 
 *					may be copied or distributed, transmitted, transcribed,
 *					stored in a retrieval system or translated into any 
 *					human or computer language in any form by any means,
 *					electronic, mechanical, manual or other-wise, or 
 *					disclosed to third parties without the express written
 *					permission of VideoLogic Limited, Unit 8, HomePark
 *					Industrial Estate, King's Langley, Hertfordshire,
 *					WD4 8LZ, U.K.
 *
 *	Description	:	Windows '95 window, menus and message handler.
 *					Full descpition of operation of SGL Test Harness System found
 *					in SGL PowerVR Graphics Library/API Test Harness document.
 *
 *	Platform	:	ANSI compatible
 *
 *	History		:
 *
 * $Log:	frontend.c $
 * Revision 1.7  97/03/10  11:42:24  EDWARDFORDE
 * Enabled strict locking.
 * 
 * Revision 1.6  97/02/19  12:39:35  EDWARDFORDE
 * 1. Enable Stop Animation menu option.
 * 2. Fix Nefertt Set Texture menu option.
 * 
 * Revision 1.5  96/11/28  17:26:15  EdwardForde
 * Insert delay before new application run.
 * Also rendering stopped between loads (safety).
 * 
 * Revision 1.4  96/11/28  16:50:54  EdwardForde
 * Fixed bug so that window clipped if application restarted and
 * window off screen.
 * 
 * Revision 1.3  96/11/22  12:49:28  EdwardForde
 * Added cancel changes to Set Light dialog box.
 * 
 * Revision 1.2  96/11/15  11:13:59  EdwardForde
 * Remove parameters passed to VideoLogicTimerFunc() and NeferttTimerFunc().
 * 
 * Revision 1.1  96/11/15  09:29:47  EdwardForde
 * Initial revision
 * 
 * 
 ********************************************************************************************/

/********************************************************************************************
/*								INCLUDE FILES												*
/********************************************************************************************/

#include <windows.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ddraw.h"
#include "sgl.h"
#include "resource.h"
#include "frontend.h"
#include "vldemo.h"
#include "ddmem.h"

/********************************************************************************************
/*								LOCAL DEFINE DEFINITIONS 									*
/********************************************************************************************/

#define DEFAULT_KEY_COLOUR	8

/********************************************************************************************
/*								EXTERNAL GLOBAL VARIABLES									*
/********************************************************************************************/

/********************************************************************************************
/*								EXTERNAL FUNCTION DEFINITIONS								*
/********************************************************************************************/

extern void SetupVideoLogicLogoDemo	(void);
extern void RunVideoLogicLogoDemo	(sgl_bool bActive);
extern void CloseVideoLogicLogoDemo	(void);
	  
extern void SetupNeferttDemo		(void);
extern void RunNeferttDemo			(sgl_bool bActive);
extern void CloseNeferttDemo		(void);

extern void	ModifyNefertt			(int nMesh);
extern int	CreateNefertt			(void);

/********************************************************************************************
/*								DEFINED GLOBAL VARIABLES									*
/********************************************************************************************/

HWND			hWnd;

/* Define world co-ordinates.
 */
sgl_vector		XAxis = {1.0f, 0.0f, 0.0f};	
sgl_vector		YAxis = {0.0f, 1.0f, 0.0f};	
sgl_vector		ZAxis = {0.0f, 0.0f, 1.0f};

/* Animation flag. Animation ON.
 */
sgl_bool  		moving_mode = TRUE;
GLOBALVARS		globalVars;

/* Camera Position.
 */
sgl_vector		camera_pos;
sgl_bool		MoveCamera = FALSE;

/* Lights 1, 2, 3 and 4 positions.
 */
sgl_vector		light_pos1;
sgl_vector		light_pos2;
sgl_vector		light_pos3;
sgl_vector		light_pos4;

int				*material_ptr;
int				PARTS = 0;

sgl_bool		bDisplayErr;
BOOL			bBufferLocked=FALSE;
int				nBitsPerPixel;

/********************************************************************************************
/*								LOCAL VARIABLES												*
/********************************************************************************************/

static int			nActivation = 0;
static HINSTANCE	hInst;
static sgl_bool		bActive = FALSE;
static sgl_versions*	versions;
volatile LPDWORD	pStatus;
static LPWORD		pMem;
static WORD			wStride;
static BOOL			bInitStartTime = TRUE;
static BOOL			bQuit = FALSE;
static int			nStrictLocks;
static sgl_bool		bDisplayFPS;
static sgl_bool		bDisplayFreeTexMem;
static short		xPos, yPos;

/********************************************************************************************
/*								LOCAL FUNCTION DEFINITIONS									*
/********************************************************************************************/

void				StartDemo				(int demo);
void				CloseDemo				(void);
void				ReStartDemo				(void);
void				ClipRenderWindow		(short sWinPosX, short sWinPosY);
LRESULT				AppGetWindowsVersion	(PTSTR pszEnvironment, PTSTR pszPlatform);
int		PASCAL		WinMain					(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow);
int					handle_menus			(HWND hwnd, UINT message, UINT wParam, LONG lParam);
long	FAR PASCAL	WndProc					(HWND hwnd, UINT message, UINT wParam, LONG lParam);
BOOL	FAR PASCAL	AboutMsgProc			(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	FogMsgProc				(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateFogDialogText		(HWND hWndDlg,float r,float g,float b,float a);
BOOL	FAR PASCAL	LightsMsgProc			(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateLightDialogText	(HWND hWndDlg, GLOBALVARS *gV);
BOOL				GetLightsDlgItemText	(HWND hWndDlg);
BOOL	FAR PASCAL	ScaleMsgProc			(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	TranslationMsgProc		(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	RotateMsgProc			(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateAxisDialogText	(HWND hWndDlg,float x,float y,float z);
BOOL				GetAxisValues			(HWND hWndDlg,float *x,float *y,float *z);
BOOL	FAR PASCAL	AmbientMsgProc			(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	MaterialAmbientMsgProc	(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	MaterialDiffuseMsgProc	(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	MaterialSpecularMsgProc	(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateMaterialSpecularDialogText(HWND hWndDlg,float r,float g,float b,int a);
BOOL	FAR PASCAL	MaterialGlowMsgProc		(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	MaterialOpacityMsgProc	(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	BackgroundColourMsgProc	(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
BOOL	FAR PASCAL	MultiShadowsMsgProc		(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateColourDialogText	(HWND hWndDlg,float r,float g,float b);
BOOL				GetColourValues			(HWND hWndDlg,float *r,float *g,float *b);
BOOL	FAR PASCAL	CameraViewportMsgProc	(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateCameraViewportDialogText	(	HWND hWndDlg, int numberDevice, int	xDevice,
														int yDevice, sgl_device_colour_types modeDevice,
														sgl_bool doublebufferDevice, float zoomCamera,
														float foregroundCamera, float inv_backgroundCamera,
														float leftCamera, float topCamera, float rightCamera,
														float bottomCamera, int leftViewport,
														int topViewport, int rightViewport,
														int bottomViewport);
BOOL				GetCameraViewportValues			(	HWND hWndDlg, float *zoomCamera,
														float *foregroundCamera, float *inv_backgroundCamera,
														float *leftCamera, float *topCamera,
														float *rightCamera, float *bottomCamera,
														int *leftViewport, int *topViewport,
														int *rightViewport, int *bottomViewport);
BOOL	FAR PASCAL	TextureShortMsgProc			(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateTextureShortDialogText(HWND hWndDlg, GLOBALVARS *gV);
BOOL	FAR PASCAL	TextureMsgProc			(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateTextureDialogText	(HWND hWndDlg, GLOBALVARS *gV);
BOOL				GetTextureDlgItemText	(HWND hWndDlg);
BOOL				LoadBitmapToScreen		(LPSTR filename, HWND ImagehWnd, HDC hDC, RECT picRect);
void				VideoLogicTimerFunc		(void);
void				NeferttTimerFunc		(void);
int					sgl_render_callback		(P_CALLBACK_ADDRESS_PARAMS lpRenderParams);
int					eor_callback			(void);
void				InitialiseMenus			(HMENU hMenu);
BOOL	FAR PASCAL	LevelOfDetailMsgProc	(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam);
void				UpdateLevelOfDetailDialogText	(HWND hWndDlg, sgl_vector boxCorner1, sgl_vector boxCorner2, int *sizes);
BOOL				GetLevelOfDetailValues	(HWND hWndDlg, sgl_vector boxCorner1, sgl_vector boxCorner2, int *sizes);
void				CachedTextureCallback	(sgl_tex_callback_struct TexDataArray[], int	num_used,
											long	free_texture_memory);
void				SetupCachedTexture		(sgl_bool cached);
void				ModifyQualitySettings	(sgl_bool	hQualList, sgl_bool	texturingQual,
											sgl_bool	shadingQual, sgl_bool	shadowQual,
											sgl_bool	fogQual, sgl_bool	collisionQual,
											BOOL		enable_offscreen);
void				MoveCameraPos			(int cameraTransform, sgl_vector camera_pos);
void				MoveLightPos			(int lightTransform, int tLightVolume, sgl_vector light_pos);
void                DDUnlockFrontBuffer     (void);
/********************************************************************************************
/*								LOCAL FUNCTIONS												*
/********************************************************************************************/


/********************************************************************************************
/*
/*	Function Name	:	AppMsgBoxId
/*	Inputs			:	HWND hwnd:		Handle to parent window for message box holding the
/*										message.
/*
/*						UINT fuStyle:	Style flags for MessageBox().
/*
/*						UINT uIdsFormat:String resource id to be loaded with LoadString()
/*						and used a the format string for wvsprintf().
/*
/*	Outputs			:	Outputs message box with required message.
/*	Returns			:	int:	The return value is the result of MessageBox() if the string
/*								resource specified by uIdsFormat is valid. The return value
/*								is zero if the string resource failed to load.
/*	Globals Used	:
/*	Description		:	This function displays a message for the application. The message
/*						text is retrieved from the string resource table using LoadString.
/*
/*						Note that this function takes any valid argument list that can
/*						be passed to wsprintf. Because of this, the application must
/*						remember to cast near string pointers to FAR when built for Win 16.
/*						You will get a nice GP fault if you do not cast them correctly.
/*
/********************************************************************************************/

int AppMsgBoxId(HWND hwnd, UINT fuStyle, UINT uIdsFormat,...)
{
    va_list     va;
    TCHAR       szFormat[APP_MAX_STRING_RC_CHARS];
    TCHAR       ach[APP_MAX_STRING_ERROR_CHARS];
    int         n;

    n = LoadString(hInst, uIdsFormat, szFormat, sizeof(szFormat));
    if (0 != n)
    {
        /* format and display the message..
         */
        va_start(va, uIdsFormat);
#ifdef WIN32
        wvsprintf(ach, szFormat, va);
#else
        wvsprintf(ach, szFormat, (LPSTR)va);
#endif
        va_end(va);

        n = MessageBox(hwnd, ach, NAME, fuStyle);
    }

    return (n);
}


/********************************************************************************************
/*
/*	Function Name	:	AppMsgBox
/*	Inputs			:	HWND hwnd:		Handle to parent window for message box holding the
/*										message.
/*
/*						UINT fuStyle:	Style flags for MessageBox().
/*
/*						PTSTR pszFormat:Format string used for wvsprintf().
/*
/*	Outputs			:	Outputs message box with required message.
/*	Returns			:	int	:The return value is the result of MessageBox() function.
/*	Globals Used	:
/*	Description		:	This function displays a message for the application in a standard
/*						message box.
/*
/*						Note that this function takes any valid argument list that can
/*						be passed to wsprintf. Because of this, the application must
/*						remember to cast near string pointers to FAR when built for Win 16.
/*						You will get a nice GP fault if you do not cast them correctly.
/*
/********************************************************************************************/

int AppMsgBox(HWND hwnd, UINT fuStyle, PTSTR pszFormat, ...)
{
    va_list     va;
    TCHAR       ach[1024];
    int         n;

    /*  format and display the message..
     */
    va_start(va, pszFormat);
#ifdef WIN32
    wvsprintf(ach, pszFormat, va);
#else
    wvsprintf(ach, pszFormat, (LPSTR)va);
#endif
    va_end(va);

    n = MessageBox(hwnd, ach, NAME, fuStyle);

    return (n);
}


/********************************************************************************************
/*
/*	Function Name	:	AppErrorHandler
/*	Inputs			:	None
/*	Outputs			:	Outputs message box with required message.
/*	Returns			:	None
/*	Globals Used	:
/*	Description		:	This routine is used to get and display SGL errors and warnings.
/*
/********************************************************************************************/

void AppErrorHandler()
{
	int	earliest_error, most_recent_error;

	/* check for errors.
	 */	
	sgl_get_errors(&earliest_error, &most_recent_error);

	switch(most_recent_error)
	{
		case sgl_no_err:
			/* No error.
			 */
		break;

		case sgl_err_no_mem:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_NO_MEM);
		break;

		case sgl_err_no_name:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_NO_NAME);
		break;

		case sgl_err_bad_name:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_BAD_NAME);
		break;

		case sgl_err_bad_parameter:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_BAD_PARAMETER);
		break;

		case sgl_err_cyclic_reference:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_CYCLIC_REFERENCE);
		break;

		case sgl_err_list_too_deep:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_LIST_TOO_DEEP);
		break;

		case sgl_err_too_many_planes:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_TOO_MANY_PLANES);
		break;

		case sgl_err_no_convex:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_NO_CONVEX);
		break;

		case sgl_err_no_mesh:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_NO_MESH);
		break;

		case sgl_err_bad_index:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_BAD_INDEX);
		break;

		case sgl_err_failed_init:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_FAILED_INIT);
		break;

		case sgl_err_bad_device:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_BAD_DEVICE);
		break;

		case sgl_err_texture_memory_full:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_TEXTURE_MEMORY_FULL);
		break;

		case sgl_err_colinear_plane_points:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_ERR_COLINEAR_PLANE_POINTS);
		break;

		case sgl_warn_colinear_face_points:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_WARN_COLINEAR_FACE_POINTS);
		break;

		case sgl_warn_colinear_uvs:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_WARN_COLINEAR_UVS);
		break;

		case sgl_warn_large_uvs:
			AppMsgBoxId(NULL, MB_OK | MB_ICONEXCLAMATION | MB_TASKMODAL,IDS_WARN_LARGE_UVS);
		break;

		default:
		break;
	}
}


/********************************************************************************************
/*
/*	Function Name	:	AppGetWindowsVersion
/*	Inputs			:	PTSTR pach:		Options pointer to buffer to receive text string of
/*										the Windows version and platform.
/*	Outputs			:	None
/*  Return (LRESULT):	The return value will be the version and platform information of
/*						the current operating system in the following format:
/*
/*						0xPPPPMMRR where:
/*
/*						MM		:	major version of Windows
/*						RR		:	minor version (revision) of Windows
/*						PPPP	:	the platform the application is running on which
/*									will be one of the following:
/*
/*						#ifdef WIN32
/*							the HIWORD() is RESERVED except for the high bit:
/*							high bit is 0 = Windows NT
/*							high bit is 1 = Win32s/Windows 3.1
/*						#else
/*							0xMMRR = Major and Minor version of [MS-]DOS
/*							GetWinFlags() & 0x8000 = Windows on OS/2 (WLO)
/*							GetWinFlags() & 0x4000 = Windows on Windows NT (WOW)
/*						#endif
/*	Globals Used	:
/*	Description		:	This function returns the version of Windows that the application
/*						is running on plus some platform information.
/*
/********************************************************************************************/

LRESULT AppGetWindowsVersion(PTSTR pszEnvironment, PTSTR pszPlatform)
{

    BYTE    bVerWinMajor;
    BYTE    bVerWinMinor;
    UINT    uVerEnv;
    DWORD   dw;
    LRESULT lr;

    dw = GetVersion();

    /*  massage the version information into something intelligent
     */
    bVerWinMajor = LOBYTE(LOWORD(dw));
    bVerWinMinor = HIBYTE(LOWORD(dw));
    uVerEnv      = HIWORD(dw);
    lr = MAKELPARAM(((UINT)bVerWinMajor << 8) | bVerWinMinor, uVerEnv);

    /*  if caller wants the environment string version...
     */
    if (NULL != pszEnvironment)
    {

#ifdef WIN32
{
    static TCHAR    szFormatVersion[]   = TEXT("%s Version %u.%.2u");
    static TCHAR    szEnvWinNT[]        = TEXT("Windows NT");
    static TCHAR    szEnvWin32s[]       = TEXT("Win32s");

    wsprintf(pszEnvironment, szFormatVersion,
             (LPSTR)((0x8000 & uVerEnv) ? szEnvWin32s : szEnvWinNT),
             bVerWinMajor, bVerWinMinor);
}
#else
{
#ifndef WF_WINNT
    #define WF_WINNT        0x4000
    #define WF_WLO          0x8000
#endif
#ifndef WF_CPUMASK
    #define WF_CPUMASK      0xFC000000
    #define WF_CPU_X86      0
    #define WF_CPU_R4000    1
    #define WF_CPU_ALPHA    2
    #define WF_CPU_CLIPPER  3
#endif

    static TCHAR    szFormatSubSys[]= TEXT("Windows Version %u.%.2u (%s%s)\n%s Subsystem, DOS Version %u.%.2u");
    static TCHAR    szFormatDOS[]   = TEXT("Windows Version %u.%.2u (%s%s)\nDOS Version %u.%.2u");
    static TCHAR    szSubSysWLO[]   = TEXT("WLO");
    static TCHAR    szSubSysWOW[]   = TEXT("WOW");
    static TCHAR    szModeEnhanced[]= TEXT("Enhanced");
    static TCHAR    szModeStandard[]= TEXT("Standard");
    static TCHAR    szEnvPaging[]   = TEXT(", Paging");

    DWORD   dwWinFlags;
    PTSTR   pszMode;

    BYTE    bVerEnvMajor    = HIBYTE(LOWORD(uVerEnv));
    BYTE    bVerEnvMinor    = LOBYTE(LOWORD(uVerEnv));

    dwWinFlags = GetWinFlags();

    pszMode = (dwWinFlags & WF_ENHANCED) ? szModeEnhanced : szModeStandard;
    if (dwWinFlags & (WF_WLO | WF_WINNT))
    {
        wsprintf(pszEnvironment, szFormatSubSys, bVerWinMajor, bVerWinMinor,
                 (LPSTR)pszMode,
                 (LPSTR)((dwWinFlags & WF_PAGING) ? szEnvPaging : gszNull),
                 (LPSTR)((dwWinFlags & WF_WINNT) ? szSubSysWOW : szSubSysWLO),
                 bVerEnvMajor, bVerEnvMinor);
    }
    else
    {
        wsprintf(pszEnvironment, szFormatDOS, bVerWinMajor, bVerWinMinor,
                 (LPSTR)pszMode,
                 (LPSTR)((dwWinFlags & WF_PAGING) ? szEnvPaging : gszNull),
                 bVerEnvMajor, bVerEnvMinor);
    }
}
#endif
    }

    /*  if caller wants the platform string version...
     */
    if (NULL != pszPlatform)
    {
#ifdef WIN32
{
    static TCHAR    szFormatPlatform[]  = TEXT("%s%u, %u Processor(s)");
    static TCHAR    szProcessorIntel[]  = TEXT("Intel ");
    static TCHAR    szProcessorMIPS[]   = TEXT("MIPS R");
    static TCHAR    szProcessorAlpha[]  = TEXT("DEC Alpha ");
    static TCHAR    szProcessorDunno[]  = TEXT("Dunno zYz");

    SYSTEM_INFO sysinfo;
    PTSTR       pszProcessor;

    /*  this is absolutely silly. one would think that the dwOemId member
     *  would provide something useful like the processor class... but
     *  no, it doesn't--it is always 0.
     */
    GetSystemInfo(&sysinfo);
    switch (sysinfo.dwProcessorType)
    {
        case PROCESSOR_INTEL_386:
        case PROCESSOR_INTEL_486:
        case PROCESSOR_INTEL_PENTIUM:
            pszProcessor = szProcessorIntel;
            break;

        case PROCESSOR_MIPS_R4000:
            pszProcessor = szProcessorMIPS;
            break;

        case PROCESSOR_ALPHA_21064:
            pszProcessor = szProcessorAlpha;
            break;

        default:
            pszProcessor = szProcessorDunno;
            break;
    }

    wsprintf(pszPlatform, szFormatPlatform, (LPSTR)pszProcessor,
             sysinfo.dwProcessorType, sysinfo.dwNumberOfProcessors);
}
#else
{
    static TCHAR    szPlat286[]         = TEXT("80286");
    static TCHAR    szPlat386[]         = TEXT("80386");
    static TCHAR    szPlat486[]         = TEXT("i486");
    static TCHAR    szPlatR4000[]       = TEXT("MIPS R4000, Emulation: ");
    static TCHAR    szPlatAlpha21064[]  = TEXT("Alpha 21064, Emulation: ");
    static TCHAR    szPlatClipper[]     = TEXT("Clipper, Emulation: ");
    static TCHAR    szPlat80x87[]       = TEXT(", 80x87");

    DWORD   dwWinFlags;

    dwWinFlags = GetWinFlags();
    pszPlatform[0] = '\0';

    if (dwWinFlags & (WF_WLO | WF_WINNT))
    {
        switch ((dwWinFlags & WF_CPUMASK) >> 26)
        {
            case WF_CPU_X86:
                break;

            case WF_CPU_R4000:
                lstrcpy(pszPlatform, szPlatR4000);
                break;

            case WF_CPU_ALPHA:
                lstrcpy(pszPlatform, szPlatAlpha21064);
                break;

            case WF_CPU_CLIPPER:
                lstrcpy(pszPlatform, szPlatClipper);
                break;
        }
    }

    if (dwWinFlags & WF_CPU286)
        lstrcat(pszPlatform, szPlat286);
    else if (dwWinFlags & WF_CPU386)
        lstrcat(pszPlatform, szPlat386);
    else if (dwWinFlags & WF_CPU486)
        lstrcat(pszPlatform, szPlat486);

    if (dwWinFlags & WF_80x87)
        lstrcat(pszPlatform, szPlat80x87);
}
#endif
    }

    return (lr);
}


/********************************************************************************************
/*
/*	Function Name	:	WinMain
/*	Inputs			:	HANDLE	hInstance
/*						HANDLE	hPrevInstance
/*						LPSTR	lpszCmdParam
/*						int		nCmdShow
/*	Outputs			:	Creates window.
/*	Returns			:	int
/*	Globals Used	:
/*	Description		:	This routine initialises the enviroment for the application.
/*						This routine holds the main program loop.
/*						Handles all Windows messages
/*						Initialises D3D, SGL etc.
/*
/********************************************************************************************/

int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	MSG         msg;
	WNDCLASS    wndclass;
	HMENU       hMenu;
	LOGBRUSH    brush;
	int			nRet = 0, loopcount;
	HDC			hDC;

	/* Get Version info
	 */
	versions	= sgl_get_versions();

	hDC = GetDC(NULL);			/* get Display Device Context	*/

	if (hDC)
	{
		nBitsPerPixel = GetDeviceCaps (hDC, BITSPIXEL);	
		ReleaseDC(NULL, hDC);

		switch(nBitsPerPixel)
		{
			case 16:
			case 24:
			case 32:
			{
				break;
			}

			default:
			{
		        AppMsgBox(hWnd, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL,
                  TEXT("Error - incompatible graphics mode"));
				return 0;
			}
		}
	}
	else
	{
        AppMsgBox(hWnd, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL,
              TEXT("Error - can't get display device context"));
		return 0;
	}

	/* setup inital values
	 */
	hInst = hInstance;

	brush.lbStyle = BS_SOLID;
	brush.lbColor = PALETTEINDEX(DEFAULT_KEY_COLOUR);

	/* set the key value for overlay
	 */
	globalVars.hBrush    = CreateBrushIndirect(&brush);
	globalVars.keyColour = DEFAULT_KEY_COLOUR;

	globalVars.demoNumber= 0;		/* no demo running.		*/
	globalVars.lightMove= 0;		/* no light moving.		*/
	bDisplayFPS = FALSE;			/* don't display FPS.	*/
	bDisplayErr = FALSE;			/* don't display Errors.*/

	/*
	// =========================
	// WINDOWS APPLICATION STUFF
	// =========================
	*/
	if (!hPrevInstance)
	{
		wndclass.style			= CS_BYTEALIGNCLIENT;
	    wndclass.lpfnWndProc 	= WndProc;
	    wndclass.cbClsExtra 	= 0;
	    wndclass.cbWndExtra		= 0;
	    wndclass.hInstance		= hInstance;
	    wndclass.hIcon			= LoadIcon( hInstance, IDI_APPLICATION );
	    wndclass.hCursor		= LoadCursor( NULL, IDC_ARROW );
	    wndclass.hbrBackground	= NULL;
	    wndclass.lpszMenuName	= MAKEINTRESOURCE(IDR_MENU1);
	    wndclass.lpszClassName	= NAME;
		RegisterClass (&wndclass);
	}

	hMenu = LoadMenu(hInstance,MAKEINTRESOURCE(IDR_MENU1));

    hWnd = CreateWindow(  	NAME,							/* window class name	*/
							"VL Logo and Nefertt Demo",		/* window caption		*/
				    		WS_OVERLAPPED | WS_SYSMENU | WS_VISIBLE | WS_BORDER,
							20,								/* initial x position	*/
							20,								/* initial y position	*/
							644,							/* initial x size		*/
							500+32,    						/* initial y size		*/
				    		NULL,
				    		hMenu,
				    		hInstance,
				    		NULL );

	/* If problem creating window.
	 */
    if (hWnd == NULL)
	{
        int LastError;
        
        AppMsgBox(hWnd, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL,
              TEXT("Create Window returned %d"), nRet);
		LastError = GetLastError();
		return FALSE;
	}

	/* When launching from 16 bit program manager we need this delay
	 */
	Sleep(100);

	BringWindowToTop (hWnd);

	/* Initialise the hardware.
	 */
    nRet = DDrawInit(hWnd);
    if (nRet)
	{
        AppMsgBox(hWnd, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL,
              TEXT("DDrawInit returned %d\n\nExiting..."), nRet);
        return 0;
	}

	/* Displays rendered image in the created window area.
	 */
    nRet = sgl_use_address_mode (&sgl_render_callback, (LPDWORD *)&pStatus);
	if (nRet)
	{
        AppMsgBox(hWnd, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL,
              TEXT("sgl_use_adress_mode returned %d"), nRet);
        DDEnd( );
		return 0;
	}

	/* Setup window to render image in.
	 */
    nRet = DDGetWindowInfo(hWnd,&pMem,&wStride);
	DDUnlockFrontBuffer();
	bBufferLocked = FALSE;
    if (nRet)
	{
        AppMsgBox(hWnd, MB_OK | MB_ICONHAND,
              TEXT("DDGetWindowInfo returned %d"), nRet);
        DDEnd( );
		return 0;
	}

	/* Start demo running.
	 */
	SetupVideoLogicLogoDemo();

	/* Initialise menus.
	 */
	InitialiseMenus(hMenu);

	nStrictLocks=0;
    /*
      This function may be needed for maximun compatibility
       sgl_get_ini_int (&nStrictLocks, 0, "Default","StrictLocks");
    */
	
    if (nStrictLocks)
	{ 
		nRet = sgl_use_eor_callback(&eor_callback);

		loopcount = 100;

		/* Init sequence
		 */
		while (loopcount--)
	    {
			/* Check for message.
			 */
    	  	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	        {
				/* If message then process it.
				 */
    	        if (!GetMessage( &msg, NULL, 0, 0 ))
				{
					DDEnd();
	                return msg.wParam;
	            }

    	        TranslateMessage(&msg); 
        	    DispatchMessage(&msg);
	        }
	    }

		/* Render sequence
		 */
		while (!bQuit)
		{
        	if (bActive)
        	{
				switch (globalVars.demoNumber)
				{
					case 1:	/* Video Logic Logo demo
							 */
							VideoLogicTimerFunc	();
					break;

					case 2:	/* Nefertt demo
							 */
							NeferttTimerFunc	();
					break;

					default:/* do nothing...
							 */
					break;
				}
	    	}
		}
    }
	else
	{
		while (1)
    	{
			/* Check for message.
			 */
    	  	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
        	{
				/* If message then process it.
				 */
    	        if (!GetMessage( &msg, NULL, 0, 0 ))
        	    {
					break;
	            }

    	        TranslateMessage(&msg); 
        	    DispatchMessage(&msg);
	        }
    	    else
        		if (bActive)
        		{
					switch (globalVars.demoNumber)
					{
						case 1:	/* Video Logic Logo demo
								 */
								VideoLogicTimerFunc	();
						break;

						case 2:	/* Nefertt demo
								 */
								NeferttTimerFunc	();
						break;

						default:/* do nothing...
								 */
						break;
					}
	    	    }
				else
					WaitMessage();
		}
    }
   	return msg.wParam;
}


/********************************************************************************************
/*
/*	Function Name	:	StartDemo
/*	Inputs			:	int	demo	: demo number.
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:
/*	Description		:	Starts the currently selected demo.
/*
/********************************************************************************************/

void StartDemo(int demo)

{
	CloseDemo();
	globalVars.demoNumber = demo;

	switch (globalVars.demoNumber)
	{
		case 1	:
			/* Video Logic Logo demo
			 */
			SetupVideoLogicLogoDemo();
		break;
		
		case 2	:
			/* Nefertt demo
			 */
			SetupNeferttDemo();
		break;
		
		default	:
			/* do nothing...
			 */
		break;
	}
}


/********************************************************************************************
/*
/*	Function Name	:	CloseDemo
/*	Inputs			:	-
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:
/*	Description		:	Closes the currently selected demo.
/*
/********************************************************************************************/

void CloseDemo()

{
	SetupCachedTexture(FALSE);

	switch (globalVars.demoNumber)
	{
		case 1	:
			/* Video Logic Logo demo
			 */
			CloseVideoLogicLogoDemo();
		break;
		
		case 2	:
			/* Nefertt demo
			 */
			CloseNeferttDemo();
		break;
		
		default	:
			/* do nothing...
			 */
		break;
	}
}


/********************************************************************************************
/*
/*	Function Name	:	ReStartDemo
/*	Inputs			:	-
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:
/*	Description		:	Routine to re-start the demos. Re-starts which ever demo was
/*						previously running.
/*
/********************************************************************************************/

void ReStartDemo()

{
	switch (globalVars.demoNumber)
	{
		case 1	:
			/* Video Logic Logo demo
			 */
			SetupVideoLogicLogoDemo();
		break;
		
		case 2	:
			/* Nefertt demo
			 */
			SetupNeferttDemo();
		break;
		
		default	:
			/* do nothing...
			 */
		break;
	}
}



/********************************************************************************************
/*
/*	Function Name	:	InitialiseMenus
/*	Inputs			:	HWND hwnd
/*						UINT message
/*						UINT wParam
/*						LONG lParam
/*	Outputs			:	
/*	Returns			:	int		0 Processed message.
/*								1 Didn't process message.
/*	Globals Used	:
/*	Description		:	Used to handle the menu options.
/*
/********************************************************************************************/

void InitialiseMenus (HMENU hMenu)

{
	/* Initialise quality menu options.
	 */
	if (globalVars.texturingQual)
		CheckMenuItem(hMenu,ID_QUALITY_TEXTURING,MF_CHECKED);
	else
		CheckMenuItem(hMenu,ID_QUALITY_TEXTURING,MF_UNCHECKED);

	if (globalVars.shadingQual)
		CheckMenuItem(hMenu,ID_QUALITY_SHADING,MF_CHECKED);
	else
		CheckMenuItem(hMenu,ID_QUALITY_SHADING,MF_UNCHECKED);

	if (globalVars.shadowQual)
		CheckMenuItem(hMenu,ID_QUALITY_SHADOWS,MF_CHECKED);
	else
		CheckMenuItem(hMenu,ID_QUALITY_SHADOWS,MF_UNCHECKED);

	if (globalVars.fogQual)
		CheckMenuItem(hMenu,ID_QUALITY_FOG,MF_CHECKED);
	else
		CheckMenuItem(hMenu,ID_QUALITY_FOG,MF_UNCHECKED);

	if (globalVars.collisionQual)
		CheckMenuItem(hMenu,ID_QUALITY_COLLISION,MF_CHECKED);
	else
		CheckMenuItem(hMenu,ID_QUALITY_COLLISION,MF_UNCHECKED);

	/* Switch different menu items ON/OFF depending on which demo.
	 */
	switch (globalVars.demoNumber)
	{
		case 1	:	/* Video Logic Logo demo
					 */
			CheckMenuItem(hMenu,ID_GENERAL_VLLOGO,						MF_CHECKED);
			CheckMenuItem(hMenu,ID_GENERAL_NEFERTT,						MF_UNCHECKED);

			EnableMenuItem(hMenu,ID_POLYGON_MODIFYMESH,					MF_GRAYED);
			EnableMenuItem(hMenu,ID_GENERAL_LOD,						MF_GRAYED);
			EnableMenuItem(hMenu,ID_GENERAL_STOPANIMATION,				MF_ENABLED);
			EnableMenuItem(hMenu,ID_GENERAL_TRANSLATION,				MF_ENABLED);
			EnableMenuItem(hMenu,ID_GENERAL_SCALE,						MF_ENABLED);
			EnableMenuItem(hMenu,ID_GENERAL_ROTATE,						MF_ENABLED);

			EnableMenuItem(hMenu,ID_MATERIALS_AMBIENT,					MF_ENABLED);
			EnableMenuItem(hMenu,ID_MATERIALS_DIFFUSE,					MF_ENABLED);
			EnableMenuItem(hMenu,ID_MATERIALS_SPECULAR,					MF_ENABLED);
			EnableMenuItem(hMenu,ID_MATERIALS_GLOW,						MF_ENABLED);
			EnableMenuItem(hMenu,ID_MATERIALS_OPACITY,					MF_ENABLED);

			EnableMenuItem(hMenu,ID_CONVEX_TEST,						MF_ENABLED);

			EnableMenuItem(hMenu,ID_POLYGON_SELECTCULL_NOCULL,			MF_GRAYED);
			EnableMenuItem(hMenu,ID_POLYGON_SELECTCULL_ANTICLOCKWISE,	MF_GRAYED);
			EnableMenuItem(hMenu,ID_POLYGON_SELECTCULL_CLOCKWISE,		MF_GRAYED);
			EnableMenuItem(hMenu,ID_POLYGON_TEST,						MF_GRAYED);

			EnableMenuItem(hMenu,ID_QUALITY_MULTISHADOWS,				MF_GRAYED);
		break;

		case 2	:	/* Nefertt demo
					 */
			CheckMenuItem(hMenu,ID_GENERAL_VLLOGO,						MF_UNCHECKED);
			CheckMenuItem(hMenu,ID_GENERAL_NEFERTT,						MF_CHECKED);

			EnableMenuItem(hMenu,ID_POLYGON_MODIFYMESH,					MF_ENABLED);
			EnableMenuItem(hMenu,ID_GENERAL_LOD,						MF_ENABLED);
			EnableMenuItem(hMenu,ID_GENERAL_STOPANIMATION,				MF_ENABLED);
			EnableMenuItem(hMenu,ID_GENERAL_TRANSLATION,				MF_GRAYED);
			EnableMenuItem(hMenu,ID_GENERAL_SCALE,						MF_GRAYED);
			EnableMenuItem(hMenu,ID_GENERAL_ROTATE,						MF_GRAYED);

			EnableMenuItem(hMenu,ID_MATERIALS_AMBIENT,					MF_GRAYED);
			EnableMenuItem(hMenu,ID_MATERIALS_DIFFUSE,					MF_GRAYED);
			EnableMenuItem(hMenu,ID_MATERIALS_SPECULAR,					MF_GRAYED);
			EnableMenuItem(hMenu,ID_MATERIALS_GLOW,						MF_GRAYED);
			EnableMenuItem(hMenu,ID_MATERIALS_OPACITY,					MF_GRAYED);

			EnableMenuItem(hMenu,ID_CONVEX_TEST,						MF_GRAYED);

			EnableMenuItem(hMenu,ID_POLYGON_SELECTCULL_NOCULL,			MF_ENABLED);
			EnableMenuItem(hMenu,ID_POLYGON_SELECTCULL_ANTICLOCKWISE,	MF_ENABLED);
			EnableMenuItem(hMenu,ID_POLYGON_SELECTCULL_CLOCKWISE,		MF_ENABLED);
			EnableMenuItem(hMenu,ID_POLYGON_TEST,						MF_ENABLED);

			EnableMenuItem(hMenu,ID_QUALITY_MULTISHADOWS,				MF_GRAYED);
		break;

		default	:
			//do nothing...
		break;
	}

	CheckDlgButton(MAKEINTRESOURCE(IDD_CAMERA_VIEWPORT_DIALOG), IDC_VIEWPORT_SUBTRACT_CHECK, BST_UNCHECKED);
	CheckMenuItem(hMenu,ID_CACHED_TEXTURE,MF_UNCHECKED);
	CheckMenuItem(hMenu,ID_POLYGON_SELECTCULL_NOCULL,MF_CHECKED);
	CheckMenuItem(hMenu,ID_POLYGON_SELECTCULL_ANTICLOCKWISE,MF_UNCHECKED);
	CheckMenuItem(hMenu,ID_POLYGON_SELECTCULL_CLOCKWISE,MF_UNCHECKED);

}


/********************************************************************************************
/*
/*	Function Name	:	handle_menus
/*	Inputs			:	HWND hwnd
/*						UINT message
/*						UINT wParam
/*						LONG lParam
/*	Outputs			:	
/*	Returns			:	int		0 Processed message.
/*								1 Didn't process message.
/*	Globals Used	:
/*	Description		:	Used to handle the menu options.
/*
/********************************************************************************************/

int handle_menus(HWND hwnd, UINT message, UINT wParam, LONG lParam)
{
	FARPROC		lpfnProc;
	int			nRet = 0;
	HMENU		hMenu;

	hMenu = GetMenu(hwnd);

	switch (wParam)
	{
		/******************************** 
		 * General Menu Options.
		 ********************************/
		case ID_GENERAL_VLLOGO:

			/* Disable rendering.
			 */
			bActive = FALSE;
			Sleep(200);

			CloseDemo();

			/* Start demo running.
			 */
			SetupVideoLogicLogoDemo();

			/* Clip the render window ? Routine sets up the viewport and clips the
			 * window if need be.
			 */
			ClipRenderWindow(xPos, yPos);

			/* Initialise menus.
			 */
			InitialiseMenus(hMenu);

			/* Renable the rendering.
			 */
			bActive = TRUE;
		break;

		case ID_GENERAL_NEFERTT:

			/* Disable rendering.
			 */
			bActive = FALSE;
			Sleep(200);

			CloseDemo();

			CloseDemo();

			/* Start demo running.
			 */
			SetupNeferttDemo();

			/* Clip the render window ? Routine sets up the viewport and clips the
			 * window if need be.
			 */
			ClipRenderWindow(xPos, yPos);

			/* Initialise menus.
			 */
			InitialiseMenus(hMenu);

			/* Renable the rendering.
			 */
			bActive = TRUE;
		break;

		case ID_GENERAL_STOPANIMATION:
			if (GetMenuState(hMenu,ID_GENERAL_STOPANIMATION,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_GENERAL_STOPANIMATION,MF_UNCHECKED);
				moving_mode = TRUE;
			}
			else
			{
				CheckMenuItem(hMenu,ID_GENERAL_STOPANIMATION,MF_CHECKED);
				moving_mode = FALSE;
			}
		break;

		case ID_GENERAL_TRANSLATION:
			/* Translation dialogue box.
			 */
			lpfnProc = MakeProcInstance((FARPROC)TranslationMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_TRANSLATION_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_GENERAL_SCALE:
			/* Scale dialogue box.
			 */
			lpfnProc = MakeProcInstance((FARPROC)ScaleMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_SCALE_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_GENERAL_ROTATE:
			/* Rotate dialogue box.
			 */
			lpfnProc = MakeProcInstance((FARPROC)RotateMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ROTATE_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_GENERAL_EXIT:
			/* Exit from program.
			 */
            KillTimer (hwnd, 1);

			bActive = FALSE;
			bQuit = TRUE;
			Sleep(100); /* This delay fixed a hanging bug */
			Sleep(100); /* This delay fixed a hanging bug */
			CloseDemo ();
            DDEnd();
                       			
            PostQuitMessage (0);
		break;

		/******************************** 
		 * View Menu Options.
		 ********************************/
		case ID_VIEW_MOVECAMERA:
			/* Switch lights OFF.
			 */
			CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT1,MF_UNCHECKED);
			CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT2,MF_UNCHECKED);
			CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT3,MF_UNCHECKED);
			CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT4,MF_UNCHECKED);

			if (GetMenuState(hMenu,ID_VIEW_MOVECAMERA,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_VIEW_MOVECAMERA,MF_UNCHECKED);
				MoveCamera = FALSE;
			}
			else
			{
				CheckMenuItem(hMenu,ID_VIEW_MOVECAMERA,MF_CHECKED);
				MoveCamera = TRUE;
				globalVars.lightMove = 0;		/* switch light movement off	*/
			}
		break;

		case ID_VIEW_SET:
			/* Camera and Viewport settings dialog box.
			 */
			lpfnProc = MakeProcInstance((FARPROC)CameraViewportMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_CAMERA_VIEWPORT_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		/******************************** 
		 * Materials Menu Options.
		 ********************************/
		case ID_MATERIALS_AMBIENT:
			lpfnProc = MakeProcInstance((FARPROC)MaterialAmbientMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_MATERIAL_AMBIENT_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_MATERIALS_DIFFUSE:
			lpfnProc = MakeProcInstance((FARPROC)MaterialDiffuseMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_MATERIAL_DIFFUSE_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_MATERIALS_SPECULAR:
			lpfnProc = MakeProcInstance((FARPROC)MaterialSpecularMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_MATERIAL_SPECULAR_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_MATERIALS_GLOW:
			lpfnProc = MakeProcInstance((FARPROC)MaterialGlowMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_MATERIAL_GLOW_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_MATERIALS_OPACITY:
			lpfnProc = MakeProcInstance((FARPROC)MaterialOpacityMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_MATERIAL_OPACITY_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;


		/******************************** 
		 * Light Menu Options.
		 ********************************/
		case ID_LIGHT_AMBIENT:
			lpfnProc = MakeProcInstance((FARPROC)AmbientMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_AMBIENT_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_LIGHT_MOVE_LIGHT1:
			/* Switch camera movement OFF.
			 */
			CheckMenuItem(hMenu,ID_VIEW_MOVECAMERA,MF_UNCHECKED);
			MoveCamera = FALSE;

			if (GetMenuState(hMenu,ID_LIGHT_MOVE_LIGHT1,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT1,MF_UNCHECKED);
				globalVars.lightMove = 0;
				globalVars.lightNumber = 0;		/* light 1 */
			}
			else
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT1,MF_CHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT2,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT3,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT4,MF_UNCHECKED);
				globalVars.lightMove = 1;
				globalVars.lightNumber = 0;		/* light 1 */
			}
		break;

 		case ID_LIGHT_MOVE_LIGHT2:
			/* Switch camera movement OFF.
			 */
			CheckMenuItem(hMenu,ID_VIEW_MOVECAMERA,MF_UNCHECKED);
			MoveCamera = FALSE;

			if (GetMenuState(hMenu,ID_LIGHT_MOVE_LIGHT2,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT2,MF_UNCHECKED);
				globalVars.lightMove = 0;
				globalVars.lightNumber = 0;		/* light 1 */
			}
			else
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT1,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT2,MF_CHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT3,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT4,MF_UNCHECKED);
				globalVars.lightMove = 2;
				globalVars.lightNumber = 1;		/* light 2 */
			}
		break;

		case ID_LIGHT_MOVE_LIGHT3:
			/* Switch camera movement OFF.
			 */
			CheckMenuItem(hMenu,ID_VIEW_MOVECAMERA,MF_UNCHECKED);
			MoveCamera = FALSE;

			if (GetMenuState(hMenu,ID_LIGHT_MOVE_LIGHT3,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT3,MF_UNCHECKED);
				globalVars.lightMove = 0;
				globalVars.lightNumber = 0;		/* light 1 */
			}
			else
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT1,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT2,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT3,MF_CHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT4,MF_UNCHECKED);
				globalVars.lightMove = 3;
				globalVars.lightNumber = 2;		/* light 3 */
			}
		break;

 		case ID_LIGHT_MOVE_LIGHT4:
			/* Switch camera movement OFF.
			 */
			CheckMenuItem(hMenu,ID_VIEW_MOVECAMERA,MF_UNCHECKED);
			MoveCamera = FALSE;

			if (GetMenuState(hMenu,ID_LIGHT_MOVE_LIGHT4,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT4,MF_UNCHECKED);
				globalVars.lightMove = 0;
				globalVars.lightNumber = 0;		/* light 1 */
			}
			else
			{
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT1,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT2,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT3,MF_UNCHECKED);
				CheckMenuItem(hMenu,ID_LIGHT_MOVE_LIGHT4,MF_CHECKED);
				globalVars.lightMove = 4;
				globalVars.lightNumber = 3;		/* light 4 */
			}
		break;

 		case ID_LIGHT_SETLIGHTS:
			lpfnProc = MakeProcInstance((FARPROC)LightsMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_LIGHTS_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		/******************************** 
		 * Quality Menu Options.
		 ********************************/
		case ID_QUALITY_SHADING:
			if (GetMenuState(hMenu,ID_QUALITY_SHADING,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_QUALITY_SHADING,MF_UNCHECKED);
				globalVars.shadingQual = FALSE;
			}
			else
			{
				CheckMenuItem(hMenu,ID_QUALITY_SHADING,MF_CHECKED);
				globalVars.shadingQual = TRUE;
			}

			ModifyQualitySettings(	globalVars.hQualList,
									globalVars.texturingQual,
									globalVars.shadingQual,
									globalVars.shadowQual,
									globalVars.fogQual,
									globalVars.collisionQual, FALSE);
		break;

		case ID_QUALITY_TEXTURING:
			if (GetMenuState(hMenu,ID_QUALITY_TEXTURING,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_QUALITY_TEXTURING,MF_UNCHECKED);
				globalVars.texturingQual = FALSE;
			}
			else
			{
				CheckMenuItem(hMenu,ID_QUALITY_TEXTURING,MF_CHECKED);
				globalVars.texturingQual = TRUE;
			}

			ModifyQualitySettings(	globalVars.hQualList,
									globalVars.texturingQual,
									globalVars.shadingQual,
									globalVars.shadowQual,
									globalVars.fogQual,
									globalVars.collisionQual, FALSE);
		break;

		case ID_QUALITY_COLLISION:
			if (GetMenuState(hMenu,ID_QUALITY_COLLISION,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_QUALITY_COLLISION,MF_UNCHECKED);
				globalVars.collisionQual = FALSE;
			}
			else
			{
				CheckMenuItem(hMenu,ID_QUALITY_COLLISION,MF_CHECKED);
				globalVars.collisionQual = TRUE;
			}
			ModifyQualitySettings(	globalVars.hQualList,
									globalVars.texturingQual,
									globalVars.shadingQual,
									globalVars.shadowQual,
									globalVars.fogQual,
									globalVars.collisionQual, FALSE);
		break;

		case ID_QUALITY_SHADOWS:
			if (GetMenuState(hMenu,ID_QUALITY_SHADOWS,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_QUALITY_SHADOWS,MF_UNCHECKED);
				globalVars.shadowQual = FALSE;
			}
			else
			{
				CheckMenuItem(hMenu,ID_QUALITY_SHADOWS,MF_CHECKED);
				globalVars.shadowQual = TRUE;
			}
			ModifyQualitySettings(	globalVars.hQualList,
									globalVars.texturingQual,
									globalVars.shadingQual,
									globalVars.shadowQual,
									globalVars.fogQual,
									globalVars.collisionQual, FALSE);
		break;

		case ID_QUALITY_FOG:
			if (GetMenuState(hMenu,ID_QUALITY_FOG,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_QUALITY_FOG,MF_UNCHECKED);
				globalVars.fogQual = FALSE;
			}
			else
			{
				CheckMenuItem(hMenu,ID_QUALITY_FOG,MF_CHECKED);
				globalVars.fogQual = TRUE;
			}

			ModifyQualitySettings(	globalVars.hQualList,
									globalVars.texturingQual,
									globalVars.shadingQual,
									globalVars.shadowQual,
									globalVars.fogQual,
									globalVars.collisionQual, FALSE);
		break;

		case ID_QUALITY_FOGLEVEL:
			lpfnProc = MakeProcInstance((FARPROC)FogMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_FOG_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_QUALITY_BACKGROUNDCOLOUR:
			/* Background Colour dialog box.
			 */
			lpfnProc = MakeProcInstance((FARPROC)BackgroundColourMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_BACKGROUND_COLOUR_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		case ID_QUALITY_MULTISHADOWS:
			/* Multi Shadows dialog box.
			 */
			lpfnProc = MakeProcInstance((FARPROC)MultiShadowsMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_MULTISHADOWS_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		/******************************** 
		 * Set Texture Menu Options.
		 ********************************/
		case ID_SET_TEXTURE:

			/* Delete cached texture.
			 */
			CheckMenuItem(hMenu,ID_CACHED_TEXTURE,MF_UNCHECKED);
			SetupCachedTexture(FALSE);

			switch (globalVars.demoNumber)
			{
				case 1:
					/* Video Logic Logo demo
					 */
					lpfnProc = MakeProcInstance((FARPROC)TextureShortMsgProc, hInst); 
					DialogBox(hInst, MAKEINTRESOURCE(IDD_TEXTURES_SHORT_DIALOG), hwnd, lpfnProc);
					FreeProcInstance(lpfnProc);
				break;

				case 2:
					/* Nefertt demo
					 */
					lpfnProc = MakeProcInstance((FARPROC)TextureMsgProc, hInst); 
					DialogBox(hInst, MAKEINTRESOURCE(IDD_TEXTURES_DIALOG), hwnd, lpfnProc);
					FreeProcInstance(lpfnProc);
				break;

				default:
					/* do nothing....
					 */
				break;
			}
		break;

		case ID_CACHED_TEXTURE:
			/* Setup cached textures.
			 */
			if (GetMenuState(hMenu,ID_CACHED_TEXTURE,MF_BYCOMMAND) == MF_CHECKED)
			{
				CheckMenuItem(hMenu,ID_CACHED_TEXTURE,MF_UNCHECKED);
				SetupCachedTexture(FALSE);
			}
			else
			{
				CheckMenuItem(hMenu,ID_CACHED_TEXTURE,MF_CHECKED);
				SetupCachedTexture(TRUE);
			}
		break;

		case ID_HELP_ABOUT:
			/* Help message.
			 */
			lpfnProc = MakeProcInstance((FARPROC)AboutMsgProc, hInst); 
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUT_DIALOG), hwnd, lpfnProc);
			FreeProcInstance(lpfnProc);
		break;

		default:
			/* do nothing...
			 */
			nRet = 1;
		break;
	}
	return(nRet);
}


/********************************************************************************************
/*
/*	Function Name	:	WndProc
/*	Inputs			:	HWND hwnd
/*						UINT message
/*						UINT wParam
/*						LONG lParam
/*	Outputs			:	None.	
/*	Returns			:	int		0 Processed message.
/*								DefWindowProc (hwnd, message, wParam, lParam)
/*								Didn't process message.	Call window handler.
/*	Globals Used	:
/*	Description		:	Main message handler. All Window messages (mouse move, key presses,
/*						menu options etc.) are handled here.
/*
/********************************************************************************************/

long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam)
{
	HDC				hdc;
	PAINTSTRUCT		ps;
	RECT			rect;
	static WORD		lastMouseX, lastMouseY;
	int				deltaMouseX, deltaMouseY, nRet = 0;

	switch (message)
	{
	    case WM_ACTIVATEAPP:
			if (wParam)
			{
				Sleep(500);			// Don't restart until Windows has tidied up
		        bActive = TRUE;
			}
			else
		        bActive = FALSE;
			return DefWindowProc (hwnd, message, wParam, lParam);
       	break;

		case WM_ACTIVATE:
			if (LOWORD(wParam) == WA_INACTIVE)
			{
		        bActive = FALSE;
			}
			else
			{
				Sleep(500); 		// Don't restart until Windows has tidied up
		        bActive = TRUE;
			}
			return DefWindowProc (hwnd, message, wParam, lParam);
      	break;
		
        case WM_SYSKEYDOWN:
			/* Used to stop rendering when ALT pressed.
			 */
        	bActive = FALSE;		// stop rendering when menu opened.
			Sleep(200); 			// delay
		break;
                
	    case WM_KEYDOWN:
	        switch(wParam)
	        {
				/* F1 Enable/Disable FPS
				 */
		        case VK_F1:
					bDisplayFPS = !bDisplayFPS;
					if (!bDisplayFPS)
						SetWindowText(hWnd,"VL Logo and Nefertt Demo");
	            break;

				/* F2 Enable/Disable Error/Warning messages.
				 */
		        case VK_F2:
					bDisplayErr = !bDisplayErr;
	            break;

				/* F3 Enable/Disable Error/Warning messages.
				 */
		        case VK_F3:
					bDisplayFreeTexMem = !bDisplayFreeTexMem;
					if (!bDisplayFreeTexMem)
						SetWindowText(hWnd,"VL Logo and Nefertt Demo");
	            break;
	        }
        break;

		case WM_COMMAND :
  			nRet = handle_menus(hwnd, message, wParam, lParam);
			if (nRet)
			{
				return DefWindowProc (hwnd, message, wParam, lParam);
			}
		break;

        case WM_MOUSEMOVE:

			/* When moving the mouse, the user must
             * hold down the left mouse button .	
             */
			if (wParam & MK_LBUTTON)
	    	{
				deltaMouseX = (int)lastMouseX - (int)LOWORD(lParam);
				deltaMouseY = (int)lastMouseY - (int)HIWORD(lParam);

				lastMouseX = LOWORD(lParam);
				lastMouseY = HIWORD(lParam);

				/* Move camera position.
				 */
				if (MoveCamera)
				{
					camera_pos[0] += (float)deltaMouseX / 1000.0f;
					camera_pos[1] += (float)deltaMouseY / 1000.0f;
				}
				else
				{
					/* Move the position of the selected light.
					 * Only move if camera not enabled.
					 */
					switch (globalVars.lightMove)
					{
						case 1	:	/* Move light 1.
									 */
									light_pos1[0] += (float)deltaMouseX / 1000.0f;
									light_pos1[1] += (float)deltaMouseY / 1000.0f;  
									break;

						case 2	:	/* Move light 2.
									 */
									light_pos2[0] += (float)deltaMouseX / 1000.0f;
									light_pos2[1] += (float)deltaMouseY / 1000.0f;  
									break;

						case 3	:	/* Move light 3.
									 */
									light_pos3[0] += (float)deltaMouseX / 1000.0f;
									light_pos3[1] += (float)deltaMouseY / 1000.0f;  
									break;

						case 4	:	/* Move light 4.
									 */
									light_pos4[0] += (float)deltaMouseX / 1000.0f;
									light_pos4[1] += (float)deltaMouseY / 1000.0f;  
									break;
				
						default	:	// do nothing...
									break;
					}
				}
			}

			if (wParam & MK_RBUTTON)
			{
				deltaMouseX = (int)lastMouseX - (int)LOWORD(lParam);
				deltaMouseY = (int)lastMouseY - (int)HIWORD(lParam);

				lastMouseX = LOWORD(lParam);
				lastMouseY = HIWORD(lParam);

				if (MoveCamera)
				{
					camera_pos[2] += (float)deltaMouseY / 100.0f;
				}
			}
		break;

        case WM_MOVE:
			/* Make a copy of the screen coordinates.
			 */
			xPos = LOWORD(lParam);
			yPos = HIWORD(lParam);
			if (!bInitStartTime)
				ClipRenderWindow(LOWORD(lParam), HIWORD(lParam));
		break;

        case WM_LBUTTONUP:
	        bActive = TRUE;
			lastMouseX = 0;
			lastMouseY = 0;
		break;

        case WM_LBUTTONDOWN:
			lastMouseX = LOWORD(lParam);
			lastMouseY = HIWORD(lParam);
		break;

        case WM_RBUTTONUP:
	        bActive = TRUE;
			lastMouseX = 0;
			lastMouseY = 0;
		break;

        case WM_RBUTTONDOWN:
			lastMouseX = LOWORD(lParam);
			lastMouseY = HIWORD(lParam);
		break;

		case WM_ERASEBKGND:
			hdc = BeginPaint (hwnd, &ps);
			GetClientRect (hwnd, &rect);
			FillRect(hdc,&rect,globalVars.hBrush);			
			EndPaint (hwnd, &ps);
		break;

		case WM_DESTROY:
            KillTimer (hwnd, 1);

			bActive = FALSE;
			bQuit = TRUE;
			Sleep(100);
			Sleep(100);
			CloseDemo ();
            DDEnd();
                       			
            PostQuitMessage (0);
		break;
		
		case WM_WINDOWPOSCHANGING:

			/* When the window moves, we must control the final X position
			 * because PowerVR must render to a 32-bit DWORD aligned address,
			 * and in 24 bit mode pixels are multiples of 3 bytes.
			 *
			 * WM_WINDOWPOSCHANGING message allows us to modify a new window position
			 * just before it moves, so we can nudge it to the nearest position that is
			 * a multiple of 3 (RGB24) and 4 (DWORD aligned), ie. a multiple of 12 bytes.
			 *
			 * We assume that each line starts on a DWORD boundry in the
			 * physical (PCI) address space.
			 */
			if (nBitsPerPixel == 24)
			{
				LPWINDOWPOS lpwp = (LPWINDOWPOS) lParam;
				
				if (! (lpwp->flags & SWP_NOMOVE) )
				{
				 	int nNewXPos=lpwp->x;
					int nRemainder;

					/* Add frame width to window position to get new client start position
					 */
					nNewXPos += GetSystemMetrics(SM_CXFRAME);

					/* Force a 12 byte boundry
					 */
					nRemainder = nNewXPos % 12;

					/* Do nearest fit
					 */
					if (nRemainder > 6)
					{
						lpwp->x += (12-nRemainder);
					}
					else if (nRemainder)
					{
						lpwp->x -=nRemainder;
					}
					lpwp->x ++;
				}
			}
		break;

		default:
			/* Call default Window message handler to process message not used by this 
			 * application.
			 */
			return DefWindowProc (hwnd, message, wParam, lParam);
		break;
	}
	return 0;
}


/********************************************************************************************
/*
/*	Function Name	:	ClipRenderWindow
/*	Inputs			:	short	sWinPosX
/*						short	sWinPosY
/*	Outputs			:	Defines viewport size.	
/*	Returns			:	-
/*	Globals Used	:	globalVars
/*	Description		:	Used to clip the render area if it goes out of bounds. Calls a move
/*						window function if clipping required. A semaphore is used to prevent
/*						recursive clipping if window moved, since this function will be
/*						recalled.
/*
/********************************************************************************************/

void ClipRenderWindow(short sWinPosX, short sWinPosY)

{
	int			leftViewport, rightViewport, bottomViewport, topViewport, nClip;
	sgl_bool	bCliped = FALSE, bRight = FALSE, bLeft = FALSE, bBottom = FALSE;
	static sgl_bool	bFirst = TRUE;

	/* Prevent > 1 recursive calls. Exit if already called once.
	 */
	if (!bFirst)
	{
		bFirst = TRUE;
		return;
	}		

	/* Clip on left hand side.
	 */
	leftViewport = globalVars.leftViewport;
	if (sWinPosX < 0)
	{
		leftViewport = abs((639 + sWinPosX) - globalVars.rightViewport);

		/* If less than 32 pixels then set.
		 */
		if ((abs(leftViewport - globalVars.rightViewport) < 32) ||
			(leftViewport < 0))
			leftViewport = globalVars.rightViewport - 31;
	
		bCliped = TRUE;
		bLeft = TRUE;
	}

	/* Clip on right hand side.
	 */
	rightViewport = globalVars.rightViewport;
	nClip = (globalVars.rightViewport + sWinPosX) - GetSystemMetrics(SM_CXFULLSCREEN);
	if (nClip > 0)
	{
		rightViewport = globalVars.leftViewport + (GetSystemMetrics(SM_CXFULLSCREEN) - sWinPosX);

		/* If less than 32 pixels then set.
		 */
		if ((abs(globalVars.leftViewport - rightViewport) < 32) ||
			(rightViewport < 0))
			rightViewport = globalVars.leftViewport + 31;

		bCliped = TRUE;
		bRight = TRUE;
	}
		
	/* Clip on bottom.
	 */
	bottomViewport = globalVars.bottomViewport;
	nClip = (bottomViewport + sWinPosY) - GetSystemMetrics(SM_CYFULLSCREEN);
	if (nClip > 0)
	{
		bottomViewport = globalVars.topViewport + (GetSystemMetrics(SM_CYFULLSCREEN) - sWinPosY);

		/* If less than 32 pixels or negative (in task bar) then set.
		 */
		if ((abs(globalVars.topViewport - bottomViewport) < 32) ||
			(bottomViewport < 0))
			bottomViewport = globalVars.topViewport + 31;

		bCliped = TRUE;
		bBottom = TRUE;
	}

	/* Update viewport and camera settings.
	 */
	sgl_set_viewport(globalVars.viewport, leftViewport, globalVars.topViewport, rightViewport,
				bottomViewport, globalVars.leftCamera, globalVars.topCamera,
				globalVars.rightCamera, globalVars.bottomCamera);

	/* If clipped need to move to 32(n-1) boundary.
	 */
	if (bCliped)
	{
		int			nNewWinPosX, nNewWinPosY, nDiff;
		float		leftCamera, topCamera, rightCamera, bottomCamera;

		sgl_get_viewport(globalVars.viewport, &leftViewport, &topViewport, &rightViewport,
					&bottomViewport, &leftCamera, &topCamera,
					&rightCamera, &bottomCamera);

		nNewWinPosX = sWinPosX;
		nNewWinPosY = sWinPosY;

		/* If right hand side clipping calculate new X window position.
		 */
		if (bRight)
		{
			nDiff = GetSystemMetrics(SM_CXFULLSCREEN) - (sWinPosX + rightViewport + 1);
			nNewWinPosX += + nDiff;
		}
																  	
		/* If bottom hand side clipping calculate new Y window position.
		 */
		if (bBottom)
		{
			nDiff = GetSystemMetrics(SM_CYFULLSCREEN) - (sWinPosY + bottomViewport + 1);
			nNewWinPosY += nDiff + GetSystemMetrics(SM_CYMENU);
		}

		/* If left hand side clipping calculate new Y window position.
		 */
		if (bLeft)
		{
			nDiff = 639 - (rightViewport - leftViewport + 1 - sWinPosX);
			nNewWinPosX = sWinPosX - nDiff;
		}

		/* Prevent > 1 recursive calls.
		 */
		bFirst = FALSE;

		/* Move the window so that rendering performed on complete window.
		 */
		SetWindowPos(hWnd, HWND_NOTOPMOST, (nNewWinPosX - 3), (nNewWinPosY - 41), 0, 0, SWP_NOSIZE);

		/* SPECIAL CASE to prevent clipping when window moved over the top using the arrow keys.
		 */
		bFirst = TRUE;
	}
	return;
}


/****************************************************************************************
/*
/*	Function Name	:	MoveCameraPos
/*	Inputs			:	int			cameraTransform
/*						sgl_vector	camera_pos
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	YAxis, XAxis
/*	Description		:	Routine to position a camera.
/*
/***************************************************************************************/

void MoveCameraPos(int cameraTransform, sgl_vector camera_pos)

{
	/* set up the camera position. Changed by MOUSE.
	 * Calculations only performed if camera selected.
	 *
	 *	3.14159f * 1.5f = 4.712385f
	 */
	if (camera_pos[0] || camera_pos[1] || camera_pos[2])
	{
		sgl_modify_transform(cameraTransform, TRUE);
		sgl_rotate(YAxis, -camera_pos[0] * 4.712385f);
		sgl_rotate(XAxis, -camera_pos[1] * 4.712385f);
		sgl_translate(0.0f, 0.0f,  -60.0f * camera_pos[2]);
	}
}


/****************************************************************************************
/*
/*	Function Name	:	MoveLightPos
/*	Inputs			:	int			lightTransform
/*						int			tLightVolume
/*						sgl_vector	light_pos
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	YAxis, XAxis
/*	Description		:	Routine to position a light. Also positions light volume if 
/*						present.
/*
/***************************************************************************************/

void MoveLightPos(int lightTransform, int tLightVolume, sgl_vector light_pos)

{
	/* Set up the light position. Changed by MOUSE.
	 */
	if (light_pos[0] || light_pos[1] || light_pos[2])
	{
		sgl_modify_transform(lightTransform, TRUE);
		sgl_rotate(YAxis, light_pos[0] * 4.712385f);
		sgl_rotate(XAxis, light_pos[1] * 4.712385f);

		/* Position light volume ?
		 */
		if (tLightVolume)
		{
			sgl_modify_transform(tLightVolume, TRUE);
			sgl_rotate(YAxis, light_pos[0] * 4.712385f);
			sgl_rotate(XAxis, light_pos[1] * 4.712385f);
		}
	}
}


/****************************************************************************************
/*
/*	Function Name	:	ModifyQualitySettings
/*	Inputs			:	
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Routine to update the quality settings.
/*
/***************************************************************************************/

void ModifyQualitySettings(	sgl_bool	hQualList, sgl_bool	texturingQual,
							sgl_bool	shadingQual, sgl_bool	shadowQual,
							sgl_bool	fogQual, sgl_bool	collisionQual,
							BOOL		enable_offscreen)
{

	sgl_modify_list(hQualList,TRUE);
	{
		sgl_qual_smooth_shading(shadingQual);
		sgl_qual_texturing(texturingQual);
		sgl_qual_collision_detection(collisionQual, enable_offscreen);
		sgl_qual_generate_shadows(shadowQual);
		sgl_qual_fog(fogQual);
	}
	sgl_to_parent();
}


/****************************************************************************************
/*
/*	Function Name	:	SetupCachedTexture
/*	Inputs			:	sgl_bool	cached	:Cache texturing ?
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	globalVars
/*						nActivation
/*	Description		:	Sets up cached texture. Used to toggle between two different
/*						cached textures and to switch cached texturing OFF. If FALSE
/*						passed and he last call was FALSE then do nothing.
/*
/***************************************************************************************/

void SetupCachedTexture(sgl_bool cached)
{
	static sgl_bool	bLastAct = FALSE;

	/* Return if call made to create normal texture if last call was to make normal
	 * texture.
	 */
	if ((!cached) && (!bLastAct))
		return;

	bLastAct = cached;

	if (cached)
	{
		/* Reset nActivation counter.
		 */
		nActivation = 0;

		if (globalVars.textureHandle[0])
		{
			sgl_delete_texture(globalVars.textureHandle[0]);
			globalVars.textureHandle[0] = 0;
		}

		sgl_modify_list(globalVars.textureList[0],TRUE);

		globalVars.nCachedTexture = sgl_create_cached_texture(0x01);
		sgl_register_texture_callback(&CachedTextureCallback,globalVars.texData,1);
	}
	else
	{
		if (globalVars.nCachedTexture)
		{
			/* Delete cached texturing.
			 */
			sgl_register_texture_callback(NULL,globalVars.texData,1);

			sgl_unload_cached_texture(globalVars.nCachedTexture);
			globalVars.nCachedTexture = 0;
		}

		sgl_modify_list(globalVars.textureList[0],TRUE);

		/* Create texture for demo depending on which demo has been enabled.
		 */
		switch (globalVars.demoNumber)
		{
			case 1:	strcpy (globalVars.textureName[0],"brick.bmp");
					globalVars.textureMem[0] = ConvertBMPtoSGL(globalVars.textureName[0],FALSE);
					globalVars.textureHandle[0]=
								sgl_create_texture(	sgl_map_16bit_mm,sgl_map_128x128,TRUE,
													TRUE,&(globalVars.textureMem[0]),NULL);
					break;

			case 2:	strcpy (globalVars.textureName[0],"blursky.bmp");
					globalVars.textureMem[0] = ConvertBMPtoSGL(globalVars.textureName[0],FALSE);
					globalVars.textureHandle[0]=
								sgl_create_texture(	sgl_map_16bit_mm,sgl_map_256x256,TRUE,
												TRUE,&(globalVars.textureMem[0]),NULL);
					break;

			default:
					break;
		}


		globalVars.materialHandle[0] = sgl_create_material(NAMED_ITEM,FALSE);
	
		sgl_set_texture_effect(TRUE,TRUE,FALSE,FALSE);

		sgl_set_texture_map(globalVars.textureHandle[0],FALSE,FALSE);
		
		/* Texture wrapping for demo depending on which demo has been enabled.
		 */
		switch (globalVars.demoNumber){
			case 2:	sgl_set_smap(	globalVars.textureIntermediateMap[0],
									globalVars.textureSu[0],
									globalVars.textureSv[0],
									globalVars.textureOu[0],
									globalVars.textureOv[0],
									globalVars.textureRadius[0]);

					sgl_set_omap(	globalVars.textureObjectMap[0],
									globalVars.textureRefIndex[0]); 
					break;

			default:
					break;
		}
	}
}


/****************************************************************************************
/*
/*	Function Name	:	CachedTextureCallback
/*	Inputs			:	sgl_tex_callback_struct	TexDataArray[]
/*						int						num_used
/*						long					free_texture_memory
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	globalVars
/*						nActivation
/*	Description		:	Call back routine for cached texture. Toggles between two textures.
/*
/***************************************************************************************/

void CachedTextureCallback(	sgl_tex_callback_struct TexDataArray[], int	num_used,
							long	free_texture_memory)
{
	static sgl_bool	bTexture = FALSE;

	/* Change texture ?
	 */
	if (nActivation > 100)
	{
		/* Unload cached texture.
		 */
		sgl_unload_cached_texture(globalVars.nCachedTexture);

		/* Select texture to display.
		 */
		if (bTexture)
			strcpy (globalVars.textureName[0],"skin1.bmp");
		else
			strcpy (globalVars.textureName[0],"leaf5.bmp");

		/* Toggle texture to take.
		 */
		bTexture = !bTexture;

		/* reset counter.
		 */
		nActivation = 0;
	}

	/* New cached texture if needed, unloaded and activation = 0.
	 */
	if ((TexDataArray[0].needed && !TexDataArray[0].loaded) || !nActivation)
	{
		sgl_map_sizes	texSize;

		globalVars.materialHandle[0] = sgl_create_material(NAMED_ITEM,FALSE);
		sgl_set_texture_effect(TRUE,TRUE,FALSE,FALSE);
		sgl_set_texture_map(globalVars.nCachedTexture,FALSE,FALSE);
	
		switch (globalVars.demoNumber)
		{
			case 2:	sgl_set_smap(	globalVars.textureIntermediateMap[0],
									globalVars.textureSu[0],
									globalVars.textureSv[0],
									globalVars.textureOu[0],
									globalVars.textureOv[0],
									globalVars.textureRadius[0]);

					sgl_set_omap(	globalVars.textureObjectMap[0],
									globalVars.textureRefIndex[0]); 
			break;

			default:
			break;
		}

		globalVars.textureMem[0] = ConvertBMPtoSGL(globalVars.textureName[0],FALSE);

		if (globalVars.textureMem[globalVars.textureNumber].x_dim <= 256)
			texSize = sgl_map_256x256;
		if (globalVars.textureMem[globalVars.textureNumber].x_dim <= 128)
			texSize = sgl_map_128x128;
		if (globalVars.textureMem[globalVars.textureNumber].x_dim <=  64)
			texSize = sgl_map_64x64;
		if (globalVars.textureMem[globalVars.textureNumber].x_dim <=  32)
			texSize = sgl_map_32x32;

		sgl_load_cached_texture(globalVars.nCachedTexture,
								sgl_map_16bit_mm,texSize,TRUE,
								TRUE,&(globalVars.textureMem[0]),NULL,FALSE);
	}

	/* Increment activation time.
	 */
	nActivation++;
	return;
}


/********************************************************************************************
/*
/*	Function Name	:	AboutMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	About dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL AboutMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{
	HWND			hwndT;
	PTSTR			pach;


    switch (Message)
    {
        case WM_INITDIALOG:
            /*  display some OS version information
             */
            pach = (PTSTR)LocalAlloc(LPTR, APP_MAX_STRING_RC_BYTES);
            if (NULL == pach)
                return (TRUE);

            AppGetWindowsVersion(pach, NULL);
            hwndT = GetDlgItem(hWndDlg, IDD_ABOUT_VERSION_OS);
            SetWindowText(hwndT, pach);

            AppGetWindowsVersion(NULL, pach);
            hwndT = GetDlgItem(hWndDlg, IDD_ABOUT_VERSION_PLATFORM);
            SetWindowText(hwndT, pach);

			/* Get SGL version information.
			 */
			pach = versions->required_header;
			hwndT = GetDlgItem(hWndDlg, IDD_ABOUT_VERSION_SGL);
            SetWindowText(hwndT, pach);

            LocalFree((HLOCAL)pach);
            return (TRUE);

        case WM_COMMAND:
			EndDialog(hWndDlg, TRUE);
            break;
    }
    return (FALSE);
}


/********************************************************************************************
/*
/*	Function Name	:	ScaleMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Scale dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL ScaleMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	float	x = 1.0f, y = 1.0f, z = 1.0f;
	BOOL        	endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:

			UpdateAxisDialogText(hWndDlg, x, y, z);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetAxisValues(hWndDlg, &x, &y, &z);

					if (endDialogFlag == TRUE)
					{
						/* Scale Logo.
						 */
						sgl_modify_transform(globalVars.nTransform, TRUE);
						sgl_scale(x, y, z);

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	TranslationMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Translation dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL TranslationMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	float	x = 0.0f, y = 0.0f, z = 0.0f;
	BOOL        	endDialogFlag;


	switch(Message)
	{
		case WM_INITDIALOG:

			UpdateAxisDialogText(hWndDlg,x,y,z);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetAxisValues(hWndDlg ,&x, &y, &z);

					if (endDialogFlag == TRUE)
					{
						/* Translate Logo.
						 */
						sgl_modify_transform(globalVars.nTransform, TRUE);
						sgl_translate(x, y, z);

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	RotateMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Rotate dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL RotateMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	int		angle = 0;
	UINT        	error;
	char        	szReturnValue[80];
	int				iReturnValue;
	BOOL        	endDialogFlag = TRUE;

	switch(Message)
	{
		case WM_INITDIALOG:

			gcvt(angle,6,szReturnValue);
			SetDlgItemText(hWndDlg,IDC_ROTATE_ANGLE_EDIT     ,szReturnValue);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					/* get angle.
					 */
					error = GetDlgItemText(hWndDlg,IDC_ROTATE_ANGLE_EDIT,szReturnValue,80);

					iReturnValue = (int)atof(szReturnValue);
					if ((iReturnValue >= -360) && (iReturnValue <= 360) && (error != 0))
					{
						angle = iReturnValue;
					}
					else
					{
						endDialogFlag = FALSE;
						gcvt(angle,6,szReturnValue);
						SetDlgItemText(hWndDlg,IDC_ROTATE_ANGLE_EDIT     ,szReturnValue);
					}

					if (endDialogFlag == TRUE)
					{
						/* Rotate Logo.
						 */
						sgl_modify_transform(globalVars.nTransform, TRUE);
						sgl_rotate(ZAxis, (angle * PI) / 180);

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateAxisDialogText
/*	Inputs			:	HWND hWndDlg,float x,float y,float z
/*	Outputs			:	Updates dialog box items.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Update axis dialog box options for any dialog box that uses axis
/*						settings.
/*
/********************************************************************************************/

void UpdateAxisDialogText (HWND hWndDlg,float x,float y,float z)
{
	char szReturnValue[80];


	gcvt(x,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_X_AXIS_EDIT  ,szReturnValue);

	gcvt(y,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_Y_AXIS_EDIT,szReturnValue);

	gcvt(z,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_Z_AXIS_EDIT ,szReturnValue);
}


/********************************************************************************************
/*
/*	Function Name	:	GetAxisValues
/*	Inputs			:	HWND hWndDlg,float *x,float *y,float *z
/*	Outputs			:	-
/*	Returns			:	BOOL
/*	Globals Used	:	-
/*	Description		:	Get axis dialog box options for any dialog box that requires axis
/*						settings.
/*
/********************************************************************************************/

BOOL GetAxisValues (HWND hWndDlg,float *x,float *y,float *z)
{
	UINT        	error;
	char        	szReturnValue[80];
	float       	fReturnValue;
	BOOL        	endDialogFlag = TRUE;

	/* get the X value
	 */
	error = GetDlgItemText(hWndDlg,IDC_X_AXIS_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -50.0) && (fReturnValue <= 50.0) && (error != 0))
	{
		*x = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateColourDialogText(hWndDlg,*x,*y,*z);
	}

	/* get the Y value
	 */
	error = GetDlgItemText(hWndDlg,IDC_Y_AXIS_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -50.0) && (fReturnValue <= 50) && (error != 0))
	{
		*y = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateColourDialogText(hWndDlg,*x,*y,*z);
	}

	/* get the Z value
	 */
	error = GetDlgItemText(hWndDlg,IDC_Z_AXIS_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -50.0) && (fReturnValue <= 50) && (error != 0))
	{
		*z = fReturnValue;
	}
		else
	{
		endDialogFlag = FALSE;
		UpdateColourDialogText(hWndDlg,*x,*y,*z);
	}
	return(endDialogFlag);
}


/********************************************************************************************
/*
/*	Function Name	:	FogMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour fog dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL FogMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	UINT			error;
	char			szReturnValue[80];
	float			fReturnValue;
	static	float	r = 0.0f, g = 0.0f, b = 0.0f, a = 0.0f;
	BOOL			endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.fogColour[0]; 
			g = globalVars.fogColour[1]; 
			b = globalVars.fogColour[2]; 
			a = globalVars.fogDensity; 

			UpdateFogDialogText(hWndDlg,r,g,b,a);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDC_FOG_1_RADIO:
					r = 0.8f;
					g = 0.8f;
					b = 0.8f;
					a = 0.005f;
					UpdateFogDialogText(hWndDlg,r,g,b,a);
				break;

				case IDC_FOG_2_RADIO:
					r = 0.4f;
					g = 0.4f;
					b = 0.4f;
					a = 0.01f;
					UpdateFogDialogText(hWndDlg,r,g,b,a);
				break;

				case IDC_FOG_3_RADIO:
					r = 0.8f;
					g = 0.8f;
					b = 0.8f;
					a = 0.05f;
					UpdateFogDialogText(hWndDlg,r,g,b,a);
				break;

				case IDC_FOG_4_RADIO:
					r = 0.8f;
					g = 0.4f;
					b = 0.4f;
					a = 0.01f;
					UpdateFogDialogText(hWndDlg,r,g,b,a);
				break;

				case IDC_FOG_5_RADIO:
					r = 0.4f;
					g = 0.8f;
					b = 0.4f;
					a = 0.01f;
					UpdateFogDialogText(hWndDlg,r,g,b,a);
				break;

				case IDC_FOG_OFF_BUTTON:
					r = 0.0f;
					g = 0.0f;
					b = 0.0f;
					a = 0.0f;
					UpdateFogDialogText(hWndDlg,r,g,b,a);
				break;

				case IDOK:
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					/* get the density value
					 */
					error = GetDlgItemText(hWndDlg,IDC_FOG_DENSITY_EDIT,szReturnValue,80);

					fReturnValue = (float)atof(szReturnValue);
					if ((fReturnValue >= 0.0) && (fReturnValue <= 1.0) && (error != 0))
					{
						a = fReturnValue;
					}
					else
					{
						endDialogFlag = FALSE;
						UpdateFogDialogText(hWndDlg,r,g,b,a);
					}

					if (endDialogFlag == TRUE)
					{
						globalVars.fogColour[0] = r; 
						globalVars.fogColour[1] = g; 
						globalVars.fogColour[2] = b; 
						globalVars.fogDensity   = a;
						
						/* Set the fog level.
						 */
						sgl_set_fog(globalVars.camera, globalVars.fogColour, globalVars.fogDensity);
						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateFogDialogText
/*	Inputs			:	HWND hWndDlg,float r,float g,float b,float a
/*	Outputs			:	Updates dialog box items.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Update the fog dialog box options.
/*
/********************************************************************************************/

void UpdateFogDialogText (HWND hWndDlg,float r,float g,float b,float a)
{
	char szReturnValue[80];

	UpdateColourDialogText(	hWndDlg, r, g, b);

	gcvt(a,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_FOG_DENSITY_EDIT     ,szReturnValue);
}


/********************************************************************************************
/*
/*	Function Name	:	LightsMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour lights dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL LightsMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{
	int		i;
    HWND	hWndCombo; 
    INT		wIndex;
	 
	switch(Message)
	{
		case WM_INITDIALOG:

			/* Get handles to the Combo box
			 */
			hWndCombo = GetDlgItem(hWndDlg, IDC_LIGHT_CONC_COMBO);

		    wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "0");
		    wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 1, (LONG)(LPSTR) "2");
	    	wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 2, (LONG)(LPSTR) "4");
		    wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 3, (LONG)(LPSTR) "8");
		    wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 4, (LONG)(LPSTR) "16");
	    	wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 5, (LONG)(LPSTR) "32");
		    wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 6, (LONG)(LPSTR) "64");

			UpdateLightDialogText(hWndDlg,&globalVars);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					if (GetLightsDlgItemText(hWndDlg) == TRUE)
					{
						for (i = 0; i < globalVars.lightNumberUsed; i++)
						{
							if (globalVars.lightType[i] == 0)
							{
								sgl_set_parallel_light(	globalVars.lightHandle[i],
														globalVars.lightColour[i],
														globalVars.lightDirection[i],
														globalVars.lightCastsShadows[i],
														globalVars.lightSmoothHighlights[i]);
							}
							else
							{
								sgl_set_point_light(	globalVars.lightHandle[i],
														globalVars.lightColour[i],
														globalVars.lightDirection[i],
														globalVars.lightPosition[i],
														globalVars.lightConcentration[i],
														globalVars.lightCastsShadows[i],
														globalVars.lightSmoothHighlights[i]);
							}
						}

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDC_LIGHT_OFF:
					globalVars.lightCastsShadows[globalVars.lightNumber] = NO_SHADOWS;
					CheckDlgButton(	hWndDlg,
									IDC_LIGHT_SHADOW_CHECK,
									globalVars.lightCastsShadows[globalVars.lightNumber]);

					globalVars.lightSmoothHighlights[globalVars.lightNumber] = FALSE;
  					CheckDlgButton(	hWndDlg,
  									IDC_LIGHT_SMOOTH_CHECK,
  									globalVars.lightSmoothHighlights[globalVars.lightNumber]);

					UpdateColourDialogText(	hWndDlg, 0.0f, 0.0f, 0.0f);
				break;

				case IDC_LIGHT_SHADOW_CHECK:
					if (IsDlgButtonChecked(hWndDlg,IDC_LIGHT_SHADOW_CHECK))
					{
						globalVars.lightCastsShadows[globalVars.lightNumber] = SHADOW_LIGHT;
					}
					else
					{
						globalVars.lightCastsShadows[globalVars.lightNumber] = NO_SHADOWS;
					}
				break;

				case IDC_LIGHT_SMOOTH_CHECK:
					if (IsDlgButtonChecked(hWndDlg,IDC_LIGHT_SMOOTH_CHECK))
					{
						globalVars.lightSmoothHighlights[globalVars.lightNumber] = TRUE;
					}
					else
					{
						globalVars.lightSmoothHighlights[globalVars.lightNumber] = FALSE;
					}
				break;

				case IDC_LIGHT_1_RADIO:
					if (GetLightsDlgItemText(hWndDlg) == TRUE)
					{
						globalVars.lightNumber = 0;
					}
					UpdateLightDialogText(hWndDlg,&globalVars);
				break;

				case IDC_LIGHT_2_RADIO:
					if (GetLightsDlgItemText(hWndDlg) == TRUE)
					{
						globalVars.lightNumber = 1;
					}
					UpdateLightDialogText(hWndDlg,&globalVars);
				break;

				case IDC_LIGHT_3_RADIO:
					if (GetLightsDlgItemText(hWndDlg) == TRUE)
					{
						globalVars.lightNumber = 2;
					}
					UpdateLightDialogText(hWndDlg,&globalVars);
				break;

				case IDC_LIGHT_4_RADIO:
					if (GetLightsDlgItemText(hWndDlg) == TRUE)
					{
						globalVars.lightNumber = 3;
					}
					UpdateLightDialogText(hWndDlg,&globalVars);
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateLightDialogText
/*	Inputs			:	HWND hWndDlg, GLOBALVARS *gV
/*	Outputs			:	Updates dialog box items.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Update the light dialog box options.
/*
/********************************************************************************************/

void UpdateLightDialogText (HWND hWndDlg, GLOBALVARS *gV)
{
	int		number;
    HWND	hWndCombo; 


	number = gV->lightNumber;

	switch (number)
	{
		case 0:
			CheckRadioButton(hWndDlg,IDC_LIGHT_1_RADIO,IDC_LIGHT_4_RADIO,IDC_LIGHT_1_RADIO);
		break;

		case 1:
			CheckRadioButton(hWndDlg,IDC_LIGHT_1_RADIO,IDC_LIGHT_4_RADIO,IDC_LIGHT_2_RADIO);
		break;

		case 2:
			CheckRadioButton(hWndDlg,IDC_LIGHT_1_RADIO,IDC_LIGHT_4_RADIO,IDC_LIGHT_3_RADIO);
		break;

		case 3:
			CheckRadioButton(hWndDlg,IDC_LIGHT_1_RADIO,IDC_LIGHT_4_RADIO,IDC_LIGHT_4_RADIO);
		break;

		default:
			/* do nothing...
			 */
		break;
	}

	/* Get handles to the Combo box
	 */
	hWndCombo = GetDlgItem(hWndDlg, IDC_LIGHT_CONC_COMBO);

	/* Which lens has been selected.
	 */
	if (globalVars.lightConcentration[globalVars.lightNumber] == 64)
		SendMessage (hWndCombo, CB_SETCURSEL, 6, 0L);
	else
		if (globalVars.lightConcentration[globalVars.lightNumber] == 32)
			SendMessage (hWndCombo, CB_SETCURSEL, 5, 0L);
		else
			if (globalVars.lightConcentration[globalVars.lightNumber] == 16)
				SendMessage (hWndCombo, CB_SETCURSEL, 4, 0L);
			else
				if (globalVars.lightConcentration[globalVars.lightNumber] == 8)
					SendMessage (hWndCombo, CB_SETCURSEL, 3, 0L);
				else
					if (globalVars.lightConcentration[globalVars.lightNumber] == 4)
						SendMessage (hWndCombo, CB_SETCURSEL, 2, 0L);
					else
						if (globalVars.lightConcentration[globalVars.lightNumber] == 2)
							SendMessage (hWndCombo, CB_SETCURSEL, 1, 0L);
						else
							SendMessage (hWndCombo, CB_SETCURSEL, 0, 0L);

	/* Light type.
	 */
	if (globalVars.lightType[globalVars.lightNumber] == 0)
		SetDlgItemText(hWndDlg,IDC_EDIT1  ,"Parallel Light");
	else
		SetDlgItemText(hWndDlg,IDC_EDIT1  ,"Point Light");

	UpdateColourDialogText(	hWndDlg,
							gV->lightColour[number][0],
							gV->lightColour[number][1],
							gV->lightColour[number][2]);

	CheckDlgButton(hWndDlg,IDC_LIGHT_SHADOW_CHECK,gV->lightCastsShadows[number]);

  	CheckDlgButton(hWndDlg,IDC_LIGHT_SMOOTH_CHECK,gV->lightSmoothHighlights[number]);
}


/********************************************************************************************
/*
/*	Function Name	:	GetLightsDlgItemText
/*	Inputs			:	HWND hWndDlg
/*	Outputs			:	-
/*	Returns			:	BOOL
/*	Globals Used	:	-
/*	Description		:	Routine to get the colour settings for a particular light when the
/*						light dialog box is active.
/*
/********************************************************************************************/

BOOL GetLightsDlgItemText(HWND hWndDlg)
{
	BOOL	endDialogFlag;
	float	r, g, b;	
    HWND	hWndCombo; 
    INT		wIndex;

	endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

	if (endDialogFlag == TRUE)
	{
		globalVars.lightColour[globalVars.lightNumber][0] = r; 
		globalVars.lightColour[globalVars.lightNumber][1] = g; 
		globalVars.lightColour[globalVars.lightNumber][2] = b;
	}

	/* Light type.
	 */
	if (globalVars.lightType[globalVars.lightNumber] == 1)
	{
		/* Get handles to the Combo box
		 */
		hWndCombo = GetDlgItem(hWndDlg, IDC_LIGHT_CONC_COMBO);

		wIndex = (WORD) SendMessage (hWndCombo, CB_GETCURSEL, 0, 0L);
		if (wIndex == CB_ERR)
		{
			endDialogFlag = FALSE;
			AppMsgBox(hWnd, MB_OK | MB_ICONEXCLAMATION,
					TEXT("No Selection"));
		}
		else
		{
			if (wIndex != 0)
				globalVars.lightConcentration[globalVars.lightNumber] = (int) pow(2,(double) wIndex); 
			else
				globalVars.lightConcentration[globalVars.lightNumber] = 0; 
		}
	}
	return endDialogFlag;
}


/********************************************************************************************
/*
/*	Function Name	:	AmbientMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour ambient dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL AmbientMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	float	r = 0.0f, g = 0.0f, b = 0.0f;
	BOOL        	endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.ambientColour[0]; 
			g = globalVars.ambientColour[1]; 
			b = globalVars.ambientColour[2]; 

			UpdateColourDialogText(hWndDlg,r,g,b);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					if (endDialogFlag == TRUE)
					{
						globalVars.ambientColour[0] = r; 
						globalVars.ambientColour[1] = g; 
						globalVars.ambientColour[2] = b; 
	
						sgl_set_ambient_light(globalVars.ambientHandle,globalVars.ambientColour,FALSE);

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	MaterialAmbientMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour ambient dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL MaterialAmbientMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	float	r = 0.0f, g = 0.0f, b = 0.0f;
	BOOL        	endDialogFlag;


	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.ambientMatColour[0]; 
			g = globalVars.ambientMatColour[1]; 
			b = globalVars.ambientMatColour[2]; 

			UpdateColourDialogText(hWndDlg,r,g,b);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					if (endDialogFlag == TRUE)
					{
						globalVars.ambientMatColour[0] = r; 
						globalVars.ambientMatColour[1] = g; 
						globalVars.ambientMatColour[2] = b; 

						sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
						{
							sgl_modify_material(globalVars.materialHandle[1], FALSE);
							sgl_set_ambient(globalVars.ambientMatColour);
						}
						sgl_to_parent();

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	MaterialDiffuseMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour ambient dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL MaterialDiffuseMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	char        	i;
	static 	float	r = 0.0f, g = 0.0f, b = 0.0f;
	BOOL        	endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.diffuseMatColour[0]; 
			g = globalVars.diffuseMatColour[1]; 
			b = globalVars.diffuseMatColour[2]; 

			UpdateColourDialogText(hWndDlg,r,g,b);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					if (endDialogFlag == TRUE)
					{
						globalVars.diffuseMatColour[0] = r; 
						globalVars.diffuseMatColour[1] = g; 
						globalVars.diffuseMatColour[2] = b; 
	
						for (i = 0; i < PARTS; i++)
						{
							sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
							{
								sgl_modify_material(*(material_ptr + i), FALSE);
								sgl_set_diffuse(globalVars.diffuseMatColour);
							}
							sgl_to_parent();
						}
						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	MaterialSpecularMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour fog dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL MaterialSpecularMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	UINT			error;
	char			szReturnValue[80];
	int				iReturnValue;
	static	float	r = 0.0f, g = 0.0f, b = 0.0f;
	int				a = 0;
	BOOL			endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.specularMatColour[0]; 
			g = globalVars.specularMatColour[1]; 
			b = globalVars.specularMatColour[2]; 
			a = globalVars.specularMatShine; 

			UpdateMaterialSpecularDialogText(hWndDlg,r,g,b,a);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					/* get the density value
					 */
					error = GetDlgItemText( hWndDlg, IDC_MATERIAL_SHINE_EDIT, szReturnValue,80);

					iReturnValue = (int)atof(szReturnValue);
					if ((iReturnValue >= 0) && (iReturnValue <= 1000) && (error != 0))
					{
						a = iReturnValue;
					}
					else
					{
						endDialogFlag = FALSE;
						UpdateMaterialSpecularDialogText(hWndDlg,r,g,b,a);
					}

					if (endDialogFlag == TRUE)
					{
						globalVars.specularMatColour[0]	= r; 
						globalVars.specularMatColour[1]	= g; 
						globalVars.specularMatColour[2]	= b; 
						globalVars.specularMatShine		= a;
						
						sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
						{
							sgl_modify_material(globalVars.materialHandle[1], FALSE);
							sgl_set_specular(globalVars.specularMatColour, globalVars.specularMatShine);
						}
						sgl_to_parent();

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateMaterialSpecularDialogText
/*	Inputs			:	HWND hWndDlg,float r,float g,float b,int a
/*	Outputs			:	Updates the dialog box items.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Update the material specular dialog box settings.
/*
/********************************************************************************************/

void UpdateMaterialSpecularDialogText (HWND hWndDlg,float r,float g,float b,int a)
{
	char szReturnValue[80];

	UpdateColourDialogText(	hWndDlg, r, g, b);
	gcvt(a,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_MATERIAL_SHINE_EDIT     ,szReturnValue);
}


/********************************************************************************************
/*
/*	Function Name	:	MaterialGlowMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour ambient dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL MaterialGlowMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	float	r = 0.0f, g = 0.0f, b = 0.0f;
	BOOL        	endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.glowMatColour[0]; 
			g = globalVars.glowMatColour[1]; 
			b = globalVars.glowMatColour[2]; 

			UpdateColourDialogText(hWndDlg,r,g,b);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					if (endDialogFlag == TRUE)
					{
						globalVars.glowMatColour[0] = r; 
						globalVars.glowMatColour[1] = g; 
						globalVars.glowMatColour[2] = b; 
	
						sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
						{
							sgl_modify_material(globalVars.materialHandle[1], FALSE);
							sgl_set_glow(globalVars.glowMatColour);
						}
						sgl_to_parent();

						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	MaterialOpacityMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour ambient dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL MaterialOpacityMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	UINT			error;
	char        	i;
	static 	float	opacity = 0.0f;
	float			fReturnValue;
	BOOL        	endDialogFlag;
	char			szReturnValue[80];

	switch(Message)
	{
		case WM_INITDIALOG:
			opacity = globalVars.opacityMatValue; 

			gcvt(opacity,6,szReturnValue);
			SetDlgItemText(hWndDlg,IDC_MATERIAL_OPACITY_EDIT     ,szReturnValue);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = TRUE;

					/* get the opacity value
					 */
					error = GetDlgItemText(	hWndDlg,
											IDC_MATERIAL_OPACITY_EDIT,
											szReturnValue,80);

					fReturnValue = (float)atof(szReturnValue);
					if ((fReturnValue >= 0.0) && (fReturnValue <= 1.0) && (error != 0))
					{
						opacity = fReturnValue;
					}
					else
					{
						endDialogFlag = FALSE;
						gcvt(opacity,6,szReturnValue);
						SetDlgItemText(hWndDlg,IDC_MATERIAL_OPACITY_EDIT     ,szReturnValue);
					}

					if (endDialogFlag == TRUE)
					{
						globalVars.opacityMatValue = opacity; 
	
						for (i = 1; i < PARTS; i += 2)
						{
							sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
							{
								sgl_modify_material(*(material_ptr + i), FALSE);
								sgl_set_opacity(globalVars.opacityMatValue);
							}
							sgl_to_parent();
						}
						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	BackgroundColourMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Colour ambient dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL BackgroundColourMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	float	r = 0.0f, g = 0.0f, b = 0.0f;
	BOOL        	endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.backgroundColour[0]; 
			g = globalVars.backgroundColour[1]; 
			b = globalVars.backgroundColour[2]; 

			UpdateColourDialogText(hWndDlg,r,g,b);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					if (endDialogFlag == TRUE)
					{
						globalVars.backgroundColour[0] = r; 
						globalVars.backgroundColour[1] = g; 
						globalVars.backgroundColour[2] = b; 

						/* Detach current background plane from list.
						 */
						sgl_detach_list(globalVars.backgroundList);

						/* Colour background plane.
						 */
						sgl_set_background_colour(globalVars.camera, globalVars.backgroundColour);
						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDC_DEFAULT:
					/* Attach current background plane to list.
					 */
					sgl_modify_list(globalVars.cameraList,FALSE);
					{
						sgl_attach_list(globalVars.backgroundList);
					}sgl_to_parent();
					EndDialog(hWndDlg, FALSE);
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	MultiShadowsMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Multi Shadows dialog box.
/*
/********************************************************************************************/

BOOL FAR PASCAL MultiShadowsMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static 	float		r = 0.0f, g = 0.0f, b = 0.0f;
	static	sgl_bool	bMultiShadows = FALSE;
	BOOL        		endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			r = globalVars.MultiShadowsColour[0]; 
			g = globalVars.MultiShadowsColour[1]; 
			b = globalVars.MultiShadowsColour[2]; 
			bMultiShadows = globalVars.bMultiShadows; 

			UpdateColourDialogText(hWndDlg,r,g,b);
			CheckDlgButton(hWndDlg, IDC_MULTISHADOWS_CHECK, bMultiShadows);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					bMultiShadows = IsDlgButtonChecked(hWndDlg, IDC_MULTISHADOWS_CHECK);
					endDialogFlag = GetColourValues(hWndDlg ,&r, &g, &b);

					if (endDialogFlag == TRUE)
					{
						globalVars.MultiShadowsColour[0] = r; 
						globalVars.MultiShadowsColour[1] = g; 
						globalVars.MultiShadowsColour[2] = b; 
						globalVars.bMultiShadows = bMultiShadows; 

						/* Set Multishadow values.
						 */
						sgl_pseudo_multishadows(globalVars.bMultiShadows, globalVars.MultiShadowsColour);
						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateColourDialogText
/*	Inputs			:	HWND hWndDlg,float r,float g,float b
/*	Outputs			:	Updates the dialog box items.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Standard routine to update the colour settings for any active dialog
/*						box with colour options.
/*
/********************************************************************************************/

void UpdateColourDialogText (HWND hWndDlg,float r,float g,float b)
{
	char szReturnValue[80];

	gcvt(r,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_COLOUR_RED_EDIT  ,szReturnValue);

	gcvt(g,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_COLOUR_GREEN_EDIT,szReturnValue);

	gcvt(b,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_COLOUR_BLUE_EDIT ,szReturnValue);
}


/********************************************************************************************
/*
/*	Function Name	:	GetColourValues
/*	Inputs			:	HWND hWndDlg,float *r,float *g,float *b
/*	Outputs			:	-
/*	Returns			:	BOOL
/*	Globals Used	:	-
/*	Description		:	Standard routine to get the colour settings from any active dialog
/*						box with colour options.
/*
/********************************************************************************************/

BOOL GetColourValues (HWND hWndDlg,float *r,float *g,float *b)
{
	UINT        	error;
	char        	szReturnValue[80];
	float       	fReturnValue;
	BOOL        	endDialogFlag = TRUE;

	/* get the red value
	 */
	error = GetDlgItemText(hWndDlg,IDC_COLOUR_RED_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (fReturnValue <= 1.0) && (error != 0))
	{
		*r = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateColourDialogText(hWndDlg,*r,*g,*b);
	}

	/* get the green value
	 */
	error = GetDlgItemText(hWndDlg,IDC_COLOUR_GREEN_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (fReturnValue <= 1.0) && (error != 0))
	{
		*g = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateColourDialogText(hWndDlg,*r,*g,*b);
	}

	/* get the blue value
	 */
	error = GetDlgItemText(hWndDlg,IDC_COLOUR_BLUE_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (fReturnValue <= 1.0) && (error != 0))
	{
		*b = fReturnValue;
	}
		else
	{
		endDialogFlag = FALSE;
		UpdateColourDialogText(hWndDlg,*r,*g,*b);
	}
	return(endDialogFlag);
}


/********************************************************************************************
/*
/*	Function Name	:	LevelOfDetailMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	LevelOfDetail ambient dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL LevelOfDetailMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static	sgl_vector	boxCorner1, boxCorner2;
	static	int			sizes[2], models[3];
	BOOL	        	endDialogFlag;

	switch(Message)
	{
		case WM_INITDIALOG:
			sgl_get_detail_levels(globalVars.levelDetail, boxCorner1, boxCorner2, models, sizes);

			UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetLevelOfDetailValues(hWndDlg, boxCorner1, boxCorner2, sizes);

					if (endDialogFlag == TRUE)
					{
						sgl_set_detail_levels(globalVars.levelDetail, boxCorner1, boxCorner2, models, sizes);
						EndDialog(hWndDlg, TRUE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateLevelOfDetailDialogText
/*	Inputs			:	HWND hWndDlg, sgl_vector boxCorner1, sgl_vector boxCorner2, int sizes[2]
/*	Outputs			:	Updates the dialog box.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Updates the level of detail dialog box fields.
/*
/********************************************************************************************/

void UpdateLevelOfDetailDialogText (HWND hWndDlg, sgl_vector boxCorner1, sgl_vector boxCorner2, int sizes[2])
{
	char szReturnValue[80];

	gcvt(boxCorner1[0],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CORNER_X1  ,szReturnValue);

	gcvt(boxCorner1[1],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CORNER_Y1  ,szReturnValue);

	gcvt(boxCorner1[2],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CORNER_Z1  ,szReturnValue);

	gcvt(boxCorner2[0],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CORNER_X2  ,szReturnValue);

	gcvt(boxCorner2[1],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CORNER_Y2  ,szReturnValue);

	gcvt(boxCorner2[2],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CORNER_Z2  ,szReturnValue);

	gcvt(sizes[0],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_SIZE_1 ,szReturnValue);

	gcvt(sizes[1],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_SIZE_2 ,szReturnValue);
}


/********************************************************************************************
/*
/*	Function Name	:	GetLevelOfDetailValues
/*	Inputs			:	HWND hWndDlg, sgl_vector boxCorner1, sgl_vector boxCorner2, int sizes[2]
/*	Outputs			:	-
/*	Returns			:	BOOL
/*	Globals Used	:	-
/*	Description		:	Gets the selected options from the level of detail dialog box.
/*
/********************************************************************************************/

BOOL GetLevelOfDetailValues (HWND hWndDlg, sgl_vector boxCorner1, sgl_vector boxCorner2, int sizes[2])
{
	UINT        	error;
	char        	szReturnValue[80];
	float       	fReturnValue;
	int	       		iReturnValue;
	BOOL        	endDialogFlag = TRUE;

	/* get the box corner X1 value
	 */
	error = GetDlgItemText(hWndDlg,IDC_CORNER_X1,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		boxCorner1[0] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	/* get the box corner Y1 value
	 */
	error = GetDlgItemText(hWndDlg,IDC_CORNER_Y1,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		boxCorner1[1] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	/* get the box corner Z1 value
	 */
	error = GetDlgItemText(hWndDlg,IDC_CORNER_Z1,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		boxCorner1[2] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	/* get the box corner X2 value
	 */
	error = GetDlgItemText(hWndDlg,IDC_CORNER_X2,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		boxCorner2[0] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	/* get the box corner Y1 value
	 */
	error = GetDlgItemText(hWndDlg,IDC_CORNER_Y2,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		boxCorner2[1] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	/* get the box corner Z2 value
	 */
	error = GetDlgItemText(hWndDlg,IDC_CORNER_Z2,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		boxCorner2[2] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	/* Size value 1.
	 */
	error = GetDlgItemText(hWndDlg,IDC_SIZE_1,szReturnValue,80);

	iReturnValue = (int)atof(szReturnValue);
	if ((iReturnValue >= 0) && (iReturnValue <= 640) && (error != 0))
	{
		sizes[0] = iReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	/* Size value 2.
	 */
	error = GetDlgItemText(hWndDlg,IDC_SIZE_2,szReturnValue,80);

	iReturnValue = (int)atof(szReturnValue);
	if ((iReturnValue >= 0) && (iReturnValue <= 640) && (error != 0))
	{
		sizes[1] = iReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateLevelOfDetailDialogText(hWndDlg, boxCorner1, boxCorner2, sizes);
	}

	return(endDialogFlag);
}


/********************************************************************************************
/*
/*	Function Name	:	CameraViewportMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Camera and viewport dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL CameraViewportMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{ 
	static	int						numberDevice;
	static	int						xDevice;
	static	int						yDevice;
	static	sgl_device_colour_types	modeDevice;
	static	sgl_bool				doublebufferDevice;
	static	float					zoomCamera;
	static	float					foregroundCamera;
	static	float					inv_backgroundCamera;
	static	float					leftCamera;
	static	float					topCamera;
	static	float					rightCamera;
	static	float					bottomCamera;
	static	int						leftViewport;
	static	int						topViewport;
	static	int						rightViewport;
	static	int						bottomViewport;
	static	UINT					subtractView = 0;

	BOOL			endDialogFlag;
    HWND			hWndCombo;                  /* Handle to the combo box control */
    INT				wIndex;
	static int		viewport2;

	/* Get handles to the Combo box
	 */
	hWndCombo = GetDlgItem(hWndDlg, IDC_CAMERA_COMBO);

	switch(Message)
	{
		case WM_INITDIALOG:
            wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "15mm");
            wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "24mm");
            wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "35mm");
            wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "50mm");
            wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "75mm");
            wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "100mm");
            wIndex = (WORD) SendMessage( hWndCombo, CB_ADDSTRING, 0, (LONG)(LPSTR) "200mm");

			/* Get Device, Viewport and camera settings.
			 */
			sgl_get_device(	globalVars.screenDevice, &numberDevice, &xDevice,	
						&yDevice, &modeDevice, &doublebufferDevice);

			sgl_get_viewport(globalVars.viewport, &leftViewport, &topViewport,
						&rightViewport, &bottomViewport, &leftCamera,
						&topCamera, &rightCamera, &bottomCamera);

			sgl_get_camera(	globalVars.camera, &zoomCamera, &foregroundCamera, &inv_backgroundCamera);

			UpdateCameraViewportDialogText(	hWndDlg, numberDevice, xDevice, yDevice, modeDevice,
											doublebufferDevice, zoomCamera, foregroundCamera,
											inv_backgroundCamera, leftCamera, topCamera,
											rightCamera, bottomCamera, leftViewport, topViewport,
											rightViewport, bottomViewport);

			CheckDlgButton(hWndDlg, IDC_VIEWPORT_SUBTRACT_CHECK, subtractView);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					endDialogFlag = GetCameraViewportValues(hWndDlg, &zoomCamera, &foregroundCamera,
															&inv_backgroundCamera, &leftCamera,
															&topCamera, &rightCamera, &bottomCamera,
															&leftViewport, &topViewport, 
															&rightViewport, &bottomViewport);

					if (endDialogFlag == TRUE)
					{
						globalVars.zoomCamera			= zoomCamera;
						globalVars.foregroundCamera		= foregroundCamera;
						globalVars.inv_backgroundCamera	= inv_backgroundCamera;
						globalVars.leftCamera			= leftCamera;
						globalVars.topCamera			= topCamera;
						globalVars.rightCamera			= rightCamera;
						globalVars.bottomCamera			= bottomCamera;
						globalVars.leftViewport			= leftViewport;
						globalVars.topViewport			= topViewport;
						globalVars.rightViewport		= rightViewport;
						globalVars.bottomViewport		= bottomViewport;

						/* Update viewport and camera settings.
						 * Clip the render window ? Routine sets up the viewport and clips the
						 * window if need be.
						 */
						ClipRenderWindow(xPos, yPos);

						sgl_set_camera(	globalVars.camera,
									globalVars.zoomCamera,
									globalVars.foregroundCamera,
									globalVars.inv_backgroundCamera);

						EndDialog(hWndDlg, TRUE);
					}

					/* Delete viewport 2.
					 */
					if (viewport2)
					{
						sgl_delete_viewport(viewport2);
						viewport2 = 0;
					}

					if (subtractView = IsDlgButtonChecked(hWndDlg, IDC_VIEWPORT_SUBTRACT_CHECK))
					{
						/* Create dummy viewport.
						 */
						viewport2 = sgl_create_viewport(	globalVars.screenDevice,
													globalVars.leftViewport / 2,
													globalVars.topViewport / 2,
													globalVars.rightViewport / 2,
													globalVars.bottomViewport / 2,
													0.0f,
													0.0f,
													0.0f,
													0.0f);
						sgl_subtract_viewport(globalVars.viewport,viewport2);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;

				case IDC_DEFAULT:
				 	/* Initialise camera and viewport settings.
					 */
					zoomCamera			= LENS_35MM;	/* 35mm	*/
					foregroundCamera	= 10.0f;
					inv_backgroundCamera= 0.0f;

					leftViewport		= 0;
					topViewport			= 0;
					rightViewport		= 640;
					bottomViewport		= 480;
					leftCamera			= 80.0f;
					topCamera			= 0.0f;
					rightCamera			= 560.0f;
					bottomCamera		= 480.0f;

					UpdateCameraViewportDialogText(	hWndDlg, numberDevice, xDevice, yDevice,
													modeDevice, doublebufferDevice, zoomCamera,
													foregroundCamera, inv_backgroundCamera,
													leftCamera, topCamera, rightCamera,
													bottomCamera, leftViewport, topViewport,
													rightViewport, bottomViewport);

					subtractView = FALSE;
					CheckDlgButton(hWndDlg, IDC_VIEWPORT_SUBTRACT_CHECK, subtractView);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateCameraViewportDialogText
/*	Inputs			:
/*	Outputs			:	Updates the dialog box entries.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Updates the camera/vewport dialog box options.
/*
/********************************************************************************************/

void UpdateCameraViewportDialogText	(	HWND hWndDlg, int numberDevice, int xDevice, int yDevice,
										sgl_device_colour_types modeDevice, sgl_bool doublebufferDevice,
										float zoomCamera, float foregroundCamera,
										float inv_backgroundCamera, float leftCamera, float topCamera,
										float rightCamera, float bottomCamera, int leftViewport,
										int topViewport, int rightViewport, int bottomViewport)
{
	char	szReturnValue[80];
	BOOL	endDialogFlag = TRUE;
    HWND	hWndCombo;                  /* Handle to the combo box control */

	/* Get handles to the Combo box
	 */
	hWndCombo = GetDlgItem(hWndDlg, IDC_CAMERA_COMBO);

	/* Which lens has been selected.
	 */
	if (zoomCamera == LENS_200MM)
		SendMessage (hWndCombo, CB_SETCURSEL, 6, 0L);						/* 200mm	*/
	else
		if (zoomCamera == LENS_100MM)
			SendMessage (hWndCombo, CB_SETCURSEL, 5, 0L);					/* 100mm	*/
		else
			if (zoomCamera == LENS_75MM)
				SendMessage (hWndCombo, CB_SETCURSEL, 4, 0L);				/* 75mm		*/
			else
				if (zoomCamera == LENS_50MM)
					SendMessage (hWndCombo, CB_SETCURSEL, 3, 0L);			/* 50mm		*/
				else
					if (zoomCamera == LENS_35MM)
						SendMessage (hWndCombo, CB_SETCURSEL, 2, 0L);		/* 35mm		*/
					else
						if (zoomCamera == LENS_24MM)
							SendMessage (hWndCombo, CB_SETCURSEL, 1, 0L);	/* 24mm		*/
						else
							SendMessage (hWndCombo, CB_SETCURSEL, 0, 0L);	/* 15mm		*/


	/* Device settings.
	 */
	gcvt(numberDevice,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_DEVICE_NUMBER  ,szReturnValue);

	gcvt(xDevice,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_DEVICE_X_DIMENSION  ,szReturnValue);

	gcvt(yDevice,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_DEVICE_Y_DIMENSION  ,szReturnValue);

	gcvt(modeDevice,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_DEVICE_MODE  ,szReturnValue);

	gcvt(doublebufferDevice,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_DEVICE_BUFFERING  ,szReturnValue);

	/* Camera Window.
	 */
	gcvt(leftCamera,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CAMERA_LEFT_EDIT  ,szReturnValue);

	gcvt(topCamera,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CAMERA_TOP_EDIT  ,szReturnValue);

	gcvt(rightCamera,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CAMERA_RIGHT_EDIT  ,szReturnValue);

	gcvt(bottomCamera,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_CAMERA_BOTTOM_EDIT  ,szReturnValue);

	/* Viewport Window.
	 */
	gcvt(leftViewport,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_VIEWPORT_LEFT_EDIT  ,szReturnValue);

	gcvt(topViewport,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_VIEWPORT_TOP_EDIT  ,szReturnValue);

	gcvt(rightViewport,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_VIEWPORT_RIGHT_EDIT  ,szReturnValue);

	gcvt(bottomViewport,6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_VIEWPORT_BOTTOM_EDIT  ,szReturnValue);
}


/********************************************************************************************
/*
/*	Function Name	:	GetCameraViewportValues
/*	Inputs			:	HWND	hWndDlg,
/*						float	*zoomCamera,
/*						float	*foregroundCamera,
/*						float	*inv_backgroundCamera,
/*						float	*leftCamera,
/*						float	*topCamera,
/*						float	*rightCamera,
/*						float	*bottomCamera,
/*						int		*leftViewport,
/*						int		*topViewport,
/*						int		*rightViewport,
/*						int		*bottomViewport
/*	Outputs			:	-
/*	Returns			:	BOOL
/*	Globals Used	:
/*	Description		:	Gets the settings selected in the camera/viewport dialog box.
/*
/********************************************************************************************/

BOOL GetCameraViewportValues(	HWND hWndDlg, float *zoomCamera, float *foregroundCamera,
								float *inv_backgroundCamera, float *leftCamera, float *topCamera,
								float *rightCamera, float *bottomCamera, int *leftViewport,
								int *topViewport, int *rightViewport, int *bottomViewport )
{
	UINT			error;
	char			szReturnValue[80];
	float			fReturnValue;
	int				iReturnValue;
	BOOL			endDialogFlag = TRUE;
    HWND hWndCombo;                  /* Handle to the combo box control */
    INT  wIndex;

	/* Get handles to the Combo box
	 */
	hWndCombo = GetDlgItem(hWndDlg, IDC_CAMERA_COMBO);

	wIndex = (WORD) SendMessage (hWndCombo, CB_GETCURSEL, 0, 0L);
	if (wIndex == CB_ERR)
        AppMsgBox(hWnd, MB_OK | MB_ICONEXCLAMATION,
                  TEXT("No Selection"));
	else{
		switch (wIndex)
		{
			case 0:
				*zoomCamera = LENS_15MM;
			break;

			case 1:
				*zoomCamera = LENS_24MM;
			break;

			case 2:
				*zoomCamera = LENS_35MM;
			break;

			case 3:
				*zoomCamera = LENS_50MM;
			break;

			case 4:
				*zoomCamera = LENS_75MM;
			break;

			case 5:
				*zoomCamera = LENS_100MM;
			break;

			case 6:
				*zoomCamera = LENS_200MM;
			break;

			default:
			break;
		}
	}

	/* Camera Window.
	 */
	error = GetDlgItemText(hWndDlg,IDC_CAMERA_LEFT_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*leftCamera = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*leftCamera,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_CAMERA_LEFT_EDIT  ,szReturnValue);
	}

	error = GetDlgItemText(hWndDlg,IDC_CAMERA_TOP_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*topCamera = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*topCamera,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_CAMERA_TOP_EDIT  ,szReturnValue);
	}

	error = GetDlgItemText(hWndDlg,IDC_CAMERA_RIGHT_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*rightCamera = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*rightCamera,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_CAMERA_RIGHT_EDIT  ,szReturnValue);
	}

	error = GetDlgItemText(hWndDlg,IDC_CAMERA_BOTTOM_EDIT,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*bottomCamera = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*bottomCamera,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_CAMERA_BOTTOM_EDIT  ,szReturnValue);
	}

	/* Viewport Window.
	 */
	error = GetDlgItemText(hWndDlg,IDC_VIEWPORT_LEFT_EDIT,szReturnValue,80);

	iReturnValue = (int)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*leftViewport = iReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*leftViewport,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_VIEWPORT_LEFT_EDIT  ,szReturnValue);
	}

	error = GetDlgItemText(hWndDlg,IDC_VIEWPORT_TOP_EDIT,szReturnValue,80);

	iReturnValue = (int)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*topViewport = iReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*topViewport,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_VIEWPORT_TOP_EDIT  ,szReturnValue);
	}

	error = GetDlgItemText(hWndDlg,IDC_VIEWPORT_RIGHT_EDIT,szReturnValue,80);

	iReturnValue = (int)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*rightViewport = iReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*rightViewport,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_VIEWPORT_RIGHT_EDIT  ,szReturnValue);
	}

	error = GetDlgItemText(hWndDlg,IDC_VIEWPORT_BOTTOM_EDIT,szReturnValue,80);

	iReturnValue = (int)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (error != 0))
	{
		*bottomViewport = iReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		gcvt(*bottomViewport,6,szReturnValue);
		SetDlgItemText(hWndDlg,IDC_VIEWPORT_BOTTOM_EDIT  ,szReturnValue);
	}

	return(endDialogFlag);
}


/********************************************************************************************
/*
/*	Function Name	:	TextureShortMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Texture dialogue box without texture wrapping functionality.
/*
/********************************************************************************************/

BOOL FAR PASCAL TextureShortMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{
	OPENFILENAME	ofn;
	PAINTSTRUCT		Paint;
	RECT			picRect;
	sgl_map_sizes	texSize;
	static char		szFileName[_MAX_PATH];
	static BOOL		bTexture = FALSE;

	GetWindowRect  (GetDlgItem(hWndDlg,IDC_STATIC_PICTURE),&picRect);
	ScreenToClient (hWndDlg, (LPPOINT) &picRect.left);
	ScreenToClient (hWndDlg, (LPPOINT) &picRect.right);

	switch(Message)
	{
		case WM_INITDIALOG:
			strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);

			if (globalVars.textureNumberUsed < 6)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO6),FALSE);
			 
			if (globalVars.textureNumberUsed < 5)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO5),FALSE);
			 
			if (globalVars.textureNumberUsed < 4)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO4),FALSE);
			 
			if (globalVars.textureNumberUsed < 3)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO3),FALSE);
			 
			if (globalVars.textureNumberUsed < 2)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO2),FALSE);
			 
			if (globalVars.textureNumberUsed < 1)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO1),FALSE); 

			UpdateTextureShortDialogText (hWndDlg, &globalVars);

		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;

		case WM_PAINT:
			BeginPaint(hWndDlg,&Paint);
			LoadBitmapToScreen(	szFileName, hWndDlg, Paint.hdc, picRect);
			EndPaint(hWndDlg,&Paint);		 
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				/* SELECT TEXTURE
				 */
				case IDC_TEXTURE_RADIO1:
					globalVars.textureNumber = 0;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO2:
					globalVars.textureNumber = 1;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO3:
					globalVars.textureNumber = 2;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO4:
					globalVars.textureNumber = 3;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO5:
					globalVars.textureNumber = 4;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO6:
					globalVars.textureNumber = 5;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				/* Read new bitmap from file.
				 */
				case IDC_TEXTURE_BUTTON1:
					szFileName[0] = 0;
				    ofn.lStructSize         = sizeof(ofn);
				    ofn.hwndOwner           = hWndDlg;
				    ofn.hInstance           = 0;
				    ofn.lpstrFilter         = "Bitmap Files\0*.bmp\0All Files\0*.*\0\0";
				    ofn.lpstrCustomFilter   = NULL;
				    ofn.nMaxCustFilter      = 0;
				    ofn.nFilterIndex        = 1;
				    ofn.lpstrFile           = szFileName;
				    ofn.nMaxFile            = 256;
				    ofn.lpstrFileTitle      = NULL;
				    ofn.nMaxFileTitle       = 0;
				    ofn.lpstrInitialDir     = ".";
				    ofn.lpstrTitle          = "File Open";
				    ofn.Flags               = 0;
				    ofn.nFileOffset         = 0;
				    ofn.nFileExtension      = 0;
				    ofn.lpstrDefExt         = NULL;
				    ofn.lCustData           = 0;
				    ofn.lpfnHook            = NULL;
				    ofn.lpTemplateName      = NULL;

					bTexture = GetOpenFileName(&ofn);
				    if (bTexture)
					{
						InvalidateRect(hWndDlg, &picRect, TRUE);
					}
				break;

				case IDOK:
				    if (bTexture)
					{
						strcpy (globalVars.textureName[globalVars.textureNumber],szFileName);

						globalVars.textureMem[globalVars.textureNumber] = ConvertBMPtoSGL(globalVars.textureName[globalVars.textureNumber],FALSE);

						if (globalVars.textureMem[globalVars.textureNumber].x_dim <= 256)
							texSize = sgl_map_256x256;
						if (globalVars.textureMem[globalVars.textureNumber].x_dim <= 128)
							texSize = sgl_map_128x128;
						if (globalVars.textureMem[globalVars.textureNumber].x_dim <=  64)
							texSize = sgl_map_64x64;
						if (globalVars.textureMem[globalVars.textureNumber].x_dim <=  32)
							texSize = sgl_map_32x32;

						sgl_delete_texture(globalVars.textureHandle[globalVars.textureNumber]);
						sgl_modify_list(globalVars.textureList[globalVars.textureNumber],TRUE);

						globalVars.textureHandle[globalVars.textureNumber]	=
						sgl_create_texture(	sgl_map_16bit_mm, texSize, TRUE, TRUE,
										&(globalVars.textureMem[globalVars.textureNumber]), FALSE);

						sgl_set_texture_effect(FALSE,TRUE,FALSE,TRUE);
						sgl_set_texture_map(globalVars.textureHandle[globalVars.textureNumber],FALSE,FALSE); 
					}
					EndDialog(hWndDlg, FALSE);
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateTextureShortDialogText
/*	Inputs			:	HWND hWndDlg, GLOBALVARS *gV
/*	Outputs			:	Updates dialog box.
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Update the texture dialog box without texture wrapping.
/*
/********************************************************************************************/

void UpdateTextureShortDialogText (HWND hWndDlg, GLOBALVARS *gV)
{

	switch (gV->textureNumber)
	{
		case 0:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO1);
		break;

		case 1:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO2);
		break;
	
		case 2:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO3);
		break;

		case 3:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO4);
		break;

		case 4:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO5);
		break;

		case 5:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO6);
		break;

		default:
		break;
	}
}


/********************************************************************************************
/*
/*	Function Name	:	TextureMsgProc
/*	Inputs			:	HWND hWndDlg
/*						WORD Message
/*						WORD wParam
/*						LONG lParam
/*	Outputs			:
/*	Returns			:	BOOLEAN		TRUE	Processed message.
/*									FALSE	Didn't process message.
/*	Globals Used	:
/*	Description		:	Texture dialogue box.
/*
/********************************************************************************************/

BOOL FAR PASCAL TextureMsgProc(HWND hWndDlg, WORD Message, WORD wParam, LONG lParam)
{
	OPENFILENAME	ofn;
	PAINTSTRUCT		Paint;
	RECT			picRect;
	sgl_map_sizes	texSize;
	static char		szFileName[_MAX_PATH];
	static BOOL		bTexture = FALSE;

	GetWindowRect  (GetDlgItem(hWndDlg,IDC_STATIC_PICTURE),&picRect);
	ScreenToClient (hWndDlg, (LPPOINT) &picRect.left);
	ScreenToClient (hWndDlg, (LPPOINT) &picRect.right);

	switch(Message)
	{
		case WM_INITDIALOG:
			strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);

			if (globalVars.textureNumberUsed < 6)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO6),FALSE);
			 
			if (globalVars.textureNumberUsed < 5)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO5),FALSE);
			 
			if (globalVars.textureNumberUsed < 4)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO4),FALSE);
			 
			if (globalVars.textureNumberUsed < 3)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO3),FALSE);
			 
			if (globalVars.textureNumberUsed < 2)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO2),FALSE);
			 
			if (globalVars.textureNumberUsed < 1)
				EnableWindow(GetDlgItem(hWndDlg,IDC_TEXTURE_RADIO1),FALSE); 

			UpdateTextureDialogText (hWndDlg, &globalVars);
		break;
                           
		case WM_CLOSE:
			PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
		break;

		case WM_PAINT:
			BeginPaint(hWndDlg,&Paint);
			LoadBitmapToScreen(szFileName, hWndDlg, Paint.hdc, picRect);
			EndPaint(hWndDlg,&Paint);		 
		break;
           
		case WM_COMMAND:
			switch(wParam)
			{
				/* SELECT TEXTURE
				 */
				case IDC_TEXTURE_RADIO1:
					globalVars.textureNumber = 0;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO2:
					globalVars.textureNumber = 1;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO3:
					globalVars.textureNumber = 2;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO4:
					globalVars.textureNumber = 3;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO5:
					globalVars.textureNumber = 4;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO6:
					globalVars.textureNumber = 5;
					strcpy (szFileName, globalVars.textureName[globalVars.textureNumber]);
					InvalidateRect (hWndDlg, &picRect, TRUE);
					UpdateTextureShortDialogText (hWndDlg, &globalVars);
					break;

				/* SELECT OBJECT MAPPING
				 */
				case IDC_TEXTURE_RADIO7:
					globalVars.textureObjectMap[globalVars.textureNumber] = sgl_omap_obj_normal;
					UpdateTextureDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO8:
					globalVars.textureObjectMap[globalVars.textureNumber] = sgl_omap_inter_normal;
					UpdateTextureDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO9:
					globalVars.textureObjectMap[globalVars.textureNumber] = sgl_omap_reflection;
					UpdateTextureDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO10:
					globalVars.textureObjectMap[globalVars.textureNumber] = sgl_omap_transmission;
					UpdateTextureDialogText (hWndDlg, &globalVars);
					break;

				/* SELECT INTERMEDIATE MAPPING
				 */	
				case IDC_TEXTURE_RADIO11:
					globalVars.textureIntermediateMap[globalVars.textureNumber] = sgl_smap_plane;
					UpdateTextureDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO12:
					globalVars.textureIntermediateMap[globalVars.textureNumber] = sgl_smap_cylinder;
					UpdateTextureDialogText (hWndDlg, &globalVars);
					break;

				case IDC_TEXTURE_RADIO13:
					globalVars.textureIntermediateMap[globalVars.textureNumber] = sgl_smap_sphere;
					UpdateTextureDialogText (hWndDlg, &globalVars);
					break;

				/* Read new bitmap from file.
				 */
				case IDC_TEXTURE_BUTTON1:
					szFileName[0] = 0;
				    ofn.lStructSize         = sizeof(ofn);
				    ofn.hwndOwner           = hWndDlg;
				    ofn.hInstance           = 0;
				    ofn.lpstrFilter         = "Bitmap Files\0*.bmp\0All Files\0*.*\0\0";
				    ofn.lpstrCustomFilter   = NULL;
				    ofn.nMaxCustFilter      = 0;
				    ofn.nFilterIndex        = 1;
				    ofn.lpstrFile           = szFileName;
				    ofn.nMaxFile            = 256;
				    ofn.lpstrFileTitle      = NULL;
				    ofn.nMaxFileTitle       = 0;
				    ofn.lpstrInitialDir     = ".";
				    ofn.lpstrTitle          = "File Open";
				    ofn.Flags               = 0;
				    ofn.nFileOffset         = 0;
				    ofn.nFileExtension      = 0;
				    ofn.lpstrDefExt         = NULL;
				    ofn.lCustData           = 0;
				    ofn.lpfnHook            = NULL;
				    ofn.lpTemplateName      = NULL;

					bTexture = GetOpenFileName(&ofn);
				    if (bTexture)
					{
						InvalidateRect(hWndDlg, &picRect, TRUE);
					}
				break;

				case IDOK:
				    if (GetTextureDlgItemText(hWndDlg))
					{
						/* Has a new texture been selected.
						 */
						if (bTexture)
						{
							strcpy (globalVars.textureName[globalVars.textureNumber],szFileName);
							globalVars.textureMem[globalVars.textureNumber] =
								ConvertBMPtoSGL(globalVars.textureName[globalVars.textureNumber],FALSE);

							sgl_delete_texture(globalVars.textureHandle[globalVars.textureNumber]);
						}

						if (globalVars.textureMem[globalVars.textureNumber].x_dim <= 256)
							texSize = sgl_map_256x256;
						if (globalVars.textureMem[globalVars.textureNumber].x_dim <= 128)
							texSize = sgl_map_128x128;
						if (globalVars.textureMem[globalVars.textureNumber].x_dim <=  64)
							texSize = sgl_map_64x64;
						if (globalVars.textureMem[globalVars.textureNumber].x_dim <=  32)
							texSize = sgl_map_32x32;

						/* Modify the texture etc.
						 */
						sgl_modify_list(globalVars.textureList[globalVars.textureNumber],TRUE);

						globalVars.textureHandle[globalVars.textureNumber]	= 
							sgl_create_texture(	sgl_map_16bit_mm,texSize,TRUE,TRUE,
											&(globalVars.textureMem[globalVars.textureNumber]),NULL);

						sgl_set_texture_effect(FALSE,TRUE,FALSE,TRUE);
						sgl_set_texture_map(globalVars.textureHandle[globalVars.textureNumber],FALSE,FALSE); 
						sgl_set_smap(	globalVars.textureIntermediateMap[globalVars.textureNumber],
										globalVars.textureSu[globalVars.textureNumber],
										globalVars.textureSv[globalVars.textureNumber],
										globalVars.textureOu[globalVars.textureNumber],
										globalVars.textureOv[globalVars.textureNumber],
										globalVars.textureRadius[globalVars.textureNumber]);
							
						sgl_set_omap(	globalVars.textureObjectMap[globalVars.textureNumber],
										globalVars.textureRefIndex[globalVars.textureNumber]); 

						EndDialog(hWndDlg, FALSE);
					}
				break;

				case IDCANCEL:
					EndDialog(hWndDlg, FALSE);
				break;
			}
		break;
                                  
		default:
			return FALSE;
	}
	return TRUE;
}


/********************************************************************************************
/*
/*	Function Name	:	UpdateTextureDialogText
/*	Inputs			:	HWND hWndDlg, GLOBALVARS *gV
/*	Outputs			:	Updates dialog box
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Updates the texture dialog box.
/*
/********************************************************************************************/

void UpdateTextureDialogText (HWND hWndDlg, GLOBALVARS *gV)
{
	char   szReturnValue[80];

	switch (gV->textureNumber)
	{
		case 0:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO1);
		break;

		case 1:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO2);
		break;
	
		case 2:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO3);
		break;

		case 3:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO4);
		break;

		case 4:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO5);
		break;

		case 5:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO1,IDC_TEXTURE_RADIO6,IDC_TEXTURE_RADIO6);
		break;

		default:
		break;
	}

	switch (gV->textureObjectMap[gV->textureNumber])
	{
		case sgl_omap_obj_normal:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO7,IDC_TEXTURE_RADIO10,IDC_TEXTURE_RADIO7);
		break;

		case sgl_omap_inter_normal:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO7,IDC_TEXTURE_RADIO10,IDC_TEXTURE_RADIO8);
		break;
	
		case sgl_omap_reflection:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO7,IDC_TEXTURE_RADIO10,IDC_TEXTURE_RADIO9);
		break;

		case sgl_omap_transmission:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO7,IDC_TEXTURE_RADIO10,IDC_TEXTURE_RADIO10);
		break;

		default:
		break;
	}

	switch (gV->textureIntermediateMap[gV->textureNumber])
	{
		case sgl_smap_plane:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO11,IDC_TEXTURE_RADIO13,IDC_TEXTURE_RADIO11);
		break;

		case sgl_smap_cylinder:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO11,IDC_TEXTURE_RADIO13,IDC_TEXTURE_RADIO12);
		break;
	
		case sgl_smap_sphere:
			CheckRadioButton(hWndDlg,IDC_TEXTURE_RADIO11,IDC_TEXTURE_RADIO13,IDC_TEXTURE_RADIO13);
		break;

		default:
		break;
	}

	/* Advanced settings.
	 */
	gcvt(gV->textureSu[gV->textureNumber],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT1   ,szReturnValue);

	gcvt(gV->textureSv[gV->textureNumber],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT2   ,szReturnValue);

	gcvt(gV->textureOu[gV->textureNumber],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT3   ,szReturnValue);

	gcvt(gV->textureOv[gV->textureNumber],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT4   ,szReturnValue);

	gcvt(gV->textureRadius[gV->textureNumber],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT5   ,szReturnValue);

	gcvt(gV->textureRefIndex[gV->textureNumber],6,szReturnValue);
	SetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT7   ,szReturnValue);
}


/********************************************************************************************
/*
/*	Function Name	:	GetTextureDlgItemText
/*	Inputs			:	HWND hWndDlg
/*	Outputs			:	-
/*	Returns			:	BOOL
/*	Globals Used	:
/*	Description		:	Gets the selected texture items selected in the texture dialog box.
/*
/********************************************************************************************/

BOOL GetTextureDlgItemText(HWND hWndDlg)
{
	UINT          error;
	char          szReturnValue[80];
	float         fReturnValue;
	BOOL          endDialogFlag;


	endDialogFlag = TRUE;

	/* get the su value
	 */
	error = GetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT1,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0001) && (fReturnValue <= 1000.0) && (error != 0))
	{
		globalVars.textureSu[globalVars.textureNumber] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateTextureDialogText(hWndDlg,&globalVars);
	}

	/* get the sv value
	 */
	error = GetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT2,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0001) && (fReturnValue <= 1000.0) && (error != 0))
	{
		globalVars.textureSv[globalVars.textureNumber] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateTextureDialogText(hWndDlg,&globalVars);
	}

	/* get the ou value
	 */
	error = GetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT3,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		globalVars.textureOu[globalVars.textureNumber] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateTextureDialogText(hWndDlg,&globalVars);
	}

	/* get the ov value
	 */
	error = GetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT4,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= -1000.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		globalVars.textureOv[globalVars.textureNumber] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateTextureDialogText(hWndDlg,&globalVars);
	}

	/* get the radius value
	 */
	error = GetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT5,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		globalVars.textureRadius[globalVars.textureNumber] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateTextureDialogText(hWndDlg,&globalVars);
	}

	/* get the refractive index value
	 */
	error = GetDlgItemText(hWndDlg,IDC_TEXTURE_EDIT7,szReturnValue,80);

	fReturnValue = (float)atof(szReturnValue);
	if ((fReturnValue >= 0.0) && (fReturnValue <= 1000.0) && (error != 0))
	{
		globalVars.textureRefIndex[globalVars.textureNumber] = fReturnValue;
	}
	else
	{
		endDialogFlag = FALSE;
		UpdateTextureDialogText(hWndDlg,&globalVars);
	}

	return endDialogFlag;
}


/********************************************************************************************
/*
/*	Function Name	:	LoadBitmapToScreen
/*	Inputs			:	LPSTR	filename
/*						HWND	ImagehWnd
/*						HDC		hDC
/*						RECT	picRect
/*	Outputs			:
/*	Returns			:	BOOLEAN
/*	Globals Used	:
/*	Description		:	Routine to load BITMAPS to the dialog box.
/*						Not used to write image BITMAPS to main window.
/*
/********************************************************************************************/

BOOL LoadBitmapToScreen(LPSTR filename, HWND ImagehWnd, HDC hDC, RECT picRect)
{
	HANDLE             hDIBInfo = NULL;
	HFILE              fh; 
	LPBITMAPINFOHEADER lpbi;
	BITMAPFILEHEADER   bf;
	WORD               offBits;

	fh = _lopen(filename, OF_READ);
	if (fh == HFILE_ERROR)
	{
        AppMsgBox(hWnd, MB_OK | MB_ICONSTOP,
                  TEXT("Can't open file"));
		_lclose(fh);
		return FALSE;
	}  
                         
	hDIBInfo = GlobalAlloc(GMEM_MOVEABLE,(DWORD)(sizeof(BITMAPINFOHEADER)));
	lpbi     = (LPBITMAPINFOHEADER)GlobalLock(hDIBInfo);
  
	_hread (fh, (LPSTR)&bf , sizeof(bf));  
	_hread (fh, (LPSTR)lpbi, sizeof(BITMAPINFOHEADER));

	GlobalUnlock(hDIBInfo);

	lpbi->biSizeImage = lpbi->biWidth *	lpbi->biHeight * (lpbi->biBitCount >> 3);

	hDIBInfo = GlobalReAlloc(hDIBInfo, lpbi->biSize + lpbi->biSizeImage, GMEM_ZEROINIT);
	lpbi     = (LPBITMAPINFOHEADER)GlobalLock(hDIBInfo); 
   
	if (hDIBInfo == NULL)
	{
        AppMsgBox(hWnd, MB_OK | MB_ICONSTOP,
                  TEXT("Memory reallocation failed"));
		GlobalUnlock(hDIBInfo);
		GlobalFree(hDIBInfo);
		_lclose(fh);
	return FALSE;
	} 
	if (lpbi->biBitCount != 24)
	{
        AppMsgBox(hWnd, MB_OK | MB_ICONSTOP,
                  TEXT("This is not a 24bpp image"));
		GlobalUnlock(hDIBInfo);
		GlobalFree(hDIBInfo);
		_lclose(fh);    
		return FALSE;
	}
	if (lpbi->biCompression != BI_RGB)
	{
        AppMsgBox(hWnd, MB_OK | MB_ICONSTOP,
                  TEXT("This image is compressed"));
		GlobalUnlock(hDIBInfo);
		GlobalFree(hDIBInfo);
		_lclose(fh);    
		return FALSE;
	}

	offBits  = (WORD)(lpbi->biSize);

	if (bf.bfOffBits != 0L) _llseek(fh,bf.bfOffBits,SEEK_SET);
  
	_hread(fh, (LPSTR)lpbi + offBits, lpbi->biSizeImage);
                  
	StretchDIBits (hDC, picRect.left, picRect.top,
	                    picRect.right - picRect.left, picRect.bottom - picRect.top,
						0, 0,
	                    (WORD)(lpbi->biWidth), (WORD)(lpbi->biHeight),
                        (LPSTR)lpbi + offBits, (LPBITMAPINFO)lpbi,
	                    DIB_RGB_COLORS, SRCCOPY);
  
	GlobalUnlock(hDIBInfo);
	GlobalFree(hDIBInfo);
	_lclose(fh);
	
	return TRUE;  
}


/********************************************************************************************
/*
/*	Function Name	:	VideoLogicTimerFunc
/*	Inputs			:	-
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Timer functions for VideoLogic logo demo.
/*
/********************************************************************************************/

void VideoLogicTimerFunc ()
{
	static int demoFlag = 0;

	if (demoFlag == 0)
	{
		demoFlag = 1; 
        RunVideoLogicLogoDemo(bActive);
        demoFlag = 0;
	}
}


/********************************************************************************************
/*
/*	Function Name	:	NeferttTimerFunc
/*	Inputs			:	-
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	-
/*	Description		:	Timer functions for Nefertt demo.
/*
/********************************************************************************************/

void NeferttTimerFunc ()
{
	static int demoFlag = 0;

	if (!demoFlag)
	{
		demoFlag = 1; 
        RunNeferttDemo(bActive);
        demoFlag = 0;
	}
}


/********************************************************************************************
/*
/*	Function Name	:	sgl_render_callback
/*	Inputs			:	P_CALLBACK_ADDRESS_PARAMS lpRenderParams
/*	Outputs			:	Output FPS and/or Texture memory size to title bar.
/*	Returns			:	int		Error code.
/*	Globals Used	:
/*	Description		:	Called before each render to find where to display image.
/*						Updates frames per second.
/*
/********************************************************************************************/

int sgl_render_callback(P_CALLBACK_ADDRESS_PARAMS lpRenderParams)
{
	int				nRet;
	DWORD			dwNowTime;
	DWORD			dwRunTime;
	float			fFrameRate;
	static DWORD	dwStartTime;
	char			szText[80];
	static int		count;

	dwNowTime = timeGetTime();

	if (bInitStartTime)
	{
		dwStartTime = dwNowTime;
		bInitStartTime = FALSE;
		count=1;
	}
	else
	{
		count++;

		/* Display the frames per second value.
		 * Update fps every 40 frames
		 */
		if (!(count % 40))
		{
			dwRunTime = dwNowTime - dwStartTime;

			if (dwRunTime)
			{
				fFrameRate 	= ((float)count * 1000.0f) / (float) dwRunTime;
			}

			sprintf(szText,"%s","VL Demo");

			/* Only display FPS if enabled.
			 */
			if (bDisplayFPS)
			{
				sprintf(szText,"%s %.1f FPS ",szText, fFrameRate);
			}

			/* Only display FPS if enabled.
			 */
			if (bDisplayFreeTexMem)
			{
				long	lFreeMem;

				lFreeMem = sgl_get_free_texture_mem();
				sprintf(szText,"%s %ld Bytes ",szText, lFreeMem);
			}

			if (bDisplayFreeTexMem || bDisplayFPS)
				SetWindowText(hWnd,szText);
				
		}
	}

	if (bBufferLocked)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
	}

	/* Get the window information.
	 */
	nRet = DDGetWindowInfo(hWnd,&pMem,&wStride);
	bBufferLocked = TRUE;

	if (nRet)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
		MessageBox (NULL, "DDGetWindowInfo() failed", NAME, MB_OK|MB_ICONHAND|MB_SYSTEMMODAL);
	}

	lpRenderParams->pMem			= pMem;		/* Starting address						*/
	lpRenderParams->wStride			= wStride;	/* Address difference between to lines	*/
	lpRenderParams->bBitsPerPixel	= 16;		/* Bits per pixel						*/
	 
	if (!nStrictLocks)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
	}
	return nRet;
}


/********************************************************************************************
/*
/*	Function Name	:	eor_callback
/*	Inputs			:	
/*	Outputs			:	
/*	Returns			:	int		Error code.
/*	Globals Used	:
/*	Description		:	
/*						SGL makes this callback during sgl_render when the previous frame
/*						has completed, that is to say at end of render.
/*						This is an important event if we are implenemting strict
/*						locking because we must unlock the surface as soon as possible
/*						and allow Windows to do it's message loop processing and update it's
/*						display.
/*
/********************************************************************************************/

int eor_callback()
{
	MSG		msg;

	/* Unlock the front buffer
	 */
	if (bBufferLocked)
	{
		DDUnlockFrontBuffer();
		bBufferLocked = FALSE;
	}

	while(1)
	{
	  	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	    {
	        if (!GetMessage( &msg, NULL, 0, 0 ))
	        {
				bQuit = TRUE;
	            return 1; /* Prevent sgl from rendering */
	        }

	        TranslateMessage(&msg); 
	        DispatchMessage(&msg);
	    }

		Sleep(2); /* Allow the mouse to move */

		if (bActive)
		{
			break; /* If active then continue to render */	
		}
	}

	return 0; /* Continue with sgl_render */

}/*eor_callback*/