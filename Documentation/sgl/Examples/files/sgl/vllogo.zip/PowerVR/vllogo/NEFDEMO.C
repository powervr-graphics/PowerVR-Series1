/********************************************************************************************
 *	Name		:	nefdemo.c
 *	Title		:	3D Nefertt Demo
 *	Author		:	VideoLogic Limited
 *	Created		:	20/09/1996
 *
 *	Copyright 	:	1995 by VideoLogic Limited. All rights reserved.
 *					No part of this software, either material or conceptual 
 *					may be copied or distributed, transmitted, transcribed,
 *					stored in a retrieval system or translated into any 
 *					human or computer language in any form by any means,
 *					electronic, mechanical, manual or other-wise, or 
 *					disclosed to third parties without the express written
 *					permission of VideoLogic Limited, Unit 8, HomePark
 *					Industrial Estate, King's Langley, Hertfordshire,
 *					WD4 8LZ, U.K.
 *
 *	Description	:	Creates 3D scene. Animates the 3D scene
 *
 *	Platform	:	ANSI compatible
 *
 *	History		:
 *
 * $Log:	nefdemo.c $
 * Revision 1.3  97/02/19  13:00:49  EDWARDFORDE
 * 1. Smooth shading enabled by default.
 * 2. Increase enviroment radius to 200.
 * 
 * Revision 1.2  97/02/19  12:40:25  EDWARDFORDE
 * 1. Fixed background so that lighting doesn't change as camera moves.
 * 2. Add rotation to Nefertt head.
 * 
 * Revision 1.1  96/11/15  09:31:32  EdwardForde
 * Initial revision
 * 
 * 
 ********************************************************************************************/

/********************************************************************************************
/*								INCLUDE FILES												*
/********************************************************************************************/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "sgl.h"
#include "math.h"
#include "frontend.h"
#include "vldemo.h"

/********************************************************************************************
/*								LOCAL DEFINE DEFINITIONS 									*
/********************************************************************************************/

#define NAMED_ITEM			TRUE
#define UNAMED_ITEM			FALSE

#define COLOUR				TRUE
#define GREY				FALSE

#define SHADOW_LIGHT		TRUE
#define NO_SHADOWS			FALSE

#define SMOOTH_SHADING		TRUE
#define NO_SMOOTH_SHADING	FALSE

#define INVISIBLE			TRUE
#define	VISIBLE				FALSE

#define	LENS_50MM			4.0f

/********************************************************************************************
/*								EXTERNAL GLOBAL VARIABLES									*
/********************************************************************************************/

extern	sgl_vector	XAxis;	
extern	sgl_vector	YAxis;	
extern	sgl_vector	ZAxis;
extern	sgl_bool	moving_mode;

extern	GLOBALVARS	globalVars;
extern	sgl_bool	MoveCamera;
extern	int			MoveLight;
extern	sgl_vector	camera_pos;

/* Lights 1, 2, 3 and 4 positions.
 */
extern	sgl_vector	light_pos1;
extern	sgl_vector	light_pos2;
extern	sgl_vector	light_pos3;
extern	sgl_vector	light_pos4;

extern	int			nDummyList, nInstance, nInstance1, nTextureList;

/********************************************************************************************
/*								EXTERNAL FUNCTION DEFINITIONS								*
/********************************************************************************************/

extern int	CreateNefertt	(void);
extern int	create_rectprism(float x, float y, float z, sgl_bool bName, sgl_bool bTexture, sgl_bool bHidden);
extern int	create_sphere	(int sph_type, float radius, int num_sides, sgl_bool bName, 
							sgl_bool bSmoothShade, sgl_bool bTexture);
extern void	SetupCachedTexture(sgl_bool cached);
extern void	MoveCameraPos	(int cameraTransform, sgl_vector camera_pos);
extern void	MoveLightPos	(int lightTransform, int tLightVolume, sgl_vector light_pos);

/********************************************************************************************
/*								DEFINED GLOBAL VARIABLES									*
/********************************************************************************************/

/********************************************************************************************
/*								LOCAL VARIABLES												*
/********************************************************************************************/

static sgl_vector Vertices[5] = 
{
	{  0.0f,0.0f,   0.0f},
	{800.0f,0.0f,   0.0f},
	{800.0f,0.0f,3200.0f},
	{  0.0f,0.0f,3200.0f}
};
static sgl_2d_vec UVS[5] = 
{
	{0.0f,	0.0f},
	{1.0f, 	0.0f},
	{1.0f, 	2.0f},
	{0.0f, 	2.0f}
};

static sgl_vector Normals[5] = 
{
	{0.0f,1.0f,0.0f},
	{0.0f,1.0f,0.0f},
	{0.0f,1.0f,0.0f},
	{0.0f,1.0f,0.0f}
};

static int Faces[4] = {0,1,2,3};
int		animation_position;
int		neferttTransform;

/********************************************************************************************
/*								LOCAL FUNCTION DEFINITIONS									*
/********************************************************************************************/

void		SetupNeferttDemo	(void);
void		RunNeferttDemo		(sgl_bool do_render);
void 		CloseNeferttDemo	(void);	  
static void	InitialiseParameters(void);

/********************************************************************************************
/*								LOCAL FUNCTIONS												*
/********************************************************************************************/

/********************************************************************************************
/*
/*	Function Name	:	SetupNeferttDemo
/*	Inputs			:	-
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	globalVars, light_pos, camera_pos
/*	Description		:	Routine to initialise and create the Nefertt demo. It creates
/*						everything to do with the scene. i.e. view, lighting, shading,
/*						tranparency, objects etc.
/********************************************************************************************/

void SetupNeferttDemo (void)
{
	sgl_colour	cBlack		= {0.0f,0.0f,0.0f};
	sgl_colour	cLightGreen	= {0.3f,1.0f,0.3f};
	sgl_colour	cBlue		= {0.0f,0.0f,0.9f};
	sgl_colour	ltblue		= {0.53f, 0.81f, 0.92f};
	sgl_colour	cWhite		= {1.0f,1.0f,1.0f};
	sgl_colour	cDarkGrey	= {0.25f,0.25f,0.25f};
	sgl_colour	cMediumGrey	= {0.8f,0.0f,0.0f};
	sgl_vector	lightDir	= {-1.0f,-1.0f,1.0f};
	sgl_vector	lightPos	= {300.0f,300.0f,-300.0f};
	int			i;

    /* Nefertt Demo setup inital values
     */
	InitialiseParameters();
	animation_position = 0;
	globalVars.demoNumber	= 2;			/* Nefertt id demo 2.	*/

	/* create screen device 0 with 640x480 screen resolution
	 * and 24 bit colour and no double buffering            
	 */
	globalVars.screenDevice = sgl_create_screen_device(	globalVars.numberDevice,
													globalVars.xDevice,	
													globalVars.yDevice,	
													globalVars.modeDevice,	
													globalVars.doublebufferDevice);

	/* set the viewport for the opened device so that there
	 * is a 20 pixel border around the rendered image      
	 */ 
	globalVars.viewport = sgl_create_viewport(	globalVars.screenDevice,
											globalVars.leftViewport,
											globalVars.topViewport,
											globalVars.rightViewport,
											globalVars.bottomViewport,
											globalVars.leftCamera,
											globalVars.topCamera,
											globalVars.rightCamera,
											globalVars.bottomCamera);

	/* setup the quality values. List which doesn't preserve the state.
	 */
	globalVars.hQualList = sgl_create_list(TRUE,FALSE,FALSE);
	{
		sgl_qual_texturing(globalVars.texturingQual);
		sgl_qual_smooth_shading(globalVars.shadingQual);
		sgl_qual_generate_shadows(globalVars.shadowQual);
		sgl_qual_fog(globalVars.fogQual);
		sgl_qual_collision_detection(globalVars.collisionQual,FALSE);
	}
	sgl_to_parent();

	/* Create list instance for rectangle lights.
	 */
	nInstance = sgl_create_list(NAMED_ITEM,TRUE,TRUE);
	{
		globalVars.convexPolydron[globalVars.convexPolydronCnt++] = 
			create_rectprism(1.0f,5.0f,1.0f, NAMED_ITEM, NO_TEXTURE,FALSE);
	}sgl_to_parent();

	/* Create list instance for second rectangle lights.
	 */
	nInstance1 = sgl_create_list(NAMED_ITEM,TRUE,TRUE);
	{
		globalVars.convexPolydron[globalVars.convexPolydronCnt++] = 
			create_rectprism(2.0f,10.0f,2.0f, NAMED_ITEM, NO_TEXTURE,FALSE);
	}sgl_to_parent();

	sgl_modify_list(SGL_DEFAULT_LIST, FALSE);

	/************************/
	/* SETUP OBJECT TEXTURE */
	/************************/

	/* Clear texture handles.
	 */
	for (i = 0 ; i < 6 ; i++)
		globalVars.textureHandle[i] = 0;

	/* Check the amount of free texture memory.
	 */
	globalVars.lFreeMem = sgl_get_free_texture_mem();

	globalVars.textureNumberUsed         = 2;
	globalVars.textureNumber             = 0;

	/* Create head texture for background plane.
	 */
	globalVars.textureIntermediateMap[0] = sgl_smap_cylinder;
	globalVars.textureObjectMap      [0] = sgl_omap_obj_normal;
	strcpy (globalVars.textureName[0],"blursky.bmp");
	globalVars.textureSu             [0] = 0.25f;	  
	globalVars.textureSv             [0] = 100.0f;
	globalVars.textureOu             [0] = 0.0f;	  
	globalVars.textureOv             [0] = -64.0f;	
	globalVars.textureRadius         [0] = 200.0f;	
	globalVars.textureRotationAxis   [0][0] = 1.0f;
	globalVars.textureRotationAxis   [0][1] = 0.0f;
	globalVars.textureRotationAxis   [0][2] = 0.0f;
	globalVars.textureRotationAngle  [0] = 0.0f;
	globalVars.textureRefIndex       [0] = 1.4f;

	globalVars.textureMem[0]     = ConvertBMPtoSGL(globalVars.textureName[0],FALSE);
	sgl_texture_size(&(globalVars.textureMem[0]));
	globalVars.textureHandle[0]  = sgl_create_texture(sgl_map_16bit_mm,sgl_map_256x256,TRUE,TRUE,&(globalVars.textureMem[0]),NULL);

	/* Create Sky texture for background plane.
	 */
	strcpy (globalVars.textureName[1],"blursky.bmp");
	globalVars.textureMem[1]     = ConvertBMPtoSGL(globalVars.textureName[1],FALSE);
	globalVars.textureHandle[1]  = sgl_create_texture(	sgl_map_16bit_mm,sgl_map_256x256,FALSE,
													TRUE,&(globalVars.textureMem[1]),NULL);

	/****************/
	/* SETUP LIGHTS */
	/****************/

	globalVars.lightNumberUsed			   =  4;	/* number of lights.	*/
	globalVars.lightNumber                 =  0;	/* light being used.	*/

	/* set the values for the first light  (parallel light)
	 */
	globalVars.lightType            [0]    =  0;
	globalVars.lightOff             [0]    =  FALSE;
	globalVars.lightColour          [0][0] =  1.0f;
	globalVars.lightColour          [0][1] =  1.0f;
	globalVars.lightColour          [0][2] =  1.0f;
	globalVars.lightColoured        [0]    =  COLOUR;
	globalVars.lightDirection       [0][0] =  0.0f;
	globalVars.lightDirection       [0][1] = -0.5f;
	globalVars.lightDirection       [0][2] =  0.0f;
 	globalVars.lightPosition        [0][0] =  0.0f;
 	globalVars.lightPosition        [0][1] =  1.0f;
 	globalVars.lightPosition        [0][2] =  0.0f;
	globalVars.lightConcentration   [0]    =  0;
	globalVars.lightCastsShadows    [0]    =  NO_SHADOWS;
	globalVars.lightSmoothHighlights[0]    =  FALSE;

    globalVars.lightHandle[0] = sgl_create_parallel_light(NAMED_ITEM,
													globalVars.lightColour[0],
												  	globalVars.lightDirection[0],
													globalVars.lightCastsShadows[0],
													globalVars.lightSmoothHighlights[0]);

	/* set the values for the second light (parallel light)
	 */
	globalVars.lightType            [1]    =  0;
	globalVars.lightOff             [1]    =  FALSE;
	globalVars.lightColour          [1][0] =  1.0f;
	globalVars.lightColour          [1][1] =  1.0f;
	globalVars.lightColour          [1][2] =  1.0f;
	globalVars.lightColoured        [1]    =  COLOUR;
	globalVars.lightDirection       [1][0] =  0.0f;
	globalVars.lightDirection       [1][1] = -0.5f;
	globalVars.lightDirection       [1][2] =  0.0f;
 	globalVars.lightPosition        [1][0] =  0.0f;
 	globalVars.lightPosition        [1][1] =  1.0f;
 	globalVars.lightPosition        [1][2] =  0.0f;
	globalVars.lightConcentration   [1]    =  0;
	globalVars.lightCastsShadows    [1]    =  NO_SHADOWS;
	globalVars.lightSmoothHighlights[1]    =  FALSE;

	globalVars.lightHandle[1] = sgl_create_parallel_light(NAMED_ITEM,
													globalVars.lightColour[1],
													globalVars.lightDirection[1],
													globalVars.lightCastsShadows[1],
													globalVars.lightSmoothHighlights[1]);

	/* set the values for the third light (point light)
	 */
	globalVars.lightType            [2]    =  1;
	globalVars.lightOff             [2]    =  FALSE;
	globalVars.lightColour          [2][0] =  1.0f;
	globalVars.lightColour          [2][1] =  1.0f;
	globalVars.lightColour          [2][2] =  1.0f;
	globalVars.lightColoured        [2]    =  COLOUR;
	globalVars.lightDirection       [2][0] =  0.0f;
	globalVars.lightDirection       [2][1] = -0.5f;
	globalVars.lightDirection       [2][2] =  0.0f;
 	globalVars.lightPosition        [2][0] =  0.0f;
 	globalVars.lightPosition        [2][1] =  100.0f;
 	globalVars.lightPosition        [2][2] =  0.0f;
	globalVars.lightConcentration   [2]    =  32;
	globalVars.lightCastsShadows    [2]    =  NO_SHADOWS;
	globalVars.lightSmoothHighlights[2]    =  FALSE;

	globalVars.lightHandle[2] = sgl_create_point_light(	NAMED_ITEM,
													globalVars.lightColour[2],
											 		globalVars.lightDirection[2],
								 					globalVars.lightPosition[2],
													globalVars.lightConcentration[2],
													globalVars.lightCastsShadows[2],
													globalVars.lightSmoothHighlights[2]);

	/* set the values for the fouth light (point light)
	 */
	globalVars.lightType            [3]    =  1;
	globalVars.lightOff             [3]    =  FALSE;
	globalVars.lightColour          [3][0] =  1.0f;
	globalVars.lightColour          [3][1] =  1.0f;
	globalVars.lightColour          [3][2] =  1.0f;
	globalVars.lightColoured        [3]    =  COLOUR;
	globalVars.lightDirection       [3][0] =  0.0f;
	globalVars.lightDirection       [3][1] = -0.5f;
	globalVars.lightDirection       [3][2] =  0.0f;
 	globalVars.lightPosition        [3][0] =  0.0f;
 	globalVars.lightPosition        [3][1] =  100.0f;
 	globalVars.lightPosition        [3][2] =  0.0f;
	globalVars.lightConcentration   [3]    =  32;
	globalVars.lightCastsShadows    [3]    =  NO_SHADOWS;
	globalVars.lightSmoothHighlights[3]    =  FALSE;

	globalVars.lightHandle[3] = sgl_create_point_light(	NAMED_ITEM,
													globalVars.lightColour[3],
								 					globalVars.lightDirection[3],
								 					globalVars.lightPosition[3],
													globalVars.lightConcentration[3],
													globalVars.lightCastsShadows[3],
													globalVars.lightSmoothHighlights[3]);

	/* Switch shadows OFF so that light prisms are not shadowed.
	 */
	sgl_switch_light( globalVars.lightHandle[0],TRUE,NO_SHADOWS,FALSE); 
	sgl_switch_light( globalVars.lightHandle[1],TRUE,NO_SHADOWS,FALSE); 
	sgl_switch_light( globalVars.lightHandle[2],TRUE,NO_SHADOWS,FALSE); 
	sgl_switch_light( globalVars.lightHandle[3],TRUE,NO_SHADOWS,FALSE); 

	globalVars.lightList = sgl_create_list(NAMED_ITEM,FALSE,FALSE);
	{
		/* Dummy List to insert substitution.
		 */
	}
	sgl_to_parent();

	/* Creates physical light object 1.
	 */
	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
	{
		globalVars.lightTransform[0] = sgl_create_transform(NAMED_ITEM);

		sgl_position_light (globalVars.lightHandle[0]);

		sgl_translate(0.0f, 100.0f,  0.0f);
		sgl_use_instance(nInstance);
	}
	sgl_to_parent();

	/* Creates physical light object 2.
	 */
 	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
	{
		globalVars.lightTransform[1] = sgl_create_transform(NAMED_ITEM);
		sgl_position_light (globalVars.lightHandle[1]);
		sgl_translate(0.0f, 100.0f,  0.0f);
		sgl_use_instance(nInstance);
	}
	sgl_to_parent();
	
	/* Creates physical light object 3.
	 */
 	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
	{
		globalVars.lightTransform[2] = sgl_create_transform(NAMED_ITEM);
		sgl_position_light (globalVars.lightHandle[2]);
		sgl_translate(0.0f, 100.0f,  0.0f);
		sgl_use_instance(nInstance);
	}
	sgl_to_parent();
	 
	/* Creates physical light object 4.
	 */
 	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
	{
		globalVars.lightTransform[3] = sgl_create_transform(NAMED_ITEM);
		sgl_position_light (globalVars.lightHandle[3]);
		sgl_translate(0.0f, 100.0f,  0.0f);
		sgl_use_instance(nInstance);
	}
	sgl_to_parent();

	/* Switch shadows ON so that light prisms are not shadowed.
	 */
	sgl_switch_light( globalVars.lightHandle[0],TRUE,SHADOW_LIGHT,FALSE); 
	sgl_switch_light( globalVars.lightHandle[1],TRUE,SHADOW_LIGHT,FALSE); 
	sgl_switch_light( globalVars.lightHandle[2],TRUE,SHADOW_LIGHT,FALSE); 
	sgl_switch_light( globalVars.lightHandle[3],TRUE,SHADOW_LIGHT,FALSE); 

	/********************/
	/* PLACE THE CAMERA */
	/********************/
	globalVars.cameraList = sgl_create_list(NAMED_ITEM,TRUE,FALSE);
  	{
		/* Setup camera.
		 */
		globalVars.cameraTransform = sgl_create_transform(NAMED_ITEM);
		sgl_translate(0.0f, 0.0f,  -68.0f);
		globalVars.camera = sgl_create_camera(	globalVars.zoomCamera,
												globalVars.foregroundCamera,
												globalVars.inv_backgroundCamera);

		globalVars.backgroundList = sgl_create_list(NAMED_ITEM,TRUE,FALSE);
		{
			/* Used to create the background image. i.e. the sky.
			 * Create here so that it is always visible on the camera.
			 * Three points are required to create a plane.
			 */
			float		uv1[2], uv2[2] , uv3[2];
			sgl_vector	BackPnt		= { 0.0f,0.0f, 10000.0f };	
			sgl_vector	Backpoint2	= { 0.0f,10.0f, 10000.0f };	
			sgl_vector	Backpoint3	= { 10.0f, 0.0f, 10000.0f };

			uv1[0] = 0.0f;
			uv1[1] = 0.0f;

			uv2[0] = 0.0f;
			uv2[1] = 0.002f;

			uv3[0] = 0.002f;
			uv3[1] = 0.0f;

			sgl_set_diffuse(cBlack);
			sgl_set_glow(ltblue);
			sgl_set_ambient(cWhite);

			globalVars.textureList[1] = sgl_create_list(TRUE,FALSE,FALSE);
			{
				sgl_set_texture_effect(FALSE,TRUE,FALSE,TRUE);
				sgl_set_texture_map(globalVars.textureHandle[1],FALSE,FALSE);
			}
			sgl_to_parent();
			sgl_add_plane(	BackPnt, Backpoint2, Backpoint3, VISIBLE,
						NULL,NULL,NULL,uv1,uv2,uv3);
		}
		sgl_to_parent();
	}
	sgl_to_parent();

	/*************/
	/* SETUP FOG */
	/*************/

	globalVars.fogColour[0] = 0.0f;
	globalVars.fogColour[1] = 0.0f;
	globalVars.fogColour[2] = 0.0f;
	globalVars.fogDensity   = 0.0f;

	sgl_set_fog(globalVars.camera, globalVars.fogColour, globalVars.fogDensity);

	/*****************/
	/* SETUP AMBIENT */
	/*****************/

	globalVars.ambientHandle = sgl_create_ambient_light(NAMED_ITEM,globalVars.ambientColour, FALSE);

	/*************************************/
	/* SETUP OBJECT TEXTURE AND MATERIAL */
	/*************************************/

	/* Dummy List to test Detach/Attach list.
	 */
	nDummyList = sgl_create_list(NAMED_ITEM,FALSE,FALSE);
	{
		globalVars.textureList[0] = sgl_create_list(TRUE,FALSE,FALSE);
		{
			nTextureList = globalVars.textureList[0];

			globalVars.materialHandle[0] = sgl_create_material(NAMED_ITEM,FALSE);
	
			sgl_set_texture_effect(TRUE,TRUE,FALSE,FALSE);

			/* Use sky texture.
			 */
			sgl_set_texture_map(globalVars.textureHandle[0],FALSE,FALSE);
		
			sgl_set_smap(globalVars.textureIntermediateMap[0],
					globalVars.textureSu[0],
					globalVars.textureSv[0],
					globalVars.textureOu[0],
					globalVars.textureOv[0],
					globalVars.textureRadius[0]);

			sgl_set_omap(globalVars.textureObjectMap[0],
					globalVars.textureRefIndex[0]); 
		}
		sgl_to_parent();
	}
	sgl_to_parent();
	

	/***********************/
	/* SETUP NEFERTTS HEAD */
	/***********************/

	/* Draw Nefertitis head.
	 */
	sgl_create_list(FALSE, TRUE, FALSE);
	{
		/* Position Nefertts head.
		 */
		sgl_translate(0.0f, 50.0f, 0.0f);

		/* Setup nefertt transform.
		 */
		neferttTransform = sgl_create_transform(NAMED_ITEM);

		globalVars.polygonMesh = CreateNefertt();
	}
	sgl_to_parent();

	/* Initialisation of camera and light positions.
	 */
	camera_pos[0] = 0.0f;
	camera_pos[1] = 0.0f;
	camera_pos[2] = 7.5f;

	light_pos1[0] = -0.18f;
	light_pos1[1] = -0.2f;
	light_pos1[2] = 0.0f;

	light_pos2[0] = -0.3333f;
	light_pos2[1] = -0.3333f;
	light_pos2[2] = 0.0f;

	light_pos3[0] = 0.0f;
	light_pos3[1] = -0.3333f;
	light_pos3[2] = 0.0f;

	light_pos4[0] = 0.3333f;
	light_pos4[1] = -0.3333f;
	light_pos4[2] = 0.0f;

	/* Setup camera position.
	 */
	sgl_modify_transform(globalVars.cameraTransform, TRUE);
	sgl_rotate(YAxis, -camera_pos[0] * 4.712385f);
	sgl_rotate(XAxis, -camera_pos[1] * 4.712385f);
	sgl_translate(0.0f, 0.0f,  -60.0f * camera_pos[2]);

	/* Set up the light 1 position.
	 */
	sgl_modify_transform(globalVars.lightTransform[0], TRUE);
	sgl_rotate(YAxis, light_pos1[0] * 4.712385f);
	sgl_rotate(XAxis, light_pos1[1] * 4.712385f);

	/* Set up the light 2 position.
	 */
	sgl_modify_transform(globalVars.lightTransform[1], TRUE);
	sgl_rotate(YAxis, light_pos2[0] * 4.712385f);
	sgl_rotate(XAxis, light_pos2[1] * 4.712385f);

	/* Set up the light 3 position.
	 */
	sgl_modify_transform(globalVars.lightTransform[2], TRUE);
	sgl_rotate(YAxis, light_pos3[0] * 4.712385f);
	sgl_rotate(XAxis, light_pos3[1] * 4.712385f);

	/* Set up the light 4 position.
	 */
	sgl_modify_transform(globalVars.lightTransform[3], TRUE);
	sgl_rotate(YAxis, light_pos4[0] * 4.712385f);
	sgl_rotate(XAxis, light_pos4[1] * 4.712385f);
}

	
/********************************************************************************************
/*
/*	Function Name	:	RunNeferttDemo
/*	Inputs			:	sgl_bool	do_render
/*
/*	Outputs			:	Renders Nefertt Head to display.
/*	Returns			:	-
/*	Globals Used	:	globalVars, light_pos, camera_pos
/*	Description		:	Routine which controls the annimation of the Nefertt scene.
/*						Renders the image to the scene.
/*
/********************************************************************************************/

void RunNeferttDemo (sgl_bool do_render)
{
	float	fraction;

	/* set up the camera position. Changed by MOUSE.
	 * Calculations only performed if camera selected.
	 *
	 *	3.14159f * 1.5f = 4.712385f
	 */
	if (MoveCamera)
		MoveCameraPos(globalVars.cameraTransform, camera_pos);
	else
	{
		/* Only perform light position calculations for light enabled.
		 */
		switch (globalVars.lightMove)
		{
			case 1:	/* Set up the light 1 position. Changed by MOUSE.
					 */
					MoveLightPos(globalVars.lightTransform[0], 0, light_pos1);
			break;						

			case 2:	/* Set up the light 2 position. Changed by MOUSE.
					 */
					MoveLightPos(globalVars.lightTransform[1], 0, light_pos2);
			break;

			case 3:	/* Set up the light 3 position. Changed by MOUSE.
					 */
					MoveLightPos(globalVars.lightTransform[2], 0, light_pos3);
			break;

			case 4:	/* Set up the light 4 position. Changed by MOUSE.
					 */
					MoveLightPos(globalVars.lightTransform[3], 0, light_pos4);
			break;

			default:/* do nothing...
					 */
			break;
		}
	}

	/* do the animation. Rotate the nefertts head around the Y Axis.
	 */
	if(moving_mode)
	{
		/* Calculate the rotation fraction.
		 */
		fraction = (float) animation_position / (float) MOVE_CYCLES;

		/* modify the nefertt transform.
		 */
		sgl_modify_transform(neferttTransform, TRUE);

		/* Rotate the head around the Y Axis.
		 */
		sgl_rotate(YAxis, fraction * TWOPI * 4);

		/* change the animation mode if necessary
		 */
		animation_position++;
	}

	if ( do_render == 1)
        sgl_render(globalVars.viewport, globalVars.camera, FALSE );
}
 
 
/****************************************************************************************
/*
/*	Function Name	:	CloseNeferttDemo
/*	Inputs			:	-
/*	Outputs			:	Deletes textures, device and viewport.
/*	Returns			:	-
/*	Globals Used	:	globalVars
/*	Description		:	Routine to close down the Nefertt demo. Deletes the set device and
/*						releases the defined list.
/***************************************************************************************/

void CloseNeferttDemo (void)	  
{
	int	i;

	/* Delete Cached Textures.
	 */
	SetupCachedTexture(FALSE);

	/* Delete Textures.
	 */
	for (i = 0 ; i < 6 ; i++)
	{
		if (globalVars.textureHandle[i])
		{
			sgl_delete_texture(globalVars.textureHandle[i]);
			globalVars.textureHandle[i] = 0;
		}
	}

	sgl_delete_viewport(globalVars.viewport);
	sgl_delete_device(globalVars.screenDevice);

	if (globalVars.nCachedTexture)
	{
		/* Delete cached texturing.
		 */
		sgl_register_texture_callback(NULL,globalVars.texData,1);

		sgl_unload_cached_texture(globalVars.nCachedTexture);
		globalVars.nCachedTexture = 0;
	}

	/* Clear all convexes.
	 */
	for (i = 0 ; i < globalVars.convexPolydronCnt ; i++)
	{
		if (globalVars.convexPolydron[i])
		{
			sgl_modify_convex(globalVars.convexPolydron[i], TRUE);
			globalVars.convexPolydron[i] = 0;
		}
	}

	/* Clear mesh.
	 */
	if (globalVars.polygonMesh)
	{
		sgl_delete_mesh(globalVars.polygonMesh);
		globalVars.polygonMesh = 0;
	}

	sgl_modify_list(SGL_DEFAULT_LIST,TRUE);	
}


/****************************************************************************************
/*
/*	Function Name	:	InitialiseParameters
/*	Inputs			:	sgl_bool	do_render
/*
/*	Outputs			:	-
/*	Returns			:	-
/*	Globals Used	:	globalVars
/*	Description		:	Initialises different parameters and settings.
/*
/***************************************************************************************/

static void InitialiseParameters()
{
	/* initialise multishadows settings.
	 */
	globalVars.bMultiShadows = TRUE;
	globalVars.MultiShadowsColour[0] = 0.1f;
	globalVars.MultiShadowsColour[1] = 0.1f;
	globalVars.MultiShadowsColour[2] = 0.1f;

	/* initialise convex handle count to zero.
	 */
	globalVars.convexPolydronCnt = 0;

	globalVars.ambientColour[0] = 0.00f;
	globalVars.ambientColour[1] = 0.00f;
	globalVars.ambientColour[2] = 0.00f;

	/* Initialise quality menu options.
	 */
	globalVars.texturingQual	= TRUE;
	globalVars.shadingQual		= TRUE;
	globalVars.shadowQual		= TRUE;
	globalVars.fogQual			= TRUE;
	globalVars.collisionQual	= FALSE;

 	/* Initialise background colour.
	 */
	globalVars.backgroundColour[0] = 0.0f;
	globalVars.backgroundColour[1] = 0.0f;
	globalVars.backgroundColour[2] = 0.0f;

 	/* Initialise camera and viewport settings.
	 */
	globalVars.zoomCamera			= LENS_50MM;	/* 50mm	*/
	globalVars.foregroundCamera		= 10.0f;
	globalVars.inv_backgroundCamera	= 0.0f;

	globalVars.leftViewport		= 0;
	globalVars.topViewport		= 0;
	globalVars.rightViewport	= 640;
	globalVars.bottomViewport	= 480;
	globalVars.leftCamera		= 80.0f;
	globalVars.topCamera		= 0.0f;
	globalVars.rightCamera		= 560.0f;
	globalVars.bottomCamera		= 480.0f;

	/* Setup device settings.
	 */
	globalVars.numberDevice		= 0;
	globalVars.xDevice			= 640;
	globalVars.yDevice			= 480;
	globalVars.modeDevice		= sgl_device_16bit;
	globalVars.doublebufferDevice = TRUE;
}

/*--------------------------- End of File --------------------------------*/
