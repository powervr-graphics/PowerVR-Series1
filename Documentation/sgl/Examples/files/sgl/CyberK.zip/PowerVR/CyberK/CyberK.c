/*-----------------------------------------------------------------------------
   Name   : CiberK (PowerVR SGL version)
   Author : Carlos Sarria     - send comments to csarria@videologic.com
   Date   : April 1997
   Update : July  1997
   Project: cyberk.c + frontend.c + sgl.lib
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#define NK  20
#define LAP 7
#define TLP 0.3f

#define SHADOW FALSE

#include <math.h>
#include <time.h>
#include <ddraw.h>

#include "sgl.h"
#include "frontend.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */
#pragma warning (disable : 4056)

#define NAMED_ITEM	 TRUE
#define UNAMED_ITEM	 FALSE

#define INVISIBLE    TRUE
#define VISIBLE      FALSE

#define PI 3.142f

#define GRV   -9.81
#define HIGH  30.0

/*------------------------------- Global Variables -----------------------------------*/

static sgl_colour 	White   = {0.9f,0.9f,0.9f};
static sgl_colour 	Black   = {0.0f,0.0f,0.0f};
static sgl_colour	Blue    = {0.1f,0.4f,0.6f};

static sgl_colour 	Yellow  = {0.7f,0.7f,0.3f};

static sgl_colour	Red     = {0.8f,0.1f,0.1f};
static sgl_colour	Grey    = {0.5f,0.5f,0.5f};


int Device, viewport1;

int GroundTex, SkyTex, MapTex, SeaTex, SkyTran, KTex;
sgl_intermediate_map BuffTex[5];

int camera, camTran, Cmr = 0;
int frame;

char pszTmp[100];

int Head, Prism1, Prism2;

int CKList[NK][2], CKBody1[NK][2], CKBody2[NK][2], CKBody3[NK][2], NumMax[NK], LongK[NK];
int StateK[NK], TimerK[NK];
sgl_vector RotVecK[NK], PathK[NK][200];
float AngK[NK], MovAngK[NK];

sgl_vector p1[NK]={0.0,0.0,200.0}, p2[NK]={0.0,0.0,200.0};

float Sig[2] ={1.0, -1.0}, NewAng[50];

/*----------------------------  Routines Prototypes ---------------------------------*/

void SetupTextures (void),
     SetupLights   (void),  
     SetupAmbient  (void),
     SetupCameras  (void);

void SetupGround     (void),
     SetupSky        (void),
     SetupSea        (void),
     CreateCyberK    (int),
     CreatePath      (int),
     NewPoint        (int),
     DrawK           (int, int),
     CreateInstances (void);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device                                                         */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
int SetupScene (int xsize, int ysize, int pixdepth)
{
int i;
   
     Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, FALSE);
     if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

     viewport1 = sgl_create_viewport (Device, 0, 0, 640, 480,100.0f, 0.0f, 580.0f, 480.0f);
     if (viewport1<0) return ERR_CREATE_VIEWPORT;
	
     srand ((unsigned)time(NULL));
     SetCursor (NULL);   /* This hides the pointer */
	 sgl_qual_texture_filter (sgl_tf_bilinear);  /* Sets Bilinear Filtering */

     SetupTextures ();
     SetupLights   ();   
     SetupCameras  ();
     SetupAmbient  ();
 
     CreateInstances ();

     SetupSky      ();	 
     SetupGround   ();
 

     for (i=0; i<NK; i++){
         StateK[i] = i&3;
         p1[i][2]  = p2[i][2]= -200;
         NewAng[i] = (float)((char)(rand()))*(50.0/255.0);;
         CreateCyberK (i);    
         NewPoint     (i);
         CreatePath   (i);
    }

 frame = 0;
 return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContextMovAngK, AngK, LongK, TimerK, StateK                 */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame(void)
{
 register i;   
  
   /* We have three diferent States: 0. Before jump (Only rotation)          */
   /*                                1. In the air  (Rotion and traslation)  */
   /*                                2. On the ground again (Only rotation)  */
   for (i=0; i<NK; i++)
   {
       switch (StateK[i]){
              default:
              case 0: MovAngK[i]+=AngK[i]/LAP; LongK[i]+=3.3; DrawK(0,i); 
                      if (TimerK[i]==LAP){TimerK[i]=-1; StateK[i]=1;}
                      break;
              case 1: MovAngK[i]-=(2.0*AngK[i])/NumMax[i]; LongK[i]=60; DrawK(TimerK[i], i); 
                      if (TimerK[i]==NumMax[i]-1){TimerK[i]=-1; StateK[i]=2;}
                      break;
              case 2: MovAngK[i]+=AngK[i]/LAP; LongK[i]-=3.3;  DrawK(NumMax[i]-1,i); 
                      if (TimerK[i]==LAP){TimerK[i]=-1; StateK[i]=0; NewPoint(i); CreatePath(i);}
                      break;
      }
      TimerK[i]++;
    }
    /* Moving the camera */
    sgl_modify_transform (camTran, TRUE);
    sgl_translate (0.0,0.0, frame*5-150);

    sgl_render(viewport1, camera, TRUE);
    frame++; if (frame == 20000) frame =0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/					   
void Finish(void)
{
    FreeAllBMPTextures ();
    sgl_delete_device  (Device);	
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupTextures                                                  */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SeaTex, SealTex, GroundTex, SkyTex                             */
/*  Description     :   Loads all texture bitmaps.                                     */
/*-------------------------------------------------------------------------------------*/
void SetupTextures (void)
{

   BuffTex[0]   = ConvertBMPtoSGL   ("ground.bmp", FALSE);
   GroundTex    = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
                                      TRUE, TRUE, &BuffTex[0],  NULL);
   BuffTex[2]   = ConvertBMPtoSGL   ("sky.bmp", FALSE);
   SkyTex       = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
                                      TRUE, TRUE, &BuffTex[2],  NULL);
   BuffTex[3]   = ConvertBMPtoSGL   ("cyberk.bmp", FALSE);
   KTex         = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
                                      TRUE, TRUE, &BuffTex[3],  NULL);
}	  
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupLigths                                                    */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   White                                                          */
/*  Description     :   Creates ambient and parallel ligths                            */
/*-------------------------------------------------------------------------------------*/
void SetupLights (void)
{
   sgl_vector SpotLightDir = {500.0f, -500.0f, -100.0f};
   sgl_vector SpotLightPos = {500.0f,  500.0f, -100.0f};
   sgl_vector LightDir     = {-100.0f, -100.0f,  100.0f};

   sgl_create_ambient_light  (UNAMED_ITEM, White, FALSE); 
   sgl_create_parallel_light (UNAMED_ITEM, White ,LightDir, SHADOW,FALSE);
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupAmbient                                                   */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   White                                                          */
/*  Description     :   Sets fog and bakcground colour.                                */
/*-------------------------------------------------------------------------------------*/
void SetupAmbient (void)
{
    sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
      sgl_set_fog(camera, Blue, 0.00075f);
      sgl_set_background_colour(camera,Blue);
    sgl_to_parent();
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupCameras                                                   */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   White                                                          */
/*  Description     :   None.                                                          */
/*-------------------------------------------------------------------------------------*/
void SetupCameras (void)
{
    sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
        sgl_translate (0.0, 50.0f, -150.0f);
        camTran = sgl_create_transform(TRUE);
        camera  = sgl_create_camera (3.0f,10.0f,0.0f);
    sgl_to_parent();

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawGround                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   GroundTex, White                                               */
/*  Description     :   Draw ground. (Translucent infinite plane)                      */
/*-------------------------------------------------------------------------------------*/
void SetupGround(void)
{
sgl_2d_vec uv1,  uv2,  uv3;
sgl_vector groundPnt = {0.0f,-1.0f,  20.0f };	
sgl_vector point2	 = {10.0f,-1.0f, 20.0f };	
sgl_vector point3	 = {0.0f,-1.0f,  10.0f };	
sgl_vector groundNrm = {0.0f,  1.0f, 0.0f };	
	
sgl_create_list(UNAMED_ITEM,TRUE,FALSE);

   /* UV vectors for texturing */
   uv1[0]=0.00f;
   uv1[1]=0.50f;
  
   uv2[0]=0.00f;
   uv2[1]=0.545f;

   uv3[0]=0.045f;
   uv3[1]=0.50f;

   sgl_qual_generate_shadows (FALSE);
   sgl_set_texture_map       (GroundTex, TRUE, TRUE);
   sgl_set_ambient           (White);
   sgl_set_diffuse           (White); 
   sgl_set_opacity           (0.7f);
   sgl_set_texture_effect    (TRUE, TRUE, TRUE, FALSE);
   sgl_add_plane             (groundPnt,point2,point3, VISIBLE, NULL,NULL,NULL,uv1,uv2,uv3); 

sgl_to_parent();
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawSky                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SkyTex, White, Black, Blue                                     */
/*  Description     :   Draw Sky.                                                      */
/*-------------------------------------------------------------------------------------*/
void SetupSky(void)
{
sgl_2d_vec uv1,  uv2,  uv3;
sgl_vector groundPnt = {0.0f,500.0f, 500.0f };	
sgl_vector point2	 = {-120.0f,500.0f, 500.0f };	
sgl_vector point3	 = {0.0f,500.0f, 620.0f };	


    uv1[0]=0.01f;
    uv1[1]=0.00f;

    uv2[0]=0.2f;
    uv2[1]=0.055f;

    uv3[0]=0.055f;
    uv3[1]=0.00f;

   sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
       SkyTran = sgl_create_transform (NAMED_ITEM); 
       sgl_qual_generate_shadows  (FALSE);
       sgl_set_texture_map        (SkyTex,FALSE,FALSE);
       sgl_set_ambient            (White);
       sgl_set_specular           (Black, 0);
       sgl_set_glow               (White);
       sgl_set_diffuse            (Blue); 
       sgl_set_texture_effect     (TRUE, TRUE, TRUE, TRUE);
		   
       sgl_add_plane              (groundPnt,point2,point3, VISIBLE, NULL,NULL,NULL,uv1,uv2,uv3); 
  sgl_to_parent();
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   CreateCyberK                                                   */ 
/*  Inputs          :   i                                                              */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Head, prism1, Prism2, KTex                                     */
/*  Description     :   Creates a CyberK list with prism instances and textures.       */
/*-------------------------------------------------------------------------------------*/
void CreateCyberK (int i)
{
register j;
sgl_colour Color;

    Color[0]= 0.2+(float)((unsigned char)rand())/(255.0*0.8);
    Color[1]= 0.2+(float)((unsigned char)rand())/(255.0*0.8);
    Color[2]= 0.2+(float)((unsigned char)rand())/(255.0*0.8);

   for (j=0; j<2; j++){
      sgl_create_list (UNAMED_ITEM, TRUE, FALSE);
        CKList[i][j] = sgl_create_transform (NAMED_ITEM); 
          sgl_set_texture_map    (KTex,TRUE,FALSE);
          sgl_set_ambient        (Black);
          sgl_set_diffuse        (Color); 
         sgl_set_texture_effect (TRUE, TRUE, TRUE, FALSE);
    
        sgl_create_list (UNAMED_ITEM, FALSE, FALSE);
          sgl_translate    (0.0, 10.0*Sig[j], 0.0);
          CKBody1[i][j] = sgl_create_transform (NAMED_ITEM); 
          sgl_use_instance (Prism2);
        sgl_to_parent ();

        sgl_create_list (UNAMED_ITEM, FALSE, FALSE);
           sgl_translate    (0.0, 20.0*Sig[j], 0.0);
           CKBody2[i][j] = sgl_create_transform (NAMED_ITEM); 
           sgl_use_instance (Prism1);
        sgl_to_parent ();

        sgl_create_list (UNAMED_ITEM, FALSE, FALSE);
            sgl_translate    (0.0, 20.0*Sig[j], 0.0);
           CKBody3[i][j] = sgl_create_transform (NAMED_ITEM);
           sgl_use_instance (Head);
        sgl_to_parent ();

     sgl_to_parent ();
  }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   CreatePath                                                     */ 
/*  Inputs          :   Num                                                            */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   PathK, p1, p2, RotVect, MovAngK, AngK                          */
/*  Description     :   Calculates a parabolic path (jump) for each CyberK             */
/*-------------------------------------------------------------------------------------*/
void CreatePath (int Num)
{
int i=0;
float dist, t=0, A, CosA, SinA, x, Vel, Lang;
sgl_vector End1, End2;

   End1[0]=p1[Num][0];End1[2]=p1[Num][2]; End2[0]=p2[Num][0];End2[2]=p2[Num][2];

   dist   = sqrt ((End2[2]-End1[2])*(End2[2]-End1[2])+(End1[0]-End2[0])*(End1[0]-End2[0]));

   RotVecK[Num][0] = (End2[2]-End1[2])/dist;
   RotVecK[Num][1] = 0.0;
   RotVecK[Num][2] = (End1[0]-End2[0])/dist;

   A               = -atan ( (End1[2]-End2[2])/(End1[0]-End2[0]) );
   CosA            = (End1[0]<End2[0]) ?  cos(A) : -cos(A);
   SinA            = (End1[0]<End2[0]) ? -sin(A) :  sin(A);

   MovAngK[Num]    = 0.0; Lang = atan (-4 * HIGH / dist);
   AngK[Num]       = ((PI/2.0)+Lang)/1.2;
   Vel             = sqrt (GRV * dist / sin(2*Lang));

  while (1){
      x = Vel * cos(Lang) * t;
      PathK[Num][i][1] = -Vel * sin (Lang) * t + GRV/2 * t*t;
      PathK[Num][i][0] = End1[0] + CosA*x;
      PathK[Num][i][2] = End1[2] + SinA*x;
      if (PathK[Num][i][1]<0.0 && i>1) break;
      t += TLP; i++;
  }

  PathK[Num][i][0] = p2[Num][0];
  PathK[Num][i][1] = p2[Num][1];
  PathK[Num][i][2] = p2[Num][2];

  NumMax[Num]=++i;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NewPoint                                                       */ 
/*  Inputs          :   Num                                                            */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   NewAng, p1, p2                                                 */
/*  Description     :   Calculates two end points for creating a new path (jump).      */
/*-------------------------------------------------------------------------------------*/
void NewPoint (int Num)
{
    NewAng[Num]+=((float)((char)(rand()))/255.0) * (2.5-Num*(2.0/50));

    p1[Num][0]=p2[Num][0]; p1[Num][2]=p2[Num][2];

    p2[Num][0] = 50*(Num/2.0+1)*cos(NewAng[Num]/2.0);
    p2[Num][2] = 500+50*(Num/2.0+1)*sin(NewAng[Num]/2.0) + frame*5;
	
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawK                                                          */ 
/*  Inputs          :   Pos, Num                                                       */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Prism3DVert, PrismVert                                         */
/*  Description     :   Moves and rotates CyberK's list to build a CyberK and its      */
/*                      reflection                                                     */
/*-------------------------------------------------------------------------------------*/
void DrawK (int Pos, int Num)
{

  sgl_modify_transform (CKList[Num][0], TRUE);
  sgl_translate (PathK[Num][Pos][0],PathK[Num][Pos][1],PathK[Num][Pos][2]); 
  sgl_rotate (RotVecK[Num], MovAngK[Num]);

  sgl_modify_transform (CKBody2[Num][0], TRUE);
  sgl_translate (0.0, (LongK[Num]-60.0)/2.0, 0.0);

  sgl_modify_transform (CKBody3[Num][0], TRUE);
  sgl_translate (0.0, (LongK[Num]-60.0)/2.0, 0.0);

  sgl_modify_transform (CKList[Num][1], TRUE);
  sgl_translate (PathK[Num][Pos][0],-PathK[Num][Pos][1],PathK[Num][Pos][2]); 
  sgl_rotate (RotVecK[Num], -MovAngK[Num]);

  sgl_modify_transform (CKBody2[Num][1], TRUE);
  sgl_translate (0.0, -(LongK[Num]-60.0)/2.0, 0.0);

  sgl_modify_transform (CKBody3[Num][1], TRUE);
  sgl_translate (0.0, -(LongK[Num]-60.0)/2.0, 0.0);

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   CreateInstances                                                */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Head, Prism1, Prism2                                           */
/*  Description     :   Creates three instances for building CyberK's body.            */
/*-------------------------------------------------------------------------------------*/
void CreateInstances (void)
{
   Head = sgl_create_list(TRUE, TRUE, TRUE);
      sgl_rotate (sgl_y_axis, -PI/1.5f);
      sgl_create_prism ( 20.0, 10.0,  10, TRUE, TRUE, TRUE);
      sgl_to_parent ();
    sgl_modify_list (SGL_DEFAULT_LIST,FALSE);
  
  Prism1 = sgl_create_list(TRUE, TRUE, TRUE);
      sgl_rotate (sgl_y_axis, -PI);
      sgl_create_prism ( 20.0, 6.0,  10, TRUE, TRUE, TRUE);
      sgl_to_parent ();
  sgl_modify_list (SGL_DEFAULT_LIST,FALSE);
  
  Prism2 = sgl_create_list(TRUE, TRUE, TRUE);
      sgl_rotate (sgl_y_axis, -PI/4);
      sgl_create_prism ( 20.0, 2.0,  10, FALSE, TRUE, TRUE);
      sgl_to_parent ();
  sgl_modify_list (SGL_DEFAULT_LIST,FALSE);
}
/*------------------------------------------------------------------------*/
/*--------------------------- End of File --------------------------------*/

