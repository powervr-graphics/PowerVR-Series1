/*****************************************************************************
Name            :   bwinds.c
Title           :   Bwinds
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Prism file windows.bpoly as SGL C Commands
					Number of Meshes = 1
Program Type    :   ANSI  
*****************************************************************************/


#include "sgl.h"


/*****************************************************************
* Function Name		: bwinds  
* Inputs			: none
* Outputs			: nMesh - pointer to mesh name
*					: nMaterial - pointer to material name
* Returns			: constant 
* Description		: Creates bwinds mesh
******************************************************************/

int bwinds(int *nMesh, int *nMaterial)
{
	int v[SGL_MAX_FACE_VERTS];

	static sgl_vector vertex_1[16]=		{
		{-0.928663f, -0.78f, 1.24469f},        	{-1.68549f, -0.78f, 1.21198f},
		{-1.85669f, -0.78f, 1.02743f},         	{-1.99104f, -0.78f, -1.08338f},
		{-1.7953f, -0.78f, -1.47379f},         	{-1.06245f, -0.78f, -1.95079f},
		{1.02946f, -0.78f, -1.59792f},          {1.59166f, -0.78f, -0.882601f},
		{-0.928663f, -0.141387f, 1.24469f},     {-1.68549f, -0.189645f, 1.21198f},
		{-1.85669f, -0.189645f, 1.02743f},      {-1.99104f, -0.374991f, -1.08338f},
		{-1.7953f, -0.374991f, -1.47379f},     	{-1.06245f, -0.423249f, -1.95079f},
		{1.02946f, -0.310291f, -1.59792f},     	{1.59166f, -0.177581f, -0.882601f}
										};

	static sgl_vector vertex_normal_1[16]={
		{0.0431877f, 0.0f, -0.999067f},            	{0.41964f, 0.0f, -0.907691f},
		{0.918814f, 0.0f, -0.39469f},              	{0.979948f, 0.0f, 0.199251f},
		{0.745657f, 0.0f, 0.66633f},               	{0.20351f, 0.f, 0.979073f},
		{-0.510611f, 0.0f, 0.859812f},             	{-0.786227f, 0.0f, 0.617938f},
		{0.0431877f, 0.0f, -0.999067f},            	{0.41964f, 0.0f, -0.907691f},
		{0.918814f, 0.0f, -0.39469f},              	{0.979948f, 0.0f, 0.199251f},
		{0.745657f, 0.0f, 0.66633f},               	{0.20351f, 0.0f, 0.979073f},
		{-0.510611f, 0.0f, 0.859812f},             	{-0.786227f, 0.0f, 0.617938f}
										};

	/* windows */

	*nMesh=sgl_create_mesh(TRUE);
	sgl_add_vertices(16, vertex_1, vertex_normal_1, FALSE);
	*nMaterial=sgl_create_material(TRUE, TRUE);
	v[0]=8; v[1]=9; v[2]=1; v[3]=0; sgl_add_face(4,v);
	v[0]=9; v[1]=10; v[2]=2; v[3]=1; sgl_add_face(4,v);
	v[0]=10; v[1]=11; v[2]=3; v[3]=2; sgl_add_face(4,v);
	v[0]=11; v[1]=12; v[2]=4; v[3]=3; sgl_add_face(4,v);
	v[0]=12; v[1]=13; v[2]=5; v[3]=4; sgl_add_face(4,v);
	v[0]=13; v[1]=14; v[2]=6; v[3]=5; sgl_add_face(4,v);
	v[0]=14; v[1]=15; v[2]=7; v[3]=6; sgl_add_face(4,v);

	return 1;
}
