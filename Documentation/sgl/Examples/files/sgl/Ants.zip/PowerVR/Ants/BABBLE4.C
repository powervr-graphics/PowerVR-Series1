/*****************************************************************************
Name            :   babble4.c
Title           :   Babble 4
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Prism file babble4.bpoly as SGL C Commands
 					Number of Meshes = 1
Program Type    :   ANSI
*****************************************************************************/

#include "sgl.h"

/*****************************************************************
* Function Name		: babble4  
* Inputs			: none
* Outputs			: nMesh - pointer to mesh name
*					: nMaterial - pointer to material name
* Returns			: constant 
* Description		: Creates babble4 mesh
******************************************************************/

int babble4(int *nMesh, int *nMaterial)
{
	int v[SGL_MAX_FACE_VERTS];

	static sgl_vector vertex_1[42]={
		{0.0f, -0.145271f, -0.122554f},            	{-0.127303f, -0.145271f, -0.122554f},
		{-0.211317f, -0.122701f, -0.122554f},    	{-0.254607f, -0.0807061f, -0.122554f},
		{-0.678951f, -0.145271f, -0.122554f},    	{-0.657391f, -0.122621f, -0.122554f},
		{-0.150383f, -0.0322824f, -0.122554f},   	{-0.255026f, 0.0798227f, -0.12787f},
		{-0.233809f, 0.0959639f, -0.12787f},     	{-0.148521f, 0.0161412f, -0.122554f},
		{-0.0818049f, 0.0161412f, -0.122554f},   	{0.0f, 0.0322824f, -0.122554f},
		{0.0f, -0.145271f, -0.254306f},            	{-0.127303f, -0.145271f, -0.254306f},
		{-0.212172f, -0.12172f, -0.254306f},     	{-0.254607f, -0.0807061f, -0.254306f},
		{-0.21665f, -0.0512272f, -0.254306f},    	{-0.150383f, -0.0322824f, -0.254306f},
		{-0.140126f, -0.0258852f, -0.259622f},   	{-0.117377f, -0.022f, -0.259622f},
		{-0.0986196f, -0.0142804f, -0.254306f},  	{-0.0680169f, -0.00071077f, -0.254306f},
		{0.0f, 0.0322824f, -0.254306f},            	{0.127303f, -0.145271f, -0.122554f},
		{0.211317f, -0.122701f, -0.122554f},     	{0.254607f, -0.0807061f, -0.122554f},
		{0.678951f, -0.145271f, -0.122554f},     	{0.657391f, -0.122621f, -0.122554f},
		{0.150383f, -0.0322824f, -0.122554f},    	{0.255026f, 0.0798227f, -0.12787f},
		{0.233809f, 0.0959639f, -0.12787f},      	{0.148521f, 0.0161412f, -0.122554f},
		{0.0818049f, 0.0161412f, -0.122554f},    	{0.127303f, -0.145271f, -0.254306f},
		{0.212172f, -0.12172f, -0.254306f},      	{0.254607f, -0.0807061f, -0.254306f},
		{0.21665f, -0.0512272f, -0.254306f},     	{0.150383f, -0.0322824f, -0.254306f},
		{0.140126f, -0.0258852f, -0.259622f},    	{0.117377f, -0.022f, -0.259622f},
		{0.0986196f, -0.0142804f, -0.254306f},   	{0.0680169f, -0.00071077f, -0.254306f}
	
	};

	static sgl_2d_vec vertex_uv_1[42]={
		{0.1f, 1.0f},              	{0.1f, 0.8125f},         	{0.1f, 0.688759f},
		{0.1f, 0.625f},          	{0.1f, 0.0f},              	{0.1f, 0.0317551f},
		{0.1f, 0.778507f},       	{0.115512f, 0.624382f},  	{0.115512f, 0.655632f},
		{0.1f, 0.78125f},        	{0.1f, 0.879513f},       	{0.1f, 1.0f},
		{0.484488f, 1.0f},         	{0.484488f, 0.8125f},    	{0.484488f, 0.6875f},
		{0.484488f, 0.625f},     	{0.484488f, 0.680905f},  	{0.484488f, 0.778507f},
		{0.5f, 0.793613f},       	{0.5f, 0.82712f},        	{0.484488f, 0.854747f},
		{0.484488f, 0.899821f},  	{0.484488f, 1.0f},         	{0.1f, 1.1875f},
		{0.1f, 1.31124f},        	{0.1f, 1.375f},          	{0.1f, 2.0f},
		{0.1f, 1.96825f},        	{0.1f, 1.22149f},        	{0.115512f, 1.37562f},
		{0.115512f, 1.34437f},   	{0.1f, 1.21875f},        	{0.1f, 1.12049f},
		{0.484488f, 1.1875f},    	{0.484488f, 1.3125f},    	{0.484488f, 1.375f},
		{0.484488f, 1.3191f},    	{0.484488f, 1.22149f},   	{0.5f, 1.20639f},
		{0.5f, 1.17288f},        	{0.484488f, 1.14525f},   	{0.484488f, 1.10018f}
	
	};

	*nMesh=sgl_create_mesh( TRUE );
	sgl_set_cull_mode(sgl_cull_anticlock);

	sgl_add_vertices(42, vertex_1, FALSE, vertex_uv_1);
	*nMaterial=sgl_create_material(TRUE, TRUE);
	v[0]=0; v[1]=1; v[2]=13; v[3]=12; sgl_add_face(4,v);
	v[0]=1; v[1]=2; v[2]=14; v[3]=13; sgl_add_face(4,v);
	v[0]=2; v[1]=3; v[2]=15; v[3]=14; sgl_add_face(4,v);
	v[0]=3; v[1]=4; v[2]=15; sgl_add_face(3,v);
	v[0]=4; v[1]=5; v[2]=16; v[3]=15; sgl_add_face(4,v);
	v[0]=5; v[1]=6; v[2]=17; v[3]=16; sgl_add_face(4,v);
	v[0]=6; v[1]=7; v[2]=18; v[3]=17; sgl_add_face(4,v);
	v[0]=7; v[1]=8; v[2]=19; v[3]=18; sgl_add_face(4,v);
	v[0]=8; v[1]=9; v[2]=20; v[3]=19; sgl_add_face(4,v);
	v[0]=9; v[1]=10; v[2]=21; v[3]=20; sgl_add_face(4,v);
	v[0]=10; v[1]=11; v[2]=22; v[3]=21; sgl_add_face(4,v);
	v[0]=12; v[1]=33; v[2]=23; v[3]=0; sgl_add_face(4,v);
	v[0]=33; v[1]=34; v[2]=24; v[3]=23; sgl_add_face(4,v);
	v[0]=34; v[1]=35; v[2]=25; v[3]=24; sgl_add_face(4,v);
	v[0]=35; v[1]=26; v[2]=25; sgl_add_face(3,v);
	v[0]=35; v[1]=36; v[2]=27; v[3]=26; sgl_add_face(4,v);
	v[0]=36; v[1]=37; v[2]=28; v[3]=27; sgl_add_face(4,v);
	v[0]=37; v[1]=38; v[2]=29; v[3]=28; sgl_add_face(4,v);
	v[0]=38; v[1]=39; v[2]=30; v[3]=29; sgl_add_face(4,v);
	v[0]=39; v[1]=40; v[2]=31; v[3]=30; sgl_add_face(4,v);
	v[0]=40; v[1]=41; v[2]=32; v[3]=31; sgl_add_face(4,v);
	v[0]=41; v[1]=22; v[2]=11; v[3]=32; sgl_add_face(4,v);
		 
	return 1;
}
