/*****************************************************************************
Name            :   callbk.c
Title           :   Call back
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   2d callback
Program Type    :   ANSI/Windows  
*****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <windows.h>
#include <mmsystem.h> 
#include <windowsx.h> 
#include "ddraw.h"
#include "sgl.h"
 
sgl_versions* versions;
sgl_win_versions* w32versions;

extern volatile char* szJoyStickStatus;
char *szStr;

BOOL bInfo=0;


/*****************************************************************
* Function Name		: sgl_2d_callback  
* Inputs			: lpSurfaceInfo	- callback surface parameters
* Outputs			: none
* Returns			: constant 
* Description		: 2d callback, called during sgl_render
*				   	  just before frame becomes visible
******************************************************************/

int sgl_2d_callback(P_CALLBACK_SURFACE_PARAMS lpSurfaceInfo)
{
    HDC                 hdc;
    HRESULT             hr = FALSE;
	char				pszTmp [120];
	int					nYPos;
	int					nGap;
	DWORD				dwNowTime;
	DWORD				dwRunTime;
	float				fFrameRate;
	int acc=0;
	int up=0;
	static int			count = 0;
	static BOOL			bInitStartTime=TRUE;
	static DWORD		dwStartTime;

	dwNowTime = timeGetTime();

	if (bInitStartTime)
	{
		dwStartTime = dwNowTime;
		bInitStartTime = FALSE;
	}

	dwRunTime = dwNowTime - dwStartTime;

	if (dwRunTime)
		fFrameRate 	= ((float)count * 1000.0f) / (float) dwRunTime;

	else
	 	fFrameRate 	= 0.0f;

	if (lpSurfaceInfo->p3DSurfaceObject != NULL)
	{
		if (IDirectDrawSurface_GetDC(lpSurfaceInfo->p3DSurfaceObject,&hdc) == DD_OK)
	    {
			 SetBkMode(hdc, TRANSPARENT);
		     SetBkColor( hdc, RGB( 0, 0, 255 ) );
		     SetTextColor( hdc, RGB( 255, 255, 0 ) );

			 if (bInfo) 
			 {
			 	nYPos = 8;
				nGap = 20;
 	   
				nYPos+=40;
	   
	   		 	sprintf(pszTmp, "AntWorld Demo  by Stel Michael");
	     	 	TextOut( hdc, 210, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;
  			 }
	
			 count++;
		     IDirectDrawSurface_ReleaseDC(lpSurfaceInfo->p3DSurfaceObject,hdc);

			 hr = TRUE;
	    }
	}

    return 0;
}
