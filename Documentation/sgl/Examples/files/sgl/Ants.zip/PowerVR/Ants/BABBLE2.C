/*****************************************************************************
Name            :   babble2.c
Title           :   Babble 2
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Prism file babble2.bpoly as SGL C Commands
 					Number of Meshes = 1
Program Type    :   ANSI
*****************************************************************************/

#include "sgl.h"

/*****************************************************************
* Function Name		: babble2  
* Inputs			: none
* Outputs			: nMesh - pointer to mesh name
*					: nMaterial - pointer to material name
* Returns			: constant 
* Description		: Creates babble2 mesh
******************************************************************/

int babble2(int *nMesh, int *nMaterial)
{
	int v[SGL_MAX_FACE_VERTS];

	static sgl_vector vertex_1[37]={
		{0.0f, 0.0715f, 0.612f},                   	{0.035625f, 0.0709414f, 0.612f},
		{0.09f, 0.053625f, 0.612f},              	{0.134063f, 0.0240195f, 0.612f},
		{0.15f, 0.0f, 0.612f},                     	{0.0329132f, 0.0709414f, 0.639266f},
		{0.0831492f, 0.053625f, 0.680883f},      	{0.123858f, 0.0240195f, 0.714607f},
		{0.138582f, 0.0f, 0.726805f},              	{0.0251907f, 0.0709414f, 0.662381f},
		{0.0636396f, 0.053625f, 0.739279f},      	{0.0947965f, 0.0240195f, 0.801593f},
		{0.106066f, 0.0f, 0.824132f},              	{0.0136331f, 0.0709414f, 0.677826f},
		{0.0344415f, 0.053625f, 0.778298f},      	{0.0513035f, 0.0240195f, 0.859715f},
		{0.0574025f, 0.0f, 0.889164f},             	{-1.55722e-09f, 0.0709414f, 0.68325f},
		{-3.93403e-09f, 0.053625f, 0.792f},      	{-5.86006e-09f, 0.0240195f, 0.880125f},
		{-6.55671e-09f, 0.0f, 0.912f},             	{-0.0136331f, 0.0709414f, 0.677826f},
		{-0.0344415f, 0.053625f, 0.778298f},     	{-0.0513035f, 0.0240195f, 0.859715f},
		{-0.0574025f, 0.0f, 0.889164f},            	{-0.0251907f, 0.0709414f, 0.662381f},
		{-0.0636396f, 0.053625f, 0.739279f},     	{-0.0947965f, 0.0240195f, 0.801593f},
		{-0.106066f, 0.0f, 0.824132f},             	{-0.0329132f, 0.0709414f, 0.639266f},
		{-0.0831492f, 0.053625f, 0.680883f},     	{-0.123858f, 0.0240195f, 0.714607f},
		{-0.138582f, 0.0f, 0.726805f},             	{-0.035625f, 0.0709414f, 0.612f},
		{-0.09f, 0.053625f, 0.612f},             	{-0.134063f, 0.0240195f, 0.612f},
		{-0.15f, 0.0f, 0.612f}                     
	};

	static sgl_vector vertex_normal_1[37]={
		{-2.91066e-09f, 2.79702f, 0.014325f},    	{0.446645f, 2.7504f, 0.0444213f},
		{1.17817f, 2.45313f, 0.117177f},         	{1.84047f, 1.84824f, 0.183046f},
		{2.11953f, 1.40635f, 0.2108f},           	{0.412907f, 2.75214f, 0.0855158f},
		{1.09331f, 2.46398f, 0.226431f},         	{1.7189f, 1.86838f, 0.355997f},
		{1.98664f, 1.42679f, 0.411446f},         	{0.316025f, 2.75214f, 0.158013f},
		{0.836779f, 2.46398f, 0.41839f},         	{1.31559f, 1.86838f, 0.657796f},
		{1.52051f, 1.42679f, 0.760254f},         	{0.171031f, 2.75214f, 0.206453f},
		{0.452862f, 2.46398f, 0.546653f},        	{0.711993f, 1.86838f, 0.859452f},
		{0.822893f, 1.42679f, 0.99332f},         	{-1.88958e-08f, 2.75214f, 0.223464f},
		{-4.73231e-08f, 2.46398f, 0.591692f},    	{-4.7983e-08f, 1.86838f, 0.930264f},
		{-3.77942e-08f, 1.42679f, 1.07516f},     	{-0.171031f, 2.75214f, 0.206453f},
		{-0.452862f, 2.46398f, 0.546653f},       	{-0.711993f, 1.86838f, 0.859452f},
		{-0.822893f, 1.42679f, 0.99332f},        	{-0.316025f, 2.75214f, 0.158013f},
		{-0.836779f, 2.46398f, 0.41839f},        	{-1.31559f, 1.86838f, 0.657796f},
		{-1.52051f, 1.42679f, 0.760254f},        	{-0.412907f, 2.75214f, 0.0855158f},
		{-1.0933f, 2.46398f, 0.226431f},         	{-1.7189f, 1.86838f, 0.355997f},
		{-1.98664f, 1.42679f, 0.411447f},        	{-0.446645f, 2.7504f, 0.0444212f},
		{-1.17817f, 2.45313f, 0.117177f},        	{-1.84047f, 1.84824f, 0.183046f},
		{-2.11953f, 1.40635f, 0.2108f}           
	};

	*nMesh=sgl_create_mesh( TRUE );

	sgl_add_vertices(37, vertex_1, vertex_normal_1, FALSE);
	sgl_set_cull_mode(sgl_cull_anticlock);

	*nMaterial=sgl_create_material(TRUE, TRUE);
	v[0]=0; v[1]=5; v[2]=1; sgl_add_face(3,v);
	v[0]=5; v[1]=6; v[2]=2; v[3]=1; sgl_add_face(4,v);
	v[0]=6; v[1]=7; v[2]=3; v[3]=2; sgl_add_face(4,v);
	v[0]=7; v[1]=8; v[2]=4; v[3]=3; sgl_add_face(4,v);
	v[0]=0; v[1]=9; v[2]=5; sgl_add_face(3,v);
	v[0]=9; v[1]=10; v[2]=6; v[3]=5; sgl_add_face(4,v);
	v[0]=10; v[1]=11; v[2]=7; v[3]=6; sgl_add_face(4,v);
	v[0]=11; v[1]=12; v[2]=8; v[3]=7; sgl_add_face(4,v);
	v[0]=0; v[1]=13; v[2]=9; sgl_add_face(3,v);
	v[0]=13; v[1]=14; v[2]=10; v[3]=9; sgl_add_face(4,v);
	v[0]=14; v[1]=15; v[2]=11; v[3]=10; sgl_add_face(4,v);
	v[0]=15; v[1]=16; v[2]=12; v[3]=11; sgl_add_face(4,v);
	v[0]=0; v[1]=17; v[2]=13; sgl_add_face(3,v);
	v[0]=17; v[1]=18; v[2]=14; v[3]=13; sgl_add_face(4,v);
	v[0]=18; v[1]=19; v[2]=15; v[3]=14; sgl_add_face(4,v);
	v[0]=19; v[1]=20; v[2]=16; v[3]=15; sgl_add_face(4,v);
	v[0]=0; v[1]=21; v[2]=17; sgl_add_face(3,v);
	v[0]=21; v[1]=22; v[2]=18; v[3]=17; sgl_add_face(4,v);
	v[0]=22; v[1]=23; v[2]=19; v[3]=18; sgl_add_face(4,v);
	v[0]=23; v[1]=24; v[2]=20; v[3]=19; sgl_add_face(4,v);
	v[0]=0; v[1]=25; v[2]=21; sgl_add_face(3,v);
	v[0]=25; v[1]=26; v[2]=22; v[3]=21; sgl_add_face(4,v);
	v[0]=26; v[1]=27; v[2]=23; v[3]=22; sgl_add_face(4,v);
	v[0]=27; v[1]=28; v[2]=24; v[3]=23; sgl_add_face(4,v);
	v[0]=0; v[1]=29; v[2]=25; sgl_add_face(3,v);
	v[0]=29; v[1]=30; v[2]=26; v[3]=25; sgl_add_face(4,v);
	v[0]=30; v[1]=31; v[2]=27; v[3]=26; sgl_add_face(4,v);
	v[0]=31; v[1]=32; v[2]=28; v[3]=27; sgl_add_face(4,v);
	v[0]=0; v[1]=33; v[2]=29; sgl_add_face(3,v);
	v[0]=33; v[1]=34; v[2]=30; v[3]=29; sgl_add_face(4,v);
	v[0]=34; v[1]=35; v[2]=31; v[3]=30; sgl_add_face(4,v);
	v[0]=35; v[1]=36; v[2]=32; v[3]=31; sgl_add_face(4,v);
	
	return 1;
}
