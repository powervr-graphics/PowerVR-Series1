/*****************************************************************************
Name            :   thrist.c
Title           :   Thrist
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Prism file thrist.bpoly as SGL C Commands
 					Number of Meshes = 1
Program Type    :   ANSI
*****************************************************************************/

#include "sgl.h"

/*****************************************************************
* Function Name		: thrist  
* Inputs			: none
* Outputs			: nMesh - pointer to mesh name
*					: nMaterial - pointer to material name
* Returns			: constant 
* Description		: Creates thrist mesh
******************************************************************/

int thrist(int *nMesh, int *nMaterial)
{
	int v[SGL_MAX_FACE_VERTS];

	static sgl_vector vertex_1[19]={
		{0.0f, 0.0322824f, -0.122554f},            	{0.0680169f, -0.00071077f, -0.122861f},
		{0.0986196f, -0.0142804f, -0.122861f},   	{0.117377f, -0.0302584f, -0.122671f},
		{0.150383f, -0.0322824f, -0.122554f},    	{0.150383f, -0.0322824f, -0.122554f},
		{0.21665f, -0.0643029f, -0.122649f},     	{0.254607f, -0.0807061f, -0.122554f},
		{0.211317f, -0.122701f, -0.122554f},     	{0.127303f, -0.145271f, -0.122554f},
		{0.0f, -0.145271f, -0.122554f},            	{-0.127303f, -0.145271f, -0.122554f},
		{-0.211317f, -0.122701f, -0.122554f},    	{-0.254607f, -0.0807061f, -0.122554f},
		{-0.21665f, -0.0643029f, -0.122649f},    	{-0.150383f, -0.0322824f, -0.122554f},
		{-0.117377f, -0.0302584f, -0.122671f},   	{-0.0986196f, -0.0142804f, -0.122861f},
		{-0.0680169f, -0.00071077f, -0.122861f}  
	};

	static sgl_2d_vec vertex_uv_1[19]={
		{4.5f, -122.5f},         	{4.63357f, -122.639f},   	{4.69367f, -122.697f},
		{4.73051f, -122.764f},   	{4.79532f, -122.773f},   	{4.79532f, -122.773f},
		{4.92546f, -122.908f},   	{5.0f, -122.977f},         	{4.91499f, -123.155f},
		{4.75f, -123.25f},       	{4.5f, -123.25f},        	{4.25f, -123.25f},
		{4.08501f, -123.155f},   	{4.0f, -122.977f},         	{4.07454f, -122.908f},
		{4.20468f, -122.773f},   	{4.26949f, -122.764f},   	{4.30633f, -122.697f},
		{4.36643f, -122.639f}    
	};

	/* thrist */
	*nMesh=sgl_create_mesh( TRUE );
	sgl_set_cull_mode(sgl_cull_anticlock);

	sgl_add_vertices(19, vertex_1, FALSE, vertex_uv_1);
	*nMaterial=sgl_create_material(TRUE, TRUE);
	v[0]=0; v[1]=10; v[2]=18; sgl_add_face(3,v);
	v[0]=0; v[1]=1; v[2]=10; sgl_add_face(3,v);
	v[0]=1; v[1]=9; v[2]=10; sgl_add_face(3,v);
	v[0]=1; v[1]=2; v[2]=9; sgl_add_face(3,v);
	v[0]=2; v[1]=3; v[2]=9; sgl_add_face(3,v);
	v[0]=3; v[1]=4; v[2]=9; sgl_add_face(3,v);
	v[0]=4; v[1]=8; v[2]=9; sgl_add_face(3,v);
	v[0]=5; v[1]=6; v[2]=8; sgl_add_face(3,v);
	v[0]=6; v[1]=7; v[2]=8; sgl_add_face(3,v);
	v[0]=10; v[1]=17; v[2]=18; sgl_add_face(3,v);
	v[0]=10; v[1]=16; v[2]=17; sgl_add_face(3,v);
	v[0]=10; v[1]=11; v[2]=16; sgl_add_face(3,v);
	v[0]=11; v[1]=15; v[2]=16; sgl_add_face(3,v);
	v[0]=11; v[1]=12; v[2]=15; sgl_add_face(3,v);
	v[0]=12; v[1]=14; v[2]=15; sgl_add_face(3,v);
	v[0]=12; v[1]=13; v[2]=14; sgl_add_face(3,v);

	return 1;
}
