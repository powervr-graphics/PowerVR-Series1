/*****************************************************************************
Name            :   babble6.c
Title           :   Babble 6 
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Prism file babble6.bpoly as SGL C Commands
					Number of Meshes = 1
Program Type    :   ANSI  
*****************************************************************************/


#include "sgl.h"


/*****************************************************************
* Function Name		: babble6  
* Inputs			: none
* Outputs			: nMesh - pointer to mesh name
*					: nMaterial - pointer to material name
* Returns			: constant 
* Description		: Creates babble6 mesh
******************************************************************/

int babble6(int *nMesh, int *nMaterial)
{
	int v[SGL_MAX_FACE_VERTS];

	static sgl_vector vertex_1[10]=		{
		{-3.8395f, -1.05685f, -6.781f},          	{3.6715f, -1.05685f, -6.781f},
		{3.0768f, -2.25613f, -5.82164f},         	{-3.46506f, -2.25613f, -5.8251f},
		{-8.1315f, -1.05685f, -2.869f},          	{-7.59958f, -2.25613f, -2.03522f},
		{-7.59991f, -2.25613f, 2.037f},          	{-8.1315f, -1.05685f, 2.999f},
		{3.07548f, -2.25613f, 2.026f},           	{3.6715f, -1.05685f, 2.999f}
										};

	static sgl_2d_vec vertex_uv_1[10]=	{
		{3.79757f, 1.0f},          	{0.559497f, 1.0f},         	{0.594148f, -5.96046e-08f},
		{3.80634f, -5.96046e-08f},	{3.10455f, 1.0f},          	{3.01709f, -5.96046e-08f},
		{2.59795f, -5.96046e-08f},	{2.5595f, 1.0f},           	{1.40487f, -5.96046e-08f},
		{1.4405f, 1.0f}
										};            

	sgl_create_mesh( TRUE );
	sgl_add_vertices(10, vertex_1, FALSE, vertex_uv_1);
	*nMaterial=sgl_create_material(TRUE, TRUE);
	v[0]=0; v[1]=1; v[2]=2; v[3]=3; sgl_add_face(4,v);
	v[0]=4; v[1]=0; v[2]=3; v[3]=5; sgl_add_face(4,v);
	v[0]=4; v[1]=5; v[2]=6; v[3]=7; sgl_add_face(4,v);
	v[0]=7; v[1]=6; v[2]=8; v[3]=9; sgl_add_face(4,v);
	v[0]=8; v[1]=2; v[2]=1; v[3]=9; sgl_add_face(4,v);
		  
	return 1;
}
