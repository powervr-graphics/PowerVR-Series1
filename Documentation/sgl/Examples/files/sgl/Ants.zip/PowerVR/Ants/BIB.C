/*****************************************************************************
Name            :   bib.c
Title           :   Bibble
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Prism file bibble.bpoly as SGL C Commands
					Number of Meshes = 1
						   .
Program Type    :   ANSI	  
*****************************************************************************/


#include "sgl.h"


/*****************************************************************
* Function Name		: bib  
* Inputs			: none
* Outputs			: nMesh - pointer to mesh name
*					: nMaterial - pointer to material name
* Returns			: constant 
* Description		: Creates bibble mesh
******************************************************************/

int bib(int *nMesh, int *nMaterial)
{
	int v[SGL_MAX_FACE_VERTS];

	static sgl_vector vertex_1[12]=	{
		{0.5f, -0.625245f, 0.5f},                	{0.5f, 0.496086f, 0.5f},
		{-0.621331f, 0.496086f, 0.5f},           	{0.499992f, 0.500978f, 0.500654f},
		{0.499992f, 0.500978f, -0.618174f},      	{-0.617424f, 0.500978f, 0.500654f},
		{0.500978f, -0.633816f, 0.499977f},      	{0.500978f, 0.500603f, -0.625429f},
		{0.500978f, 0.500539f, 0.499939f},       	{-0.617555f, 0.496215f, 0.497065f},
		{0.495956f, -0.618455f, 0.497065f},      	{0.495948f, 0.497065f, -0.61852f}
									};

	/* bibble */

	*nMesh=sgl_create_mesh( TRUE );
	sgl_add_vertices(12, vertex_1, FALSE, FALSE);
	*nMaterial=sgl_create_material(TRUE, TRUE);
	v[0]=0; v[1]=1; v[2]=2; sgl_add_face(3,v);
	v[0]=3; v[1]=4; v[2]=5; sgl_add_face(3,v);
	v[0]=6; v[1]=7; v[2]=8; sgl_add_face(3,v);
	v[0]=9; v[1]=10; v[2]=11; sgl_add_face(3,v);

	return 1;
}
