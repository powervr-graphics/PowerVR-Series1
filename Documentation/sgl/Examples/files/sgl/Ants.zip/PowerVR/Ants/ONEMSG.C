/*****************************************************************************
Name            :   onemsg.c 

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Ensures that only one message is given out where 
			     	required (OneXXX functions)
Program Type    :   ANSI
*****************************************************************************/

#include <stdio.h>
#include <windows.h>

/* Note: bDoneAMessage must be set TRUE before MessageBox is called because
   MessageBox might cause an event that calls the calling function, leading to
   recursive messages */

static BOOL bDoneAMessage = FALSE;


void OneMessage(char *pcMessage, char *pcTitle)
{
	if (! bDoneAMessage)
	{
		bDoneAMessage = TRUE;
		MessageBox(NULL, pcMessage, pcTitle, MB_OK);
	}
}


void IntMessage(int nNumber, char *pcTitle)
{
	char pcMessage[100];

	sprintf(pcMessage, "%d", nNumber);
	MessageBox(NULL, pcMessage, pcTitle, MB_OK);
}


void OneIntMessage(int nNumber, char *pcTitle)
{
	if (! bDoneAMessage)
	{
		char pcMessage[100];

		bDoneAMessage = TRUE;
		sprintf(pcMessage, "%d", nNumber);
		MessageBox(NULL, pcMessage, pcTitle, MB_OK);
	}
}
