/*****************************************************************************
Name            :   joystick.c
Title           :   Joystick

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Joystick software interface
Program Type    :   ANSI
*****************************************************************************/

#include <stdio.h>
#include <windows.h>
#include <mmsystem.h>
#include "joystick.h"

static BOOL gfJoystickAvailable = FALSE;
static UINT gwJoystick;
static JOYCAPS gJoystickCaps;
static HWND ghJoyWnd = NULL;

char szJoyStickStatus[80] = {0};
extern char *szStr;


BOOL JoystickInit ()
{
	UINT wNumJoysticks = joyGetNumDevs (), wJoystick;
	JOYINFO JoyInfo; 
					
	if (wNumJoysticks != 0)
	{
		for (wJoystick = 0; (wJoystick < wNumJoysticks) && !gfJoystickAvailable; ++wJoystick)
		{
			if (joyGetDevCaps (wJoystick, &gJoystickCaps, sizeof (gJoystickCaps)) == JOYERR_NOERROR)
			{
				BOOL fRetry = TRUE;

				while (fRetry)
				{
					fRetry = FALSE;
					
					switch (joyGetPos (wJoystick, &JoyInfo))
					{
						case JOYERR_NOERROR:
						{
							/* this joystick plugged in, so break out and set return value TRUE */
							gfJoystickAvailable = TRUE;
							gwJoystick = wJoystick;
							break;
						}
					
					
						case JOYERR_PARMS:
						{
#if 0
							DPF ("joyGetPos: bad parameters");
#endif
							break;
						}

						case MMSYSERR_NODRIVER:
						{
#if 0
							DPF ("joyGetPos: No joystick driver");
#endif
							break;
						}
						
						default:
						{
#if 0
							DPF ("joyGetPos: Unexpected error");
#endif
							break;
						}
					}
				}
			}
			else
			{
#if 0
				DPF ("Error getting joystick %d devcaps", wJoystick);
#endif
			}
		}
	}
	
	if (!gfJoystickAvailable)
	{
#if 0
		DPF ("Joystick services not available");
#endif
	}
	
	return (gfJoystickAvailable);
}


void JoystickDeinit ()
{
	if (ghJoyWnd)
	{
		JoystickSetWindow (ghJoyWnd, FALSE);
	}
}


void JoystickSetWindow (HWND hWnd, BOOL fSet)
{
	if (gfJoystickAvailable)
	{
		if (fSet)
		{
			if (ghJoyWnd)
			{
				JoystickSetWindow (ghJoyWnd, FALSE);
			}
	
			switch (joySetCapture (hWnd, gwJoystick, gJoystickCaps.wPeriodMin, TRUE))
			{
				case JOYERR_NOERROR:
				{
					joySetThreshold (gwJoystick, 1000);
					break;
				}
							
				case JOYERR_UNPLUGGED:
				{
#if 0
					DPF ("joySetCapture: unplugged");
#endif
					break;
				}
							
				case JOYERR_NOCANDO:
				{
#if 0
					DPF ("joySetCapture: no can do");
#endif
					break;
				}
						
				case JOYERR_PARMS:
				{
#if 0
					DPF ("joySetCapture: bad parameters");
#endif
					break;
				}
	
				case MMSYSERR_NODRIVER:
				{
#if 0
					DPF ("joySetCapture: No joystick driver");
#endif
					break;
				}
							
				default:
				{
#if 0
					DPF ("joySetCapture: Unexpected error");
#endif
					break;
				}
			}
	
			ghJoyWnd = hWnd;
		}
		else
		{
			if (ghJoyWnd)
			{
				if (ghJoyWnd != hWnd)
				{
#if 0
					DPF ("Bad window handle for joystick release!");
#endif
				}
		
				joyReleaseCapture (gwJoystick);
				ghJoyWnd = NULL;
			}
		}
	}
	else
	{
#if 0
		DPF ("Joystick services not available");
#endif
	}
}


BOOL JoystickGetPos (int *pnX, int *pnY, WORD *pwButtons)
{
	if (gfJoystickAvailable)
	{
		JOYINFO JoyInfo; 
					
		joyGetPos (gwJoystick, &JoyInfo);

		sprintf(szJoyStickStatus, "Joystick : X=%d Y=%d", (int)JoyInfo.wXpos, (int)JoyInfo.wYpos);
		szStr = &szJoyStickStatus[0];
		
		/* damping */
		
		if (JoyInfo.wXpos < 0x8888)
		{
			JoyInfo.wXpos = min (0x8888, JoyInfo.wXpos);
		}
		else
		{
			JoyInfo.wXpos = max (0x8888, JoyInfo.wXpos);
		}

		if (JoyInfo.wYpos < 0x8888)
		{
			JoyInfo.wYpos = min (0x8888, JoyInfo.wYpos);
		}
		else
		{
			JoyInfo.wYpos = max (0x8888, JoyInfo.wYpos);
		}
  
		*pnX = (int) (JoyInfo.wXpos - 0x8888);
		*pnY = (int) (JoyInfo.wYpos - 0x8888);

		*pwButtons = (WORD) JoyInfo.wButtons;
	}                            
	else
	{
		strcpy (szJoyStickStatus, "Joystick : not available");
	}   

    return (gfJoystickAvailable);
}
