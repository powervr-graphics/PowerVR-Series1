/*****************************************************************************
Name            :   craft.cpp
Title           :   Craft model 
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Creates named craft model in display list
Program Type    :   Microsoft Visual C++ V2
*****************************************************************************/

#define Cplusplus 
#define PI	3.142f

#include "math.h"
#include "sgl.h"

extern void	sgl_simple_plane2(sgl_vector a,sgl_vector b,sgl_vector c,sgl_bool visible);

extern void	sgl_texture_plane( int texName, float a[3], float b[3], float c[3], int visible, 
					float xScale, float yScale, sgl_bool FirstPlane);

extern void	sgl_texture_plane_glow( int texName, float a[3], float b[3], float c[3], int visible, 
					float xScale, float yScale, sgl_bool FirstPlane);

extern int cpan1Tex,cpan2Tex,cpan3Tex,pan1Tex,pan3Tex,thrustTex;

extern  int	CraftModel; 

static sgl_colour	white	=	{1.0f,1.0f,1.0f};
static sgl_colour	black	=	{0.0f,0.0f,0.0f};
static sgl_colour 	SkyBlue	=	{0.5f, 0.6f, 0.9f};


/*****************************************************************
* Function Name		: addNoseParts  
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: creates craft nose
******************************************************************/

static void addNoseParts()
{

/* nose tip */
    
	float p1[3]={-5.0f,-1.0f,5.0f};
	float p2[3]={-5.0f,0.0f,6.0f};
	float p3[3]={-5.0f,1.0f,5.0f};
	float p4[3]={-5.0f,1.0f,-5.0f};
	float p5[3]={-5.0f,0.0f,-6.0f};
	float p6[3]={-5.0f,-1.0f,-5.0f}; 
	
	float p7[3]={0.0f,-2.0f,7.0f};
	float p8[3]={0.0f,0.0f,15.0f};
	float p9[3]={0.0f,2.0f,11.0f};
	float p10[3]={0.0f,4.0f,7.0f};
	float p11[3]={0.0f,4.0f,-7.0f};
	float p12[3]={0.0f,2.0f,-11.0f};
	float p13[3]={0.0f,0.0f,-15.0f};
	float p14[3]={0.0f,-2.0f,-7.0f};
                                 
	float p15[3]={5.0f,-2.0f,8.0f};
	float p16[3]={5.0f,0.0f,20.0f};
	float p17[3]={5.0f,3.0f,15.0f};
	float p18[3]={5.0f,5.5f,8.0f};                                 
    float p19[3]={5.0f,5.5f,-8.0f};                  
	float p20[3]={5.0f,3.0f,-15.0f};
	float p21[3]={5.0f,0.0f,-20.0f};
	float p22[3]={5.0f,-2.0f,-8.0f};

	float p23[3]={15.0f,-2.0f,9.0f};
	float p24[3]={15.0f,0.0f,23.0f};
	float p25[3]={15.0f,4.0f,19.0f};
	float p26[3]={15.0f,7.0f,10.0f};
	float p27[3]={15.0f,7.0f,-10.0f};
	float p28[3]={15.0f,4.0f,-19.0f};
	float p29[3]={15.0f,0.0f,-23.0f};
	float p30[3]={15.0f,-2.0f,-9.0f};
	
	float p31[3]={35.0f,-2.0f,10.0f};
	float p32[3]={35.0f,0.0f,26.0f};
	float p33[3]={35.0f,3.0f,22.5f};
	float p34[3]={35.0f,8.0f,11.0f};
	float p35[3]={35.0f,8.0f,-11.0f};
	float p36[3]={35.0f,3.0f,-22.5f}; 
	float p37[3]={35.0f,0.0f,-26.0f};
	float p38[3]={35.0f,-2.0f,-10.0f};
	
	float p39[3]={70.0f,-2.0f,10.0f};
	float p40[3]={70.0f,0.0f,26.0f};
	float p41[3]={70.0f,3.0f,22.5f};
	float p42[3]={70.0f,8.0f,11.0f};
	float p43[3]={70.0f,8.0f,-11.0f};
	float p44[3]={70.0f,3.0f,-22.5f}; 
	float p45[3]={70.0f,0.0f,-26.0f};
	float p46[3]={70.0f,-2.0f,-10.0f};
                              
	sgl_create_list(FALSE,TRUE,FALSE);

        sgl_translate(-70.0f,0.5f,0.0f);

		sgl_scale(1.5f,1.0f,1.0f);
 
        sgl_texture_plane(cpan1Tex,p1,p3,p6,FALSE,1.0f,1.0f,TRUE);    	// front                               
        sgl_texture_plane(cpan1Tex,p11,p3,p10,FALSE,1.0f,1.0f,FALSE);  	// top
        sgl_texture_plane(cpan3Tex,p10,p3,p9,FALSE,1.0f,1.0f,FALSE);   	// 1 top     
        sgl_texture_plane(cpan1Tex,p9,p2,p8,FALSE,1.0f,1.0f,FALSE);   	// trig top 2          
        sgl_texture_plane(cpan3Tex,p1,p7,p2,FALSE,1.0f,1.0f,FALSE);   	// bot 1       
        sgl_texture_plane(cpan1Tex,p6,p14,p1,FALSE,1.0f,1.0f,FALSE);  	// bot 
        sgl_texture_plane(cpan3Tex,p5,p14,p6,FALSE,1.0f,1.0f,FALSE);  	// bot 1
        sgl_texture_plane(cpan1Tex,p13,p5,p12,FALSE,1.0f,1.0f,FALSE);  	// trig top 2
		sgl_texture_plane(cpan3Tex,p12,p4,p11,FALSE,1.0f,1.0f,FALSE);     // 1 top
                           
		/*part 2 */
        sgl_texture_plane(cpan1Tex,p19,p10,p18,FALSE,1.0f,1.0f,FALSE);   	// top                                                                                                                         
        sgl_texture_plane(cpan3Tex,p18,p10,p17,FALSE,1.0f,1.0f,FALSE);   	// top 1 
        sgl_texture_plane(cpan1Tex,p17,p9,p16,FALSE,1.0f,1.0f,FALSE);    	// top 
        sgl_texture_plane(cpan3Tex,p7,p15,p8,FALSE,1.0f,1.0f,FALSE);    	// bot 1   
		sgl_texture_plane(cpan1Tex,p15,p7,p22,FALSE,1.0f,1.0f,FALSE);   	// bot  	
        sgl_texture_plane(cpan3Tex,p13,p22,p14,FALSE,1.0f,1.0f,FALSE);  	// bot 1   
		sgl_texture_plane(cpan1Tex,p21,p12,p20,FALSE,1.0f,1.0f,FALSE);  	// top 2 
		sgl_texture_plane(cpan3Tex,p20,p11,p19,FALSE,1.0f,1.0f,FALSE);  	// top 1
	
		/* part 3 */
        sgl_texture_plane(cpan1Tex,p27,p18,p26,FALSE,1.0f,1.0f,FALSE);  	// top
	   	sgl_texture_plane(cpan3Tex,p26,p18,p25,FALSE,1.0f,1.0f,FALSE);    // top 1
	   	sgl_texture_plane(cpan1Tex,p25,p17,p24,FALSE,1.0f,1.0f,FALSE);    // top 2    
        sgl_texture_plane(cpan3Tex,p15,p23,p16,FALSE,1.0f,1.0f,FALSE);    // bot 1
       	sgl_texture_plane(cpan1Tex,p23,p15,p30,FALSE,1.0f,1.0f,FALSE);  	// bot  
      	sgl_texture_plane(cpan3Tex,p21,p30,p22,FALSE,1.0f,1.0f,FALSE);    // bot 1
		sgl_texture_plane(cpan1Tex,p29,p20,p28,FALSE,1.0f,1.0f,FALSE);    // top 2
      	sgl_texture_plane(cpan3Tex,p28,p19,p27,FALSE,1.0f,1.0f,FALSE);    // top 1

		/* part4 */
        sgl_texture_plane(cpan1Tex,p35,p26,p34,FALSE,1.0f,1.0f,FALSE);    //top
        sgl_texture_plane(cpan3Tex,p34,p26,p33,FALSE,1.0f,1.0f,FALSE);       
        sgl_texture_plane(cpan1Tex,p33,p25,p32,FALSE,1.0f,1.0f,FALSE);                
        sgl_texture_plane(cpan3Tex,p23,p31,p24,FALSE,1.0f,1.0f,FALSE);                
        sgl_texture_plane(cpan1Tex,p31,p23,p38,FALSE,1.0f,1.0f,FALSE);               
        sgl_texture_plane(cpan3Tex,p29,p38,p30,FALSE,1.0f,1.0f,FALSE);               
        sgl_texture_plane(cpan1Tex,p37,p28,p36,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan3Tex,p36,p27,p35,FALSE,1.0f,1.0f,FALSE);        		
  	    sgl_texture_plane(cpan1Tex,p43,p34,p42,FALSE,1.0f,1.0f,FALSE);  	//top      
	    sgl_texture_plane(cpan3Tex,p42,p34,p41,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p41,p33,p40,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan3Tex,p31,p39,p32,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p39,p31,p46,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan3Tex,p37,p46,p38,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p45,p36,p44,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan3Tex,p44,p35,p43,FALSE,1.0f,1.0f,FALSE);  
      	sgl_texture_plane(cpan1Tex,p46,p42,p39,FALSE,1.0f,1.0f,FALSE); 	// back
                                  
	sgl_to_parent();   
}


/*****************************************************************
* Function Name		: addWins  
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: creates craft wings 
******************************************************************/

static void addWins()
{
	float p1[3]={-1.0f,0.0f,-35.0f};
	float p2[3]={-1.0f,0.0f,35.0f};
	float p3[3]={-1.0f,38.0f,43.0f};
	float p4[3]={-1.0f,43.0f,43.0f};
	float p5[3]={-1.0f,45.5f,40.5f};
	float p6[3]={-1.0f,45.5f,35.0f};
    float p7[3]={-1.0f,27.0f,-35.0f};
    
	float p8[3]={1.0f,0.0f,-35.0f};
	float p9[3]={1.0f,0.0f,35.0f};
	float p10[3]={1.0f,38.0f,43.0f};
	float p11[3]={1.0f,43.0f,43.0f};
	float p12[3]={1.0f,45.5f,40.5f};
	float p13[3]={1.0f,45.5f,35.0f};
    float p14[3]={1.0f,27.0f,-35.0f};
    

	float p15[3]={0.0f,37.5f,45.5f};
	float p16[3]={0.0f,44.0f,45.5f};
	float p17[3]={0.0f,47.0f,41.0f};
	float p18[3]={0.0f,47.0f,35.0f};
	

	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
   
        sgl_translate(40.0f,8.0f,0.0f);	 
        sgl_rotate(sgl_y_axis,PI/2.0f);	   
        sgl_rotate(sgl_z_axis,-1.215f);	
        sgl_scale(0.8f,-1.6f,0.48f);

		sgl_simple_plane2(p2,p1,p8,TRUE);       
		sgl_simple_plane2(p1,p7,p14,FALSE);  
		
		/* top and bottom */
        sgl_texture_plane(cpan2Tex,p2,p7,p1,FALSE,-1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan2Tex,p8,p14,p9,FALSE,1.0f,1.0f,FALSE);  
        
        /* upright fin edges */      
        sgl_texture_plane(cpan1Tex,p14,p7,p18,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p15,p2,p9,FALSE,1.0f,1.0f,FALSE);        
                                               
        /* other edges - top */                                     
        sgl_texture_plane(cpan1Tex,p17,p18,p6,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p4,p16,p17,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p3,p15,p16,FALSE,1.0f,1.0f,FALSE);  

		/* bot */		                           
        sgl_texture_plane(cpan1Tex,p13,p18,p17,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p12,p17,p16,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p16,p15,p10,FALSE,1.0f,1.0f,FALSE);  

        /* newies */
        sgl_texture_plane(cpan1Tex,p7,p6,p18,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p15,p3,p2,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p6,p18,p14,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p10,p15,p9,FALSE,1.0f,1.0f,FALSE);  
  
	sgl_to_parent();
 
   	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);

        sgl_translate(40.0f,8.0f,0.0f);		
        sgl_rotate(sgl_y_axis,PI/2.0f);											
        sgl_rotate(sgl_z_axis,1.215f);														
		sgl_scale(0.8f,-1.6f,0.48f);
										
		sgl_simple_plane2(p2,p1,p8,TRUE);       
		sgl_simple_plane2(p1,p7,p14,FALSE);  
		
		/* top and bottom */
        sgl_texture_plane(cpan2Tex,p2,p7,p1,FALSE,-1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan2Tex,p8,p14,p9,FALSE,1.0f,1.0f,FALSE);  
		
        /* upright fin edges */           
        sgl_texture_plane(cpan1Tex,p14,p7,p18,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p15,p2,p9,FALSE,1.0f,1.0f,FALSE);        
                                               
        /* other edges - top */                                       
        sgl_texture_plane(cpan1Tex,p17,p18,p6,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p4,p16,p17,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p3,p15,p16,FALSE,1.0f,1.0f,FALSE);  
                           
		/* bot */	                           
        sgl_texture_plane(cpan1Tex,p13,p18,p17,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p12,p17,p16,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p16,p15,p10,FALSE,1.0f,1.0f,FALSE);  

	sgl_to_parent();
}


/*****************************************************************
* Function Name		: addFins  
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: creates craft fins
******************************************************************/

static void addFins()
{
	float p1[3]={-0.75f,0.0f,-5.0f};
	float p2[3]={-0.75f,0.0f,15.0f};
	float p3[3]={-0.75f,14.0f,24.0f};
	float p4[3]={-0.75f,17.0f,24.0f};
	float p5[3]={-0.75f,18.5f,23.5f};
	float p6[3]={-0.75f,19.0f,22.0f};
	float p7[3]={-0.75f,19.0f,19.0f};
	
	float p8[3]={0.75f,0.0f,-5.0f};
	float p9[3]={0.75f,0.0f,15.0f};
	float p10[3]={0.75f,14.0f,24.0f};
	float p11[3]={0.75f,17.0f,24.0f};
	float p12[3]={0.75f,18.5f,23.5f};
	float p13[3]={0.75f,19.0f,22.0f};
	float p14[3]={0.75f,19.0f,19.0f};

	float p15[3]={0.0f,0.0f,-8.0f};
	float p16[3]={0.0f,0.0f,17.0f};
	float p17[3]={0.0f,13.0f,26.0f};
	float p18[3]={0.0f,17.0f,26.0f};
	float p19[3]={0.0f,20.0f,25.0f};
	float p20[3]={0.0f,21.0f,22.0f};
	float p21[3]={0.0f,21.0f,17.5f};


	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
        
        sgl_translate(40.0f,8.0f,5.0f);			 
        sgl_rotate(sgl_y_axis,PI/2.0f);
        sgl_rotate(sgl_z_axis,PI/4.0f);			  
        
        sgl_simple_plane2(p2,p1,p8,TRUE);       

		/* top and bottom */
        sgl_texture_plane(cpan2Tex,p2,p7,p1,FALSE,1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan2Tex,p8,p14,p9,FALSE,-1.0f,1.0f,FALSE);  
        
        /* other edges - top */                                            
        sgl_texture_plane(cpan1Tex,p1,p7,p15,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p21,p7,p6,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p20,p6,p5,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p19,p5,p4,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p18,p4,p3,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p17,p3,p2,FALSE,1.0f,1.0f,FALSE);  

		/* bot */		                           
        sgl_texture_plane(cpan1Tex,p15,p14,p8,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p13,p14,p21,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p12,p13,p20,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p11,p12,p19,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p10,p11,p18,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p9,p10,p17,FALSE,1.0f,1.0f,FALSE);  

	sgl_to_parent();


	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
        
        sgl_translate(40.0f,8.0f,-5.0f);
        
        sgl_rotate(sgl_y_axis,PI/2.0f);
        sgl_rotate(sgl_z_axis,-PI/4.0f);
        
		sgl_simple_plane2(p2,p1,p8,TRUE);       

		/* top and bottom */
        sgl_texture_plane(cpan2Tex,p2,p7,p1,FALSE,1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan2Tex,p8,p14,p9,FALSE,-1.0f,1.0f,FALSE);  
		
        /* other edges - top */                                          
        sgl_texture_plane(cpan1Tex,p1,p7,p15,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p21,p7,p6,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p20,p6,p5,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p19,p5,p4,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p18,p4,p3,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p17,p3,p2,FALSE,1.0f,1.0f,FALSE);  
                           
	   	/* bot */  		                           
        sgl_texture_plane(cpan1Tex,p15,p14,p8,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p13,p14,p21,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p12,p13,p20,FALSE,1.0f,1.0f,FALSE); 
        sgl_texture_plane(cpan1Tex,p11,p12,p19,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p10,p11,p18,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p9,p10,p17,FALSE,1.0f,1.0f,FALSE);  

	sgl_to_parent();


	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
        
        sgl_translate(50.0f,23.0f,0.0f);
        
        sgl_rotate(sgl_y_axis,PI/2.0f);
        sgl_rotate(sgl_z_axis,-PI/2.0f);

        sgl_scale(1.0f,2.0f,1.0f);
        
		sgl_simple_plane2(p2,p1,p8,TRUE);       

		/* top and bottom */
        sgl_texture_plane(cpan2Tex,p2,p7,p1,FALSE,1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan2Tex,p8,p14,p9,FALSE,-1.0f,1.0f,FALSE);  
 
        /* other edges - top */                                          
        sgl_texture_plane(cpan1Tex,p1,p7,p15,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p21,p7,p6,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p20,p6,p5,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p19,p5,p4,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p18,p4,p3,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p17,p3,p2,FALSE,1.0f,1.0f,FALSE);  
      
		/* bot */	                           
        sgl_texture_plane(cpan1Tex,p15,p14,p8,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p13,p14,p21,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p12,p13,p20,FALSE,1.0f,1.0f,FALSE); 
        sgl_texture_plane(cpan1Tex,p11,p12,p19,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p10,p11,p18,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p9,p10,p17,FALSE,1.0f,1.0f,FALSE);  

	sgl_to_parent();

	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
        
        sgl_translate(50.0f,23.0f,0.0f); 
        sgl_rotate(sgl_y_axis,PI/2.0f);
        sgl_rotate(sgl_z_axis,PI/2.0f);
        
        sgl_scale(1.0f,2.0f,1.0f);
        
		sgl_simple_plane2(p2,p1,p8,TRUE);       

		/* top and bottom */
        sgl_texture_plane(cpan2Tex,p2,p7,p1,FALSE,1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan2Tex,p8,p14,p9,FALSE,-1.0f,1.0f,FALSE);  
        
        /* other edges - top */                                       
        sgl_texture_plane(cpan1Tex,p1,p7,p15,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p21,p7,p6,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p20,p6,p5,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p19,p5,p4,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p18,p4,p3,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p17,p3,p2,FALSE,1.0f,1.0f,FALSE);  
     
		/* bot */	                           
        sgl_texture_plane(cpan1Tex,p15,p14,p8,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p13,p14,p21,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p12,p13,p20,FALSE,1.0f,1.0f,FALSE); 
        sgl_texture_plane(cpan1Tex,p11,p12,p19,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p10,p11,p18,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p9,p10,p17,FALSE,1.0f,1.0f,FALSE);  

	sgl_to_parent();	   
}  


/*****************************************************************
* Function Name		: addTop  
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: creates top of craft
******************************************************************/

static void addTop()
{

	float p1[3]={-10.0f,0.0f,-7.0f};
	float p2[3]={-10.0f,0.0f,7.0f};
	float p3[3]={-10.0f,4.0f,5.0f};
	float p4[3]={-10.0f,5.0f,3.0f};
	float p5[3]={-10.0f,5.0f,-3.0f};
	float p6[3]={-10.0f,4.0f,-5.0f};
	
	float p7[3]={5.0f,0.0f,-7.0f};
	float p8[3]={5.0f,0.0f,7.0f};
	float p9[3]={5.0f,4.0f,5.0f};
	float p10[3]={5.0f,5.0f,3.0f};
	float p11[3]={5.0f,5.0f,-3.0f};
	float p12[3]={5.0f,4.0f,-5.0f};
    
    float p13[3]={35.0f,0.0f,2.0f};
    float p14[3]={35.0f,0.0f,-2.0f};

    
	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
        
        sgl_translate(-10.0f,7.5f,0.0f);	
		sgl_scale(1.0f,1.0f,2.0f);
        
		sgl_simple_plane2(p2,p1,p7,TRUE);       
        
        sgl_texture_plane(cpan2Tex,p1,p6,p7,FALSE,1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan1Tex,p6,p5,p12,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p5,p4,p11,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p9,p10,p3,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan2Tex,p8,p9,p2,FALSE,1.0f,1.0f,FALSE);  
 
        sgl_texture_plane(cpan1Tex,p2,p3,p1,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan1Tex,p13,p14,p10,FALSE,1.0f,1.0f,FALSE); 
          
        sgl_texture_plane(cpan1Tex,p12,p11,p14,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p7,p12,p14,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p10,p9,p13,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan1Tex,p9,p8,p13,FALSE,1.0f,1.0f,FALSE);  

	sgl_to_parent();

  
	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
        
        sgl_translate(40.0f,0.0f,0.0f);	   
		sgl_scale(-2.0f,1.6f,6.0f);
   
        sgl_texture_plane(cpan2Tex,p1,p6,p7,FALSE,1.0f,1.0f,TRUE);
        sgl_texture_plane(cpan2Tex,p6,p5,p12,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p5,p4,p11,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan2Tex,p9,p10,p3,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan2Tex,p8,p9,p2,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p13,p14,p10,FALSE,1.0f,1.0f,FALSE);      
        sgl_texture_plane(cpan2Tex,p12,p11,p14,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p7,p12,p14,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p10,p9,p13,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p9,p8,p13,FALSE,1.0f,1.0f,FALSE);  
	 	sgl_texture_plane(cpan2Tex,p1,p7,p2,FALSE,1.0f,4.0f,FALSE);   
	  
	    sgl_texture_plane_glow(thrustTex,p2,p3,p1,FALSE,1.0f,4.0f,FALSE);        
	   
	sgl_to_parent();


	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(white);
        
        sgl_translate(40.0f,0.0f,0.0f);
		sgl_scale(-2.0f,-1.6f,6.0f);

        sgl_texture_plane_glow(thrustTex,p2,p3,p1,FALSE,1.0f,4.0f,TRUE);        
	   
	    sgl_texture_plane(cpan2Tex,p1,p6,p7,FALSE,1.0f,1.0f,FALSE);
        sgl_texture_plane(cpan2Tex,p6,p5,p12,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p5,p4,p11,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan2Tex,p9,p10,p3,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(cpan2Tex,p8,p9,p2,FALSE,1.0f,1.0f,FALSE);  
	   	sgl_texture_plane(cpan2Tex,p13,p14,p10,FALSE,1.0f,1.0f,FALSE);   
        sgl_texture_plane(cpan2Tex,p12,p11,p14,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p7,p12,p14,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p10,p9,p13,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(cpan2Tex,p9,p8,p13,FALSE,1.0f,1.0f,FALSE);    
        sgl_texture_plane(cpan2Tex,p1,p7,p2,FALSE,1.0f,4.0f,FALSE);   
	
	sgl_to_parent();
} 


/*****************************************************************
* Function Name		: addCockpit  
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: creates craft cockpit
******************************************************************/

static void addCockpit()
{ 
	float p1[3]={5.0f,8.0f,-15.0f}; 
	float p2[3]={-5.0f,8.0f,-15.0f};
	float p3[3]={-10.0f,8.0f,-10.0f};  
	float p4[3]={-12.5f,8.0f,10.0f};   
	float p5[3]={12.5f,8.0f,10.0f};
	float p6[3]={10.0f,8.0f,-10.0f};	 
	float p7[3]={10.0f,0.0f,-25.0f};   	 
	float p8[3]={-10.0f,0.0f,-25.0f};   
	float p9[3]={-17.5f,0.0f,-12.5f};
	float p10[3]={-22.5f,0.0f,13.5f};   
	float p11[3]={-10.0f,0.0f,24.5f};   
	float p12[3]={10.0f,0.0f,24.5f};   
	float p13[3]={22.5f,0.0f,13.5f};   
	float p14[3]={17.5f,0.0f,-12.5f};
    float cocol[3]={0.1f,0.1f,0.1f};
    

	sgl_create_list(FALSE,TRUE,FALSE);

		sgl_set_diffuse(cocol);
        
        sgl_translate(-24.0f,4.1f,0.0f);   
        sgl_scale(1.2f,0.8f,0.65f);	  
       	sgl_rotate(sgl_y_axis, PI/2.0f);
                               
        /* bot */                         
		sgl_simple_plane2(p10,p9,p14,TRUE);       
        
        /* top */
        sgl_texture_plane(pan1Tex,p4,p5,p6,FALSE,1.0f,1.0f,FALSE);
                                         
		/* back */                                         
        sgl_texture_plane(pan3Tex,p12,p5,p4,FALSE,1.0f,1.0f,FALSE);  
        
        /* windows */
        sgl_texture_plane(pan3Tex,p13,p5,p12,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(pan3Tex,p14,p6,p13,FALSE,1.0f,1.0f,FALSE);        
        sgl_texture_plane(pan3Tex,p7,p1,p14,FALSE,1.0f,1.0f,FALSE);  
       	sgl_texture_plane(pan3Tex,p8,p2,p7,FALSE,1.0f,1.0f,FALSE);         
        sgl_texture_plane(pan3Tex,p9,p2,p8,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(pan3Tex,p4,p3,p9,FALSE,1.0f,1.0f,FALSE);  
        sgl_texture_plane(pan3Tex,p11,p4,p10,FALSE,1.0f,1.0f,FALSE);  
                
	sgl_to_parent();  
}

 
/*****************************************************************
* Function Name		: addNewCraft  
* Inputs			: pos[] - position of new craft
* Outputs			: none
* Returns			: void 
* Description		: creates new named craft at the specified 
*					  position
******************************************************************/

void addNewCraft(float pos[3])
{

  	CraftModel = sgl_create_list(TRUE,TRUE,TRUE);

		sgl_translate(pos[0],pos[1],pos[2]+7.0f);   
		sgl_scale(0.175f,0.175f,0.18f);
		sgl_rotate(sgl_y_axis,PI/2.0f);
		sgl_set_diffuse(white);
	  	sgl_set_specular(SkyBlue,1);  

		addNoseParts(); 
		addCockpit();
		addWins(); 
		addFins();   
		addTop();

	sgl_to_parent();
}


