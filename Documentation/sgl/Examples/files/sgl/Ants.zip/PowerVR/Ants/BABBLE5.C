/*****************************************************************************
Name            :   babble5.c
Title           :   Top
C Author        :   Stel Michael

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Prism file babble5.bpoly as SGL C Commands
 					Number of Meshes = 1
Program Type    :   ANSI
*****************************************************************************/

#include "sgl.h"

/*****************************************************************
* Function Name		: babble5  
* Inputs			: none
* Outputs			: nMesh - pointer to mesh name
*					: nMaterial - pointer to material name
* Returns			: constant 
* Description		: Creates babble5 mesh
******************************************************************/

int babble5(int *nMesh, int *nMaterial)
{
	int v[SGL_MAX_FACE_VERTS];

	static sgl_vector vertex_1[31]={
		{3.135f, -0.0612f, 0.0650001f},          	{3.135f, -0.27081f, -3.358f},
		{-2.7665f, -0.585225f, -4.336f},         	{-1.38951f, 0.0523518f, -1.10058f},
		{-1.38951f, 0.0523518f, -1.10058f},      	{-2.7665f, -0.585225f, -4.336f},
		{-5.449f, -0.585225f, -1.891f},          	{-1.38951f, 0.0523518f, -1.10058f},
		{-5.449f, -0.585225f, -1.891f},          	{-4.9125f, -0.27081f, 2.51f},
		{-1.157f, -0.0612f, 2.51f},              	{3.135f, -0.113603f, 0.0650001f},
		{3.135f, -0.323213f, -3.358f},           	{-2.7665f, -0.637627f, -4.336f},
		{-1.38951f, -5.07159e-05f, -1.10058f},   	{-1.38951f, -5.07159e-05f, -1.10058f},
		{-2.7665f, -0.637627f, -4.336f},         	{-5.449f, -0.637627f, -1.891f},
		{-1.38951f, -5.07159e-05f, -1.10058f},   	{-5.449f, -0.637627f, -1.891f},
		{-4.9125f, -0.323213f, 2.51f},           	{-1.157f, -0.113603f, 2.51f},
		{-1.157f, -0.0612f, 2.51f},              	{-4.9125f, -0.27081f, 2.51f},
		{-4.9125f, -0.323213f, 2.51f},           	{-1.157f, -0.113603f, 2.51f},
		{3.6715f, -1.05685f, 2.999f},            	{3.6715f, -1.05685f, -6.781f},
		{-3.8395f, -1.05685f, -6.781f},          	{-8.1315f, -1.05685f, -2.869f},
		{-8.1315f, -1.05685f, 2.999f}            
	};

	static sgl_2d_vec vertex_uv_1[31]={
		{1.2f, 3.81818f},        	{2.6f, 3.81818f},        	{3.0f, 1.81818f},
		{1.67672f, 2.28484f},    	{1.67672f, 2.28484f},    	{3.0f, 1.81818f},
		{2.0f, 0.909091f},         	{1.67672f, 2.28484f},    	{2.0f, 0.909091f},
		{0.2f, 1.09091f},        	{0.2f, 2.36364f},        	{1.2f, 3.81818f},
		{2.6f, 3.81818f},        	{3.0f, 1.81818f},          	{1.67672f, 2.28484f},
		{1.67672f, 2.28484f},    	{3.0f, 1.81818f},          	{2.0f, 0.909091f},
		{1.67672f, 2.28484f},    	{2.0f, 0.909091f},         	{0.2f, 1.09091f},
		{0.2f, 2.36364f},        	{0.2f, 2.36364f},        	{0.2f, 1.09091f},
		{0.2f, 1.09091f},        	{0.2f, 2.36364f},        	{0.0f, 4.0f},
		{4.0f, 4.0f},               {4.0f, 1.45455f},        	{2.4f, 0.0f},
		{0.0f, 0.0f}                 
	};

	*nMesh=sgl_create_mesh( TRUE );
	sgl_add_vertices(31, vertex_1, FALSE, vertex_uv_1);
	*nMaterial=sgl_create_material(TRUE, TRUE);

	v[0]=0; v[1]=1; v[2]=2; v[3]=3; sgl_add_face(4,v);
	v[0]=4; v[1]=5; v[2]=6; sgl_add_face(3,v);
	v[0]=7; v[1]=8; v[2]=9; v[3]=10; sgl_add_face(4,v);
	v[0]=14; v[1]=13; v[2]=12; v[3]=11; sgl_add_face(4,v);
	v[0]=17; v[1]=16; v[2]=15; sgl_add_face(3,v);	  
	v[0]=21; v[1]=20; v[2]=19; v[3]=18; sgl_add_face(4,v);	
	v[0]=26; v[1]=28; v[2]=29; v[3]=30; sgl_add_face(4,v);
	v[0]=26; v[1]=27; v[2]=28; sgl_add_face(3,v);		
	 
	return 1;
}
