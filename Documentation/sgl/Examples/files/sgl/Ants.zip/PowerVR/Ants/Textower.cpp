/*****************************************************************************
Name            :   textower.cpp 
Title : 			Tower Example
Author :			Stel Michael
Created : 			22/08/1995

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Tower example using SGL
Program Type    :   Microsoft Visual C++ V2
*****************************************************************************/


#define Cplusplus 

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <windowsx.h>
#include "ddraw.h"
#include "math.h"
#include "sgl.h"
#include "joystick.h"
#include "mountain.h"
#include "craftmod.h"
#include "sclist.h" 
#include "actor.h"
#include "player.h" 
#include "autoobj.h" 
#include "obtypes.h" 
#include "textower.h"
#include "missile.h"
#include "ant.h"
#include "effects.h"

#define JOY_X_DAMP	5000.0f
#define JOY_Y_DAMP	5000.0f
#define BOXSIZE	(48.0f)

extern "C" int babble2(int *nMesh, int *nMaterial);

extern "C" int babble3(int *nMesh, int *nMaterial);

extern "C" int babble(int *nMesh, int *nMaterial);

extern "C" int babble5(int *nMesh, int *nMaterial);

extern "C" int thrist(int *nMesh, int *nMaterial);

extern "C" int cfront(int *nMesh, int *nMaterial);

extern "C" int cback(int *nMesh, int *nMaterial);

extern "C" int bwinds(int *nMesh, int *nMaterial);

extern "C" int babble6(int *nMesh, int *nMaterial);

extern "C" int cont(int *nMesh, int *nMaterial);

void AddTowerHigh();
void AddTowerMid();
void AddTowerLow();
void AddGenerator();
void AddGeneratorLow();
void AddHead();

float jx,jy;    
int lp,rp,sp;
int skyoff;
int	JoyNum=0;
int VPort;

extern DWORD dwKeyColour;
extern BOOL bUseOverlay;
extern "C" int fish(int *nMesh, int *nMaterial);

float JoyBufX[6]={0.0f,0.0f,0.0f,0.0f,0.0f,0.0f};
float JoyBufY[6]={0.0f,0.0f,0.0f,0.0f,0.0f,0.0f};

void add_pad(float	pad_pos[3]);
void Hexi(sgl_vector	hexi_pos);

Player GamePlayer;
SceneList MyScene;

ControlledCraft *myCraft;

float xLow,yLow;
float xRange,yRange;

gi_ant *ant_ptr[MAXANTS];

int viewport1,viewport2;
int logicalDevice;
int	groundTex, pan1Tex, pan2Tex, pan3Tex, barbTex,glowyTex,badTex,thrustTex;	
int	cpan1Tex,cpan2Tex,cpan3Tex,fireTex,lballTex,padTex,seaTex,bdingTex,wdowsTex,girlTex,clowTex,crafTex;
int CraftModel;
int	camTran, towTran, lightTran, lightMat, blobTran;

sgl_intermediate_map 	First,Second,Third,Fourth,Fifth,Sixth,Seventh;
sgl_intermediate_map 	Eighth,Ninth,Tenth,Eleventh,Twelth,Thirteen,Fourteen,Fifteen,Eighteen,Twenth;
sgl_intermediate_map 	Sixteen, Sevteen,twen1;

static sgl_vector	Light3Pos = {-40.0f,200.0f,-2040.0f};
static sgl_vector	Light3Dir = {-1.0f,-1.0f,-1.0f};

sgl_vector start_ori = { 0.0f,3.142f,0.0f }; 
sgl_vector ParLightDir = {-2.0f,-1.0f,2.0f};

static sgl_colour 	White	=	{1.0f,1.0f,1.0f};
static sgl_colour 	black 	=	{0.0f,0.0f,0.0f};
static sgl_colour 	Yellow	=	{0.7f,0.7f,0.3f};
static sgl_colour 	SkyBlue	=	{0.5f, 0.6f, 0.9f};  
static sgl_colour	fogWhite=	{0.6f,0.6f,1.0f};
static sgl_colour	Gren	=	{0.2f,1.0f,0.4f};
static sgl_colour	blue	=	{0.2f,0.2f,1.0f};
static sgl_colour	bluey	=	{0.1f,0.1f,0.2f};
static sgl_colour	Red		=	{0.8f,0.8f,0.8f};
static sgl_colour	red		=	{0.8f,0.4f,0.4f};
static sgl_colour	darkgrey=	{0.15f,0.15f,0.15f};
static sgl_colour	grey	=	{0.50f,0.50f,0.50f};
static sgl_colour	mgrey	=	{0.3f,0.3f,0.3f};
static sgl_colour	grey1	=	{0.60f,0.60f,0.60f};
static sgl_colour	grey2	=	{0.40f,0.40f,0.40f};
static sgl_colour	moody 	= 	{1.0f,0.8f,0.5f};

float expPos[3]={0.0f,30.0f,0.0f};   

Effect Explosion(20,expPos); 
Effect Explosion2(20,expPos); 

/* variables for named items */

static	int	camera1,pointLight,skytran;
static	int camera2,camera3,camera4,camera5,camera6,camera8;
static 	int frame;
int light1,light2;
int pointLight2;
int camera7;
int Meshname,Meshmat;

sgl_2d_vec	uv1,uv2,uv3;
	
static	float	camAngle, camOff, Yang, Xang;

static sgl_vector	skyPnt		= {0.0f,1800.0f ,0.0f};
static sgl_vector	skyPnt2		= {0.0f,1800.0f, 10000.0f };	
static sgl_vector	skyPnt3		= {-10000.0f,1800.0f, 0.0f };	
static sgl_vector	lskyPnt		= {0.0f,1000.0f ,0.0f};
static sgl_vector	lskyPnt2	= {0.0f,1000.0f, 100.0f };	
static sgl_vector	lskyPnt3	= {-100.0f,1000.0f, 0.0f };	

sgl_vector	ant_pos	= {0.0f,60.0f,0.0f};
sgl_vector  ant_ori = { 0.0f,1.0f,0.0f }; 
sgl_vector	ant_pos2= {1000.0f,60.0f,0.0f};
sgl_vector  ant_ori2= { 0.0f,3.0f,0.0f }; 

SimpObj	  *cam1=NULL;
SimpObj   *cam2=NULL;
SimpObj	  *cam3=NULL;
SimpObj   *cam4=NULL;

float thepossy[3] = {0.0f,600.0f,0.0f};

float cam_pos[4][3] =	{	
							{-400.0f,700.0f,-400.0f},
							{-787.0f,331.0f,284.0f},
							{100.0f,800.0f,0.0f},
							{1400.0f,1000.0f,500.0f},
						};
int cammy=1;	

static int	TowerHighId,TowerLowId,TowerMidId;
static int  GenLowId, GenHighId;
static int towTranMid;
static int GirlLow,GirlHigh,GirlLower;	

BOOL	Shads,Ress;
BOOL	Paws=FALSE;

AutomatedCraft *CamCraft;

 
/*****************************************************************
* Function Name		: Direct_Camera 
* Inputs			: p[] - point to which the camera is directed 
*			          relative to camera position
* Outputs			: none
* Input/Output		: camera1 - camera object
* Returns			: void 
* Description		: Modifies camera direction
******************************************************************/

void Direct_Camera(float p[3],SimpObj *camera1)
{          
	float x_off,y_off,z_off;           
	float magxz,mag,sin_rat;   
	float y_ang,x_ang;
	float xGoff=0.0f,yGoff=0.0f;
                       
	x_off=camera1->pos[0]-p[0]; 
	y_off=camera1->pos[1]-p[1];
	z_off=camera1->pos[2]-p[2]; 
       
	magxz= (float) sqrt(x_off*x_off+z_off*z_off);                        
	mag= (float) sqrt(x_off*x_off+y_off*y_off+z_off*z_off);            
	sin_rat=x_off/magxz;                                  
	y_ang= (float) asin(fabs(sin_rat));
	     
	if (z_off>0.0f)
		y_ang=PI-y_ang;            
	                  
	if (x_off>0.0f)                  
	    y_ang=-y_ang;	                  
	                  
	sin_rat=y_off/mag;
    x_ang= (float) asin(fabs(sin_rat));    
    
    if (sin_rat<0.0)
    	x_ang=-x_ang;
                
	camera1->ori[0]=x_ang;
	camera1->ori[1]=y_ang;
	camera1->ori[2]=0.0f;
	                    
	sgl_modify_transform(camera1->id,TRUE);	                                                        
    sgl_translate(xGoff+camera1->pos[0],camera1->pos[1],yGoff+camera1->pos[2]);    
    sgl_rotate(sgl_y_axis,camera1->ori[1]);
    sgl_rotate(sgl_x_axis,camera1->ori[0]);
    sgl_rotate(sgl_z_axis,camera1->ori[2]);	 
}                                     


/*****************************************************************
* Function Name		: Follow_Camera 
* Inputs			: p[] - point to which the camera is directed
*				      relative to craft (the global, "CamCraft")
* Outputs			: maggy - magnitude of distance beween object
*					  and camera 
* Input/Output		: camera1 - camera object
* Returns			: void 
* Description		: Directs the camera to the point p[3].  
*					  p[3] is is a point in the craft's local 
*					  coordinate system
******************************************************************/

void Follow_Camera(float p[3],SimpObj *camera1,float &maggy)
{       
	float x_off,y_off,z_off;           
	float magxz,mag,sin_rat;   
	float y_ang,x_ang;
         
	x_off=CamCraft->GetPos()[0]-p[0]; // +xGoff;
	y_off=CamCraft->GetPos()[1]-p[1];
	z_off=CamCraft->GetPos()[2]-p[2]; // +yGoff;
       
	magxz= (float) sqrt(x_off*x_off+z_off*z_off);            
    
	mag= (float) sqrt(x_off*x_off+y_off*y_off+z_off*z_off);            

	sin_rat=x_off/magxz;                 
	                 
	y_ang= (float) asin(fabs(sin_rat));
	     
	if (z_off>0.0f)
		y_ang=PI-y_ang;            
	                  
	if (x_off>0.0f)                  
	    y_ang=-y_ang;	                  
	                  
	sin_rat=y_off/mag;
 
    x_ang= (float) asin(fabs(sin_rat));    
    
    if (sin_rat<0.0)
    	x_ang=-x_ang;
                
	camera1->ori[0]=x_ang;
	camera1->ori[1]=y_ang;
	camera1->ori[2]=0.0f;
	                    
	sgl_modify_transform(camera1->id,TRUE);	                    
    sgl_rotate(sgl_y_axis,camera1->ori[1]);
    sgl_rotate(sgl_x_axis,camera1->ori[0]);
    sgl_rotate(sgl_z_axis,camera1->ori[2]);

	maggy = magxz;
}                                     


void FollowCam(float p[3],float o[3],int col,int collF)
{   
	int t,g,t2,g2;
    cam4 = Create_Object(cam_pos[3],start_ori);

    g=sgl_create_list(TRUE,TRUE,FALSE);  
	if (g>=0) 
	{   
		t = sgl_create_transform(TRUE);  
		
		g2 = sgl_create_list(TRUE,TRUE,FALSE);
			if (g2>=0)
			{
				t2 = sgl_create_transform(TRUE);

					cam4->group=sgl_create_list(TRUE,TRUE,FALSE);   
					if (cam4->group>=0)
					{
						cam4->id = sgl_create_transform(TRUE);	
						camera4 = sgl_create_camera(3.0f,4.0f,0.0f);
						sgl_to_parent();
    				}	
   	   	sgl_to_parent();   
			}                   
    	
		sgl_to_parent();		
			
		CamCraft= new AutomatedCraft(t,g,p,o,12.0f,&GamePlayer,TRUE);                         
    	CamCraft->SetStatus(CHASING);
        
    	MyScene.AddObject(CamCraft);		
	}
}      


/*****************************************************************
* Function Name		: Craft 
* Inputs			: startPos - starting position of craft
*					  startOri - starting origin of craft
* Outputs			: none		 
* Returns			: void 
* Description		: create craft in current display list
******************************************************************/

void Craft(float startPos[3],float startOri[3])
{   
	int groupy,groupy2,tranny,tranny2;

	float no[3]={0.0f,0.0f,0.0f};

    groupy=sgl_create_list(TRUE,TRUE,FALSE);  
	if (groupy>=0) 
	{
		tranny = sgl_create_transform(TRUE);  
		groupy2 = sgl_create_list(TRUE,TRUE,FALSE);

		if (groupy2>=0)
		{
			tranny2 = sgl_create_transform(TRUE);  
			
			sgl_create_transform(FALSE);
			sgl_scale(2.0f,2.0f,2.0f);            

				sgl_create_list(FALSE, TRUE, FALSE);
			   	
					sgl_translate(0.0f,2.0f,-4.0f);
					sgl_scale(14.0f,14.0f,14.0f);
  		
					sgl_set_glow(bluey);
					sgl_set_diffuse(darkgrey);
		
			  		sgl_set_specular(White,0);  

					babble2(&Meshname,&Meshmat);
  										  	
					sgl_set_texture_map(crafTex,FALSE,FALSE); 
					sgl_set_diffuse(White);
			  		sgl_set_specular(black,0);  
					sgl_set_texture_effect(FALSE,TRUE,FALSE,FALSE);

					cfront(&Meshname,&Meshmat);
					cback(&Meshname,&Meshmat);
 
					sgl_set_texture_map(thrustTex,FALSE,FALSE);
					sgl_set_glow(White);
					sgl_set_diffuse(black);
			   		sgl_set_specular(black,0);  
					sgl_set_texture_effect(FALSE,FALSE,FALSE,TRUE);

					thrist(&Meshname,&Meshmat);

				sgl_to_parent();

				sgl_translate(0.0f,4.0f,4.8f); 
			
				camera5 = sgl_create_camera(3.0f,0.1f,0.0f);
				sgl_rotate(sgl_y_axis,PI);
				sgl_scale(-1.0f,1.0f,1.0f);
				sgl_translate(0.2f,1.44f,0.0f);
			
				camera3 = sgl_create_camera(3.0f,0.1f,0.0f);

    	    sgl_to_parent();   
    	}    
  
		sgl_scale(2.0f,2.0f,2.0f);
	 
		sgl_translate(0.0f,6.75f,-25.0f);   
		sgl_translate(0.0f,7.5f,0.0f);   
		sgl_rotate(sgl_x_axis,0.25f);

		camera6 = sgl_create_camera(2.0f,1.0f,0.0f);

		sgl_to_parent();   
			
		myCraft= new ControlledCraft(tranny,groupy,tranny2,groupy2,startPos,startOri,18.0f,TRUE);   

		if (myCraft!=NULL)
		{
			GamePlayer.SetCurrentBody(myCraft);
	                    
			myCraft->SetStatus(CHASING);
			MyScene.AddObject(myCraft);  
		}
	}  
}


/*****************************************************************
* Function Name		: EnemyCraft 
* Inputs			: p[] - position
*				    : o[] - origin
*					  col - if zero camera8 is created
*					  collF - unused 
* Outputs			: none		 
* Returns			: void 
* Description		: create craft in current display list
******************************************************************/

void EnemyCraft(float p[3],float o[3],int col,int collF)
{   
	int t,g,t2,g2;
    
    float possy[3]={0.0f,0.0f,0.0f};
    g=sgl_create_list(TRUE,TRUE,FALSE);
     
	if (g>=0) 
	{   
		t = sgl_create_transform(TRUE);  
		g2 = sgl_create_list(TRUE,TRUE,FALSE);
			if (g2>=0)
			{
				t2 = sgl_create_transform(TRUE);
				sgl_scale(2.0f,2.0f,2.0f);
 
 				sgl_use_instance(CraftModel);

				if (col==0)
				{
					sgl_translate(0.0f,3.2f,12.75f);  
					camera8 = sgl_create_camera(2.0f,1.0f,0.0f);
				}
  		sgl_to_parent();  
    		}                    
    	
		sgl_translate(0.0f,6.75f,-45.0f);   
		sgl_translate(0.0f,10.0f,0.0f);   
		sgl_rotate(sgl_x_axis,0.25f);
		sgl_to_parent();		
			
		AutomatedCraft *SpaceCraft= new AutomatedCraft(t,g,p,o,12.0f,&GamePlayer,FALSE);                         
    
    	SpaceCraft->SetStatus(CHASING);

    	MyScene.AddObject(SpaceCraft);		
	}
}     


/*****************************************************************
* Function Name		: SetupScene
******************************************************************/

void SetupScene(HWND hWnd, WORD wKeyColour)
{	
	sgl_vector	ParLight2Dir = {-1.0f,0.2f,-0.2f};
	sgl_vector	groundPnt	= {0.0f,-10.0f, 0.0f };	
	sgl_vector	point2		= {-10.0f,-10.0f, 0.0f };	
	sgl_vector	point3		= {0.0f,-10.0f, 10.0f };	
	sgl_vector	groundPntX	= {0.0f,-1010.0f, 2000.0f };	
	sgl_vector	point2X		= {-20.0f,-1010.0f, 2000.0f };	
	sgl_vector	point3X		= {0.0f,-1010.0f, 2020.0f };	
	sgl_vector 	start_ori2 = { 0.4f,1.0f,0.8f }; 
	sgl_vector 	start_ori3 = { 0.0f,0.0f,0.0f }; 
	sgl_vector	craftpos	= {50.0f,1600.0f,0.0f};
	sgl_vector	padPos	= {2000.0f,200.0f,-800.0f};
	sgl_vector	HexiPos	= {3000.0f,-20.0f,-8000.0f};
	sgl_vector	craftpos2	= {800.0f,500.0f,0.0f};
	sgl_vector	craftpos3	= {0.0f,1700.0f,-1200.0f};

	float zoomFac=15.0f;
	float possy[3]={0.0f,0.0f,0.0f};

	sgl_vector  TowCorn1 = {-100.0f,0.0f,-100.0f};
	sgl_vector  TowCorn2 = {100.0f,1000.0f,100.0f};

	sgl_vector  GenCorn1 = {-50.0f,0.0f,-50.0f};
	sgl_vector  GenCorn2 = {50.0f,200.0f,50.0f};

	sgl_vector  GirlCorn1 = {-100.0f,-150.0f,-100.0f};
	sgl_vector  GirlCorn2 = {100.0f,150.0f,100.0f};

	int	TowMod[3];
	int	GenMod[3];
	int	GirlMod[3];

	int TowSize[2] = { 50,60 };
	int GenSize[2] = { 30,40 };
	int GirlSize[2] = { 60,80 };
  
	int dnum,xdev,ydev;

	sgl_bool buf;
	sgl_device_colour_types col;

	Shads = TRUE;
	Ress = FALSE;
	skyoff=0;
   	VPort = FALSE;
	JoystickInit();				   

	/* create screen device 0 with 640x480 screen resolution and
	   16 bit colour and double buffering */

	logicalDevice = sgl_create_screen_device (0,640,479,sgl_device_16bit, TRUE);

	if (logicalDevice<0)
	{
		fprintf(stderr,"ERROR %01d: Failed to Open Screen Device\n",logicalDevice);
		DestroyWindow(hWnd);
		exit(1);	
	}
 
	sgl_get_device (logicalDevice, &dnum, &xdev, &ydev, &col ,&buf);
														   
	/* set the viewport for the opened device */
 	viewport1 = sgl_create_viewport( logicalDevice,  0,0,640,480, 80.0f, 0.0f, 560.0f, 480.0f);
 	viewport2 = sgl_create_viewport( logicalDevice,  32,32,260,127, 60.0f, 0.0f, 240.0f, 160.0f);

	/* load up and assign names to textures */
	First = ConvertBMPtoSGL("grass2.bmp", FALSE);
	Second = ConvertBMPtoSGL("badblk2.bmp", TRUE);
	Third = ConvertBMPtoSGL("pan1.bmp", FALSE);
	Fourth = ConvertBMPtoSGL("pan2.bmp", FALSE);
	Fifth = ConvertBMPtoSGL("pan3.bmp", FALSE);
	Sixth = ConvertBMPtoSGL("barbie.bmp", TRUE);
	Seventh = ConvertBMPtoSGL("glowy.bmp", FALSE);
	Eighth = ConvertBMPtoSGL("cpan1.bmp", FALSE);
	Ninth = ConvertBMPtoSGL("cpan2.bmp", FALSE);
	Tenth = ConvertBMPtoSGL("cloud2.bmp", FALSE);
	Twenth = ConvertBMPtoSGL("cloud2.bmp", TRUE);
	Fourteen = ConvertBMPtoSGL("bolt.bmp", FALSE);
	Eleventh = ConvertBMPtoSGL("thrusty.bmp", FALSE);
	Twelth	= ConvertBMPtoSGL("rivets.bmp", FALSE);	
	Thirteen = ConvertBMPtoSGL("rux2.bmp", TRUE);
	Fifteen = ConvertBMPtoSGL("sea2.bmp", FALSE);
	Sixteen = ConvertBMPtoSGL("bding.bmp", FALSE);
	Sevteen = ConvertBMPtoSGL("ows.bmp", FALSE);
	Eighteen = ConvertBMPtoSGL("beauty.bmp", FALSE);
	twen1 = ConvertBMPtoSGL("craf1.bmp", FALSE);

	groundTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_256x256, 		
							sgl_mipmap_generate_2x2, TRUE, &First,  NULL);

	badTex = sgl_create_texture( sgl_map_trans16, sgl_map_128x128, 			
							sgl_mipmap_generate_none, FALSE, &Second, NULL);

	pan1Tex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Third, NULL);

	pan2Tex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
	 						sgl_mipmap_generate_2x2, TRUE, &Fifth, NULL);

	pan3Tex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Fourth, NULL);

	barbTex = sgl_create_texture( sgl_map_trans16_mm, sgl_map_128x128,
		 					sgl_mipmap_generate_2x2, TRUE, &Sixth, NULL);

	glowyTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Seventh, NULL);
  
	cpan1Tex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Eighth, NULL);

	cpan2Tex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Ninth, NULL);
								
	cpan3Tex = sgl_create_texture( sgl_map_16bit, sgl_map_256x256, 		
							sgl_mipmap_generate_2x2, TRUE, &Tenth, NULL);
								 
	crafTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_256x256, 		
							sgl_mipmap_generate_2x2, TRUE, &twen1, NULL);	
							 
	clowTex = sgl_create_texture( sgl_map_trans16_mm, sgl_map_256x256, 		
							sgl_mipmap_generate_2x2, TRUE, &Twenth, NULL);
								 
	thrustTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Eleventh, NULL);

	fireTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Twelth, NULL);

	padTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Fourteen, NULL);

	seaTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_256x256, 		
							sgl_mipmap_generate_2x2, TRUE, &Fifteen, NULL);

 	bdingTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Sixteen, NULL);
	
	wdowsTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							sgl_mipmap_generate_2x2, TRUE, &Sevteen, NULL);

	lballTex = sgl_create_texture( sgl_map_trans16, sgl_map_128x128, 			
							sgl_mipmap_generate_none, FALSE, &Thirteen, NULL);

	girlTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_256x256, 		
					   		sgl_mipmap_generate_2x2, TRUE, &Eighteen, NULL);

	addNewCraft(possy); // Adds the craft's model
	AddTowerLow();
	AddTowerMid();
	AddTowerHigh();
	AddGeneratorLow();
	AddGenerator();
	
	GirlLower=sgl_create_list(TRUE,TRUE,TRUE);

		sgl_scale(1.0f,1.4f,1.0f);
 
		sgl_set_diffuse(darkgrey); 
		sgl_set_specular(black,0); 
		sgl_set_glow(White); 

	 	sgl_set_texture_effect(FALSE,FALSE,FALSE,TRUE);
		sgl_set_texture_map(girlTex,FALSE,FALSE);

		sgl_create_sphere(	1, 60.0f, 2, FALSE,FALSE,TRUE);

	sgl_to_parent();

	GirlLow=sgl_create_list(TRUE,TRUE,TRUE);

		sgl_scale(1.0f,1.4f,1.0f);
  
		sgl_set_diffuse(darkgrey); 
		sgl_set_specular(black,0); 
		sgl_set_glow(White); 

	 	sgl_set_texture_effect(FALSE,FALSE,FALSE,TRUE);
		sgl_set_texture_map(girlTex,FALSE,FALSE);

		sgl_create_sphere(	1, 60.0f, 3, FALSE,FALSE,TRUE);

	sgl_to_parent();

 
	GirlHigh=sgl_create_list(TRUE,TRUE,TRUE);

		sgl_scale(1.0f,1.4f,1.0f);
  
		sgl_set_diffuse(darkgrey); 
		sgl_set_specular(black,0); 
		sgl_set_glow(White); 

	 	sgl_set_texture_effect(FALSE,FALSE,FALSE,TRUE);
		sgl_set_texture_map(girlTex,FALSE,FALSE);

		sgl_set_opacity(0.6f);

		sgl_create_sphere(	1, 60.0f, 5, FALSE,FALSE,TRUE);

	sgl_to_parent();

	/* create lights */

	sgl_create_list(FALSE,TRUE,TRUE);

   		sgl_create_ambient_light (FALSE,darkgrey, FALSE); 

		light1 = sgl_create_parallel_light( TRUE, White, 				
						ParLightDir,FALSE,FALSE);

		pointLight2  = sgl_create_point_light( TRUE, grey, 				
						Light3Dir,Light3Pos,0,FALSE,FALSE);
				
		/* Set up camera */
    	cam1 = Create_Object(cam_pos[0],start_ori);

		cam1->group = sgl_create_list(TRUE,TRUE,FALSE);  
		cam1->id = sgl_create_transform(TRUE);
		camera1 = sgl_create_camera(3.0f,4.0f,0.0f);

	sgl_to_parent();
     
	ant_ptr[0] = Create_Ant(ant_pos, ant_ori, 6000.0f);
		ant_ptr[1] = Create_Ant(ant_pos2, ant_ori2, 8000.0f);

	Hexi(HexiPos);

	sgl_switch_light( light1,TRUE,FALSE,FALSE); 

	/* Add the ground plane */
	sgl_create_list(FALSE, TRUE, FALSE);
   
		sgl_translate(HexiPos[0]-100.0f, -100.0f, HexiPos[2]);
		sgl_scale(2.8f,1.2f,2.8f);
 
		sgl_set_texture_map(groundTex, FALSE, FALSE);
		sgl_set_texture_effect(TRUE,TRUE,FALSE, TRUE);

		GenerateMountain(3, 0.7f, 40.0f);

	sgl_to_parent();
                  	
	sgl_create_list(FALSE, TRUE, FALSE);

		sgl_translate(0.0f, -80.0f, 500.0f);

		sgl_set_texture_map(groundTex, FALSE, FALSE);
		sgl_set_texture_effect(TRUE,TRUE,FALSE, TRUE);

		sgl_scale(10.0f,2.0f,10.0f);

		GenerateMountain(3, 0.7f, 40.0f);

	sgl_to_parent();
  
	sgl_create_list(FALSE, TRUE, FALSE);

		sgl_translate(0.0f,120.0f,0.0f);
		sgl_scale(80.0f,80.0f,80.0f);
 
		sgl_create_list(FALSE, TRUE, FALSE);

			sgl_create_material(FALSE,TRUE);	

			sgl_translate(0.0f,-0.1f,0.0f);	   
			sgl_scale(2.0f,1.2f,2.0f);

			sgl_set_glow(bluey);
			sgl_set_diffuse(darkgrey);
		
		  	sgl_set_specular(White,0);  
   
			bwinds(&Meshname,&Meshmat);

		sgl_to_parent();
	 
		sgl_set_texture_map(pan1Tex,FALSE,FALSE);
		sgl_set_glow(black);
		sgl_set_diffuse(White);
	  	sgl_set_specular(black,0);  
		sgl_set_texture_effect(FALSE,TRUE,FALSE,FALSE);
		sgl_set_cull_mode(sgl_cull_anticlock);
		babble(&Meshname,&Meshmat);
		babble5(&Meshname,&Meshmat);
		babble6(&Meshname,&Meshmat);

	sgl_to_parent();
  
  	sgl_create_list(FALSE,TRUE,FALSE);

		uv1[0]=0.0f;
		uv1[1]=0.0f;

		uv2[0]=(2.43f)/1.6f;
		uv2[1]=0.0f;

		uv3[0]=0.0f;
		uv3[1]=(2.43f)/1.6f;

		sgl_set_glow(grey1); 
		sgl_set_diffuse(black); 
		sgl_set_specular(black, 0); 
		sgl_set_ambient(black);

		sgl_set_texture_effect(FALSE,FALSE,FALSE, TRUE);
   		sgl_set_texture_map(cpan3Tex,FALSE,FALSE);
		sgl_add_plane(skyPnt,skyPnt2,skyPnt3,FALSE,
						NULL,NULL,NULL,uv1,uv2,uv3); 

	sgl_to_parent();
    
 	sgl_create_list(FALSE,TRUE,FALSE);

		uv1[0]=0.0f;
		uv1[1]=0.0f;

		uv2[0]=0.025f;
		uv2[1]=0.0f;

		uv3[0]=0.0f;
		uv3[1]=0.025f;
					  
		sgl_set_glow(White); 
		sgl_set_diffuse(black); 
		sgl_set_specular(black, 0); 
		sgl_set_ambient(black);

		sgl_set_texture_effect(FALSE,FALSE,FALSE, TRUE);
		sgl_set_texture_map(clowTex,FALSE,FALSE);
	
		skytran = sgl_create_transform(TRUE);		

		sgl_add_plane(lskyPnt,lskyPnt2,lskyPnt3,FALSE,
						NULL,NULL,NULL,uv1,uv2,uv3); 	
	
	sgl_to_parent();

	sgl_switch_light( pointLight2,FALSE,FALSE,FALSE); 
  
	sgl_create_list(FALSE,TRUE,FALSE);

		uv1[0]=0.0f;
		uv1[1]=0.0f;
		uv2[0]=0.04f;
		uv2[1]=0.0f;
		uv3[0]=0.0f;
		uv3[1]=0.08f;

		sgl_set_diffuse(grey2); 
		sgl_set_specular(black,0); 
		sgl_set_glow(grey1); 

		sgl_set_texture_effect(FALSE,FALSE,FALSE,TRUE);
		sgl_set_texture_map(seaTex,FALSE,FALSE);
		sgl_add_plane(groundPnt,point2,point3, FALSE, 				
						NULL,NULL,NULL,uv1,uv2,uv3); 
	sgl_to_parent();

	sgl_switch_light( pointLight2,TRUE,FALSE,FALSE); 
   	
   	sgl_create_list(FALSE,TRUE,FALSE);
		
		sgl_translate(-60.0f,100.0f,60.0f);
		sgl_scale(1.6f,1.6f,1.6f);

		TowMod[0]=TowerHighId;
		TowMod[1]=TowerMidId;
		TowMod[2]=TowerLowId;

		sgl_create_detail_levels (FALSE, TowCorn1,TowCorn2,TowMod,TowSize);											  

	sgl_to_parent();
 
	sgl_create_list(FALSE,TRUE,FALSE);
		
		sgl_translate(-1200.0f,0.0f,60.0f);
		
		GenMod[0]=GenHighId;
		GenMod[1]=GenLowId;
		GenMod[2]=GenLowId;

		sgl_create_detail_levels (FALSE, GenCorn1,GenCorn2,GenMod,GenSize);											  

	sgl_to_parent();

 	Craft(craftpos,start_ori);	
 	EnemyCraft(craftpos2,start_ori2,0,0);

	FollowCam(craftpos3,start_ori3,0,1);

	cammy = 3; 	   

	sgl_create_list(FALSE,TRUE,FALSE);

	   	sgl_translate(3500.0f, 180.0f, -6500.0f);

		GirlMod[0]=GirlHigh;
		GirlMod[1]=GirlLow;
		GirlMod[2]=GirlLower;

		sgl_create_detail_levels (FALSE, GirlCorn1,GirlCorn2,GirlMod,GirlSize);											  

	sgl_to_parent();
		
	/* set the fog and background */

	sgl_set_fog(camera6, fogWhite, 0.0005f);
	sgl_set_background_colour(camera6,fogWhite);

	sgl_set_fog(camera5, fogWhite, 0.0005f);
	sgl_set_background_colour(camera5,fogWhite);

	sgl_set_fog(camera2, fogWhite, 0.0005f);
	sgl_set_background_colour(camera2,fogWhite);

	sgl_set_fog(camera1, fogWhite, 0.0005f);
	sgl_set_background_colour(camera1,fogWhite);

	sgl_set_fog(camera3, fogWhite, 0.0005f);
	sgl_set_background_colour(camera3,fogWhite);

	sgl_set_fog(camera4, fogWhite, 0.0005f);
	sgl_set_background_colour(camera4,fogWhite);

	sgl_set_fog(camera7, fogWhite, 0.0005f);
	sgl_set_background_colour(camera7,fogWhite);

	sgl_set_fog(camera8, fogWhite, 0.0005f);
	sgl_set_background_colour(camera8,fogWhite);
 
	Xang = 0.8f;
	Yang = 0.0f;

	camAngle=0.0f;
	camOff=-1900.0f;
  	frame = 0;
}


/*****************************************************************
* Function Name		: doJoy 
* Inputs			: none
* Outputs			: lp - left  button
*					  rp - right button
*					  jx - x-axis position
*					  jy - y-axis position
* Returns			: void 
* Description		: Gets joystick status
******************************************************************/

void doJoy(int &lp,int &rp,float &jx, float &jy)
{
	int JoyX, JoyY;
	WORD wButtons;

	JoystickGetPos(&JoyX, &JoyY, &wButtons);
  
  	xRange=100000.0f;
	yRange=100000.0f;
    xLow=8000.0f;
    yLow=8000.0f;

	if ((JoyX<15000) && (JoyX>-15000))
		JoyX = 0;
	if ((JoyY<15000) && (JoyY>-15000))
		JoyY = 0;
 
	jx = ((float) JoyX) / 50000.0f ; 
 	jy =- ((float) JoyY) / 50000.0f ; 
 
   	lp=(wButtons & JOY_BUTTON1);
   	rp=(wButtons & JOY_BUTTON2);
}  


/*****************************************************************
* Function Name		: NextFrame 
* Inputs			: none
* Outputs			: none
* Returns			: void 			 
* Description		: Generates and renders next frame 
******************************************************************/	
	   
void NextFrame()
{
	sgl_vector	aXis = { 1.0f,1.0f,1.0f };
	float magxz; 
		
	/* Animate Scene */

	if (frame>700) 
	{
		frame=0;
		camAngle=0.0f;
	}

	Light3Pos[1] = 600.0f* (float) fabs( sin( (double) camAngle*8.0))+5.0f;

	camAngle+=0.01f;

	doJoy(lp,rp,jx,jy);   	   

	JoyBufX[JoyNum]=jx;
	JoyBufY[JoyNum]=jy;

	jx = (JoyBufX[0]+JoyBufX[1]+JoyBufX[2]+JoyBufX[3]+JoyBufX[4]+JoyBufX[5])/6.0f;
	jy = (JoyBufY[0]+JoyBufY[1]+JoyBufY[2]+JoyBufY[3]+JoyBufY[4]+JoyBufY[5])/6.0f;

	JoyNum++;

	if (JoyNum==6)
		JoyNum=0;

	if (!Paws)
	{
		skyoff+=4;
		if (skyoff>4000)
			skyoff=0;

		sgl_modify_transform(skytran,TRUE);
		sgl_translate( (float) skyoff*2.0f,0.0f, (float) skyoff);
		sgl_rotate(sgl_y_axis,1.0f);

		MyScene.ProcessScene();
		Process_Missiles(rp,GamePlayer.GetObject());  
 
		if (Explosion.GetStatus()==ALIVE) 
			Explosion.AnimateParticles();
		
		if (Explosion2.GetStatus()==ALIVE) 
			Explosion2.AnimateParticles();
 
		Animate_Ant(ant_ptr[0],GamePlayer.GetObject(), 0);
		Animate_Ant(ant_ptr[1],GamePlayer.GetObject(), 1);

		/* animate the revolving tower top */

  		sgl_modify_transform (towTran, TRUE);	
    	sgl_rotate(sgl_y_axis,-camAngle*4.0f);
		sgl_modify_transform (towTranMid, TRUE);	
    	sgl_rotate(sgl_y_axis,-camAngle*4.0f);
	}

	/* Render image */
 
	if (VPort)
	   	sgl_render(viewport2, camera3, FALSE);

	switch(cammy)
	{
		case 1:
			sgl_render(logicalDevice, camera5, TRUE);
			break;

		case 2:
			sgl_render(logicalDevice, camera6, TRUE);
			break;

		case 3:
			Follow_Camera(GamePlayer.GetObject()->GetPos(),cam4,magxz);
			sgl_set_camera(camera4,3.0f,4.0f,0.0f);
			sgl_render(viewport1, camera4, TRUE);
			break;

		case 4:
			Follow_Camera(GamePlayer.GetObject()->GetPos(),cam4,magxz);
			sgl_set_camera(camera4,(magxz/100.0f),4.0f,0.0f);
			sgl_render(viewport1, camera4, TRUE);
			break;

		case 5:
			sgl_render(viewport1, camera3, TRUE);
			break;

		case 6:
			sgl_render(viewport1, camera7, TRUE);
			break;

		case 7:
			sgl_render(viewport1, camera8, TRUE);
			break;	 
	}

	if (Ress)
 	{
		if (ant_ptr[0]->status==DEAD)
 		{
	 		sgl_delete_list(ant_ptr[0]->id);
			free(ant_ptr[0]);
			sgl_switch_light( light1,TRUE,TRUE,FALSE);

			ant_ptr[0] = Create_Ant(ant_pos, ant_ori, 6000.0f);

			sgl_set_fog(camera7, fogWhite, 0.00075f);

			sgl_set_background_colour(camera7,fogWhite);

			sgl_switch_light( light1,TRUE,FALSE,FALSE); 
	 	}
			
		if (ant_ptr[1]->status==DEAD)
 		{
	 		sgl_delete_list(ant_ptr[1]->id);
			free(ant_ptr[1]);
			sgl_switch_light( light1,TRUE,TRUE,FALSE);

			ant_ptr[1] = Create_Ant(ant_pos2, ant_ori2, 8000.0f);

			sgl_set_fog(camera7, fogWhite, 0.00075f);

			sgl_set_background_colour(camera7,fogWhite);

			sgl_switch_light( light1,TRUE,FALSE,FALSE); 
		}
		Ress = FALSE;
	}
	frame++;
}


/*****************************************************************
* Function Name		: Finish 
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: Close device
******************************************************************/					   
	
void Finish()
{
	sgl_delete_device(logicalDevice);	
}	  


/*****************************************************************
* Function Name		: sgl_cross_prod 
* Inputs			: Vec1 - 1st vector 
*					: Vec2 - 2nd vector
* Outputs			: Vec3 - cross product of Vec1 and Vec2
* Returns			: void 
* Description		: Find cross product of two vectors
******************************************************************/				   

void sgl_cross_prod(const sgl_vector Vec1, const sgl_vector Vec2, sgl_vector Vec3)
{
	Vec3[0] = (Vec1[1] * Vec2[2]) - (Vec1[2] * Vec2[1]);
	Vec3[1] = (Vec1[2] * Vec2[0]) - (Vec1[0] * Vec2[2]);
	Vec3[2] = (Vec1[0] * Vec2[1]) - (Vec1[1] * Vec2[0]);
}

					   
/*****************************************************************
* Function Name		: sgl_vec_sub 
* Inputs			: Vec1 - 1st vector 
*					: Vec2 - 2nd vector
* Outputs			: Result - result of Vec1-Vec2
* Returns			: void 
* Description		: Subtracts two vectors
******************************************************************/	

void sgl_vec_sub(const sgl_vector Vec1, const sgl_vector Vec2, sgl_vector Result)
{
	Result[0] = Vec1[0] - Vec2[0];
	Result[1] = Vec1[1] - Vec2[1];
	Result[2] = Vec1[2] - Vec2[2];
}


/*****************************************************************
* Function Name		: sgl_simple_plane2
* Inputs			: a, b, c - plane vertices
*				 	  visible - plane visibility
* Outputs			: none
* Returns			: void 
* Description		: Adds a simple plane, specified as three 
*					  vertices
******************************************************************/

void sgl_simple_plane2(sgl_vector a,sgl_vector b,sgl_vector c,sgl_bool visible)
{                                       
	sgl_vector ab,ac;
	float norm[3];

	sgl_vec_sub(b,a,ab);  
	sgl_vec_sub(c,a,ac);
	                      
	sgl_cross_prod(ab,ac,norm);
	               
	sgl_add_simple_plane(a,norm,visible);    
} 


/*****************************************************************
* Function Name		: sgl_texture_plane
* Inputs			: texName - name of texture
*					  a, b, c - plane vertices
*					  visible - plane visibility
*				 	  xScale, yScale - texturing scale
*					  FirstPlane - must specify if this is the 
*					  first plane
* Outputs			: none
* Returns			: void 
* Description		: Textures a plane
******************************************************************/

void sgl_texture_plane( int texName, float a[3], float b[3], float c[3], int visible, 
					float xScale, float yScale, sgl_bool FirstPlane)
{                                       
	static int LastTextureName=-1;
	sgl_2d_vec uv1,uv2,uv3;
    sgl_vector ab,ac,vec;
	float veclen,nmag,temmy;
	sgl_vector normal;
	
	sgl_vec_sub(b,a,ab);  
	sgl_vec_sub(c,a,ac);

	veclen= (float) sqrt((double)ac[0]*ac[0]+ac[1]*ac[1]+ac[2]*ac[2]);	

    if (veclen!=0.0f)
	{
		ac[0]/=veclen;
		ac[1]/=veclen;
		ac[2]/=veclen;	
    }
	
	temmy = ab[0]*ac[0]+ab[1]*ac[1]+ab[2]*ac[2];
	
	ab[0]-=	(ac[0]*temmy);
	ab[1]-=	(ac[1]*temmy);
	ab[2]-=	(ac[2]*temmy);
	             
	sgl_cross_prod(ab,ac,normal);

	nmag= (float) sqrt((double)normal[0]*normal[0]+normal[1]*normal[1]+normal[2]*normal[2]);
	
	/* get unit vector */
	
	if (nmag!=0.0f)
	{
		normal[0]/=nmag;
		normal[1]/=nmag;
		normal[2]/=nmag;	
    }

	sgl_cross_prod(ac,normal,vec);
  	
	nmag= (float) sqrt((double)vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);
	
	/* get unit vector */
	
	if (nmag!=0.0f)
	{
		vec[0]/=nmag;
		vec[1]/=nmag;
		vec[2]/=nmag;	
    }
    
    /* multiply by length of ab (should be unit_vec dot ab) */

	veclen=vec[0]*ab[0]+vec[1]*ab[1]+vec[2]*ab[2]; 

    vec[0]*=veclen;
    vec[1]*=veclen;
    vec[2]*=veclen;

	uv1[0]=0.0f;
	uv2[0]=0.0f;
 	uv3[0]=1.0f/xScale;

	uv1[1]=0.0f;
	uv2[1]=(1.0f/yScale);
 	uv3[1]=0.0f;
 
 	/*  create a new local material if a new texture is specified  */ 

	if (((LastTextureName==-1) || (texName!=LastTextureName)) || FirstPlane)
	{
		sgl_create_material(FALSE,TRUE);	
		sgl_set_texture_map(texName,FALSE,FALSE);
		sgl_set_glow(black);
		sgl_set_diffuse(White);
		sgl_set_texture_effect(TRUE,TRUE,TRUE,FALSE);

	}

   	sgl_add_plane(a,b,c,visible,NULL,NULL,NULL,uv1,uv2,uv3); 

	LastTextureName = texName; 							 
} 
					   	   

/*****************************************************************
* Function Name		: sgl_texture_plane_glow
* Inputs			: texName - name of texture
*					  a, b, c - plane vertices
*					  visible - plane visibility
*				 	  xScale, yScale - texturing scale
*					  FirstPlane - must specify if this is the 
*				      first plane
* Outputs			: none
* Returns			: void 
* Description		: Textures a plane that glows
******************************************************************/

void sgl_texture_plane_glow(int texName, float a[3], float b[3], float c[3], int visible, 
					float xScale, float yScale, sgl_bool FirstPlane)
{                                       
	static int LastTextureName=-1;
	sgl_2d_vec uv1,uv2,uv3;
    sgl_vector ab,ac,vec;
	float veclen,nmag,temmy;
	sgl_vector normal;

	sgl_vec_sub(b,a,ab);  
	sgl_vec_sub(c,a,ac);

	veclen= (float) sqrt((double)ac[0]*ac[0]+ac[1]*ac[1]+ac[2]*ac[2]);	

    if (veclen!=0.0f)
	{
		ac[0]/=veclen;
		ac[1]/=veclen;
		ac[2]/=veclen;	
    }
	
	temmy = ab[0]*ac[0]+ab[1]*ac[1]+ab[2]*ac[2];
	
	ab[0]-=	(ac[0]*temmy);
	ab[1]-=	(ac[1]*temmy);
	ab[2]-=	(ac[2]*temmy);
  
	b[0] = a[0] + ab[0];
	b[1] = a[1] + ab[1];
	b[2] = a[2] + ab[2];
             
	sgl_cross_prod(ab,ac,normal);

	nmag= (float) sqrt((double)normal[0]*normal[0]+normal[1]*normal[1]+normal[2]*normal[2]);
	
	/* get unit vector */
	
	if (nmag!=0.0f)
	{
		normal[0]/=nmag;
		normal[1]/=nmag;
		normal[2]/=nmag;	
    }

	sgl_cross_prod(ac,normal,vec);
  	
	nmag= (float) sqrt((double)vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);
	
	/* get unit vector */
	
	if (nmag!=0.0f)
	{
		vec[0]/=nmag;
		vec[1]/=nmag;
		vec[2]/=nmag;	
    }

    /* multiply by length of ab (should be unit_vec dot ab) */

	veclen=vec[0]*ab[0]+vec[1]*ab[1]+vec[2]*ab[2];

    vec[0]*=veclen;
    vec[1]*=veclen;
    vec[2]*=veclen;

	uv1[0]=0.0f;
	uv2[0]=0.0f;
 	uv3[0]=1.0f/xScale;

	uv1[1]=0.0f;
	uv2[1]=1.0f/yScale;
 	uv3[1]=0.0f;
 
 	/* create a new local material if a new texture is specified  */ 

	if (((LastTextureName==-1) || (texName!=LastTextureName)) || FirstPlane)
	{
		sgl_create_material(FALSE,TRUE);	
		sgl_set_texture_map(texName,FALSE,FALSE);
		sgl_set_glow(White);
		sgl_set_diffuse(black);
		sgl_set_specular(black,0);

		sgl_set_texture_effect(FALSE,FALSE,FALSE,TRUE);
	}

   	sgl_add_plane(a,b,c,visible,NULL,NULL,NULL,uv1,uv2,uv3); 

	LastTextureName = texName; 							 
} 
					   	   

/*****************************************************************
* Function Name		: RevolveSection
* Inputs			: Vertices - array of 2d vertices, these must 
*					  form a closed convex polygon
*  				   	  NumVertices - number of vertices
*					  NumSections - number of elements in full object
*					  SectionStep - Number of section steps per iteration
*					  All sections will have a convex primitive, 
*					  otherwise every n sections will have one.
* Outputs			: none
* Returns			: void 
* Description		: Rotates a closed convex polygon about the y axis 
*				      forming a 3d object
******************************************************************/

void RevolveSection(sgl_2d_vec Vertices[],int NumVertices,int NumSections,int SectionStep,int 
textureName)
{
	float AngleStep,CurAngle,SecAngle;
	int	CurVertice;
    int CurSection;
    sgl_vector p1,p2,p3,p4,p5,p6;

	AngleStep=TWOPI/((float) NumSections);
	CurAngle=0.0f;
    
	for(CurSection = 0; CurSection < NumSections; CurSection++)
	{  
		/* CurAngle and SecAngle define the two boundaries of the section */
   		SecAngle = CurAngle+AngleStep;

		/* Step through the vertices, adding bounding planes as we go */

		for (CurVertice=0; CurVertice < (NumVertices - 1); CurVertice++)
		{	

			p1[0] = Vertices[CurVertice][0]* (float) cos(CurAngle);
			p1[1] = Vertices[CurVertice][1];
			p1[2] = Vertices[CurVertice][0]* (float) sin(CurAngle);
		    
			p2[0] = Vertices[CurVertice][0]* (float) cos(SecAngle);
			p2[1] = Vertices[CurVertice][1];
			p2[2] = Vertices[CurVertice][0]* (float) sin(SecAngle);
	    
			p3[0] = Vertices[CurVertice+1][0]* (float) cos(CurAngle);
			p3[1] = Vertices[CurVertice+1][1];
			p3[2] = Vertices[CurVertice+1][0]* (float) sin(CurAngle);
	    
			p4[0] = Vertices[CurVertice+1][0]* (float) cos(SecAngle);
			p4[1] = Vertices[CurVertice+1][1];
			p4[2] = Vertices[CurVertice+1][0]* (float) sin(SecAngle);
					   
			/* add the two bounding planes at first iteration */

	        if (CurVertice==0)
   	    	{   
	        	p5[0] = Vertices[NumVertices-2][0]* (float) cos(CurAngle);
				p5[1] = Vertices[NumVertices-2][1];
				p5[2] = Vertices[NumVertices-2][0]* (float) sin(CurAngle);
	    
				p6[0] = Vertices[NumVertices-2][0]* (float) cos(SecAngle);
				p6[1] = Vertices[NumVertices-2][1];
				p6[2] = Vertices[NumVertices-2][0]* (float) sin(SecAngle);
				
				/* must create a new polyhedron */
				sgl_create_convex(FALSE);

				/* sgl_simple_plane2 define a plane using three points
				   instead of a point and a vector as in sgl_simple_plane */ 

				sgl_texture_plane(textureName,p1,p5,p3,FALSE, 1.0f, 	
											1.0f,TRUE);
				sgl_texture_plane(textureName,p2,p4,p6,FALSE, 1.0f, 	
											1.0f,FALSE);
	        }                                
        
			/* add outline plane */
			sgl_texture_plane(textureName,p1,p3,p2,FALSE,1.0f,1.0f,FALSE);
		}  	 
	CurAngle+=(AngleStep*((float) SectionStep));
    }
}


/*****************************************************************
* Function Name		: Tube 
* Inputs			: Vertices - two 2d vertices 
*  				   	  NumVertices - tube's number of vertices
*					  Hollow - if hollow is true, invisible planes are 
*					  used for top
* Outputs			: none
* Returns			: void 
* Description		: Forms a very simple surface of revolution using two 
*					  given 2d vertices
******************************************************************/

void Tube(sgl_2d_vec Vertices[], int NumVertices, int NumSides, int textureName, sgl_bool 
Hollow)
{
	float AngleStep, SecAngle;
	float CurAngle = 0.0f;
	int	CurSide	= 0;
	sgl_vector Base;
	sgl_vector Top;
	sgl_vector p1, p2, p3, p4;
	sgl_bool First;

	/* AngleStep is the angle of rotation per iteration */
	AngleStep = TWOPI / NumSides;
 	SecAngle = CurAngle + AngleStep;
    First = TRUE;

	/* loop throught the sides of the object */
	
	for (CurSide=0; CurSide<NumSides; CurSide++) 
	{   
		p1[0] = Vertices[0][0]* (float) cos(CurAngle);
		p1[1] = Vertices[0][1];
		p1[2] = Vertices[0][0]* (float) sin(CurAngle);
	     
		p2[0] = Vertices[0][0]* (float) cos(SecAngle);
		p2[1] = Vertices[0][1];
		p2[2] = Vertices[0][0]* (float) sin(SecAngle);

   		p3[0] = Vertices[1][0]* (float) cos(CurAngle);
	   	p3[1] = Vertices[1][1];
		p3[2] = Vertices[1][0]* (float) sin(CurAngle);

		/* for first iteration check to see if we need to add bounding planes
		   at top and bottom */

		if (CurSide == 0)
		{
			p4[0] = Vertices[1][0]* (float) cos(SecAngle);
			p4[1] = Vertices[1][1];
			p4[2] = Vertices[1][0]* (float) sin(SecAngle);
		
			Base[0] = 0.0f;
			Base[1] = Vertices[0][1];	
			Base[2] = 0.0f;       

			Top[0] = 0.0f;
			Top[1] = Vertices[1][1];
			Top[2] = 0.0f;
    
			/* if the x component for either vertex isn't zero, then add
			   a bounding plane */   

			if (Vertices[1][0] != 0.0f)  
			{
				sgl_create_convex(FALSE);
				First = FALSE;
				sgl_texture_plane(textureName,p3,Top,p4,Hollow, 1.0f, 1.0f, TRUE);
			}

			if (Vertices[0][0] != 0.0f)     
			{
				if (First)
				{
					sgl_create_convex(FALSE);
					sgl_texture_plane(textureName,Base,p1,p2,Hollow, 1.0f, 
										1.0f, TRUE);
					First = FALSE;
				}
				else
					sgl_texture_plane(textureName,Base,p1,p2,Hollow, 1.0f, 
										1.0f,FALSE);
			}
		}

   		if (First)
   		{
   			sgl_create_convex(FALSE);
	   		sgl_texture_plane(textureName,p1,p3,p2,FALSE, 1.0f, 1.0f,TRUE);
   			First = FALSE;
   		}
		else
   			sgl_texture_plane(textureName,p1,p3,p2,FALSE, 1.0f, 1.0f,FALSE);
		
		CurAngle = SecAngle;
	 	SecAngle += AngleStep;
	}
}


/*****************************************************************
* Function Name		: AddTower 
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: Constructs model of tower
******************************************************************/

void AddTowerHigh()
{
	/* Data for the tower */

	sgl_2d_vec	VoutlineTop[6] = { {75.0f,0.0f},
					    {72.0f,2.0f},
					    {60.0f,5.0f},
					    {55.0f,5.0f},
					    {50.0f,0.0f},
					    {75.0f,0.0f}};

   	sgl_2d_vec	VoutlineCen[5] = { {73.0f,0.0f},
					    {73.0f,5.0f},
					    {50.0f,5.0f}, 
					    {50.0f,0.0f},
					    {73.0f,0.0f}};  		
					
	sgl_2d_vec	Frame1[5] = { {65.0f, 0.0f},
				  		{50.0f, 10.0f},
				   		{45.0f, 5.0f},
				   		{50.0f, 0.0f},
				  		{65.0f, 0.0f}};

	sgl_2d_vec	Frame2[5] = { {5.0f,25.0f},
	                    {5.0f,20.0f},
	                    {45.0f,5.0f},
	                    {50.0f,10.0f},
	                    {5.0f,25.0f}};
    
   	sgl_2d_vec	Tow1[2] = { {30.0f,0.0f},
    		     	  		{25.0f,50.0f}};
    						
   	sgl_2d_vec 	Tow2[2] = { {25.0f,50.0f},					
    						{15.0f,250.0f}};
    						
   	sgl_2d_vec	Tow3[2] = { {15.0f,250.0f},
                       		{12.5f,300.0f}};  
                            
   	sgl_2d_vec	Tow4[2] = {	{12.5f,300.0f},
							{5.0f,360.0f}};

	/* Add the tower */ 

	TowerHighId=sgl_create_list(TRUE,TRUE,TRUE);

		sgl_set_diffuse(White); 
	  	sgl_set_specular(SkyBlue,1);  

		sgl_scale(1.4f,1.45f,1.4f);

		/* Add main central part of the tower */
		
		/* NOTE: it would be more plane efficient with a routine
				 that took a convex arc of points in this particular 
				 case */
 
       	Tube(Tow1, 2, 10, pan2Tex, FALSE);
       	Tube(Tow2, 2, 10, pan2Tex, FALSE);
   		Tube(Tow3, 2, 10, pan2Tex, FALSE);
    	Tube(Tow4, 2, 10, pan2Tex, FALSE);         
	
		/* translate to rotating part of tower */
		sgl_translate(0.0f,280.0f,0.0f);

		/* a named transform is used to rotate the tower top */	
		towTranMid = sgl_create_transform(TRUE);
	
		sgl_create_list(FALSE,TRUE,FALSE);

			/* Add central dougnut shaped observation area */
			RevolveSection(VoutlineTop,6,12,1,pan1Tex);

 			/* Add the top struts */	  
   	        RevolveSection(Frame2,5,24,3,pan1Tex);

			/* disable shadowing for some parts of the tower to speed up rendering */
  	   		RevolveSection(Frame1,5,24,3,pan1Tex);
 
  		   	sgl_translate(0.0f,-5.0f,0.0f);

		   	sgl_set_glow(Yellow);
		   	sgl_set_diffuse(black);
 
			RevolveSection(VoutlineCen,5,12,1,pan1Tex);
	
			/* a scale with a -1 causes a relection about the axis */
			sgl_scale(1.0f,-1.0f,1.0f);	 
		   	sgl_set_glow(black);
	    	sgl_set_diffuse(White);

			RevolveSection(VoutlineTop,6,12,1,pan1Tex);
    
			 /* Add the bottom strutts */
       		RevolveSection(Frame1,5,24,3,pan1Tex);
	   		RevolveSection(Frame2,5,24,3,pan1Tex);

		sgl_to_parent();
     
    sgl_to_parent();
}


void AddTowerMid()
{ 
	/* Data for the tower */

	sgl_2d_vec	VoutlineTop[6] = { {75.0f,0.0f},
					    {72.0f,2.0f},
					    {60.0f,5.0f},
					    {55.0f,5.0f},
					    {50.0f,0.0f},
					    {75.0f,0.0f}};

   	sgl_2d_vec	VoutlineCen[5] = { {73.0f,0.0f},
					    {73.0f,5.0f},
					    {50.0f,5.0f}, 
					    {50.0f,0.0f},
					    {73.0f,0.0f}};  
								
	sgl_2d_vec	Frame1[5] = { {65.0f, 0.0f},
				  	{50.0f, 10.0f},
				   	{45.0f, 5.0f},
				   	{50.0f, 0.0f},
				  	{65.0f, 0.0f}};

	sgl_2d_vec	Frame2[5] = { {5.0f,25.0f},
	                {5.0f,20.0f},
	                {45.0f,5.0f},
	                {50.0f,10.0f},
	                {5.0f,25.0f}};
    
   	sgl_2d_vec	Tow1[2] = {	{30.0f,0.0f},
    		     	   		{25.0f,50.0f}};
    						
   	sgl_2d_vec 	Tow2[2] = {	{25.0f,50.0f},					
    					    {15.0f,250.0f}};
    						
   	sgl_2d_vec	Tow3[2] = {	{15.0f,250.0f},
                       		{12.5f,300.0f}};  
                            
   	sgl_2d_vec	Tow4[2] = {	{12.5f,300.0f},
							{5.0f,360.0f}};

	/* Add the tower */
	TowerMidId=sgl_create_list(TRUE,TRUE,TRUE);
	   
	  	sgl_set_diffuse(White); 
		
		sgl_set_specular(SkyBlue,1);  

		sgl_scale(1.4f,1.45f,1.4f);

		/* Add main central part of the tower */
		
		/* NOTE: it would be more plane efficient with a routine
				 that took a convex arc of points in this particular 
				 case */
 
      	Tube(Tow1, 2, 6, pan2Tex, FALSE);
       	Tube(Tow2, 2, 6, pan2Tex, FALSE);
   		Tube(Tow3, 2, 6, pan2Tex, FALSE);
    	Tube(Tow4, 2, 6, pan2Tex, FALSE);         
	
		/* translate to rotating part of tower */
		sgl_translate(0.0f,280.0f,0.0f);

		/* a named transform is used to rotate the tower top */	
		towTran = sgl_create_transform(TRUE);
	    
		sgl_create_list(FALSE,TRUE,FALSE);

			/*Add central dougnut shaped observation area */
			RevolveSection(VoutlineTop,6,8,1,pan1Tex);

 			/* Add the top struts */

   	        RevolveSection(Frame2,5,18,3,pan1Tex);

			/* disable shadowing for some parts of the tower to speed up rendering */
  	   		RevolveSection(Frame1,5,18,3,pan1Tex);
 
  		   	sgl_translate(0.0f,-5.0f,0.0f);

		   	sgl_set_glow(Yellow);
		   	sgl_set_diffuse(black);
 
			RevolveSection(VoutlineCen,5,8,1,pan1Tex);
	
			/* a scale with a -1 causes a relection about the axis */
			sgl_scale(1.0f,-1.0f,1.0f);	 
		   	sgl_set_glow(black);
	    	sgl_set_diffuse(White);

			RevolveSection(VoutlineTop,6,8,1,pan1Tex);
    
			/* Add the bottom strutts */
       		RevolveSection(Frame1,5,18,3,pan1Tex);
	   		RevolveSection(Frame2,5,18,3,pan1Tex);

		sgl_to_parent();
		      
    sgl_to_parent();
}


void AddTowerLow()
{
	/* Data for the tower */

	sgl_2d_vec	VoutlineTop[6] = { {75.0f,0.0f},
					    {72.0f,2.0f},
					    {60.0f,5.0f},
					    {55.0f,5.0f},
					    {50.0f,0.0f},
					    {75.0f,0.0f}};

   	sgl_2d_vec	VoutlineCen[5] = { {73.0f,0.0f},
					    {73.0f,5.0f},
					    {50.0f,5.0f}, 
					    {50.0f,0.0f},
					    {73.0f,0.0f}};  
							
	sgl_2d_vec	Frame1[5] = { {65.0f, 0.0f},
				  	{50.0f, 10.0f},
				   	{45.0f, 5.0f},
				   	{50.0f, 0.0f},
				  	{65.0f, 0.0f}};

	sgl_2d_vec	Frame2[5] = { {5.0f,25.0f},
	                      			{5.0f,20.0f},
	                      			{45.0f,5.0f},
	                      			{50.0f,10.0f},
	                      			{5.0f,25.0f}};
    
   	sgl_2d_vec	Tow1[2] = { {30.0f,0.0f},
    		     	   		{25.0f,50.0f}};
    						
   	sgl_2d_vec 	Tow2[2] = {	{25.0f,50.0f},					
    					{15.0f,250.0f}};
    						
   	sgl_2d_vec	Tow3[2] = {	{15.0f,250.0f},
                       				 {12.5f,300.0f}};  
                            
   	sgl_2d_vec	Tow4[2] = { {12.5f,300.0f},
					{5.0f,360.0f}};


	/* Add the tower */

	TowerLowId = sgl_create_list(TRUE,TRUE,TRUE);

		sgl_set_diffuse(White); 
	   	sgl_set_specular(SkyBlue,1);  

		sgl_scale(1.4f,1.45f,1.4f);

		/* Add main central part of the tower */
		
		/* NOTE: it would be more plane efficient with a routine
				 that took a convex arc of points in this particular case */
 
       	Tube(Tow1, 2, 4, pan2Tex, FALSE);
       	Tube(Tow2, 2, 4, pan2Tex, FALSE);
   		Tube(Tow3, 2, 4, pan2Tex, FALSE);
    	Tube(Tow4, 2, 4, pan2Tex, FALSE);         

		/* translate to rotating part of tower */
		sgl_translate(0.0f,280.0f,0.0f);

		/* a named transform is used to rotate the tower top */	
		towTran = sgl_create_transform(TRUE);
  
		sgl_create_list(FALSE,TRUE,FALSE);

			/* Add central dougnut shaped observation area */
			RevolveSection(VoutlineTop,6,6,1,pan1Tex);

 			/* Add the top struts */
   	 		RevolveSection(Frame2,5,18,6,pan1Tex);

  		   	sgl_translate(0.0f,-5.0f,0.0f);

		   	sgl_set_glow(Yellow);
		   	sgl_set_diffuse(black);

			/* a scale with a -1 causes a reflection about the axis */
			sgl_scale(1.0f,-1.0f,1.0f);	 
		   	sgl_set_glow(black);
	    	sgl_set_diffuse(White);

			RevolveSection(VoutlineTop,6,6,1,pan1Tex);
    
			/* Add the bottom strutts */
			RevolveSection(Frame2,5,18,6,pan1Tex);

		sgl_to_parent();
       
    sgl_to_parent();
}


/*****************************************************************
* Function Name		: AddGenerator 
* Inputs			: none
* Outputs			: none
* Returns			: void 
* Description		: Constructs model of generator
******************************************************************/

void AddGenerator()
{

 	sgl_2d_vec Gen1[2] = { {35.0f,0.0f},
    		     	   	{35.0f,35.0f}};

    sgl_2d_vec Gen2[2] = { {30.0f,35.0f},
    		     	   	{30.0f,135.0f}};

   	sgl_2d_vec Gen3[2] = { {35.0f,135.0f},
    		     	   	  {35.0f,170.0f}};

    sgl_2d_vec Fence[2] = { {150.0f,5.0f},
    		     	   	{150.0f,30.0f}};

	sgl_2d_vec Topoutline[6]={ {152.5f,0.0f},
				{152.5f,5.0f},
				{147.5f,5.0f}, 
				{147.5f,0.0f},
				{152.5f,0.0f}};  
	
	GenHighId = sgl_create_list(TRUE,TRUE,TRUE);

		sgl_scale(1.8f,0.9f,0.9f);
		sgl_translate(50.0f,0.0f,0.0f);

		sgl_set_diffuse(White); 
   		sgl_set_specular(SkyBlue,1);  

	   	Tube(Gen1, 2, 6, pan1Tex,FALSE);	
	  
		/* Set global translucency value */ 
   		sgl_set_opacity(0.45f);
		Tube(Gen2, 2, 12, glowyTex, FALSE);
 
		/* Set global translucency back to fully opaque */
  		sgl_set_opacity(1.0f);
		Tube(Gen3, 2, 6, pan1Tex, FALSE);
 
		/* Add translucent textured fence */ 
	   	Tube(Fence, 2, 12, barbTex, TRUE);

   		RevolveSection(Topoutline,5,12,1,pan1Tex);

		sgl_translate(0.0f,30.0f,0.0f);

   		RevolveSection(Topoutline,5,12,1,pan1Tex);
	
	   	sgl_create_list(FALSE,TRUE,FALSE);
	
			sgl_translate(0.0f,190.0f,0.0f);
			sgl_rotate(sgl_x_axis, PI/2.0f);	

			AddHead();	

	    sgl_to_parent();

    sgl_to_parent();
}


void AddGeneratorLow()
{

 	sgl_2d_vec Gen1[2] = { {35.0f,0.0f},
    		     	   	{35.0f,35.0f}};

    sgl_2d_vec Gen2[2] = { {30.0f,35.0f},
    		     	   	{30.0f,135.0f}};

   	sgl_2d_vec Gen3[2] = { {35.0f,135.0f},
    		     	   	  {35.0f,170.0f}};

    sgl_2d_vec Fence[2] = {	{150.0f,5.0f},
    		     	   	{150.0f,30.0f}};

	sgl_2d_vec Topoutline[6]={ {152.5f,0.0f},
				{152.5f,5.0f},
				{147.5f,5.0f}, 
				{147.5f,0.0f},
				{152.5f,0.0f}};  

	GenLowId = sgl_create_list(TRUE,TRUE,TRUE);

		sgl_scale(1.8f,0.9f,0.9f);
		sgl_translate(50.0f,0.0f,0.0f);

		sgl_set_diffuse(White); 
   		sgl_set_specular(SkyBlue,1);  

	   	Tube(Gen1, 2, 6, pan1Tex,FALSE);	

		/* Set global translucency value */ 
 	   	Tube(Gen2, 2, 6, glowyTex, FALSE);
 
		/* Set global translucency back to fully opaque */
 		sgl_set_opacity(1.0f);
	 	Tube(Gen3, 2, 6, pan1Tex, FALSE);

	  	/* Add translucent textured fence */ 
   		RevolveSection(Topoutline,5,6,1,pan1Tex);
	 	sgl_translate(0.0f,30.0f,0.0f);
   		RevolveSection(Topoutline,5,6,1,pan1Tex);
 
	   	sgl_create_list(FALSE,TRUE,FALSE);
	
			sgl_translate(0.0f,190.0f,0.0f);
	   		sgl_rotate(sgl_x_axis, PI/2.0f);	

			AddHead();	

	    sgl_to_parent();

    sgl_to_parent();
}


/*****************************************************************
* Function Name		: AddHead 
* Inputs			: none
* Outputs			: none
* Returns			: void 									  
* Description		: Adds a translucent textured map of a head, 
*					  bounded by invisible planes.
******************************************************************/

void AddHead()
{
	sgl_vector	sidePnt;
	sgl_vector	sideNorm;
	sgl_vector	pnt2;	
	sgl_vector	pnt3;	

	/* build up a cube with 5 simple planes, and one textured plane */

   	sgl_create_convex(FALSE);

	/* Add plane with head texture */
					  
	sgl_create_material(FALSE,TRUE);  

	sgl_set_texture_map(badTex,FALSE,FALSE);

	sideNorm[0]=0.0f;
	sideNorm[1]=-1.0f;
	sideNorm[2]=0.0f;

	sidePnt[0]=-BOXSIZE;
	sidePnt[1]=-1.0f;
   	sidePnt[2]=-BOXSIZE;

	uv1[0]=0.0f;
	uv1[1]=0.0f;

	pnt2[0]=BOXSIZE;
	pnt2[1]=-1.0f;
	pnt2[2]=-BOXSIZE;

	uv2[0]=0.0f;
	uv2[1]=1.0f;

	pnt3[0]=-BOXSIZE;
	pnt3[1]=-1.0f;
	pnt3[2]=BOXSIZE;

	uv3[0]=1.0f;
	uv3[1]=0.0f;

	sgl_add_plane(sidePnt,pnt2,pnt3,FALSE,NULL,NULL,NULL,uv1,uv2,uv3); 

	/* Add bounding invisible planes */

 	sideNorm[0] = 1.0f;
	sideNorm[1] = 0.0f;
	sideNorm[2] = 0.0f;

   	sidePnt[0] = sideNorm[0] * BOXSIZE;
   	sidePnt[1] = sideNorm[1] * 1.0f;
   	sidePnt[2] = sideNorm[2] * BOXSIZE;

	sgl_add_simple_plane(sidePnt, sideNorm, TRUE);

 	sideNorm[0] = 0.0f;
	sideNorm[1] = 0.0f;
	sideNorm[2] = 1.0f;
   	sidePnt[0] = sideNorm[0] * BOXSIZE;
   	sidePnt[1] = sideNorm[1] * 1.0f;
   	sidePnt[2] = sideNorm[2]*BOXSIZE;

	sgl_add_simple_plane(sidePnt, sideNorm, TRUE);	

	sideNorm[0]=-1.0f;
	sideNorm[1]=0.0f;
	sideNorm[2]=0.0f;

   	sidePnt[0]=sideNorm[0]*BOXSIZE;
   	sidePnt[1]=sideNorm[1]*1.0f;
   	sidePnt[2]=sideNorm[2]*BOXSIZE;

	sgl_add_simple_plane(sidePnt, sideNorm, TRUE);	

	sideNorm[0]=0.0f;
	sideNorm[1]=0.0f;
	sideNorm[2]=-1.0f;

   	sidePnt[0]=-BOXSIZE;
   	sidePnt[1]=-1.0f;
   	sidePnt[2]=-BOXSIZE;

	sgl_add_simple_plane(sidePnt, sideNorm, TRUE);	

	sideNorm[0]=0.0f;
	sideNorm[1]=1.0f;
	sideNorm[2]=0.0f;
 
 	sidePnt[0]=sideNorm[0]*BOXSIZE;
   	sidePnt[1]=sideNorm[1]*1.0f;
   	sidePnt[2]=sideNorm[2]*BOXSIZE;

	sgl_add_simple_plane(sidePnt, sideNorm, TRUE);	
}


/*****************************************************************
* Function Name		: add_pad 
* Inputs			: pad_pos[] - position of pad
* Outputs			: none
* Returns			: void 									  
* Description		: Adds a pad at pad_pos[]
******************************************************************/

void add_pad(float pad_pos[3])
{
	float zv=0.0f;	
	float ang_step;
	float cur_ang=0.0f;
	float base[3];
	float top[3];
	float p1[3],p2[3],p3[3],p4[3];
    int   cur_side=0;
    int   cur_vert;
	int num_sides;
	int num_verts;

    float verts[5][2]={	{15.0f,0.0f},
						{10.0f,2.5f},
						{10.0f,150.0f},
						{50.0f,166.0f},
						{50.0f,170.0f}};
   	
	num_verts = 4;
	num_sides = 8;
	
	ang_step = TWOPI/num_sides;
   
	sgl_create_list(FALSE,TRUE,FALSE);
    	sgl_translate(pad_pos[0],pad_pos[1],pad_pos[2]);
    	sgl_scale(400.0f,400.0f,400.0f);
 
    	for (cur_vert=0;cur_vert<num_verts;cur_vert++)
	 	{
			cur_ang=0.0f;
		
			base[0]=0.0f;
			base[1]=verts[cur_vert][1];	
			base[2]=0.0f;

			top[0]=0.0f;
			top[1]=verts[cur_vert+1][1];
	    	top[2]=0.0f;

			p1[0]=verts[cur_vert][0]* (float) cos(cur_ang);
			p1[1]=verts[cur_vert][1];
			p1[2]=verts[cur_vert][0]* (float) sin(cur_ang);
	    
			p2[0]=verts[cur_vert][0]* (float) cos(cur_ang+ang_step);
			p2[1]=verts[cur_vert][1];
			p2[2]=verts[cur_vert][0]* (float) sin(cur_ang+ang_step);
	    
			p3[0]=verts[cur_vert+1][0]* (float) cos(cur_ang);
			p3[1]=verts[cur_vert+1][1];
			p3[2]=verts[cur_vert+1][0]* (float) sin(cur_ang);
	    
			p4[0]=verts[cur_vert+1][0]* (float) cos(cur_ang+ang_step);
			p4[1]=verts[cur_vert+1][1];
			p4[2]=verts[cur_vert+1][0]* (float) sin(cur_ang+ang_step);
        
        	if (cur_vert==1)
				sgl_texture_plane(pan1Tex,p1,p3,p2,TRUE,1.0f,1.0f,FALSE);  	            	
        	else            
		    	sgl_texture_plane(pan3Tex,p1,p3,p2,TRUE,1.0f,1.0f,FALSE);        

	  		sgl_texture_plane(padTex,p3,top,p4,FALSE,3.0f,2.0f,FALSE); // needs testing!!!

			sgl_simple_plane2(base,p1,p2,FALSE);
	
			cur_ang+=ang_step;
		
			for (cur_side=1;cur_side<num_sides;cur_side++) 
			{   
		   	 	p1[0]=verts[cur_vert][0]* (float) cos(cur_ang);
				p1[1]=verts[cur_vert][1];
		    	p1[2]=verts[cur_vert][0]* (float) sin(cur_ang);
	    
		    	p2[0]=verts[cur_vert][0]* (float) cos(cur_ang+ang_step);
				p2[1]=verts[cur_vert][1];
				p2[2]=verts[cur_vert][0]* (float) sin(cur_ang+ang_step);
	    
		    	p3[0]=verts[cur_vert+1][0]* (float) cos(cur_ang);
				p3[1]=verts[cur_vert+1][1];
		   		p3[2]=verts[cur_vert+1][0]* (float) sin(cur_ang);

            	if (cur_vert==1)
             	{
            		if (cur_side==3)
				   		sgl_texture_plane(pan1Tex,p1,p3,p2,FALSE,1.0f,1.0f,FALSE);
	            	else if ((cur_side==1)||(cur_side==4))
				    	sgl_texture_plane(pan2Tex,p1,p3,p2,FALSE,1.0f,1.0f,FALSE);
					else  
						sgl_texture_plane(pan3Tex,p1,p3,p2,FALSE,1.0f,1.0f,FALSE);  	            	
           		 }
            else            
		    	sgl_texture_plane(pan3Tex,p1,p3,p2,FALSE,1.0f,1.0f,FALSE);
	    
			cur_ang+=ang_step;
		}
	}
    sgl_to_parent();
}


/*****************************************************************
* Function Name		: Hexi 
* Inputs			: hexi_pos - position of hexi
* Outputs			: none
* Returns			: void 									  
* Description		: Adds hexagonal building
******************************************************************/

void Hexi(sgl_vector hexi_pos)
{         
    float bu1[2][2] = { {40.0f,0.0f},					
    					{40.0f,35.0f}};
    						
    float bu2[2][2] = { {40.0f,35.0f},
                       {30.0f,40.0f}};
                            
    float bu3[2][2] = { {30.0f,40.0f},
    				 	{0.0f,45.0f}};                        
   
	float blp1[3]={5.0f,0.0f,60.0f};
	float blp2[3]={5.0f,27.5f,60.0f};
	float blp3[3]={5.0f,45.0f,25.0f};
	float blp4[3]={5.0f,45.0f,-25.0f};
	float blp5[3]={5.0f,27.5f,-60.5f};
	float blp6[3]={5.0f,0.0f,-60.0f};
	float blp7[3]={-5.0f,0.0f,60.0f};
	float blp8[3]={-5.0f,27.5f,60.0f};
	float blp9[3]={-5.0f,45.0f,25.0f};
	float blp10[3]={-5.0f,45.0f,-25.0f};
	float blp11[3]={-5.0f,27.5f,-60.0f};
	float blp12[3]={-5.0f,0.0f,-60.0f};

	/* hexi building */

 	sgl_create_list(FALSE,TRUE,FALSE);
 		
 		sgl_translate(hexi_pos[0],hexi_pos[1],hexi_pos[2]);
		sgl_scale(10.0f,10.0f,10.0f);
	   	
	   	sgl_set_diffuse(White);

	  	Tube(bu1,2,8,wdowsTex,FALSE);
	  	Tube(bu2,2,8,bdingTex,FALSE);
	  	Tube(bu3,2,8,pan3Tex,FALSE);

		for (int i=0;i<4;i++)
		{
			sgl_rotate(sgl_y_axis, (PI/4.0f));
            
            blp3[1]+=0.01f;
            blp4[1]+=0.01f;
            blp9[1]+=0.01f;
            blp10[1]+=0.01f;
            
			sgl_create_list(FALSE,TRUE,FALSE);

  				 sgl_simple_plane2(blp6,blp1,blp7,TRUE);

				 sgl_texture_plane(pan3Tex,blp6,blp5,blp1,FALSE,1.0f,1.0f,FALSE);
				 sgl_texture_plane(pan3Tex,blp7,blp8,blp12,FALSE,1.0f,1.0f,FALSE);
				 sgl_texture_plane(wdowsTex,blp1,blp2,blp7,FALSE,3.0f,1.0f,FALSE); 
				 sgl_texture_plane(bdingTex,blp2,blp3,blp8,FALSE,1.0f,1.0f,FALSE);      
				 sgl_texture_plane(pan3Tex,blp3,blp4,blp9,FALSE,1.0f,1.0f,FALSE);
				 sgl_texture_plane(bdingTex,blp11,blp10,blp5,FALSE,1.0f,1.0f,FALSE);  
				 sgl_texture_plane(wdowsTex,blp12,blp11,blp6,FALSE,3.0f,1.0f,FALSE);
			
			sgl_to_parent();
		}	
	sgl_to_parent();
}








