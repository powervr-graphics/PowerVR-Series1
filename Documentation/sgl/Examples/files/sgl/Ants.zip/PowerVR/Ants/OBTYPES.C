/*****************************************************************************
Name            :   obtypes.c 
C Author        :   Stel Michael
Created         :   8 Jul 1993

Copyright       :   1992 by VideoLogic Limited. All rights reserved.
		    No part of this software, either material or conceptual
		    may be copied or distributed, transmitted, transcribed,
		    stored in a retrieval system or translated into any
		    human or computer language in any form by any means,
		    electronic, mechanical, manual or other-wise, or
		    disclosed to third parties without the express written
		    permission of VideoLogic Limited, HomePark Estate,
		    King's Langley, Hertfordshire, WD4 8LZ, U.K.

Description     :   Functions for creating and moving craft for dome game
Program Type    :   Mircrosoft Visual C++ V2
*****************************************************************************/

#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include "obtypes.h"
#include "math.h"


/******************************************************************
* Function Name		: Create_Object  
* Inputs		    : pos - starting position of your craft
*				      ori - starting orientation of your craft		
* Outputs			: none
* Returns			: SimpObj 
* Description		: Creates a craft object   
******************************************************************/

SimpObj *Create_Object(float    pos[3], float ori[3])
{
	SimpObj *c_ptr;
	int i;

	if ( ( c_ptr =  (SimpObj *) malloc(sizeof(SimpObj)) ) !=NULL )
	{
		for(i=0;i<3;i++)
		{
			c_ptr->pos[i]=pos[i];
			c_ptr->ori[i]=ori[i];
		}
		c_ptr->velocity=1.0f;
	}  

	return(c_ptr);
}



