/*-----------------------------------------------------------------------------
   Name   : SEAL ( PowerVR SGL )
   Author : Carlos Sarria    - send comments to csarria@videologic.com
   Date   : March 1997
   Update : July  1997
   Project: seal.c + frontend.c + sgl.lib
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#include <math.h>
#include <ddraw.h>

#include "sgl.h"
#include "frontend.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */
#pragma warning (disable : 4056)

#define NAMED_ITEM   TRUE
#define UNAMED_ITEM	 FALSE

#define PI 3.142f

/*------------------------------- Global Variables -----------------------------------*/

static sgl_colour 	White   = {0.9f,0.9f,0.9f};
static sgl_colour 	Black   = {0.0f,0.0f,0.0f};
static sgl_colour	Blue    = {0.1f,0.4f,0.6f};
static sgl_colour	Grey    = {0.3f,0.3f,0.3f};
static sgl_colour	Fog     = {0.1f,0.3f,0.5f};

int Device, viewport1;

int GroundTex, SkyTex, SeaTex, SealTex;
sgl_intermediate_map BuffTex[4];

int camera, frame;

char pszTmp[100];

int PetMesh, PetList, PetShadow;
int SeaTran, SeaTran1, SkyTran;
sgl_vector PetPath [20];

float PetTime = 0.0f, VelH = 0.3f;
float PetPosY = 10.0f, dY = 0.3f, Radius = 50.0f, TPet = 3.0f;

sgl_vector LightDir = {0.0f, -100.0f,0.0f};

/*----------------------------  Routines Prototypes ---------------------------------*/

void SetupTextures (void),
     SetupAmbient  (void),
     SetupCameras  (void);

void SetupGround    (void),
     SetupSky       (void),
     SetupSea       (void),
     SetupPet       (void),
     MovePet        (void),
     DrawPet        (void);

/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupScene                                                     */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Error message or 0                                             */
/*  Globals Used    :   Device , viewport1                                             */
/*  Description     :   This routine is used to set SGL device and setup some values.  */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
   
    Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, FALSE);
    if (Device<0) return ERR_CREATE_SCREEN_DEVICE;
    
    viewport1 = sgl_create_viewport (Device, 0, 0, 640, 480,100.0f, 0.0f, 580.0f, 480.0f);
    if (viewport1<0) return ERR_CREATE_VIEWPORT;
	
    SetCursor (NULL);   /* This hides the pointer */
	sgl_qual_texture_filter (sgl_tf_bilinear);  /* Sets Bilinear Filtering */

    SetupTextures ();
    SetupCameras  ();
    SetupAmbient  ();

    SetupSky    ();
    SetupSea    ();
    SetupGround ();
	 
    SetupPet ();

    frame = 0;
return 0;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   NextFrame                                                      */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   frame, SeaTran, SeaTran1, SkyTran, viewport1, camera           */
/*  Description     :   Drawing everything and rendering.                              */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void NextFrame()
{
static SeaFrame = 1, SF=1;
int i=0;


    MovePet();
  
    /* SF is just a up-down step for SeaFrame   */
    /* to avoid a huge value for this variable  */
    if (SeaFrame> 640*PI	|| SeaFrame<1) SF = -SF;
	
    /* Moving Sea surface */
    sgl_modify_transform (SeaTran, TRUE);
    sgl_translate (SeaFrame/20.0, 0.0, 0.0);
    sgl_scale     (0.9+sin(SeaFrame/32.0)/20.0,1.0,0.9+sin(SeaFrame/64.0)/20.0);

    /* Moving Sea shadow on the ground */
    sgl_modify_transform (SeaTran1, TRUE);
    sgl_translate (SeaFrame/20.0, 0.0, 0.0);
    sgl_scale     (0.9+sin(SeaFrame/32.0)/20.0,1.0,0.9+sin(SeaFrame/64.0)/20.0);

    /* Moving Sky */
    sgl_modify_transform (SkyTran, TRUE);
    sgl_translate (0.0,0.0,-3.0*SeaFrame);

    sgl_render(viewport1, camera, TRUE);

    frame++;
    SeaFrame+=SF;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   Finish                                                         */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Device                                                         */
/*  Description     :   Free textures and close device.                                */
/*                      This routine is called from FRONTEND.C                         */
/*-------------------------------------------------------------------------------------*/
void Finish()
{
    FreeAllBMPTextures ();
    sgl_delete_device  (Device);	
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupTextures                                                  */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   BuffTex, GroundTex, SeaTex, SkyTex, SealTex                    */
/*  Description     :   Loads all textures.                                            */
/*-------------------------------------------------------------------------------------*/
void SetupTextures (void)
{
    BuffTex[0]   = ConvertBMPtoSGL   ("ground.bmp", FALSE);
    GroundTex    = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, TRUE, TRUE, &BuffTex[0],  NULL);

    BuffTex[1]   = ConvertBMPtoSGL   ("sky.bmp", FALSE);
    SkyTex       = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, TRUE, TRUE, &BuffTex[1],  NULL);

    BuffTex[2]   = ConvertBMPtoSGL   ("sea.bmp", FALSE);
    SeaTex       = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, TRUE, TRUE, &BuffTex[2],  NULL);

    BuffTex[3]   = ConvertBMPtoSGL   ("seal.bmp", FALSE);
    SealTex      = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, TRUE, TRUE, &BuffTex[3],  NULL);
}	  
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupAmbient                                                   */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   Fog, camera                                                    */
/*  Description     :   Setting fog and background colour                              */
/*-------------------------------------------------------------------------------------*/
void SetupAmbient (void)
{
    sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
      sgl_set_fog (camera, Fog, 0.0080f);
      sgl_set_background_colour  (camera, Fog);
    sgl_to_parent();
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupCameras                                                   */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   camera                                                         */
/*  Description     :   Setting the camera.                                            */
/*-------------------------------------------------------------------------------------*/
void SetupCameras (void)
{
    sgl_create_list (UNAMED_ITEM,TRUE,FALSE);
      sgl_translate (0.0, 10.0f, -150.0f);
      camera  = sgl_create_camera (3.0f,10.0f,0.0f); 
    sgl_to_parent();

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupGround                                                    */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   White, LightDir, GroundTex                                     */
/*  Description     :   Draw ground.                                                   */
/*-------------------------------------------------------------------------------------*/
void SetupGround()
{
sgl_2d_vec uv1,  uv2,  uv3;
sgl_vector  groundPnt = {0.0f,-5.0f, 20.0f };	
sgl_vector  point2	  = {10.0f,-5.0f, 20.0f };	
sgl_vector  point3	  = {0.0f,-5.0f, 10.0f };	
sgl_vector  normal	  = {0.0f,  1.0f, 0.0f };	
	
   sgl_create_list(UNAMED_ITEM,TRUE,FALSE);

     sgl_create_parallel_light (NAMED_ITEM, White , LightDir, 0,FALSE);

     uv1[0]=0.07f;
     uv1[1]=0.00f;

     uv2[0]=0.00f;
     uv2[1]=0.45f;

     uv3[0]=0.45f;
     uv3[1]=0.00f;
	   
     sgl_set_texture_map    (GroundTex,TRUE,FALSE);
     sgl_set_ambient        (White);
     sgl_set_diffuse        (White); 
     sgl_set_texture_effect (TRUE, TRUE, TRUE, FALSE);
	 
     sgl_add_plane          (groundPnt,point2,point3, FALSE, 
                             NULL,NULL,NULL,uv1,uv2,uv3); 
    
  sgl_to_parent();
	
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupSky                                                       */
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   White, Black, Blue, SkyTex                                     */
/*  Description     :   Draws sky.                                                     */
/*-------------------------------------------------------------------------------------*/
void SetupSky()
{
sgl_2d_vec uv1,  uv2,  uv3;
sgl_vector  groundPnt = {0.0f,100.0f, 500.0f };	
sgl_vector  point2	  = {-20.0f,100.0f, 500.0f };	
sgl_vector  point3	  = {0.0f,100.0f, 520.0f };	

   uv1[0]=0.02f;
   uv1[1]=0.00f;

   uv2[0]=0.00f;
   uv2[1]=0.055f;

   uv3[0]=0.055f;
   uv3[1]=0.00f;

   sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
   
       sgl_qual_generate_shadows (FALSE);

       SkyTran = sgl_create_transform (NAMED_ITEM); 

       sgl_set_texture_map    (SkyTex,TRUE,TRUE);
       sgl_set_ambient        (White);
       sgl_set_specular       (Black, 0);
       sgl_set_glow           (White);
       sgl_set_diffuse        (Blue); 
       sgl_set_texture_effect (TRUE, TRUE, TRUE, TRUE);
     
       sgl_add_plane          (groundPnt,point2,point3, FALSE, 
                               NULL,NULL,NULL,uv1,uv2,uv3); 
  sgl_to_parent();
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupSea                                                       */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   SGLContex                                                      */
/*  Description     :   Draw the sea and its shadow.                                       */
/*-------------------------------------------------------------------------------------*/
void SetupSea()
{
sgl_2d_vec uv1,  uv2,  uv3;
sgl_vector point1  = {-100.0f, 50.0f, -150.0f };	
sgl_vector point2  = {-500.0f, 50.0f,  500.0f };	
sgl_vector point3  = { 500.0f, 50.0f,  500.0f };	

      uv1[0]=0.0;
      uv1[1]=0.0;

      uv2[0]=0.0;
      uv2[1]=10.0;

      uv3[0]=10.0;
      uv3[1]=10.0;


  sgl_create_list(NAMED_ITEM,TRUE,FALSE);

       sgl_qual_generate_shadows (FALSE);

       SeaTran = sgl_create_transform (NAMED_ITEM); 

       sgl_set_texture_map    (SeaTex,FALSE,FALSE);
       sgl_set_ambient        (White);
       sgl_set_specular       (Black, 0);
       sgl_set_glow           (White);
       sgl_set_opacity        (0.70f);
       sgl_set_texture_effect (FALSE, FALSE, FALSE, TRUE);

       sgl_add_plane          (point1,point2,point3, FALSE, NULL,NULL,NULL,uv1,uv2,uv3); 

   sgl_to_parent();

   point1[1] = point2[1] = point3[1] = -4.99f;

   sgl_create_list(NAMED_ITEM,TRUE,FALSE);

       sgl_qual_generate_shadows (FALSE);

       SeaTran1 = sgl_create_transform (NAMED_ITEM); 

       sgl_set_texture_map    (SeaTex,FALSE,FALSE);
       sgl_set_ambient        (White);
       sgl_set_specular       (Black, 0);
       sgl_set_glow           (White);
       sgl_set_opacity        (0.50);
       sgl_set_texture_effect (FALSE, FALSE, FALSE, TRUE);

       sgl_add_plane          (point1,point2,point3, FALSE, NULL,NULL,NULL,uv1,uv2,uv3); 

 sgl_to_parent();

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   MovePet                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   PetPath, PetPosY, PetTime, Radius, VelH, PetMesh, PetList      */
/*  Description     :   Create the Seal's spine and draw the Seal.                     */
/*-------------------------------------------------------------------------------------*/
void MovePet (void)
{
register i;

    for (i=0; i<11; i++){
        PetPath[10-i][1] = PetPosY + sin((PetTime+i)/3.0)*3.0;
        PetPath[10-i][0] = cos ((PetTime+i)*(TPet/(Radius))) * Radius;
        PetPath[10-i][2] = sin ((PetTime+i)*(TPet/(Radius))) * Radius;
    }
    PetTime += 1.0;
    PetPosY += VelH; if (PetPosY < -3 || PetPosY > 48.0) VelH = -VelH;

    /*  We are modificating the mesh shape, so we have to delete the old    */
    /*  mesh and create another one.                                        */
    /*  Don't forget to delete the list containing the mesh as well.        */
    sgl_delete_mesh (PetMesh);   
    sgl_delete_list (PetList);
    DrawPet ();
 }   
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   DrawPet                                                        */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   PetPath, PetMesh, PetList, PetShadow                           */
/*  Description     :   This routine draws our Seal.                                   */
/*-------------------------------------------------------------------------------------*/
void DrawPet (void)
{
 sgl_vector vt[20*50], vn[20*50], pBody, n;
 sgl_2d_vec vuv[20*50];

 register  i, j, pos;
 int PperC = 10, NumL = 10; 
 int VertIds[5], a, b, c;

 double    CosA, SinA, CosB, SinB, CosC, SenC;
 double    LenXYZ, LenXY, pTemp;


    for(j=0;j<NumL;j++){
        n[0]=PetPath[j][0] - PetPath[j+1][0];
        n[2]=PetPath[j][2] - PetPath[j+1][2];
        n[1]=PetPath[j][1] - PetPath[j+1][1];

		    
        LenXY = sqrt(n[0]*n[0] + n[2]*n[2]);

        if (LenXY > 0.0) {CosA = n[0] / LenXY; SinA = n[2] / LenXY;}
        else             {CosA = 1.0;          SinA = 0.0;         }

        LenXYZ  = sqrt (n[0]*n[0] + n[2]*n[2] + n[1]*n[1]);

        CosB = n[1]  / LenXYZ;           SinB = LenXY / LenXYZ;
        CosC = cos ((2.0*PI)/(PperC-1)); SenC = sin ((2.0*PI)/(PperC-1));

	
        /* This sets a point pBody(0, r, 0) */
       pBody[0] =  pBody[2]= 0.0; pBody[1] =  sin((float)j*(PI/8.0))*3.0 + 0.2; 

       /* This's the tail size */
       if (j==9) {pBody[1] = 3.0;} 

       /* Rotating pBody around n (two consecutive spine points) */
       for (i=0; i<PperC; i++)
       {
            pTemp    =  CosA * pBody[0] + SinA * pBody[2];
            pBody[2] = -SinA * pBody[0] + CosA * pBody[2];
            pBody[0] =  pTemp;

            pTemp    =  CosB * pBody[1] + SinB * pBody[0];
            pBody[0] = -SinB * pBody[1] + CosB * pBody[0];
            pBody[1] =  pTemp;

            pTemp    =  CosC * pBody[0] - SenC * pBody[2];
            pBody[2] =  SenC * pBody[0] + CosC * pBody[2];
            pBody[0] =  pTemp;

            pTemp    =  CosB * pBody[1] - SinB * pBody[0];
            pBody[0] =  SinB * pBody[1] + CosB * pBody[0];
            pBody[1] =  pTemp;

            pTemp    =  CosA * pBody[0] - SinA * pBody[2];
            pBody[2] =  SinA * pBody[0] + CosA * pBody[2];
            pBody[0] =  pTemp;

            pos = i+(j)*PperC;

            /* Seal vertex */
            vt[pos][0] = PetPath[j][0]+pBody[0];
            vt[pos][2] = PetPath[j][2]+pBody[2];
            vt[pos][1] = PetPath[j][1]+pBody[1]+3.0;

            vn[pos][0] = pBody[0];
            vn[pos][1] = pBody[1];
            vn[pos][2] = pBody[2];

            vuv[pos][0] = (float)(i+5.5)/9.0;
            vuv[pos][1] = (float)(j)/9.5;
			
            /* Flatting the tail */
            if (j==9){ vt[pos][1] = PetPath[j][1]+3.0; }
     }
   }

    /* Creating a new mesh */
       PetList = sgl_create_list (NAMED_ITEM, TRUE, FALSE);
       PetMesh = sgl_create_mesh (NAMED_ITEM);
       sgl_create_parallel_light (NAMED_ITEM, White , LightDir, 0,FALSE);
       sgl_add_vertices (11*PperC, &vt[0], &vn[0], &vuv[0]);

       for (j=0;j<NumL;j++)
       {
           for (i=0;i<PperC-1;i++)
           {
             if (j<5){ /* This is to avoid the pointed nose effect */
             VertIds[2] = i+(j)*PperC;      VertIds[3] = i+1+j*PperC; 
             VertIds[0] = i+1+(j+1)*PperC;  VertIds[1] = i+(j+1)*PperC;
             }
             else {
             VertIds[0] = i+(j)*PperC;      VertIds[1] = i+1+j*PperC; 
             VertIds[2] = i+1+(j+1)*PperC;  VertIds[3] = i+(j+1)*PperC;
             }
          sgl_add_face (4, VertIds);
          } 
       }

       sgl_to_parent ();

    /* To modify the shadow shape we are using sgl_modify_mesh because in this case  */
    /* we don't require smooth shading and texturing.                                  */
    /* This way to do it is faster but doesn't conserve texture information.          */
    sgl_modify_mesh (PetShadow, FALSE);
    for (j=0;j<NumL;j++)
    {
        vt[2+j*PperC][1] = vt[7+j*PperC][1] = -4.9f;
        a = 2; b = 7; c = 0; 
        if (vt[2+j*PperC][0]>vt[7+j*PperC][0] || vt[2+j*PperC][0]<vt[7+j*PperC][0])  
           {a=7; b=2;}
        sgl_set_vertex (((j-c)*2+0), vt[a+j*PperC], NULL, NULL);
        sgl_set_vertex (((j-c)*2+1), vt[b+j*PperC], NULL, NULL);
	
    }
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   SetupPet                                                       */ 
/*  Inputs          :   None                                                           */  
/*  Outputs         :   None                                                           */
/*  Returns         :   None                                                           */
/*  Globals Used    :   PetShadow, SealTex                                             */
/*  Description     :   Creates PetShadow mesh and set the texture for the seal.       */
/*-------------------------------------------------------------------------------------*/
void SetupPet (void)
{
register i,j;
int VertIds[4];
sgl_vector Sh[2*10];

   sgl_create_list (FALSE,TRUE,FALSE);

      for(j=0;j<20;j+=2) for(i=0;i<2;i++) {Sh[j+i][0] = j*2.0; Sh[j+i][1] = -20.0; Sh[j+i][2] = i*2.0;}

      sgl_set_ambient        (Grey);
      sgl_set_diffuse        (Grey); 
      sgl_set_texture_effect (TRUE,TRUE,TRUE,TRUE);

      PetShadow = sgl_create_mesh (NAMED_ITEM);

      sgl_add_vertices (2*10, &Sh[0], NULL, NULL);

      for (j=0;j<9;j++){
          VertIds[0] = 1+(j)*2; VertIds[1] = 0+j*2; 
          VertIds[2] = 2+(j)*2; VertIds[3] = 3+(j)*2;
          sgl_add_face (4, VertIds);
      }
  
  sgl_to_parent();

  /* First values for the spine */
  for(i=9;i>=0;i--){
      PetPath[i][1] =  10.0;
	  PetPath[i][0] =  cos (PetTime*(TPet/(Radius))) * Radius;
      PetPath[i][2] =  sin (PetTime*(TPet/(Radius))) * Radius;
	  PetTime++;
      }

  /* We set here the texture for the Seal only once */
  /* we don't have to create it every time we create the seal's mesh  */
  /* because it is the last one and it will be the default texture */
  sgl_set_texture_map    (SealTex,FALSE,FALSE);
  sgl_set_ambient        (White);
  sgl_set_specular       (Black, 0);
  sgl_set_diffuse        (White); 
  sgl_set_texture_effect (TRUE,TRUE,FALSE,FALSE);


  DrawPet();
}

/*------------------------------------------------------------------------*/
/*--------------------------- End of File --------------------------------*/

