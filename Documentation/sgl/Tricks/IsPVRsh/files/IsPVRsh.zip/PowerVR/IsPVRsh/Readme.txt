Copyright : 1998 by VideoLogic Limited. All rights reserved.


	** PowerVR Detection program **


This application (IsPVRsh.exe) performs a PowerVR detection process in your system.

* First, it tests if DirectX is installed and which version is running (the
  program will NOT work with versions earlier than DirectX 3.0). It does it internally
  so no information about DirectX is displayed.

* Second, a SGL test is performed. SGL is the low-level library used with any PowerVR
  boards (PCX1 or PCX2).
  The steps are :
  1. Test if a PowerVR board is physically present with a PCI scan.
  2. Test if SGL.DLL exist and return version information.
  3. Load SGL.DLL and call sgl_get_version() to obtain internal
     version information.

* Third and last, a D3D test is performed.
  The steps are :
  1. Check if a PowerVR board is physically present
  2. Test if PVRHAL32.DLL exist and return version information.
  3. Check if D3D functions are available through PowerVR. This is
     performed by attempting to create a texture surface with PowerVR
     FourCC.

All these informations are then displayed in the main window.


COMMAND LINE OPTIONS :

-NoSGL : Does not perform the SGL test
-NoD3D : Does not perform the D3D test

This can be useful as a diagnose purpose.


New version (20/02/98):
- The program now supports NEC PC-98 systems.


Email any comments and feedback to : nthibieroz@videologic.com



