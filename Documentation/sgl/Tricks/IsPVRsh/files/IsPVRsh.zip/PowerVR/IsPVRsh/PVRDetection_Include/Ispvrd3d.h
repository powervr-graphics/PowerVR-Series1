/*****************************************************************************
  Name : IsPVRD3D.H
  Date : November 1997
  Platform : ANSI compatible

  Header file used to call functions from IsPVRD3D.C
	
  Copyright : 1997 by VideoLogic Limited. All rights reserved.
******************************************************************************/

#ifndef _ISPVRD3D_H_
#define _ISPVRD3D_H_

/*************************
**		  Defines 		**
*************************/
/*	From sgl.h.	*/
#ifndef NEC_VENDOR_ID		/* If not already included */
#define NEC_VENDOR_ID					0x1033  /* PCI Vendor ID */
#define MIDAS3_PCI_BRIDGE_DEVICE_ID		0x001F  /* PCI bridge ID */
#define PCX1_DEVICE_ID					0x002A  /* PCX-1 device ID */
#define PCX2_DEVICE_ID					0x0046  /* PCX-2 device ID */
#endif

/* Added ARC-1 device id */
#ifndef ARC1_DEVICE_ID
#define ARC1_DEVICE_ID					0x0061	/* ARC-1 device ID */
#endif


/*************************
**		 Typedefs		**
*************************/
typedef struct _PowerVRD3DInfo {
	INT		nStatus;							/* Detection Status */

	DWORD	dwChipID;							/* Board chip ID */
	DWORD	dwManufacturer;						/* Manufacturer ID */
	CHAR	szOEM[64];							/* OEM string (Matrox or Generic) */
	
	INT		nHALMajorVersion;					/* Taken from PVRHAL32.DLL version info */
	INT		nHALMinorVersion;					/* Taken from PVRHAL32.DLL version info */
	INT		nHALBugVersion;						/* Taken from PVRHAL32.DLL version info */
	INT		nHALBuildVersion;					/* Taken from PVRHAL32.DLL version info */
	CHAR	szHALResourceVersion[64];			/* Taken from PVRHAL32.DLL version info */

	CHAR	szReserved[64];						/* Reserved for future use */
} PowerVRD3DInfo, *pPowerVRD3DInfo;


/*************************
**		  Enum			**
*************************/
enum
{
	STATUS_D3D_BEGIN=0,				/* Status at the beginning of the detection process */
	STATUS_D3D_BOARD_PRESENT,		/* A PowerVR board has been detected */
	STATUS_D3D_HAL_PRESENT,			/* PVRHAL32.DLL is installed in the system */
	STATUS_D3D_INSTALLED,			/* D3D is actually installed (not tested) */
	STATUS_D3D_HAL_DRIVER,			/* A D3D Hardware driver has been detected */
	STATUS_D3D_AVAILABLE			/* D3D functions through PowerVR are available */
};	

/*************************
** Function declaration **
*************************/

#ifdef __cplusplus		/* C++ compiling ? */
extern "C" {
#endif

int IsPVRD3D(pPowerVRD3DInfo ppiPowerVRD3DInfo);

#ifdef __cplusplus
}
#endif

#endif	_ISPVRD3D_H_	/* End if ISPVRD3D.H */

