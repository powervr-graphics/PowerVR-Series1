/*****************************************************************************
  Name : ISPVRD3D.C	v1.03
  Date : February 1998
  Platform : ANSI compatible

  * DESCRIPTION:
  Set of functions used to detect if a PowerVR board is present and if its D3D 
  functions are available through the HAL.

  * BUILD INFO:
  Some structures declarations and macros have been taken out of PVRD3D.H, so that
  the developper does not need to include this header in his/her project. However,
  you can include PVRD3D.H if you need it : structures and macros will not be
  duplicated.
  Library : ddraw.lib

  * USEFUL COMMENTS:
  The main function is :

  int IsPVRD3D(pPowerVRD3DInfo ppiPowerVRD3DInfo);

  The function will return TRUE if D3D functions are fully available through the
  PowerVR HAL. It will update the pPowerVRD3DInfo structure IF IT HAS BEEN SUBMITTED.
  That is, you can call the function with a NULL parameter.

  New changes : - Added a PC98 detection function.

  Email any comments to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/


/* Special define to use IID_IDirect3D : it must precede everything */
/* Alternatively, link with DXGUID.LIB if you don't want to use this macro */
#define	INITGUID


/*************** Includes *************/
#include <windows.h>
#include <winver.h>		/* For version information functions */
#include <stdio.h>		/* For sprintf */

#include <ddraw.h>
#include <d3d.h>
#include "Ispvrd3d.h"	/* Internal header */


/*************** Defines **************/
#define MAX_MEM_IO_WINDOWS  6
/* From vsgl.h */
#define VSGL_GET_PHYSICAL_BOARD_INFO	27
#define VSGL_GPPORT						0x0058

#define MATROX_M3D_GPPORT_VALUE			0xF6F6


/* From pvrd3d.h */
#ifndef _PVRD3D_
#ifndef BUILDFOURCC
#define BUILDFOURCC(a,b,c,d)	((a) | ((b) << 8) | ((c) << 16) | ((d) << 24))
#define FOURCC_PVR_CTL			BUILDFOURCC ('P', 'V', 'R', 'C')
#endif
#endif	/* if pvrd3d.h */

/* Useful macros */
#ifndef TRUE
  #define TRUE	1
#endif
#ifndef FALSE
  #define FALSE	0
#endif

#ifdef RELEASE
#undef RELEASE(x)
#endif
#define RELEASE(x) if (x) { x->lpVtbl->Release(x); x = NULL; }


/*************** Typedefs *************/
/* Structures needed to retrieve board physical information from vsgl.vxd */
typedef enum
{
	PVR_STATUS_PENDING	= 0x00000000,
	PVR_STATUS_EOR		= 0x00000001
} PVR_STATUS;

typedef enum
{
	DISABLE_BOARD=0,
	MIDAS3,
	MIDAS4,
	MIDAS5,
	MIDAS5_003
} DEVICE_TYPE;

typedef struct BoardDataBlock
{
	DEVICE_TYPE	DeviceType;
	unsigned long 	PCIVendorID;
	unsigned long 	PCIDeviceID;
	unsigned long 	PCIBus;
	unsigned long 	PCIDev;
	unsigned long 	PCIFunc;
	unsigned long 	RevisionID;

	unsigned long 	IRQ;
	unsigned long 	nMemWindows;
	unsigned long 	PhysMemWindows   [MAX_MEM_IO_WINDOWS][2];
	unsigned long 	LinearMemWindows [MAX_MEM_IO_WINDOWS];
	unsigned long 	nIOWindows;
	unsigned long 	IOWindows        [MAX_MEM_IO_WINDOWS][2];

	PVR_STATUS volatile	*pStatus;
	
} BoardDataBlock;


/* From pvrd3d.h */
#ifndef _PVRD3D_	/* if pvrd3d.h is not defined, include structure definition */
typedef struct _PVR_CTL_
{
	DWORD	dwType;
	PVOID	pvReserved;
	union
	{
		DWORD		dwFeatureCTL;			/* if dwType = PVR_FCTL, Specifies feature CTL flags 	  */
		float		fShadowBrightness;		/* if dwType = PVR_SHADOWVOL, Specifies shadow brightness */
		D3DCOLOR	dcLightVolumeColour;	/* if dwType = PVR_LIGHTVOL, Specifies light vol colour   */
	};
	DWORD	dwBGColour;						/* See feature control flags below  */
	DWORD	dwReserved[8];
} PVR_CTL, *PPVR_CTL;
#endif


typedef struct _driverInfo
{
	BOOL bIsHardware;		/* hw or software driver */
	D3DDEVICEDESC Desc;
	char Name[50];
	char About[255];
	GUID Guid;
} driverInfo;


/*************** Global variables **************/
/* Array to store all D3D drivers. We assume no more than 10 drivers will be found !*/
driverInfo			Driver[10];
static int			nNumDrivers=0;		/* Must be global to keep trace of different D3D drivers */


/*************** Prototypes ********************/
static int PCIScan(DWORD nVendor, DWORD nDevice);
static int DetectPC98();
static int IsM3D();
static int GetHALDLLVersion(pPowerVRD3DInfo ppiPowerVRD3DInfo);
static int IsPowerVRD3DDevice(pPowerVRD3DInfo ppiPowerVRD3DInfo);
int IsPVRD3D(pPowerVRD3DInfo ppiPowerVRD3DInfo);


/***************************************
 *************** Functions *************
 **************************************/


/*******************************************************************************
 * Function Name  : PCIScan
 * Inputs         : nVendor, nDevice
 * Outputs        : None
 * Returns        : TRUE or FALSE
 * Global Used    : None
 * Description    : Perform a PCI scan to test if a PowerVR board is physically
 *					present.
 *					We assume there is only one PowerVR board in the machine 
 *					(nIndex = 0 -> detects first PCI board corresponding to the 
 *					device ID and manufacturer ID submitted).
 *					
 *******************************************************************************/
static int PCIScan(DWORD nVendor, DWORD nDevice)
{
	int		nIndex=0;	
	int		nBoardDetection=FALSE;
		
	/* If the system is one of the NEC PC 98 series, use corresponding
	   interrupt number and parameters values */
	if (DetectPC98())
	{
		__asm
		{
			mov		ecx, nDevice;
			mov		edx, nVendor;
			mov		esi, nIndex;
			mov		eax, 0xCC02;
			int		0x1F;
			jc		Board_Continue1;		/* Carry flag set = error in detection (not detected) */
		
			mov		nBoardDetection, TRUE;	/* Carry flag clear = PCI board detected */
			Board_Continue1:	
		}
	}
	else
	{
		__asm
		{
			mov		ecx, nDevice;
			mov		edx, nVendor;
			mov		esi, nIndex;
			mov		eax, 0xB102;
			int		0x1A;
			jc		Board_Continue2;		/* Carry flag set = error in detection (not detected) */
		
			mov		nBoardDetection, TRUE;	/* Carry flag clear = PCI board detected */
			Board_Continue2:	
		}
	}

	return(nBoardDetection);
}


/*******************************************************************************
 * Function Name  : DetectPC98
 * Returns		  : TRUE if the PC is one of the NEC PC98 series
 * Global Used    : None
 * Description    : Checks to see if the system is a PC98.
 *					Use the windows keyboard type function to determine if we
 *					are in a PC98 machine - courtesy NEC
 *					
 *******************************************************************************/
static int DetectPC98()
{
	int		bPC98=FALSE;
	int		nSubType;
	
	/* Check keyboard type */
	if (GetKeyboardType(0)==7)
	{
		/* Japanese keyboard */
		nSubType=GetKeyboardType(1);

		/* Check range since we are having problems detecting
		   new PC-98 keyboard types.  */
		if((nSubType>0x0D00) && (nSubType<0x0d08))
		{ 
			bPC98=TRUE;   /* PC-98 detected */
			OutputDebugString("PC98 detected!\n");
		}
		else
		{
			bPC98=FALSE;   /* PC-AT */
		}
	}

	return (bPC98);
}


/*******************************************************************************
 * Function Name  : IsM3D
 * Returns        : TRUE or FALSE
 * Global Used    : None
 * Description    : Detect if the PowerVR board is a Matrox board (m3D) or a
 *					generic board.
 *					To perform the detection, the VSGL.VXD driver is asked with
 *					a code of operation (VSGL_GET_PHYSICAL_BOARD_INFO) and
 *					relevant information is returned.
 *					Returns TRUE if a Matrox m3D has been detected.
 *					
 *******************************************************************************/
static int IsM3D()
{
	DWORD			*pRegs=NULL;
	DWORD			*pGPPORT;
	HANDLE			hVxD;
	DWORD			PhysBoardID=0;		
	BoardDataBlock	BDB;
	char			pszTmp[300];
	int				nM3DDetected=FALSE;

	/* Load hardware information from the VSGL.VXD device driver */
	hVxD=CreateFile("\\\\.\\VSGL.VXD", 0, 0, NULL, 0, FILE_FLAG_DELETE_ON_CLOSE, NULL);
	if (hVxD==INVALID_HANDLE_VALUE)
	{
		/* vsgl.vxd was not found or not loaded correctly */
		OutputDebugString("Failed to open VxD\n");
		CloseHandle(hVxD);
		hVxD=NULL;
		return FALSE;		
	}

	/* Sends a control code to the VSGL.VXD device driver */
	if (DeviceIoControl (hVxD, VSGL_GET_PHYSICAL_BOARD_INFO, 
						 &PhysBoardID, sizeof (PhysBoardID), 
						 &BDB, sizeof (BDB), NULL, NULL))
	{
		/* pRegs is the linear address of PCX2 registers */
		pRegs=(DWORD *)BDB.LinearMemWindows[0];

		/* Retrieve GPPORT address */
		pGPPORT=(DWORD *)((char *)pRegs+VSGL_GPPORT);

		// Set for input
		*pGPPORT=0x00000000;

		/* Needed if optimization is ON */
		Sleep(10);	

		/* Read GPPORT value
		   For the M3D, Matrox has connected resistors to this port, thus
		   obtaining a value (MATROX_M3D_GPPORT_VALUE) when reading that port */
		if ( (*pGPPORT & 0x0000FFFF)==MATROX_M3D_GPPORT_VALUE )
		{
			/* Matrox M3D detected */
			nM3DDetected=TRUE;
			OutputDebugString("Matrox M3D detected\n");
		}
		
		/* Display info in debug screen */
		sprintf(pszTmp, "GP PORT address=0x%X\nGP PORT value=0x%X\n", pGPPORT, *pGPPORT);
		OutputDebugString(pszTmp);
	}
	else	/* If DeviceIoControl has failed */
	{
		OutputDebugString("Unable to get physical board info\n");
	}
	
	/* Close device driver handle */
	CloseHandle (hVxD);
	hVxD=NULL;

	return (nM3DDetected);
}



/*******************************************************************************
 * Function Name  : GetHALDLLVersion
 * Inputs/Outputs : ppiPowerVRD3DInfo
 * Returns        : TRUE or FALSE
 * Global Used    : None
 * Description    : Test if PVRHAL32.DLL exists
 *					Return TRUE if it does, FALSE otherwise
 *					If ppiPowerVRInfo exists(non NULL), then version information
 *					is returned.
 *					
 *******************************************************************************/
static int GetHALDLLVersion(pPowerVRD3DInfo ppiPowerVRD3DInfo)
{
	LPVOID	lpvVersionInfo;
	DWORD	dwVerInfoSize;
	DWORD	dwHandle;					/* Version Info Handle */
	LPVOID	lpFixedVersionInfo;
	LPVOID	lpFixedVersionInfoLength;
	VS_FIXEDFILEINFO *pFixedInfo;
	HGLOBAL hMem;
	LPSTR   lpstrVffInfo;
	LPSTR   lpVersion;					/* String pointer to 'version' text */
	UINT	*puVersionLen=(UINT *)calloc(1, sizeof(UINT));
	CHAR	pszFileName[70];
	
	/* Copy "PVRHAL32.DLL" in pszFileName string */
	strcpy(pszFileName, "PVRHAL32.DLL");
	
	/* Take structure size */
	dwVerInfoSize = GetFileVersionInfoSize(pszFileName, &dwHandle);
    
	/* If dwVerInfoSize exists, continue, else return FALSE */
	if (!dwVerInfoSize)
    {
		OutputDebugString("GetFileVersionInfoSize() failed in GetSGLDLLVersion()\n");
		return FALSE;
	}

    /* If PowerVRD3DInfo structure is supplied */
	if (ppiPowerVRD3DInfo)	
	{
		/* First extract version numbers */

		/* Allocate memory to receive Version Information structure */
		hMem = GlobalAlloc(GMEM_MOVEABLE, dwVerInfoSize);
		if (hMem==NULL)
		{
			OutputDebugString("Memory could not be allocated\n");
			return FALSE;
		}
			
		/* Lock memory */
		lpvVersionInfo=GlobalLock(hMem);
		if (lpvVersionInfo==NULL)
		{
			OutputDebugString("GlobalLock() failed in GetHALDLLVersion()\n");
			GlobalFree(hMem);
			return FALSE;
		}

		/* Get file version info */
		if (!GetFileVersionInfo(pszFileName, dwHandle, dwVerInfoSize, lpvVersionInfo))
		{
			OutputDebugString("GetFileVersionInfo() failed in GetHALDLLVersion()\n");
			GlobalUnlock(hMem);
			GlobalFree(hMem);
			return FALSE;
		}
			
		/* Load fixed File Information */
		if (!VerQueryValue (lpvVersionInfo,
							TEXT("\\"),
							&lpFixedVersionInfo,
							(PUINT) &lpFixedVersionInfoLength))
		{
			OutputDebugString("VerQueryValue() failed in GetHALDLLVersion()\n");
			GlobalUnlock(hMem);
			GlobalFree(hMem);
			return FALSE;
		}
			
		/* Retrieve information */
		pFixedInfo = (VS_FIXEDFILEINFO *)lpFixedVersionInfo;

		/* Write version numbers in PowerVRInfo SGL structure */
		ppiPowerVRD3DInfo->nHALMajorVersion=HIWORD(pFixedInfo->dwFileVersionMS);
		ppiPowerVRD3DInfo->nHALMinorVersion=LOWORD(pFixedInfo->dwFileVersionMS);
		ppiPowerVRD3DInfo->nHALBugVersion=  HIWORD(pFixedInfo->dwFileVersionLS);
		ppiPowerVRD3DInfo->nHALBuildVersion=LOWORD(pFixedInfo->dwFileVersionLS);
										
		/* Unlock memory */
		GlobalUnlock(hMem);
		/* Free memory */
		GlobalFree (hMem);		
	
		/* Then extract version string */
		
		/* Allocate memory to receive a string */
		hMem = GlobalAlloc(GMEM_MOVEABLE, dwVerInfoSize);
		if (hMem==NULL)
		{
			OutputDebugString("Memory could not be allocated\n");
			return FALSE;
		}

		/* Lock memory */
		lpstrVffInfo = (char *)GlobalLock(hMem);
		if (lpstrVffInfo==NULL)
		{
			OutputDebugString("GlobalLock() failed in GetHALDLLVersion()\n");
			GlobalFree(hMem);
			return FALSE;
		}

		/* Get file version info */
		if (!GetFileVersionInfo(pszFileName, dwHandle, dwVerInfoSize, lpstrVffInfo))
		{
			OutputDebugString("GetFileVersionInfo() failed in GetHALDLLVersion()\n");
			GlobalUnlock(hMem);
			GlobalFree(hMem);
			return FALSE;
		}

		/* File Version */
		if (!VerQueryValue((LPVOID)lpstrVffInfo,
						TEXT("\\StringFileInfo\\040904E4\\FileVersion"),
						(LPVOID *)&lpVersion,puVersionLen))
		{
			OutputDebugString("VerQueryValue() failed in GetHALDLLVersion()\n");
			GlobalUnlock(hMem);
			GlobalFree(hMem);
			return FALSE;
		}
			
		/* Copy version string into PowerVRInfo SGL structure */
		strcpy(ppiPowerVRD3DInfo->szHALResourceVersion, lpVersion);
							
		/* Unlock memory */
		GlobalUnlock (hMem);
		/* Free memory */
		GlobalFree (hMem);		
	}	/* End if ppiPowerVRD3DInfo */
	
	return(TRUE);
}


/*******************************************************************************
 * Function Name  : EnumDeviceDriverCallback
 * Description    : Callback function which enumerates all D3D available drivers
 *					Should only be called by IsPowerVRD3DDevice()
 *					
 *******************************************************************************/
static HRESULT
CALLBACK EnumDeviceDriverCallback (LPGUID lpGuid, LPSTR lpDeviceDescription,
                      LPSTR lpDeviceName, LPD3DDEVICEDESC lpHWDesc,
                      LPD3DDEVICEDESC lpHELDesc, LPVOID lpUserArg)
{
	/* Save this driver's info; we'll figure out which one we 
	   want to use in PickDriver */
    memcpy (&Driver[nNumDrivers].Guid, lpGuid, sizeof(GUID));
    lstrcpy (Driver[nNumDrivers].About, lpDeviceDescription);
    lstrcpy (Driver[nNumDrivers].Name, lpDeviceName);
    
	/* If the color model for a HW (HAL) driver is invalid or 0, then the 
	   driver must be a SW (HEL) driver, so use this as a test to see 
	   which type of driver we just saved */
    if (lpHWDesc->dcmColorModel)
	{
        Driver[nNumDrivers].bIsHardware = TRUE;
        memcpy (&Driver[nNumDrivers].Desc, lpHWDesc, sizeof(D3DDEVICEDESC));
    }
	else
	{
        Driver[nNumDrivers].bIsHardware = FALSE;
        memcpy (&Driver[nNumDrivers].Desc, lpHELDesc, sizeof(D3DDEVICEDESC));
	}

    nNumDrivers++;
    return (D3DENUMRET_OK);
}


/*******************************************************************************
 * Function Name  : IsPowerVRD3DDevice
 * Inputs/Outputs : ppiPowerVRD3DInfo
 * Returns        : TRUE or FALSE
 * Global Used    : nNumDriver
 * Description    : Test if PowerVR HAL functions are available.
 *					ppiPowerVRD3DInfo can be NULL
 *
 *******************************************************************************/
static int IsPowerVRD3DDevice(pPowerVRD3DInfo ppiPowerVRD3DInfo)
{
	LPDIRECTDRAW		lpDD;
	LPDIRECTDRAW2		lpDD2;
	D3DTEXTUREHANDLE 	hTex;
	LPDIRECT3DTEXTURE	lpD3DTexture;
	DDSURFACEDESC 		DDSurfDesc;
	LPDIRECTDRAWSURFACE	lpDDSurface;
	LPDIRECTDRAWSURFACE lpDDSBackBuffer;
	PPVR_CTL			lpPVRCtl;
	HRESULT				hres;
	LPDIRECT3D			lpD3D;
	LPDIRECT3DDEVICE	lpD3DDevice;
	int					CurrentDriver=-1;
	int					i;
	
	/* Creates an instance of a DirectDraw object */
	hres=DirectDrawCreate(NULL, &lpDD, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Error in DirectDrawCreate\n");
		RELEASE(lpDD);
		return FALSE;
	}

	/* Creates an instance of a DirectDraw2 object */
	hres=lpDD->lpVtbl->QueryInterface(lpDD, &IID_IDirectDraw2, (LPVOID *)&lpDD2);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to find a interface to DirectDraw2\n");
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}
	
	/* First call to DirectDraw succeeded : DirectX installed */
	if (ppiPowerVRD3DInfo)	/* If structure has been supplied */
	{
		ppiPowerVRD3DInfo->nStatus=STATUS_D3D_INSTALLED;
	}

	/* Query interface to see if Direct3D II is available */
	hres=lpDD2->lpVtbl->QueryInterface(lpDD2, &IID_IDirect3D, (LPVOID *)&lpD3D);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to detect Direct3D version 2.0\n");
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* Set Cooperative Level */
	hres=lpDD2->lpVtbl->SetCooperativeLevel(lpDD2, GetActiveWindow(), DDSCL_NORMAL);
	if (hres!=DD_OK) 
	{
		OutputDebugString("Error in SetCooperativeLevel\n");
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* Create back buffer surface. We need DDSCAPS_3DDEVICE					   
	   to create a surface that gets attached to a device */
	/* Set surface instance to 0 */
	memset (&DDSurfDesc, 0, sizeof(DDSURFACEDESC));
	DDSurfDesc.dwSize = sizeof(DDSURFACEDESC);
	DDSurfDesc.dwFlags = DDSD_WIDTH | DDSD_HEIGHT | DDSD_CAPS;
	DDSurfDesc.dwWidth = 2;
	DDSurfDesc.dwHeight = 2;
	DDSurfDesc.ddsCaps.dwCaps = DDSCAPS_3DDEVICE | DDSCAPS_OFFSCREENPLAIN;

	/* Create the back buffer surface */
	hres = lpDD2->lpVtbl->CreateSurface (lpDD2, &DDSurfDesc, &lpDDSBackBuffer, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to create surface\n");
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* Enumerate all installed device drivers and pick one
	   based on (in this case) hardware color model */
	hres = lpD3D->lpVtbl->EnumDevices(lpD3D, EnumDeviceDriverCallback, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed in EnumDevices\n");
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}
		
	/* Return the first HW, RGB driver, if any */
	for (i=0; i<nNumDrivers; i++) 
		{
			if (Driver[i].bIsHardware && (Driver[i].Desc.dcmColorModel & D3DCOLOR_RGB))
			{
				CurrentDriver=i;
				break;
			}
		}
	if (CurrentDriver==-1)
	{
		return FALSE;	/* No hardware driver with RGB detected */
	}
	
	/* A D3D Hardware driver has been detected */
	if (ppiPowerVRD3DInfo)		/* If structure has been supplied */
	{
		ppiPowerVRD3DInfo->nStatus=STATUS_D3D_HAL_DRIVER;
	}

	/* Get the Direct3D Device interface from the GUID associated 
	   with the chosen driver. If the interface is not supported 
	   by the device, then lpD3DDevice will be set to NULL and 
	   hres will return as E_NOINTERFACE */
	hres = lpDDSBackBuffer->lpVtbl->QueryInterface (lpDDSBackBuffer, 
										&Driver[CurrentDriver].Guid, (LPVOID *)&lpD3DDevice);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed in getting a device\n");
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}
	
	/* Try creating texturing surface */
	DDSurfDesc.dwSize = sizeof (DDSURFACEDESC);
    DDSurfDesc.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
    DDSurfDesc.dwHeight = 2;
    DDSurfDesc.dwWidth = 2;
    DDSurfDesc.ddsCaps.dwCaps = DDSCAPS_TEXTURE; 
    DDSurfDesc.ddpfPixelFormat.dwSize = sizeof (DDPIXELFORMAT); 
    DDSurfDesc.ddpfPixelFormat.dwFlags = DDPF_FOURCC; 
	DDSurfDesc.ddpfPixelFormat.dwFourCC = FOURCC_PVR_CTL; 

	/* If creation failed, PowerVR isn't present */
	hres=lpDD2->lpVtbl->CreateSurface(lpDD2, &DDSurfDesc, &lpDDSurface, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to create surface\n");
		RELEASE(lpD3DDevice);
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);	
		return FALSE;
	}

	/* Lock it to get pointer to our control structure */
	hres=lpDDSurface->lpVtbl->Lock(lpDDSurface, NULL, &DDSurfDesc, DDLOCK_WAIT, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to lock surface\n");
		RELEASE(lpDDSurface);
		RELEASE(lpD3DDevice);
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);	
		return FALSE;
	}

	/* Get pointer */
	lpPVRCtl = (PPVR_CTL) DDSurfDesc.lpSurface;

	/* Have the pointer unlock surface now */
	hres=lpDDSurface->lpVtbl->Unlock(lpDDSurface, &DDSurfDesc);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to Unlock surface\n");
		RELEASE(lpDDSurface);
		RELEASE(lpD3DDevice);
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}
		
	/* Get texturing interface */
	hres=lpDDSurface->lpVtbl->QueryInterface(lpDDSurface, &IID_IDirect3DTexture, (LPVOID *)&lpD3DTexture);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to get texturing interface\r\n");
		RELEASE(lpDDSurface);
		RELEASE(lpD3DDevice);
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/*	Get a handle for the texture, if PowerVR is the supplied device we'll 
		see a non zero value in lpPVRCtl->pvReserved. */
	hres=lpD3DTexture->lpVtbl->GetHandle(lpD3DTexture, lpD3DDevice, &hTex);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to get texture handle\n");
		RELEASE(lpD3DTexture);
		RELEASE(lpDDSurface);
		RELEASE(lpD3DDevice);
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* If zero then no PowerVR */
	if (!lpPVRCtl->pvReserved)
	{
		OutputDebugString("Reserved word is NULL\n");
		RELEASE(lpD3DTexture);
		RELEASE(lpDDSurface);
		RELEASE(lpD3DDevice);
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return(FALSE);
	}
	
	/* Free everything */
	RELEASE(lpD3DTexture);
	RELEASE(lpDDSurface);
	RELEASE(lpD3DDevice);
	RELEASE(lpDDSBackBuffer);
	RELEASE(lpD3D);
	RELEASE(lpDD2);
	RELEASE(lpDD);
		
	/* Must be Power VR ! */
	return(TRUE);
}



/*******************************************************************************
 * Function Name  : IsPVRD3D
 * Input/Output	  : ppiPowerVRD3DInfo (can be NULL)
 * Returns        : TRUE or FALSE
 * Global Used    : None
 * Description    : Test if D3D functions are available for PowerVR
 *					The steps are :
 *					1. Check if a PowerVR board is physically present
 *					2. Test if PVRHAL32.DLL exist and return version information.
 *					3. Check if D3D functions are available through PowerVR. This is
 *					   performed by attempting to create a texture surface with PowerVR
 *					   FourCC. If success->PowerVR.
 *					nStatus in the pPowerVRInfo structure indicates how far the
 *					detection process went.
 *					
 *******************************************************************************/
int IsPVRD3D(pPowerVRD3DInfo ppiPowerVRD3DInfo)
{
	int Returned_Value=FALSE;

	/***************************************************
	** Detect the (most recent) board with a PCI scan **
	***************************************************/
	if (PCIScan(NEC_VENDOR_ID, ARC1_DEVICE_ID))
	{
		if (ppiPowerVRD3DInfo)
		{
			ppiPowerVRD3DInfo->nStatus=STATUS_D3D_BOARD_PRESENT;
			ppiPowerVRD3DInfo->dwManufacturer=NEC_VENDOR_ID;
			ppiPowerVRD3DInfo->dwChipID=ARC1_DEVICE_ID;
		}
	}
	else
	if (PCIScan(NEC_VENDOR_ID, PCX2_DEVICE_ID))
	{
		if (ppiPowerVRD3DInfo)
		{
			ppiPowerVRD3DInfo->nStatus=STATUS_D3D_BOARD_PRESENT;
			ppiPowerVRD3DInfo->dwManufacturer=NEC_VENDOR_ID;
			ppiPowerVRD3DInfo->dwChipID=PCX2_DEVICE_ID;
		}
	}
	else
	if (PCIScan(NEC_VENDOR_ID, PCX1_DEVICE_ID))
	{
		if (ppiPowerVRD3DInfo)
		{
			ppiPowerVRD3DInfo->nStatus=STATUS_D3D_BOARD_PRESENT;
			ppiPowerVRD3DInfo->dwManufacturer=NEC_VENDOR_ID;
			ppiPowerVRD3DInfo->dwChipID=PCX1_DEVICE_ID;
		}
	}
	else
	if (PCIScan(NEC_VENDOR_ID, MIDAS3_PCI_BRIDGE_DEVICE_ID))
	{
		if (ppiPowerVRD3DInfo)
		{
			ppiPowerVRD3DInfo->nStatus=STATUS_D3D_BOARD_PRESENT;
			ppiPowerVRD3DInfo->dwManufacturer=NEC_VENDOR_ID;
			ppiPowerVRD3DInfo->dwChipID=MIDAS3_PCI_BRIDGE_DEVICE_ID;
		}
	}
	else
	{
		return(FALSE);
	}

	/*************************************************************************
	** If a PCX2 is detected, then perform OEM detection (Matrox or Generic) *
	*************************************************************************/	
	/* Since we already know that a PowerVR board exists in the system, we
	   only run this test if the user has supplied a pPowerVRD3DInfo structure */
	if (ppiPowerVRD3DInfo )
	{
		if (ppiPowerVRD3DInfo->dwChipID==PCX2_DEVICE_ID && IsM3D())
		{
			strcpy(ppiPowerVRD3DInfo->szOEM, "Matrox");
		}
		else
		{
			strcpy(ppiPowerVRD3DInfo->szOEM, "Generic");
		}
	}


	/*****************************************************************************
	** Detect the file existance and get the version resource from PVRHAL32.DLL **
	*****************************************************************************/	
	if (!GetHALDLLVersion(ppiPowerVRD3DInfo))
	{
		return (FALSE);
	}
	
	/* If user supplied a pPowerVRD3DInfo structure */
	if (ppiPowerVRD3DInfo) 
	{
		ppiPowerVRD3DInfo->nStatus=STATUS_D3D_HAL_PRESENT;
	}


	/*******************************************************************
	**     Detect if D3D functions are available through PowerVR	  **
	*******************************************************************/
	if (!IsPowerVRD3DDevice(ppiPowerVRD3DInfo))
	{
		return (FALSE);
	}
	
	/* If user supplied a pPowerVRD3DInfo structure */
	if (ppiPowerVRD3DInfo)
	{
		ppiPowerVRD3DInfo->nStatus=STATUS_D3D_AVAILABLE;
	}

	return(TRUE);	/* All tests have been successfully passed */
}
