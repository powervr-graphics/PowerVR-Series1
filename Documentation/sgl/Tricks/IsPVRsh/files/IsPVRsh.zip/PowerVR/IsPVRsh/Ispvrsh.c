/*****************************************************************************
  Name : ISPVRSH.C v1.02
  Date : January 1998
  Platform : ANSI compatible

  * DESCRIPTION:
  Shell program used to test Ispvr() and Ispvrd3d() functions from Ispvr.c and
  Ispvrd3d.c.

  * BUILD INFO:
  Make a project including Ispvr.c, Ispvrd3d.c along with this file (Ispvrsh.c).
  Libraries : version.lib, ddraw.lib
  Resource : IsPVRsh.rc, SPowerVR.bmp
  
  * USEFUL COMMENTS:
  The main window is in fact a dialog box. It just calls the two functions Ispvr()
  and Ispvrd3d() at initialisation time (WM_INITDIALOG), and updates the controls
  in the dialog box to display PowerVR SGL and D3D informations.


  Email any comments to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/


/************* Includes ***********/
#include <windows.h>
#include <windowsx.h>	/* For GET_WM_COMMAND_ID macro */
#include <stdio.h>		/* For sprintf */
#include <ddraw.h>		/* For GetDXVersion() */
#include <dinput.h>		/* For GetDXVersion() */

#include "Ispvr.h"		/* For SGL functions */
#include "Ispvrd3d.h"	/* For D3D functions */
#include "resource.h"	/* Resource header file */


/************* Defines ************/
#ifdef NEW
#undef NEW(x)
#endif
#define NEW(x)	(x *)calloc(1, sizeof(x))

/************* Typedefs ***********/
/* For GetDXVersion() */
typedef HRESULT (WINAPI *DIRECTDRAWCREATE)(GUID *, LPDIRECTDRAW *, IUnknown *);
typedef HRESULT (WINAPI *DIRECTINPUTCREATE)(HINSTANCE, DWORD, LPDIRECTINPUT *, IUnknown *);


/************* Globals ************/
static MSG			msg;
static HWND			hwnd;
static WNDCLASS		wndclass;
static HINSTANCE	HInst;					/* Windows management variables */

static int			SGLOK=FALSE;
static int			D3DOK=FALSE;			/* Flags used to indicate full availability of SGL or D3D */
static BOOL			bTestSGL=TRUE;
static BOOL			bTestD3D=TRUE;			/* Will SGL or D3D tests be performed ? */

static pPowerVRInfo pMyPowerVRInfo=NULL;		/* SGL functions */
static pPowerVRD3DInfo pMyPowerVRD3DInfo=NULL;	/* D3D functions */


/************* Prototypes ************/
static void	RunPowerVRTest();
static void DisplayPowerVRInfo(HWND hwnd, pPowerVRInfo ppiPowerVRInfo, pPowerVRD3DInfo ppiPowerVRD3DInfo);
static void Finish();
static LRESULT CALLBACK WindowProc( HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam );
int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow);
static void GetDXVersion (LPDWORD pdwDXVersion, LPDWORD pdwDXPlatform);

									
/***********************************
************** Functions ***********
***********************************/


/*******************************************************************************
 * Function Name  : RunPowerVRTest
 * Global Used    : pMyPowerVRInfo, pMyPowerVRD3DInfo, SGLOK, D3DOK
 * Description    : Test function which runs IsPVR() and IsPVRD3D() functions
 *					
 *******************************************************************************/
static void RunPowerVRTest()
{
	char	pszTmp[300];
	DWORD	dwDXVersion;
	DWORD	dwOS;
		
	/* Retrieve DirectX version */
	GetDXVersion(&dwDXVersion, &dwOS);

	/* Check platform */
	if (dwOS!=VER_PLATFORM_WIN32_WINDOWS)
	{
		MessageBox(hwnd, "Windows 9x needed to run this program", "PowerVR Detection", MB_OK | MB_ICONERROR);
		/* Free memory */
		if (pMyPowerVRInfo) free(pMyPowerVRInfo);
		if (pMyPowerVRD3DInfo) free(pMyPowerVRD3DInfo);
		/* Exit immediately */
		exit(0);
	}
	
	/* Check DirectX version */
	if (dwDXVersion<0x0200)
	{
		MessageBox(hwnd, "DirectX 2.0 at least is needed to run this program", "PowerVR Detection", MB_OK | MB_ICONERROR);
		/* Free memory */
		if (pMyPowerVRInfo) free(pMyPowerVRInfo);
		if (pMyPowerVRD3DInfo) free(pMyPowerVRD3DInfo);
		/* Exit immediately */
		exit(0);
	}
	
	/* If SGL test is required */
	if (bTestSGL)
	{
		/* Test hardware detection and SGL functions */
		/* You can call IsPVR(NULL) if you don't want to pass a structure */
		/* The returned value will tell you if all SGL tests have been successfully passed */
		if (IsPVR(pMyPowerVRInfo))		
		{
			SGLOK=TRUE;
			sprintf(pszTmp, "\nSGL FUNCTIONS DETECTED AND AVAILABLE\n\n");
			OutputDebugString(pszTmp);
		}
		else
		{
			SGLOK=FALSE;
			sprintf(pszTmp, "\nSGL FUNCTIONS FAILED\n\n");
			OutputDebugString(pszTmp);
		}
	}
	else
	{
		OutputDebugString("SGL functions not tested\n");
	}

	/* If D3D test is required */
	if (bTestD3D)
	{
		/* Test availability of D3D functions */
		/* You can call IsPVRD3D(NULL) if you don't want to pass a structure */
		/* The returned value will tell you if all D3D tests have been successfully passed */
		if (IsPVRD3D(pMyPowerVRD3DInfo))	
		{
			D3DOK=TRUE;
			sprintf(pszTmp, "\nD3D FUNCTIONS DETECTED AND AVAILABLE\n\n");
			OutputDebugString(pszTmp);
		}
		else
		{
			D3DOK=FALSE;
			sprintf(pszTmp, "\nD3D FUNCTIONS FAILED\n\n");
			OutputDebugString(pszTmp);
		}
	}
	else
	{
		OutputDebugString("D3D functions not tested\n");
	}
}


/*******************************************************************************
 * Function Name  : DisplayPowerVRInfo
 * Inputs		  : hwnd, ppiPowerVRInfo, ppiPowerVRD3DInfo 
 * Returns        : Nothing
 * Global Used    : None
 * Description    : Update the main dialog box information with the pPowerVRInfo
 *					and pPowerVRD3DInfo structures contents
 *					
 *******************************************************************************/
static void DisplayPowerVRInfo(HWND hwnd, pPowerVRInfo ppiPowerVRInfo, pPowerVRD3DInfo ppiPowerVRD3DInfo)
{
	char			pszString[300];
	pPowerVRInfo	p=ppiPowerVRInfo;		/* shorter ! */
	pPowerVRD3DInfo pD3D=ppiPowerVRD3DInfo;	/* shorter ! */
	
	/* If SGL test is not performed */
	if (!bTestSGL)
	{
		ppiPowerVRInfo=NULL;
		SetDlgItemText(hwnd, IDC_SGLSTATUS, "NOT TESTED");

	}
	
	/* If D3D test is not performed */
	if (!bTestD3D)
	{
		ppiPowerVRD3DInfo=NULL;
		SetDlgItemText(hwnd, IDC_D3DSTATUS, "NOT TESTED");
	}
	
	/* Display SGL structure information */
	if (ppiPowerVRInfo)
	{
		/* Hardware display */
		switch (p->dwChipID)
		{
			case MIDAS3_PCI_BRIDGE_DEVICE_ID : sprintf(pszString, "0x%X (MIDAS3)", p->dwChipID); break;
			case PCX1_DEVICE_ID : sprintf(pszString, "0x%X (PCX1)", p->dwChipID); break;
			case PCX2_DEVICE_ID : sprintf(pszString, "0x%X (PCX2)", p->dwChipID); break;
			case ARC1_DEVICE_ID : sprintf(pszString, "0x%X (ARC1)", p->dwChipID); break;
			default : sprintf(pszString, "Unknown");
		}
		SetDlgItemText(hwnd, IDC_SGLCHIPID, pszString);
		if (p->dwManufacturer==NEC_VENDOR_ID)
		{
			sprintf(pszString, "0x%X (NEC)", p->dwManufacturer);
		}
		else 
		{
			sprintf(pszString, "0x%X", p->dwManufacturer);
		}
		SetDlgItemText(hwnd, IDC_SGLMANUFACTURER, pszString);
		sprintf(pszString, "%s", p->szOEM);
		SetDlgItemText(hwnd, IDC_SGLOEM, pszString);
	
		/* SGL version number display */
		sprintf(pszString, "%u.%u.%u.%u", p->nSGLMajorVersion, p->nSGLMinorVersion, p->nSGLBugVersion, p->nSGLBuildVersion);
		SetDlgItemText(hwnd, IDC_SGLVERSION, pszString);
		
		/* SGL version string display */
		sprintf(pszString, "%s", p->szSGLResourceVersion);
		SetDlgItemText(hwnd, IDC_SGLRESOURCEVERSION, pszString);
	
		/* SGL internal load display */
		sprintf(pszString, "%s", p->szSGLInternalVersion);
		SetDlgItemText(hwnd, IDC_SGLINTERNALVERSION, pszString);
		sprintf(pszString, "%s",  p->szSGLInternalRequiredHeader);
		SetDlgItemText(hwnd, IDC_SGLREQUIREDHEADER, pszString);
	
		/* SGL status display */
		switch (p->nStatus)
		{
			case STATUS_SGL_BEGIN :		sprintf(pszString, "STATUS_BEGIN"); break;
			case STATUS_BOARD_PRESENT : sprintf(pszString, "STATUS_BOARD_PRESENT"); break;
			case STATUS_SGL_PRESENT :	sprintf(pszString, "STATUS_SGL_PRESENT"); break;
			case STATUS_SGL_LOADED :	sprintf(pszString, "STATUS_SGL_LOADED"); break;
			default :					sprintf(pszString, "Unknown");
		}
		SetDlgItemText(hwnd, IDC_SGLSTATUS, pszString);
	}
		
	/* Display D3D structure information */
	if (ppiPowerVRD3DInfo)
	{
		/* Hardware display */
		switch (pD3D->dwChipID)
		{
			case MIDAS3_PCI_BRIDGE_DEVICE_ID :	sprintf(pszString, "0x%X (MIDAS3)", pD3D->dwChipID); break;
			case PCX1_DEVICE_ID :				sprintf(pszString, "0x%X (PCX1)", pD3D->dwChipID); break;
			case PCX2_DEVICE_ID :				sprintf(pszString, "0x%X (PCX2)", pD3D->dwChipID); break;
			case ARC1_DEVICE_ID :				sprintf(pszString, "0x%X (ARC1)", pD3D->dwChipID); break;
			default :							sprintf(pszString, "Unknown");
		}
		SetDlgItemText(hwnd, IDC_D3DCHIPID, pszString);
		if (pD3D->dwManufacturer==NEC_VENDOR_ID)
		{
			sprintf(pszString, "0x%X (NEC)", pD3D->dwManufacturer);
		}
		else 
		{
			sprintf(pszString, "0x%X", pD3D->dwManufacturer);
		}
		SetDlgItemText(hwnd, IDC_D3DMANUFACTURER, pszString);
		sprintf(pszString, "%s", pD3D->szOEM);
		SetDlgItemText(hwnd, IDC_D3DOEM, pszString);
	
		/* D3D version number display */
		sprintf(pszString, "%u.%u.%u.%u", pD3D->nHALMajorVersion, pD3D->nHALMinorVersion, pD3D->nHALBugVersion, 
										  pD3D->nHALBuildVersion);
		SetDlgItemText(hwnd, IDC_HALVERSION, pszString);
		
		/* D3D version string display */
		sprintf(pszString, "%s", pD3D->szHALResourceVersion);
		SetDlgItemText(hwnd, IDC_HALRESOURCEVERSION, pszString);
					
		/* D3D status display */
		switch (pD3D->nStatus)
		{
			case STATUS_D3D_BEGIN :			sprintf(pszString, "STATUS_D3D_BEGIN"); break;
			case STATUS_D3D_BOARD_PRESENT : sprintf(pszString, "STATUS_D3D_BOARD_PRESENT"); break;
			case STATUS_D3D_HAL_PRESENT :	sprintf(pszString, "STATUS_D3D_HAL_PRESENT"); break;
			case STATUS_D3D_INSTALLED :		sprintf(pszString, "STATUS_D3D_INSTALLED"); break;
			case STATUS_D3D_HAL_DRIVER :	sprintf(pszString, "STATUS_HAL_DRIVER"); break;
			case STATUS_D3D_AVAILABLE :		sprintf(pszString, "STATUS_D3D_AVAILABLE"); break;
			default :						sprintf(pszString, "Unknown");
		}
		SetDlgItemText(hwnd, IDC_D3DSTATUS, pszString);
	}
		
	/*	Final results display : check or uncheck SGL and D3D checkboxes 
		depending on the test results */
	if (SGLOK)
	{
		SendDlgItemMessage(hwnd, IDC_SGLFULLYAVAILABLE, BM_SETCHECK, BST_CHECKED, 0);
	}
	else 
	{
		SendDlgItemMessage(hwnd, IDC_SGLFULLYAVAILABLE, BM_SETCHECK, BST_UNCHECKED, 0);
	}
	
	if (D3DOK)
	{
		SendDlgItemMessage(hwnd, IDC_DIRECT3DFULLYAVAILABLE, BM_SETCHECK, BST_CHECKED, 0);
	}
	else 
	{
		SendDlgItemMessage(hwnd, IDC_DIRECT3DFULLYAVAILABLE, BM_SETCHECK, BST_UNCHECKED, 0);
	}
}


/*******************************************************************************
 * Function Name  : Finish
 * Returns        : Nothing
 * Global Used    : pMyPowerVRInfo, pMyPowerVRD3DInfo
 * Description    : Free memory allocated for pMyPowerVRInfo and pMyPowerVRD3DInfo
 *					
 *******************************************************************************/
void Finish()
{
	/* Free memory */
	if (pMyPowerVRInfo) free(pMyPowerVRInfo);
	if (pMyPowerVRD3DInfo) free(pMyPowerVRD3DInfo);
	
	/* Post Quit Message */
	PostQuitMessage(0); 
}


/*******************************************************************************
 * Function Name  : WindowProc
 * Returns        : LRESULT
 * Inputs		  : hwnd, message, wParam, lParam
 * Global Used    : pMyPowerVRInfo, pMyPowerVRD3DInfo
 * Description    : Callback function for main dialog box window
 *					
 *******************************************************************************/
/* Message processing function */
static LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	/* RunPowerVRTest() is run at the beginning */
	case	WM_INITDIALOG:	/* Allocate memory for PowerVRInfo structure */
							pMyPowerVRInfo=NEW(PowerVRInfo);

							/* Allocate memory for PowerVRD3DInfo structure */
							pMyPowerVRD3DInfo=NEW(PowerVRD3DInfo);

							/* Run PowerVR test and display information in window */
							RunPowerVRTest();

							/* Display results */
							DisplayPowerVRInfo(hwnd, pMyPowerVRInfo, pMyPowerVRD3DInfo);
							break;
		
	/* Handle Main Dialog box commands */
	case	WM_COMMAND:
		switch (GET_WM_COMMAND_ID(wParam, lParam))
		{
		/* Nothing to handle ! */							
		
		default : return DefWindowProc(hwnd, message, wParam, lParam); break;
		}
		break;

	/* Test if ESCAPE key has been pressed : free memory and quit program */
	case	WM_KEYDOWN :
		switch (wParam)
		{
		case	VK_ESCAPE :	Finish();
							break;
		default :	break;
		}
		break;

	/* Destroy window : free memory and quit program */
	case	WM_DESTROY : Finish(); 
						 break;

	}
return DefWindowProc(hwnd, message, wParam, lParam);
}


/*******************************************************************************
 * Function Name  : WinMain
 * Returns        : int
 * Inputs		  : hInstance, hprevInstance, lpCmdLine, nCmdShow
 * Global Used    : wndclass, hwnd, msg
 * Description    : Callback function for main dialog box window
 *					
 *******************************************************************************/
int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    LPSTR	pszOption;
	
	if (!hPrevInstance)
	{
        wndclass.style=0;
        wndclass.lpfnWndProc=(WNDPROC)WindowProc;
        wndclass.cbClsExtra=0;
        wndclass.cbWndExtra=DLGWINDOWEXTRA;
        wndclass.hInstance=hInstance;
        wndclass.hIcon=LoadIcon(NULL, IDI_QUESTION);
        wndclass.hCursor=LoadCursor(NULL, IDC_ARROW);
        wndclass.hbrBackground=GetStockObject(LTGRAY_BRUSH);
        wndclass.lpszMenuName=NULL;
        wndclass.lpszClassName="PowerVR Detection Class";
        RegisterClass(&wndclass);
    }

	/* Parse the command line in seach of one of the following options:
       -NoSGL : SGL test will not be performed
	   -NoD3D : D3D test will not be performed
	   String comparison is NOT case sensitive. */
	pszOption=strtok(lpCmdLine, " -");    
    while(pszOption!=NULL )   
	{
	    if (!lstrcmpi(pszOption, "nosgl")) 
		{
            bTestSGL=FALSE;
        } 
		if (!lstrcmpi(pszOption, "nod3d"))
		{
            bTestD3D=FALSE;
        } 
        pszOption=strtok(NULL, " -");
    }

	/* Create main window as a dialog box */
	hwnd=CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAINDLG), 0, WindowProc); 

	/* Test if window has been created */
	if (hwnd==NULL)
	{
		MessageBox(NULL, "Unable to create main Window\n", "PowerVR Detection", MB_ICONERROR | MB_OK);
		exit(0);		/* Exit immediately */
	}

	/* Show and update window */
	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);

	/* Message loop */
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}


/*******************************************************************************
 * Function Name  : GetDXVersion
 * Returns        : This function returns two arguments:
 *					dwDXVersion:
 *					0	    No DirectX installed
 *					0x100   DirectX version 1 installed
 *					0x200   DirectX 2 installed
 *					0x300   DirectX 3 installed
 *					0x500   At least DirectX 5 installed.
 *					0x501   At least DirectX 5a installed.
 *					dwDXPlatform:
 *					0	                            Unknown (This is a failure case.
 *															 Should never happen)
 *					VER_PLATFORM_WIN32_WINDOWS	    Windows 9X platform
 *					VER_PLATFORM_WIN32_NT	    Windows NT platform
 * Global Used    : None
 * Description    : Detects and returns DirectX version installed on the system.
 *					This function has been taken from the DirectX 5.0 SDK
 *					
 *******************************************************************************/
static void GetDXVersion (LPDWORD pdwDXVersion, LPDWORD pdwDXPlatform)
{
    HRESULT					hr;
    HINSTANCE				DDHinst = 0;
    HINSTANCE				DIHinst = 0;
    LPDIRECTDRAW			pDDraw = 0;
    LPDIRECTDRAW2			pDDraw2 = 0;
    DIRECTDRAWCREATE		DirectDrawCreate = 0;
    DIRECTINPUTCREATE		DirectInputCreate = 0;
    OSVERSIONINFO			osVer;
	DDSURFACEDESC			desc;
    LPDIRECTDRAWSURFACE	    pSurf = 0;
    LPDIRECTDRAWSURFACE3    pSurf3 = 0;

    /* First get the windows platform */
    osVer.dwOSVersionInfoSize = sizeof(osVer);
    if (!GetVersionEx(&osVer))
    {
		*pdwDXVersion = 0;
		*pdwDXPlatform = 0;
		return;
    }

    if (osVer.dwPlatformId == VER_PLATFORM_WIN32_NT)
    {
		*pdwDXPlatform = VER_PLATFORM_WIN32_NT;
		/* NT is easy... NT 4.0 is DX2, 4.0 SP3 is DX3, 5.0 is DX5
		   and no DX on earlier versions. */
		if (osVer.dwMajorVersion < 4)
		{
		    *pdwDXPlatform = 0;	//No DX on NT3.51 or earlier
			return;
		}
		if (osVer.dwMajorVersion == 4)
		{
		    /* NT4 up to SP2 is DX2, and SP3 onwards is DX3, so we are at least DX2 */
			*pdwDXVersion = 0x200;

            /* We're not supposed to be able to tell which SP we're on, so check for dinput */
            DIHinst = LoadLibrary("DINPUT.DLL");
            if (DIHinst == 0) 
            {
                /* No DInput... must be DX2 on NT 4 pre-SP3 */
                OutputDebugString("Couldn't LoadLibrary DInput\r\n");
				return;
            }

            DirectInputCreate=(DIRECTINPUTCREATE)GetProcAddress(DIHinst, "DirectInputCreateA");
            FreeLibrary(DIHinst);

            if (DirectInputCreate == 0) 
            {
                /* No DInput... must be pre-SP3 DX2 */
                OutputDebugString("Couldn't GetProcAddress DInputCreate\r\n");
				return;
            }

	    /* It must be NT4, DX2 */
	    *pdwDXVersion = 0x300; //DX3 on NT4 SP3 or higher
	    return;
		}
	
		/* Else it's NT5 or higher, and it's DX5a or higher: */
		*pdwDXVersion = 0x501; //DX5a on NT5
		return;
    }

    /* Not NT... must be Win9x */
    *pdwDXPlatform = VER_PLATFORM_WIN32_WINDOWS;

    /* If we are on Memphis or higher, then we are at least DX5a */
    if ( (osVer.dwBuildNumber & 0xffff) > 1353) /* Check for higher than developer release */
    {
		*pdwDXVersion = 0x501; /* DX5a on Memphis or higher */
		return;
    }

    /* Now we know we are in Windows 9x (or maybe 3.1), so anything's possible.
       First see if DDRAW.DLL even exists. */
    DDHinst = LoadLibrary("DDRAW.DLL");
    if (DDHinst == 0) 
    {
		*pdwDXVersion = 0;
		*pdwDXPlatform = 0;
		FreeLibrary(DDHinst);
		return;
    }

    /* See if we can create the DirectDraw object. */
    DirectDrawCreate = (DIRECTDRAWCREATE)GetProcAddress(DDHinst, "DirectDrawCreate");
    if (DirectDrawCreate == 0) 
    {
		*pdwDXVersion = 0;
		*pdwDXPlatform = 0;
		FreeLibrary(DDHinst);
        OutputDebugString("Couldn't LoadLibrary DDraw\r\n");
		return;
    }

    hr=DirectDrawCreate(NULL, &pDDraw, NULL);
    if (FAILED(hr)) 
    {
		*pdwDXVersion = 0;
		*pdwDXPlatform = 0;
		FreeLibrary(DDHinst);
        OutputDebugString("Couldn't create DDraw\r\n");
		return;
    }

    /* So DirectDraw exists.  We are at least DX1. */
    *pdwDXVersion = 0x100;

    /* Let's see if IID_IDirectDraw2 exists. */
    hr = pDDraw->lpVtbl->QueryInterface(pDDraw, &IID_IDirectDraw2, (LPVOID *)&pDDraw2);
    if (FAILED(hr)) 
    {
		/* No IDirectDraw2 exists... must be DX1 */
		pDDraw->lpVtbl->Release(pDDraw);
		FreeLibrary(DDHinst);
        OutputDebugString("Couldn't QI DDraw2\r\n");
		return;
    }
    /* IDirectDraw2 exists. We must be at least DX2 */
    pDDraw2->lpVtbl->Release(pDDraw2);
    *pdwDXVersion = 0x200;

    /* See if we can create the DirectInput object. */
    DIHinst = LoadLibrary("DINPUT.DLL");
    if (DIHinst == 0) 
    {
        /* No DInput... must be DX2 */
        OutputDebugString("Couldn't LoadLibrary DInput\r\n");
		pDDraw->lpVtbl->Release(pDDraw);
		FreeLibrary(DDHinst);
		return;
    }

    DirectInputCreate = (DIRECTINPUTCREATE)GetProcAddress(DIHinst, "DirectInputCreateA");
    FreeLibrary(DIHinst);

    if (DirectInputCreate == 0) 
    {
        /* No DInput... must be DX2 */
		FreeLibrary(DDHinst);
		pDDraw->lpVtbl->Release(pDDraw);
        OutputDebugString("Couldn't GetProcAddress DInputCreate\r\n");
		return;
    }

    /* DirectInputCreate exists. That's enough to tell us that we are at least DX3 */
    *pdwDXVersion = 0x300;

    /* Checks for 3a vs 3b? */

    /* We can tell if DX5 is present by checking for the existence of IDirectDrawSurface3.
       First we need a surface to QI off of. */
    
    ZeroMemory(&desc, sizeof(desc));
    desc.dwSize = sizeof(desc);
    desc.dwFlags = DDSD_CAPS;
    desc.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;

    hr = pDDraw->lpVtbl->SetCooperativeLevel(pDDraw, NULL, DDSCL_NORMAL);
    if (FAILED(hr)) 
    {
		/* Failure. This means DDraw isn't properly installed. */
		pDDraw->lpVtbl->Release(pDDraw);
		FreeLibrary(DDHinst);
		*pdwDXVersion = 0;
        OutputDebugString("Couldn't Set coop level\r\n");
		return;
    }

    hr = pDDraw->lpVtbl->CreateSurface(pDDraw, &desc, &pSurf, NULL);
    if (FAILED(hr)) 
    {
	/* Failure. This means DDraw isn't properly installed. */
	pDDraw->lpVtbl->Release(pDDraw);
	FreeLibrary(DDHinst);
	*pdwDXVersion = 0;
    OutputDebugString("Couldn't CreateSurface\r\n");
	return;
    }

    /* Try for the IDirectDrawSurface3 interface. If it works, we're on DX5 at least */
    if ( FAILED(pSurf->lpVtbl->QueryInterface(pSurf, &IID_IDirectDrawSurface3,(LPVOID*)&pSurf3)) )
    {
        pDDraw->lpVtbl->Release(pDDraw);
        FreeLibrary(DDHinst);
        return;
    }

    /* QI for IDirectDrawSurface3 succeeded. We must be at least DX5 */
    *pdwDXVersion = 0x500;

    pSurf->lpVtbl->Release(pSurf);
    pDDraw->lpVtbl->Release(pDDraw);
    FreeLibrary(DDHinst);

    return;
}

