//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IsPVRsh.rc
//
#define IDD_MAINDLG                     101
#define IDD_POWERVR                     103
#define IDC_SGLFULLYAVAILABLE           1004
#define IDC_DIRECT3DFULLYAVAILABLE      1005
#define IDC_SGLCHIPID                   1007
#define IDC_SGLMANUFACTURER             1008
#define IDC_SGLVERSION                  1009
#define IDC_HALVERSION                  1010
#define IDC_SGLRESOURCEVERSION          1013
#define IDC_SGLINTERNALVERSION          1014
#define IDC_SGLREQUIREDHEADER           1015
#define IDC_SGLSTATUS                   1016
#define IDC_D3DCHIPID                   1017
#define IDC_D3DMANUFACTURER             1018
#define IDC_HALRESOURCEVERSION          1019
#define IDC_D3DSTATUS                   1024
#define IDC_SGLOEM                      1025
#define IDC_D3DOEM                      1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
