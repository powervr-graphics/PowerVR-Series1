/*****************************************************************************
  Name : PVRD3D.C
  Platform : ANSI compatible

  * DESCRIPTION:
  Simple function used to indicate if the LPD3DDEVICE2 selected is a
  PowerVR board (PCX1, PCX2)

	
  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/
#define INITGUID

#include <d3d.h>


/* From pvrd3d.h */
#ifndef _PVRD3D_

#define BUILDFOURCC(a,b,c,d)	((a) | ((b) << 8) | ((c) << 16) | ((d) << 24))
#define FOURCC_PVR_CTL			BUILDFOURCC ('P', 'V', 'R', 'C')

typedef struct _PVR_CTL_
{
	DWORD	dwType;
	PVOID	pvReserved;
	union
	{
		DWORD		dwFeatureCTL;			/* if dwType = PVR_FCTL, Specifies feature CTL flags 	  */
		float		fShadowBrightness;		/* if dwType = PVR_SHADOWVOL, Specifies shadow brightness */
		D3DCOLOR	dcLightVolumeColour;	/* if dwType = PVR_LIGHTVOL, Specifies light vol colour   */
	};
	DWORD	dwBGColour;						/* See feature control flags below  */
	DWORD	dwReserved[8];
} PVR_CTL, *PPVR_CTL;

#endif	/* if pvrd3d.h */

#undef RELEASE
#define RELEASE(x) if (x) { (x)->lpVtbl->Release(x); (x) = NULL; }


typedef struct _driverInfo
{
	BOOL bIsHardware;		/* hw or software driver */
	D3DDEVICEDESC Desc;
	char Name[50];
	char About[255];
	GUID Guid;
} driverInfo;


/* Global variables */

/* Array to store all D3D drivers. We assume no more than 10 drivers will be found */
static driverInfo	Driver[10];
static int			nNumDrivers=0;		/* Must be global to keep trace of different D3D drivers */


/* Prototype */
static BOOL IsPowerVRD3DDevice(LPDIRECTDRAW2 lpDD2, LPDIRECT3DDEVICE2 lpD3DDevice2);



/*******************************************************************************
 * Function Name  : IsPowerVRD3DDevice
 * Input		  : lpDD2, lpD3DDevice2
 * Returns        : TRUE or FALSE
 * Description    : Returns TRUE if D3DDEVICE2 passed is a PowerVR (PCX1, PCX2)
 *					device.
 *					You can easily modify the function if you use execute
 *					buffers (LPDIRECT3DDEVICE instead of LPDIRECT3DDEVICE2)
 *
 *******************************************************************************/
static BOOL IsPowerVRD3DDevice(LPDIRECTDRAW2 lpDD2, LPDIRECT3DDEVICE2 lpD3DDevice2)
{
	D3DTEXTUREHANDLE 	hTex;
	LPDIRECT3DTEXTURE2	lpD3DTexture2;
	LPDIRECTDRAWSURFACE lpDDSurface;
	DDSURFACEDESC 		DDSurfDesc;
	PPVR_CTL			lpPVRCtl;
	HRESULT				hres;
		
	/* Try creating texturing surface */
	DDSurfDesc.dwSize = sizeof (DDSURFACEDESC);
    DDSurfDesc.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
    DDSurfDesc.dwHeight = 2;
    DDSurfDesc.dwWidth = 2;
    DDSurfDesc.ddsCaps.dwCaps = DDSCAPS_TEXTURE; 
    DDSurfDesc.ddpfPixelFormat.dwSize = sizeof (DDPIXELFORMAT); 
    DDSurfDesc.ddpfPixelFormat.dwFlags = DDPF_FOURCC; 
	DDSurfDesc.ddpfPixelFormat.dwFourCC = FOURCC_PVR_CTL; 

	/* If creation failed, PowerVR isn't present */
	hres=lpDD2->lpVtbl->CreateSurface(lpDD2, &DDSurfDesc, &lpDDSurface, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to create texture surface\n");
		return FALSE;
	}

	/* Lock it to get pointer to our control structure */
	hres=lpDDSurface->lpVtbl->Lock(lpDDSurface, NULL, &DDSurfDesc, DDLOCK_WAIT, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to lock surface\n");
		RELEASE(lpDDSurface);
		return FALSE;
	}

	/* Get pointer */
	lpPVRCtl = (PPVR_CTL)DDSurfDesc.lpSurface;

	/* Have the pointer unlock surface now */
	hres=lpDDSurface->lpVtbl->Unlock(lpDDSurface, &DDSurfDesc);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to Unlock surface\n");
		RELEASE(lpDDSurface);
		return FALSE;
	}
		
	/* Get texturing interface */
	hres=lpDDSurface->lpVtbl->QueryInterface(lpDDSurface, &IID_IDirect3DTexture2, (LPVOID *)&lpD3DTexture2);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to get texturing interface\r\n");
		RELEASE(lpDDSurface);
		return FALSE;
	}

	/*	Get a handle for the texture, if PowerVR is the supplied device we'll 
		see a non zero value in lpPVRCtl->pvReserved. */
	hres=lpD3DTexture2->lpVtbl->GetHandle(lpD3DTexture2, lpD3DDevice2, &hTex);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to get texture handle\n");
		RELEASE(lpD3DTexture2);
		RELEASE(lpDDSurface);
		return FALSE;
	}

	/* If zero then no PowerVR */
	if (!lpPVRCtl->pvReserved)
	{
		OutputDebugString("D3DDEVICE2 is not PowerVR\n");
		RELEASE(lpD3DTexture2);
		RELEASE(lpDDSurface);
		return(FALSE);
	}
	
	/* Free everything */
	RELEASE(lpD3DTexture2);
	RELEASE(lpDDSurface);
		
	/* Must be Power VR ! */
	OutputDebugString("D3DDEVICE2 is PowerVR\n");
	return(TRUE);
}


/*******************************************************************************
 * Function Name  : EnumDeviceDriverCallback
 * Description    : Callback function which enumerates all D3D available drivers
 *					Should only be called by IsPowerVRD3DDevice()
 *					
 *******************************************************************************/
static HRESULT
CALLBACK EnumDeviceDriverCallback (LPGUID lpGuid, LPSTR lpDeviceDescription,
                      LPSTR lpDeviceName, LPD3DDEVICEDESC lpHWDesc,
                      LPD3DDEVICEDESC lpHELDesc, LPVOID lpUserArg)
{
	/* Save this driver's info; we'll figure out which one we 
	   want to use in PickDriver */
    memcpy (&Driver[nNumDrivers].Guid, lpGuid, sizeof(GUID));
    lstrcpy (Driver[nNumDrivers].About, lpDeviceDescription);
    lstrcpy (Driver[nNumDrivers].Name, lpDeviceName);
    
	/* If the color model for a HW (HAL) driver is invalid or 0, then the 
	   driver must be a SW (HEL) driver, so use this as a test to see 
	   which type of driver we just saved */
    if (lpHWDesc->dcmColorModel)
	{
        Driver[nNumDrivers].bIsHardware = TRUE;
        memcpy (&Driver[nNumDrivers].Desc, lpHWDesc, sizeof(D3DDEVICEDESC));
    }
	else
	{
        Driver[nNumDrivers].bIsHardware = FALSE;
        memcpy (&Driver[nNumDrivers].Desc, lpHELDesc, sizeof(D3DDEVICEDESC));
	}

    nNumDrivers++;
    return (D3DENUMRET_OK);
}



/*******************************************************************************
 * Function Name  : WinMain
 * Description    : Used to test IsPowerVRD3DDevice(...) function.
 *
 *******************************************************************************/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	LPDIRECTDRAW		lpDD;
	LPDIRECTDRAW2		lpDD2;
	LPDIRECTDRAWSURFACE lpDDSBackBuffer;
	LPDIRECT3DDEVICE2	lpDev2;
	LPDIRECT3D2			lpD3D2;
	HRESULT				hres;
	DDSURFACEDESC 		DDSurfDesc;
	BOOL				bPowerVRPresent=FALSE;
	int					CurrentDriver=-1;
	int					i;

	/* Creates an instance of a DirectDraw object */
	hres=DirectDrawCreate(NULL, &lpDD, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Error in DirectDrawCreate\n");
		RELEASE(lpDD);
		return FALSE;
	}

	/* Creates an instance of a DirectDraw2 object */
	hres=lpDD->lpVtbl->QueryInterface(lpDD, &IID_IDirectDraw2, (LPVOID *)&lpDD2);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to find a interface to DirectDraw2\n");
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}
	
	/* Query interface to see if Direct3D II is available */
	hres=lpDD2->lpVtbl->QueryInterface(lpDD2, &IID_IDirect3D2, (LPVOID *)&lpD3D2);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to detect Direct3D version 2.0\n");
		RELEASE(lpD3D2);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* Set Cooperative Level */
	hres=lpDD2->lpVtbl->SetCooperativeLevel(lpDD2, GetActiveWindow(), DDSCL_NORMAL);
	if (hres!=DD_OK) 
	{
		OutputDebugString("Error in SetCooperativeLevel\n");
		RELEASE(lpD3D2);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* Create back buffer surface. We need DDSCAPS_3DDEVICE					   
	   to create a surface that gets attached to a device */
	/* Set surface instance to 0 */
	memset (&DDSurfDesc, 0, sizeof(DDSURFACEDESC));
	DDSurfDesc.dwSize = sizeof(DDSURFACEDESC);
	DDSurfDesc.dwFlags = DDSD_WIDTH | DDSD_HEIGHT | DDSD_CAPS;
	DDSurfDesc.dwWidth = 2;
	DDSurfDesc.dwHeight = 2;
	DDSurfDesc.ddsCaps.dwCaps = DDSCAPS_3DDEVICE | DDSCAPS_OFFSCREENPLAIN;

	/* Create the back buffer surface */
	hres = lpDD2->lpVtbl->CreateSurface(lpDD2, &DDSurfDesc, &lpDDSBackBuffer, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed to create back buffer\n");
		RELEASE(lpD3D2);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* Enumerate all installed device drivers and pick one
	   based on (in this case) hardware color model */
	hres = lpD3D2->lpVtbl->EnumDevices(lpD3D2, EnumDeviceDriverCallback, NULL);
	if (hres!=DD_OK)
	{
		OutputDebugString("Failed in enumerating D3D devices\n");
		RELEASE(lpDDSBackBuffer);
		RELEASE(lpD3D2);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}
		
	/* Return the first HW, RGB driver, if any */
	for (i=0; i<nNumDrivers; i++) 
	{
		if (Driver[i].bIsHardware && (Driver[i].Desc.dcmColorModel & D3DCOLOR_RGB))
		{
			CurrentDriver=i;
			break;
		}
	}
	if (CurrentDriver==-1)
	{
		OutputDebugString("No hardware D3D device found\n");
		MessageBox(NULL, "No hardware D3D device found", "PowerVR D3D Device ?", MB_OK);
		return FALSE;	/* No hardware driver with RGB detected */
	}

	/* Create the Direct3D device 2 selected and attach it to the back buffer */
	hres=lpD3D2->lpVtbl->CreateDevice(lpD3D2, &Driver[CurrentDriver].Guid, lpDDSBackBuffer, &lpDev2);
	if (hres!=DD_OK)
	{
		OutputDebugString("CreateSurface failed (for D3D Device 2)\n");
		RELEASE(lpD3D2);
		RELEASE(lpDD2);
		RELEASE(lpDD);
		return FALSE;
	}

	/* Now let's call IsPowerVRD3DDevice(...) to know if this hardware DIRECT3DDEVICE2
	   is PowerVR */
	if (IsPowerVRD3DDevice(lpDD2, lpDev2))
	{
		MessageBox(NULL, "Selected D3D device is PowerVR", "PowerVR D3D Device ?", MB_OK);
		bPowerVRPresent=TRUE;
	}
	else
	{
		MessageBox(NULL, "Selected D3D device is NOT PowerVR", "PowerVR D3D Device ?", MB_OK);
		bPowerVRPresent=FALSE;
	}

	/* Release everything */
	RELEASE(lpDev2);
	RELEASE(lpD3D2);
	RELEASE(lpDD2);
	RELEASE(lpDD);

	/* End of program */
}







