/******************************************************************************
 * Name : main.c
 * Title : flickering shadows example
 * Author : Simon Fenney.
 * Created : 26/07/1995
 *
 * Copyright : 1997 by VideoLogic Limited. All rights reserved.
 * 	Example code for PowerSGL which may be copied and modified freely.
 * 
 *
 * Description : Simple PowerSGL example to show real-time shadow effects
 *		 from a flickering candle light source in a small enclosed room.
 *
 * Platform : ANSI compatible
 *
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "math.h"

#include "sgl.h"

/*
// DEFINE THE ANIMATION SPEED
*/
#define SLOW   (1)
#define NORMAL (2)
#define FAST   (6)

#define ANIMATION_SPEED	  NORMAL

/*
// Define the Output Image size.
//
// Cannot go above 1024 for a dimension NOR above the display's max
//
// The size of the image has an insignificant effect on rendering speed
*/
#define IMAGE_SIZE 0

#if (IMAGE_SIZE == 0)
	#define IMAGE_SIZE_X (640)
	#define IMAGE_SIZE_Y (480)

#elif (IMAGE_SIZE == 1)
	#define IMAGE_SIZE_X (800)
	#define IMAGE_SIZE_Y (600)

#else
	#define IMAGE_SIZE_X (1000)
	#define IMAGE_SIZE_Y (700)
#endif

/*
// Define some constants to make some parameters a little
// easier to read
*/

#define NAMED_ITEM                      TRUE
#define UNAMED_ITEM                     FALSE

#define SHADOW_LIGHT            		TRUE
#define NO_SHADOWS                      FALSE

#define INVISIBLE                       TRUE
#define VISIBLE                         FALSE


/*
// Set the lens length to one of the predefines
*/
#define LENS_200MM                      16.0f
#define LENS_50MM                       4.0f
#define LENS_35MM                       3.0f
#define LENS_24MM                       2.0f

#define LENS_LEN	LENS_35MM			



#define PI      3.14159f

/*
// Define some values for modeling the room.
// (The walls are actually a bit higher than this to make up 
// for the lack of a roof!)
*/
#define ROOM_WIDTH   (290.0f)
#define ROOM_HEIGHT  (100.0f)

float shelf_base[3]  = {20.0f, 10.0f, ROOM_WIDTH/2.0f};
float candle_base[3] = {5.0f,  2.0f,  -3.0f};
float flame_base[3]  =  {0.0f,  10.0f, 0.0f};

float table_base[3]  =  {-20.0f, -ROOM_HEIGHT/2.0f, 0.0f};
float chair_base[3]  =  {10.0f,  -ROOM_HEIGHT/2.0f, -24.0f};
float chair2_base[3] =  { 6.0f,  -ROOM_HEIGHT/2.0f, 55.0f};

/*
// Define some standard colours
*/
sgl_colour  black 	 = {0.0f,0.0f,0.0f};
sgl_colour  darkgrey = {0.25f,0.25f,0.25f};
sgl_colour  yellow   = {1.0f,1.0f,0.0f};
sgl_colour  CandleYellow = {2.0f,2.0f,0.5f};/*this is for the light*/
sgl_colour  grey 		 = {0.5f,0.5f,0.5f};

sgl_colour  lightgrey= {0.75f,0.75f,0.75f};
sgl_colour  white    = {1.0f,1.0f,1.0f};


sgl_vector  ParLightDir = {0.4f,-1.0f,0.5f};  
sgl_vector  zero_vector = {0.0f, 0.0f, 0.0f};

/*
// The axis that we pivot the camera around
*/
sgl_vector CameraAxis  = {-0.5f, 1.0f, 0.0f};


/*
// Define the names of the textures we read, and whether
// we need to make them transparent.
*/
#define NUM_TEXTURES 8
int  Textures[NUM_TEXTURES];

char TexFileNames[NUM_TEXTURES][20] =
{
		"floor.bmp",
		"wallston.bmp",
		"woodtop2.bmp",
		"flame1.bmp",
		"flame2.bmp",
		"grass2.bmp",
		"cloudsda.bmp",
		"wax.bmp"
};

int TexTrans[NUM_TEXTURES]=
{ 
		FALSE,
		FALSE,
		FALSE,
		TRUE,
		TRUE,
		FALSE,
		FALSE,
		FALSE
};

/*********************************************************
// Routine to load a bunch of textures and save the sgl names
// of them in the global "Textures" Array.
//
// This routine simply reads a set of BMP files. Ideally you
// would probably read pre-processed texture files, but this
// makes it easy for prototyping etc.
**********************************************************/
void LoadTextures(void)
{
	int i;
	sgl_intermediate_map myMap;

	for(i = 0; i < NUM_TEXTURES; i++)
	{
		sgl_map_types PixelType;

		/*
		// Load the bmp map texture into the intermediate format
		*/
	  	myMap = ConvertBMPtoSGL(TexFileNames[i], TexTrans[i]);

		/*
		// Convert and store the texture, generating MIPmap
		*/
		if(TexTrans[i])
		{
			PixelType = sgl_map_trans16_mm;	  /*we want transluent MIPmapped*/
		}
		else
		{
			PixelType = sgl_map_16bit_mm;	/*Opaque MIP mapped */
		}
		
		Textures[i] = sgl_create_texture (PixelType,
		 								/*to keep things simple, all are 128x128*/ 
										sgl_map_128x128,
										TRUE, /*generate the MIP map automatically*/ 
										TRUE, /*dither when reducing colour depth*/
								  		&myMap,
								  		NULL); /*we aren't suppling MIP levels*/


		/*
		// Release the memory created when the texture was loaded
		//
		// NOTE: For some reason, the normal "free" fails under some
		// compilers/Operating systems, so use the one supplied
		// with sgl to release the "pixels" memory.
		*/
		sgl_free_pixels (&myMap);
	}/*end for*/ 

}


/*********************************************************
// Put in sky and ground .. mainly as a frame of reference
// as the model gets placed
*********************************************************/

void CreateSkyAndGround()
{
	sgl_2d_vec uv1,  uv2,  uv3;
	sgl_vector	groundPnt	= {0.0f,-90.0f, 2000.0f };	
	sgl_vector	point2		= {-10.0f,-90.0f, 2000.0f };	
	sgl_vector	point3		= {0.0f,-90.0f, 2010.0f };	

	sgl_vector	skyPnt		= {0.0f, 1000.0f ,3000.0f};
	sgl_vector	skyPnt2		= {0.0f,1000.0f, 3010.0f };	
	sgl_vector	skyPnt3		= {-10.0f,1000.0f, 3000.0f };	

	/* ****************************************
	// Add the ground plane 
	//
	// SET GROUND PLANE SO IT IS SHADED BY THE LIGHT
	*****************************************/
	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);

		/*
		// Choose some arbitrary mapping for UVs that
		// looks ok
		*/
		uv1[0]=1.0E-2f;
		uv1[1]=0.0f;

		uv2[0]=5.43E-2f;
		uv2[1]=0.0f;

		uv3[0]=0.0f;
		uv3[1]=5.43E-2f;
	
		/*
		// Set it to be shaded by using diffuse colour
		*/
		sgl_set_texture_map(Textures[5],FALSE,FALSE);

		sgl_set_diffuse(white); 
		sgl_set_texture_effect(TRUE,TRUE,TRUE,FALSE);

		sgl_add_plane(groundPnt,point2,point3, VISIBLE, 
					 NULL,NULL,NULL,uv1,uv2,uv3); 
	sgl_to_parent();


	/*****************************************
	// Add a sky plane 
	//
	// Set sky to "glow" using the texture colour, and so it is NOT
	// shaded by the light.
	*****************************************/

	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);
		sgl_set_opacity(1.0f);

		uv1[0]=0.0f;
		uv1[1]=0.0f;

		uv2[0]=2.43E-3f;
		uv2[1]=0.0f;

		uv3[0]=0.0f;
		uv3[1]=2.43E-3f;

		sgl_set_glow(white); 
		sgl_set_diffuse(black); 
		sgl_set_specular(black, 0); /*actually specular is already 0 by default*/
		sgl_set_ambient(black);

		sgl_set_texture_effect(FALSE,FALSE,FALSE, TRUE);
		sgl_set_texture_map(Textures[5],FALSE,FALSE);
		sgl_add_plane(skyPnt,skyPnt2,skyPnt3,VISIBLE,
						NULL,NULL,NULL,uv1,uv2,uv3); 

	sgl_to_parent();
}


/*
// Global names to some predefined material types
*/
int MaterialList;

int Wood1Material;
int Wood2Material;
int WallMaterial;
int FloorMaterial;
int FlameMaterial;

/*********************************************************
// Routine to set up some material instances that will be
// re-used.
// All these will be created in the same separate list - It
// seems tidier that way.
//
// It also assumes no errors will occur!
**********************************************************/
void CreateMaterialInstances(void)
{
	/*
	// Create separate list
	*/
	MaterialList = sgl_create_list(TRUE, TRUE, TRUE);

	/*
	// create a generic Wood material instance
	*/
	Wood1Material = sgl_create_material(TRUE, FALSE);

		/*
		// Set it to use a wood texture, and not to flip U & V 
		// after every rep.
		*/
		sgl_set_texture_map(Textures[2], FALSE, FALSE);

		/*
		// Set the texture to be affected only by the Diffuse
		// and Ambient components
		*/
		sgl_set_texture_effect(TRUE, TRUE, FALSE, FALSE);

		/*
		// Set up the diffuse colour
		*/
		sgl_set_diffuse(white);


	/*
	// create a second wood material that is a bit darker, but 
	// has some specular component
	*/
	Wood2Material = sgl_create_material(TRUE, FALSE);

		/*
		// Set it to use a wood texture, and not to flip U & V 
		// after every rep.
		*/
		sgl_set_texture_map(Textures[2], FALSE, FALSE);

		/*
		// Set the texture to be affected only the Diffuse and Ambient
		// components
		*/
		sgl_set_texture_effect(TRUE, TRUE, FALSE, FALSE);

		/*
		// Set up the diffuse colour
		*/
		sgl_set_diffuse(darkgrey);

		/*
		// Set up the specular
		*/
		sgl_set_specular(grey, 20);

	/*
	// Create the wall material
	*/
	WallMaterial = sgl_create_material(TRUE, FALSE);

		sgl_set_texture_map(Textures[1], FALSE, FALSE);
		sgl_set_texture_effect(TRUE, TRUE, FALSE, FALSE);
	   	sgl_set_diffuse(darkgrey);

	/*
	// Create Floor material
	*/ 
   	FloorMaterial = sgl_create_material(TRUE, FALSE);
		sgl_set_texture_map(Textures[0], FALSE, FALSE);
		sgl_set_texture_effect(TRUE, TRUE, FALSE, FALSE);
	   	sgl_set_diffuse(lightgrey);
	
	/*
	// FlameMaterial
	*/
    FlameMaterial = sgl_create_material(TRUE, FALSE);
		sgl_set_texture_map(Textures[3], FALSE, FALSE);

		/*
		// In this situation, we want the object to "glow" and
		// NOT be "shaded". Have the texture be affected only by
		// the glow, and set the diffuse etc to black
		*/
		sgl_set_texture_effect(FALSE, FALSE, FALSE, TRUE);

		sgl_set_glow(white);
		sgl_set_diffuse(black);
		sgl_set_ambient(black);
		sgl_set_specular(black, 0);

}


/*********************************************************
// Routine to create a Table as an instance, and return the
// name of that list. The table is built out of convex 
// pieces so that it can automatically generate shadows.
// 
// Note that modelling of the table is VERY basic. It is 
// only an example after all!  Ideally, it would be
// built by some sort of modelling package.
**********************************************************/

int CreateTable()
{
 	int TableInstance;
	int i;
	static sgl_vector TableTopCorners[4] = 
	{	
		{ 0.0f, 35.0f,  0.0f},
		{ 0.0f, 35.0f, 40.0f},
		{60.0f, 35.0f, 40.0f},	
		{60.0f, 35.0f,  0.0f},
	};

	/*
	// The following are just randomly chosen texture coords.
	// To keep things simply, we'll re-use these for each face,
	// but of course the texture won't join up
	*/
	static sgl_2d_vec UVs[3] = 
	{
		{0.0f, 0.0f},
		{0.0f, 1.3f},
		{1.7f, 2.1f}
	};


	sgl_vector Vect[3];

	/*
	// Create the list the table will reside in
	*/
	TableInstance = sgl_create_list(TRUE, TRUE, TRUE);

	/*
	// Use the second wood material
	*/ 
	sgl_use_material_instance(Wood2Material, FALSE); 

	/*
	// Define an anonymous convex object for the top
	// of the table.
	// First define the "top" surface. The UV coords I've
	// chosen are pretty much arbitrary.
	*/
	sgl_create_convex(FALSE);
	sgl_add_plane ( TableTopCorners[0],	/*specify in clockwise order*/
					TableTopCorners[1], 
					TableTopCorners[2],
					FALSE, 
					NULL, /*not smooth shaded*/
					NULL,
					NULL,
					UVs[0], UVs[1], UVs[2]);
	/*
	// Do the edges of the table.
	*/
	for(i = 0; i < 4; i ++)
	{
		/*
		// For this edge, we'll use two of the points from
		// the top of the table PLUS another below it
		*/
		Vect[0][0] = TableTopCorners[i][0];
		Vect[0][1] = TableTopCorners[i][1] - 5.0f;
		Vect[0][2] = TableTopCorners[i][2];

		sgl_add_plane ( TableTopCorners[(i+1) % 4],					 
						TableTopCorners[i],
						Vect[0],					
					FALSE, 
					NULL, /*not smooth shaded*/
					NULL,
					NULL,
					UVs[0], UVs[1], UVs[2]);


	}/*end for*/

	/*
	// Finally define the underside of the table top
	// by choosing three of the top points and moving
	// them down a bit. Note that we still need to have
	// them in clockwise order when viewed from the outside
	// hence they are given in the opposite order.
	*/
	for(i = 0; i < 3; i++)
	{
		Vect[i][0] = TableTopCorners[i][0]; 
		Vect[i][1] = TableTopCorners[i][1] - 4.0f; 
		Vect[i][2] = TableTopCorners[i][2]; 
	}
	sgl_add_plane ( Vect[2],	/*specify in clockwise order*/
					Vect[1], 
					Vect[0],
					FALSE, 
					NULL, /*not smooth shaded*/
					NULL,
					NULL,
					UVs[0], UVs[1], UVs[2]);


	/*
	// To make life simple, just use some predefined blocks
	// to build the rest of the scene objects.
	//
	// Normally these would be contructed using a modelling 
	// package....
	//
	// Put in the four legs of the table.
	*/
	for(i=0; i < 4; i++)
	{
		sgl_create_list(FALSE, TRUE, FALSE);
	
		/*
		// Translate from the origin out to a corner position
		// The modelling is pretty awfull!
		*/
		sgl_translate(TableTopCorners[i][0], 
					  TableTopCorners[i][1] / 2.0f + 0.2f, 
					  TableTopCorners[i][2]);

		sgl_create_rectprism(4.0f, TableTopCorners[i][1], 4.0f, FALSE, TRUE);

		sgl_to_parent();
	 }
	return TableInstance;
}


/*********************************************************
**********************************************************/
#define SeatRadius (8.0f)
#define SeatThickness (3.0f)
#define SeatHeight	  (17.0f)

int CreateChair()
{
	int ChairInstance;

	ChairInstance = sgl_create_list(TRUE, TRUE, TRUE);

	sgl_use_material_instance(Wood1Material, FALSE); 

	/*
	// Create the base of the chair (well stool really)
	*/
	sgl_translate(0.0f, SeatHeight, 0.0f); 
	sgl_create_prism(SeatThickness, SeatRadius, 12, FALSE, TRUE, TRUE); 
	
	/*
	// Create the legs. I want these placed evenly about a circle,
	// so I'll use rotations to place them
	*/
	sgl_translate(0.0f, -SeatHeight/2.0f, (SeatRadius * 0.75f));
	sgl_create_prism(SeatHeight, 1.0f, 6, FALSE, FALSE, TRUE);

	sgl_translate(0.0f,  0.0f, -(SeatRadius * 0.75f));
	sgl_rotate(sgl_y_axis, PI * 0.666666f);
	sgl_translate(0.0f,  0.0f,  (SeatRadius * 0.75f));

	sgl_create_prism(SeatHeight, 1.0f, 6, FALSE, FALSE, TRUE);


	sgl_translate(0.0f,  0.0f, -(SeatRadius * 0.75f));
	sgl_rotate(sgl_y_axis, PI * 0.66666f);
	sgl_translate(0.0f,  0.0f,  (SeatRadius * 0.75f));

	sgl_create_prism(SeatHeight, 1.0f, 6, FALSE, FALSE, TRUE);

	return ChairInstance;
}
/*********************************************************
**********************************************************/
int CreateShelf()
{
	int ShelfInstance;

	ShelfInstance = sgl_create_list(TRUE, TRUE, TRUE);

	sgl_use_material_instance(Wood1Material, FALSE); 

	sgl_create_rectprism(20.0f, 2.0f, 10.0f, FALSE, TRUE);
	return ShelfInstance;
}

/*********************************************************
**********************************************************/
int CreateCandle()
{
	int CandleInstance;

	CandleInstance = sgl_create_list(TRUE, TRUE, TRUE);

	/*
	// I really don't need the candle body to cast shadows,
	// so temporarily turn them off. They'll come back on
	// when we exit this list....
	*/
	sgl_qual_generate_shadows(FALSE);

	/*
	// Hmmm really need to create a candle material, I'll use
	// all the settings of the wood but just re-define the texture
	*/
	sgl_use_material_instance(Wood1Material, FALSE);
	sgl_set_texture_map(Textures[7], FALSE, FALSE);

	sgl_translate(0.0f, 5.0f, 0.0f); 
	sgl_create_prism(10.0f, 2.0f, 5, FALSE, TRUE, TRUE);
	
	return CandleInstance;
}

/*********************************************************
**********************************************************/
int CreateFlame()
{
	int FlameInstance;

	static sgl_vector vertices[4] =
	{
		{-2.0f, 0.0f, 0.0f},
		{-2.0f, 6.0f, 0.0f},
		{ 2.0f, 6.0f, 0.0f},
		{ 2.0f, 0.0f, 0.0f},
	};

	static sgl_2d_vec uvs[4] =
	{
		{ 0.2f, 0.0f},
		{ 0.2f, 1.0f},
		{ 0.8f, 1.0f},
		{ 0.8f, 0.0f},
	};


	static int faces[1][4] = 
	{
		{0,1,2,3},
	};


	FlameInstance = sgl_create_list(TRUE, TRUE, TRUE);
	
	/*
	// Use the flame material
	*/
	sgl_use_material_instance(FlameMaterial, FALSE);

	/*
	// create the flame from a mesh - basically two quads
	// intersecting at 90 degrees
	*/
	sgl_create_mesh(FALSE);
	sgl_add_vertices (8, vertices, 
						 NULL, /*no smooth shading*/
						 uvs);

	sgl_add_face(4, faces[0]);

	return FlameInstance;
}
/*********************************************************
**********************************************************/
void CreateRoom()
{
#define EXTRA_HEIGHT (60.0f)
	/*
	// This creates 4 simple walls and one floor, using
	// a mesh
	*/
		static sgl_vector vertices[8] =
	{
		{-ROOM_WIDTH/2, -ROOM_HEIGHT/2, 			   -ROOM_WIDTH/2},
		{-ROOM_WIDTH/2,  ROOM_HEIGHT/2 + EXTRA_HEIGHT, -ROOM_WIDTH/2},
		{-ROOM_WIDTH/2,  ROOM_HEIGHT/2 + EXTRA_HEIGHT,  ROOM_WIDTH/2},
		{-ROOM_WIDTH/2, -ROOM_HEIGHT/2,  				ROOM_WIDTH/2},

		{ ROOM_WIDTH/2,  ROOM_HEIGHT/2 + EXTRA_HEIGHT,  ROOM_WIDTH/2},
		{ ROOM_WIDTH/2, -ROOM_HEIGHT/2,  				ROOM_WIDTH/2},
		{ ROOM_WIDTH/2, -ROOM_HEIGHT/2, 				-ROOM_WIDTH/2},
		{ ROOM_WIDTH/2,  ROOM_HEIGHT/2 + EXTRA_HEIGHT, 	-ROOM_WIDTH/2},
	};

	static sgl_2d_vec uvs[8] =
	{
		{ 0.0f,  0.0f}, /*0*/
		{ 0.0f, 5.0f},	/*1*/
		{5.0f, 5.0f},	/*2*/
		{5.0f,  0.0f},	/*3*/

		{ 10.0f, 5.0f}, /*4*/
		{ 10.0f, 0.0f},	/*5*/
		{ 0.0f,  5.0f}, /*6*/
		{-5.0f,  5.0f}  /*7*/

	};


	static int faces[5][4] = 
	{
		{0,1,2,3},
		{3,2,4,5},
		{7,1,0,6},
		{5,4,7,6},

		{6,0,3,5},
	};

	sgl_use_material_instance(WallMaterial, FALSE);
	/*
	// create the walls and floor from a mesh - basically 
	// 5 quads - 4 with wall material, and one using the floor
	*/
	sgl_create_mesh(FALSE);
	sgl_add_vertices (8, vertices, 
						 NULL, /*no smooth shading*/
						 uvs);

	sgl_add_face(4, faces[0]);
	sgl_add_face(4, faces[1]);
	sgl_add_face(4, faces[2]);
	sgl_add_face(4, faces[3]);

	/*
	// add a LOCAL material to the mesh. We must
	// mark it as local, or else we will terminate
	// the construction of our current mesh object.
	*/
	sgl_use_material_instance(FloorMaterial, TRUE);

	sgl_add_face(4, faces[4]);

}

/*********************************************************
**********************************************************/

void main(int argc, char **argv)
{
	int logicalDevice, viewport1;

	/*
	// The names of the various models
	*/
	int TableInstance, 
		ChairInstance,
		ShelfInstance,
		CandleInstance,
		FlameInstance;
	int CamTrans, 
		Camera1;

	int CandleLight;
	int FlameTransform;

	int NextFlameUpdate;
	int frame;


    /*
    // create screen device 0 with 640x480 screen resolution and 
    // 24 bit colour (or whatever is closest) and no double buffering.
	*/
    logicalDevice = sgl_create_screen_device(0, 
    		IMAGE_SIZE_X, IMAGE_SIZE_Y,
    		sgl_device_16bit,FALSE);	

    if (logicalDevice<0)
    {
    	fprintf(stderr,"ERROR %01d: Failed to Open Screen Device\n",logicalDevice);
        exit(1);        
    }
        
	viewport1 = sgl_create_viewport (logicalDevice, 0, 0, 640, 480,100.0f, 0.0f, 580.0f, 480.0f);
   			
	/*
	// Load up the textures we want
	*/


	LoadTextures();

	/*
	// Create a set of materials that we'll instance and re-use
	*/
	CreateMaterialInstances();


	/*
	// Create various models. We'll do these as instances simply to make
	// the main display list a bit cleaner. This requires slightly more
	// time for display list traversal, but this should insignificant.
	*/
	TableInstance = CreateTable();
	ChairInstance = CreateChair();
	ShelfInstance = CreateShelf();

	CandleInstance= CreateCandle();
	FlameInstance = CreateFlame();

	/*
	// Return to the "default" display list after creation of the various
	// instances.
	*/
	sgl_modify_list(SGL_DEFAULT_LIST, FALSE);

	/*
	// Create a camera with its own transformation matrix so that
	// we can trivially move the view point around.
	//
	*/
    sgl_create_list( UNAMED_ITEM, TRUE, FALSE );
    	
    	CamTrans = sgl_create_transform(TRUE);
    	Camera1  = sgl_create_camera(LENS_LEN,10.0f,0.0f);

		/*
		// Use "fog" to give an effect of poor/dim lighting.
		*/
		sgl_set_fog(Camera1, black, 0.01f);

    sgl_to_parent();
    
	/*
	// Set up some global lighting, and "declare" the point source light
	// which is going to be "attached" to the flame of the candle.
	*/
    sgl_create_ambient_light( UNAMED_ITEM,darkgrey, FALSE);
	sgl_create_parallel_light( UNAMED_ITEM, lightgrey, ParLightDir,NO_SHADOWS,FALSE);


    CandleLight = sgl_create_point_light(NAMED_ITEM, 
    					CandleYellow, 
						/*Direction is irrelevant here as concentration is 0*/
						zero_vector,
						/* We will use the "position light" routine and we don't need
						// any additional offset from that position
						*/
						zero_vector,
						0,	/*concentration = 0=> light goes in all directions,*/
						
						TRUE, /* Set the light to be able to generate shadows*/
						FALSE);



	/*
	// Add the shelf and the candle to the scene.
	*/
    sgl_create_list( UNAMED_ITEM, TRUE, FALSE );

		/*
		// Move from the scene origin to the "base" of the shelf
		*/
		sgl_translate(shelf_base[0], shelf_base[1], shelf_base[2]);

		/*
		// Use the shelf in the display list
		*/
		sgl_use_instance(ShelfInstance);

		/*
		// Move from the shelf base to the base of the candle
		*/
		sgl_translate(candle_base[0], candle_base[1], candle_base[2]);

		/*
		//Add the main body of the candle
		*/
		sgl_use_instance(CandleInstance);

		/*
		// Move from the base of the candle to the position of the flame
		*/
		sgl_translate(flame_base[0], flame_base[1], flame_base[2]);

		/*
		// Create a transformation that is used to animate the flame
		// itself PLUS the position of the light attached to the flame.
		// This is just a place holder... we'll define the motion later.
		*/
		FlameTransform = sgl_create_transform(NAMED_ITEM);

		sgl_position_light(CandleLight);
		sgl_use_instance(FlameInstance);

    sgl_to_parent();

	/*
	// Put in some sky and ground
	*/
	CreateSkyAndGround();


	/*
	// Create the walls and floor of the room
	*/
	CreateRoom();

	/*
	// Add the various other objects etc.
	*/
	sgl_create_list( UNAMED_ITEM, TRUE, FALSE );
		sgl_translate(table_base[0], table_base[1], table_base[2]);
		sgl_rotate(sgl_y_axis, 0.5f);
		sgl_use_instance(TableInstance);

    sgl_to_parent();

	sgl_create_list( UNAMED_ITEM, TRUE, FALSE );
		sgl_translate(chair_base[0], chair_base[1], chair_base[2]);
		sgl_use_instance(ChairInstance);

    sgl_to_parent();
 

	sgl_create_list( UNAMED_ITEM, TRUE, FALSE );
		sgl_translate(chair2_base[0], chair2_base[1], chair2_base[2]);
		sgl_rotate(sgl_y_axis, 1.3f);

		sgl_use_instance(ChairInstance);

    sgl_to_parent();

	NextFlameUpdate = 0;

	/*
	// Simply Run through a few thousand frames moving the 
	// camera and the flame about.
	*/
    for (frame = 0; frame<5100 ; frame+=ANIMATION_SPEED)
    {
		/*
		// Move the camera around
		//
		// The animation is rather simplistic
		*/
        sgl_modify_transform(CamTrans, TRUE );
		sgl_rotate(CameraAxis, 1.02f + frame * -0.001f);

		/*
		// Do some compensation for the roll of the camera
		*/
		if(frame > 2500)
		{
			sgl_rotate(sgl_z_axis, (frame - 2500) * 0.0003f);
		}

		/*
		// Move out for a few frames, then move in again
		*/
		if(frame < 2000)
		{
        	sgl_translate (0.0f, 0.0f, -(frame * 0.062f + 39.0f));
		}
		else
		{
        	sgl_translate (0.0f, 0.0f, -(2000.0f * 0.062f + 39.0f) + ((frame - 2000) * 0.018f));
		}

		/*
		// Every "N" frames, jitter the position of the light/flame.
		*/
		if(NextFlameUpdate <= frame)
		{
			sgl_vector light_col;
			float intensity;

			/*
			// Choose when next to change the flames behaviour
			*/
			NextFlameUpdate = (sgl_rand() % 6) + frame + 4;

			/*
			// Re-position the flame
			// displace vertically plus a smaller amount horizontally
			*/
			sgl_modify_transform(FlameTransform, TRUE );
			sgl_translate( 0.25f- (sgl_rand() %  500)/1000.0f, 
						    2.5f- (sgl_rand() % 5000)/1000.0f,   
						   0.25f- (sgl_rand() %  500)/1000.0f);

			/*
			// mess about with the brightness of the candle
			*/
			intensity = 1.0f - (sgl_rand() % 300)/1000.0f;
			light_col[0] = CandleYellow[0] * intensity;
			light_col[1] = CandleYellow[1] * intensity;
			light_col[2] = CandleYellow[2] * intensity;

     		sgl_set_point_light(CandleLight, 
    					light_col, 
						zero_vector,
						zero_vector,
						0,
						TRUE,
						FALSE);

			/*
			// Also change the glow of the candle to match the intensity
			*/
			light_col[0] = intensity;
			light_col[1] = intensity;
			light_col[2] = intensity;

			sgl_modify_material(FlameMaterial, FALSE);
	   		sgl_set_glow(light_col);

			/*
			// randomly choose a bit image for the flame as well
			*/
			if((sgl_rand() % 100) > 50)
			{
				sgl_set_texture_map(Textures[3], FALSE, FALSE);
			}
			else
			{
				sgl_set_texture_map(Textures[4], FALSE, FALSE);
			}
		}
		
		/*
		// Render the new image
		*/

	   sgl_render(viewport1, Camera1, TRUE);

	}/*end for*/


    /* Close down the display device in an orderly fashion */
    
    sgl_delete_device(logicalDevice);       

    exit(0);
}         

/*--------------------------- End of File --------------------------------*/
