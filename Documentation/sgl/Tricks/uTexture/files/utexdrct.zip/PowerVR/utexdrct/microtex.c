/******************************************************************************
 * Name 	: MicroTexturing
 * Title 	: PowerVR SGL Direct MicroTexturing Example
 * Author 	: Marc Pinter-Krainer
 * Created 	: February 1997
 *
 * Copyright : 1997 by VideoLogic Limited. All rights reserved.
 * : No part of this software, either material or conceptual 
 * : may be copied or distributed, transmitted, transcribed,
 * : stored in a retrieval system or translated into any 
 * : human or computer language in any form by any means,
 * : electronic, mechanical, manual or other-wise, or 
 * : disclosed to third parties without the express written
 * : permission of VideoLogic Limited, Unit 8, HomePark
 * : Industrial Estate, King's Langley, Hertfordshire,
 * : WD4 8LZ, U.K.
 *
 *
 *****************************************************************************/

#include "sgl.h"
#include "math.h"
#define RGB(r, g, b) ((sgl_uint32) (((r) << 16) | ((g) << 8) | (b)))


SGLCONTEXT	SGLContext;
SGLVERTEX	Vert[] = {
	/*  X     Y     Z  (1/W)     COLOUR       Specular COLOUR   (u/W)  (v/W) */
	{  0.0f,  0.0f,0.0f,0.1f,RGB(255,255,255),RGB(255,255,255), 0.0f,   0.0f},
	{639.0f,  0.0f,0.0f,0.1f,RGB(255,255,255),RGB(255,255,255), 0.0005f,0.0f},
	{639.0f,479.0f,0.0f,1.0f,RGB(255,255,255),RGB(255,255,255), 0.0005f,0.0005f},
	{  0.0f,479.0f,0.0f,1.0f,RGB(255,255,255),RGB(255,255,255), 0.0f,   0.0005f},
	{  0.0f,  0.0f,0.0f,0.11f,RGB(255,255,255),RGB(255,255,255),0.0f,   0.0f},
	{639.0f,  0.0f,0.0f,0.11f,RGB(255,255,255),RGB(255,255,255),0.01f,  0.0f},
	{639.0f,479.0f,0.0f,1.01f,RGB(255,255,255),RGB(255,255,255),0.01f,  0.01f},
	{  0.0f,479.0f,0.0f,1.01f,RGB(255,255,255),RGB(255,255,255),0.0f,   0.01f}
					 };
sgl_intermediate_map MM[7],*pMM[7],Tex1,Tex2;
float invW;
int vertex,frame,Device,microTex,macroTex;
int MacroLayer[][4] = {0,1,2,3};
int MicroLayer[][4] = {4,5,6,7};

int main()
{
	/************************************************************* 
		create screen device 0 with 640x480 screen resolution and
	 		16 bit colour and no double buffering 
	*************************************************************/

    Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	
	if (Device >= 0)
	{
	Tex1=	ConvertBMPtoSGL("rp.bmp", TRUE);
	Tex2=	ConvertBMPtoSGL("rf.bmp", FALSE);
	MM[0] = ConvertBMPtoSGL("rp1x1.bmp", TRUE);
	MM[1] = ConvertBMPtoSGL("rp2x2.bmp", TRUE);
	MM[2] = ConvertBMPtoSGL("rp4x4.bmp", TRUE);
	MM[3] = ConvertBMPtoSGL("rp8x8.bmp", TRUE);
	MM[4] = ConvertBMPtoSGL("rp16x16.bmp", TRUE);
	MM[5] = ConvertBMPtoSGL("rp32x32.bmp", TRUE);
	MM[6] = ConvertBMPtoSGL("rp64x64.bmp", TRUE);

	pMM[0] = &MM[0];
	pMM[1] = &MM[1];
	pMM[2] = &MM[2];
	pMM[3] = &MM[3];
	pMM[4] = &MM[4];
	pMM[5] = &MM[5];
	pMM[6] = &MM[6];

	microTex = sgl_create_texture( sgl_map_trans16_mm, sgl_map_128x128, 		
							FALSE,TRUE, &Tex1, pMM);

	macroTex = sgl_create_texture( sgl_map_16bit_mm, sgl_map_128x128, 		
							TRUE, TRUE, &Tex2,NULL);
	
	SGLContext.bFogOn=			FALSE;
	SGLContext.fFogR=			0.5f;
	SGLContext.fFogG=			0.5f;
	SGLContext.fFogB=			0.5f;
	SGLContext.u32FogDensity=	15;
	SGLContext.bCullBackfacing=	TRUE;
	
	for(frame=500;frame>8;frame--)
	{
		for(vertex=0;vertex<2;vertex++)
		{
			invW=0.1f/frame;
			Vert[vertex].fInvW=		invW/3.0f;
			Vert[vertex+2].fInvW=	invW;
			Vert[vertex+4].fInvW=	invW/3.0f+0.00001f;
			Vert[vertex+6].fInvW=	invW+0.00001f;
		}
		sgltri_startofframe (&SGLContext);
		SGLContext.nTextureName=	macroTex;
		SGLContext.u32Flags=		SGLTT_TEXTURE | SGLTT_MIPMAP;
		sgltri_quads			    (&SGLContext, 1, MacroLayer, Vert);
		SGLContext.nTextureName=	microTex;
		SGLContext.u32Flags=		SGLTT_TEXTURE | SGLTT_MIPMAP | SGLTT_GLOBALTRANS;
		SGLContext.u32GlobalTrans=	(int)(250-frame/2);
		sgltri_quads		(&SGLContext, 1, MicroLayer, Vert);
		sgltri_render		(&SGLContext);
	}

	FreeAllBMPTextures ();
	sgl_delete_device(Device);
	}
	return 1;
}
