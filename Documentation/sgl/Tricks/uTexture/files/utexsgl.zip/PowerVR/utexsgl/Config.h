#ifndef __CONFIG_H
#define __CONFIG_H

/*
// ========
// config.h
// ========
//
// For Videologic Tutorial 2 by John Catchpole.
//
// configuration
*/	    


/*
// general purpose
*/
#define PI 3.141592654f
/*
// I'd like to use X, Y, and Z but these seem to be used by Windows header
// files.
*/
#if 0
 #define X 0
 #define Y 1
 #define Z 2
#else
 #define XX 0
 #define YY 1
 #define ZZ 2
#endif

#define DEFAULT_KEY_COLOUR /*8*/0

/*
// SGL shading bug workaround
//
// NOTE: When this is fixed we can return the lights to being non-coloured.
*/
#define SHADING TRUE
#if SHADING
	#define NON_SHADED_BRIGHTNESS 1.0f/*0.2f*/
#else
	#define NON_SHADED_BRIGHTNESS 1.0f
#endif

/*
// flat shading prison bars bug workaround
*/
#define ALL_TEXTURED TRUE

/*
// SGL polling bug workaround
//
// Set FIX_FRAME_RATE TRUE if the software is taking less time than the
// hardware.
*/
#define FIX_FRAME_RATE FALSE
#define FRAME_RATE	   1.0f /* shortest frame time in seconds */

/*
// lights
*/
#define AMBIENT_SUN_COLOUR		 {0.7f, 0.7f, 0.7f}

#define SUN_COLOUR    {0.6f, 0.6f, 0.6f}
#define SUN_DIRECTION {0.0f, -1.0f, 1.0f}
#define SUN_HIGHLIGHTS FALSE

/*
// camera
*/
#define ZOOM_FACTOR 4.0f
#define FGND_DIST   1.0f
#define BGND_DIST   0.0f
#define FOG_COLOUR	{0.6f, 0.6f, 0.5f} /* yellow grey */
#define BGND_COLOUR FOG_COLOUR
#define FOG_DENSITY 2.0e-4f

/*
// scene
*/
#define SHOW_MODELS TRUE /* set FALSE to test maximum frame rate */

#define GROUND_ALTITUDE  0.0f
#define GROUND_TEXTURE_SIZE  200.0f /* 500.0f used for full flight demo */

#define SKY_ALTITUDE	 15000.0f
#define SKY_TEXTURE_SIZE 40000.0f
#define SKY_FLIP_UV		 FALSE

#define SHOW_CRAFT		  (SHOW_MODELS ? TRUE : FALSE)
#define NUM_CRAFT		  7
#define CRAFT_GROUND_Y    9.0f
#define CRAFT_SCALE		  1.5f
#define CRAFT_SHADOWS	  TRUE
#define CRAFT_SHADED_0    SHADING
#define CRAFT_SHADED_1    SHADING /* should be FALSE when bug fixed? */
#define CRAFT_SHADED_2    FALSE
#define CRAFT_TEXTURED_0  TRUE
#define CRAFT_TEXTURED_1  ALL_TEXTURED
#define CRAFT_TEXTURED_2  ALL_TEXTURED
#define CRAFT_CORNER_1	  {-10.0f, -10.0f, -10.0f}
#define CRAFT_CORNER_2    {10.0f, 10.0f, 10.0f}
#define CRAFT_THRESHOLD_1 15
#define CRAFT_THRESHOLD_2 40

#define SHOW_SPINNING_CRAFT		 (SHOW_MODELS ? TRUE : FALSE)
#define SPINNING_CRAFT_POS		 1000.0f, 50.0f, 960.0f
#define SPINNING_CRAFT_RATE		 (0.004f*PI)

/*
// run
*/
#define START_POS 0.0f, 50.0f, -100.0f
#define START_VERT_ROTATION (0.04f*PI) /* point slightly downwards */
#define ACCELERATION		0.25f /* change in distance covered per 1/100s */
#define DECELERATION		0.8f
#define MAX_SPEED			50.0f
/* TURN RATE is the turn angle per joystick radian per 1/100s. */
#define TURN_RATE			(0.08f/PI)

/*
// timer for starting successive frames
*/
#define TIMER_PERIOD 10 /* milliseconds,but minimum seems to be more like 40 */
/*
// The maximum frame rate is approximately FRAMES_PER_TIMER_CALL * 18 frames
// per second because the timer has a resolution of about 18 Hz.
*/
#define FRAMES_PER_TIMER_CALL 4

/*
// frame rate display
*/
#define FRAME_RATE_X  20
#define FRAME_RATE_Y  20
#define FRAME_RATE_FONT  "Arial"
#define FRAME_RATE_FONT_WEIGHT  FW_BOLD
#define FRAME_RATE_FONT_HEIGHT  24
#define FRAME_RATE_MESSAGE  " fps"
#define FRAME_RATE_SAMPLE_TIME  1.0f


#endif /* #ifndef __CONFIG_H */
