/******************************************************************************
 * Name 	: MicroTexturing
 * Title 	: PowerVR SGL MicroTexturing Example
 * Author 	: Marc Pinter-Krainer
 * Created 	: January 1997
 *
 * Copyright : 1997 by VideoLogic Limited. All rights reserved.
 * : No part of this software, either material or conceptual 
 * : may be copied or distributed, transmitted, transcribed,
 * : stored in a retrieval system or translated into any 
 * : human or computer language in any form by any means,
 * : electronic, mechanical, manual or other-wise, or 
 * : disclosed to third parties without the express written
 * : permission of VideoLogic Limited, Unit 8, HomePark
 * : Industrial Estate, King's Langley, Hertfordshire,
 * : WD4 8LZ, U.K.
 *
 *
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "math.h"

#include <windows.h>
#include <windowsx.h>
#include "ddraw.h"
#include "sgl.h"

#include "microtex.h"

#pragma warning (disable : 4244)
#pragma warning (disable : 4056)

#define NAMED_ITEM			TRUE
#define UNAMED_ITEM			FALSE

#define COLOUR				TRUE
#define GREY				FALSE

#define SHADOW_LIGHT		TRUE
#define NO_SHADOWS			FALSE

#define SMOOTH_SHADING		TRUE
#define NO_SMOOTH_SHADING	FALSE

#define INVISIBLE			TRUE
#define	VISIBLE			FALSE

#define	ON				TRUE
#define OFF				FALSE

#define	LENS_200MM			16.0f
#define	LENS_50MM			4.0f
#define	LENS_35MM			3.0f
#define	LENS_24MM			2.0f
#define LENS_FUN_MM			1.2f

#define PI	3.142f
#define TWOPI 	(2.0f * PI)

extern float	xpos,ypos,bxpos,bypos,bzpos,vx,vy;

float opac;
int finished=0;
int viewport1;
int logicalDevice;

int	objTex1, microTex, micromat;	
sgl_intermediate_map First,Second;
sgl_intermediate_map MM[8];
sgl_intermediate_map *pMM[8];

int	GroundTrans ,GroundTrans2,lightTran, lightMat, camTran;


static	sgl_vector	Light3Pos = {-20.0f,200.0f,50.0f};
static	sgl_vector	Light3Dir = {0.5f,-0.5f,0.5f};

static sgl_colour 	White	 =	{1.0f,1.0f,1.0f};
static sgl_colour 	black 	=	{0.0f,0.0f,0.0f};
static sgl_colour 	Yellow	=	{0.7f,0.7f,0.3f};
static sgl_colour 	SkyBlue	=	{0.5f, 0.6f, 0.9f};  
static sgl_colour	fogWhite=	{0.7f,0.7f,0.9f};
static sgl_colour	blue	=	{0.2f,0.2f,1.0f};
static sgl_colour	Red	=	{0.8f,0.1f,0.1f};
static sgl_colour	darkgrey	=	{0.25f,0.25f,0.25f};

/* variables for named items */

static	int	camera1,light1,pointLight;

static 	int frame;

sgl_2d_vec	uv1,uv2,uv3;
	

char pszTmp [120];

int SetupScene (HWND hW7nd, int xsize, int ysize, int pixdepth)
{	
	sgl_vector	ParLightDir = {-1.0f,-1.0f,1.0f};

	sgl_vector	groundPnt	= {0.0f,0.0f, 2000.0f };	
	sgl_vector	point2		= {-20.0f,0.0f, 2000.0f };	
	sgl_vector	point3		= {0.0f,0.0f, 2020.0f };	

	float	zoomFac=15.0f;
	float	cam_rect_left = 80.0f;
	float	cam_rect_top = 0.0f;
	float	cam_rect_right = 560.0f;
	float	cam_rect_bottom = 480.0f;

	int nSGLPixSize;

	/************************************************************* 
		create screen device 0 with 640x480 screen resolution and
	 		24 bit colour and no double buffering 
	*************************************************************/

	if (pixdepth > 16)
	{
		nSGLPixSize = sgl_device_24bit;
	}
	else
	{
		nSGLPixSize = sgl_device_16bit;
	}

	logicalDevice = sgl_create_screen_device (0, xsize, (ysize-1), nSGLPixSize, TRUE);
	
	if (logicalDevice<0)
	{
		sprintf(pszTmp,"ERROR %01d: Failed to Open Screen Device\n",logicalDevice);
		OutputDebugString(pszTmp);
		return ERR_CREATE_SCREEN_DEVICE;
	}

	/**************************************************************
		   	    set the viewport for the opened device  
	**************************************************************/
 	switch (ysize)
	{
		/* 800x600 */
		case 600:
		{
			cam_rect_left = 80.0f;
			cam_rect_top = 0.0f;		  	
			cam_rect_right = 560.0f;
			cam_rect_bottom = 480.0f;
			break;
		}
		
		/* 640x480 */
		case 480:
		{
			cam_rect_left = 80.0f;
			cam_rect_top = 0.0f;
			cam_rect_right = 560.0f;
			cam_rect_bottom = 480.0f;
			break;
		}
		
		/* 600x400 */
		case 400:
		{
			cam_rect_left = 80.0f;
			cam_rect_top = 0.0f;
			cam_rect_right = 560.0f;
			cam_rect_bottom = 480.0f;
			break;
		}
		
		/* 320x240 */
		case 240:
		{
			cam_rect_left = 100.0f;
			cam_rect_top = 100.0f;
			cam_rect_right = 300.0f;
			cam_rect_bottom = 300.0f;
			break;
		}
	}

	viewport1 = sgl_create_viewport (logicalDevice,
									 0, 0, xsize, (ysize-1),
									 cam_rect_left, cam_rect_top, cam_rect_right, cam_rect_bottom);
   	if (viewport1<0)
	{
		sprintf(pszTmp,"ERROR %01d: Failed to Create Viewport\n",viewport1);
		OutputDebugString(pszTmp);
		return ERR_CREATE_VIEWPORT;
	}

	/**************************************************************
			  load up and assign names to textures 
	**************************************************************/		  
	First = ConvertBMPtoSGL("water.bmp", TRUE);
	Second = ConvertBMPtoSGL("ocean.bmp", FALSE);

	MM[0] = ConvertBMPtoSGL("water1x1.bmp", TRUE);
	MM[1] = ConvertBMPtoSGL("water2x2.bmp", TRUE);
	MM[2] = ConvertBMPtoSGL("water4x4.bmp", TRUE);
	MM[3] = ConvertBMPtoSGL("water8x8.bmp", TRUE);
	MM[4] = ConvertBMPtoSGL("water16x16.bmp", TRUE);
	MM[5] = ConvertBMPtoSGL("water32x32.bmp", TRUE);
	MM[6] = ConvertBMPtoSGL("water64x64.bmp", TRUE);
	MM[7] = ConvertBMPtoSGL("water128x128.bmp",TRUE);

	pMM[0] = &MM[0];
	pMM[1] = &MM[1];
	pMM[2] = &MM[2];
	pMM[3] = &MM[3];
	pMM[4] = &MM[4];
	pMM[5] = &MM[5];
	pMM[6] = &MM[6];
	pMM[7] = &MM[7];

	microTex = sgl_create_texture( sgl_map_trans16_mm, sgl_map_256x256, 		
							FALSE,TRUE, &First, pMM);


	objTex1 = sgl_create_texture( sgl_map_16bit, sgl_map_128x128, 		
							FALSE, TRUE, &Second,  NULL);



  	/*************************************************************
				 Create lights
	 *************************************************************/
	sgl_qual_texture_filter (sgl_tf_bilinear);  /* Sets Bilinear Filtering */

   	
   	sgl_create_ambient_light (UNAMED_ITEM,White, FALSE); 
															  

	
	light1 = sgl_create_parallel_light( NAMED_ITEM, darkgrey, 				
						ParLightDir,NO_SHADOWS,FALSE);
															

	pointLight  = sgl_create_point_light( NAMED_ITEM, White, 				
					Light3Dir,Light3Pos,0,SHADOW_LIGHT,TRUE);

	/**************************************************************
	  			      Set up camera
	**************************************************************/

	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);

		/* the following transform is used to animate to camera */

		camTran = sgl_create_transform(TRUE);
		sgl_translate(0.0f,20.0f,0.0f);
		sgl_rotate(sgl_x_axis,0.1f);
		camera1 = sgl_create_camera(LENS_50MM,10.0f,0.0f);

	sgl_to_parent();

	sgl_set_fog(camera1, fogWhite, 0.001f);
	sgl_set_background_colour(camera1,fogWhite);


	/************* Add the microtextured Ground **************/

	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);

		uv1[0]=0.0f;
		uv1[1]=0.0f;
		uv2[0]=0.0f;
		uv2[1]=0.3f;
		uv3[0]=0.3f;
		uv3[1]=0.0f;

		GroundTrans = sgl_create_transform(TRUE); 
		sgl_set_diffuse(White); 
		sgl_set_texture_effect(TRUE,TRUE,TRUE,FALSE);
		sgl_set_texture_map(objTex1,FALSE,FALSE);
		sgl_rotate(sgl_y_axis,-0.3f);
		sgl_add_plane(groundPnt,point2,point3, VISIBLE, 				
						NULL,NULL,NULL,uv1,uv2,uv3);


	sgl_to_parent();

	sgl_create_list(UNAMED_ITEM,TRUE,FALSE);

		uv1[0]=0.0f;
		uv1[1]=0.0f;
		uv2[0]=0.0f;
		uv2[1]=2.0f;
		uv3[0]=2.0f;
		uv3[1]=0.0f;
		GroundTrans2 = sgl_create_transform(TRUE); 
		micromat=sgl_create_material (TRUE,FALSE);
		  sgl_set_diffuse(White); 
		  sgl_set_opacity(1.1f);
		  sgl_set_texture_effect(TRUE,TRUE,TRUE,FALSE);
		  sgl_set_texture_map(microTex,FALSE,FALSE);

		sgl_translate(0.0f,0.1f,0.0f);
		sgl_rotate(sgl_y_axis,0.5f);
		sgl_add_plane(groundPnt,point2,point3, VISIBLE, 				
						NULL,NULL,NULL,uv1,uv2,uv3); 


	sgl_to_parent();

  	frame = 0;
	return 0;
}



void NextFrame()
{

	/*********************************************************
	 	 		Animate Scene	   		   		
	*********************************************************/

	if (frame>1500) 
	{
		frame=0;
	}

	/*******************  Modify Transparency **************/

	sgl_modify_material(micromat,FALSE);
	sgl_set_opacity(((255.0f-ypos)/1000.0f)+0.7f);

	/*******************  animate the camera ***************/	

	sgl_modify_transform(camTran, TRUE);	
	sgl_translate(0.0f,ypos,xpos);
	sgl_rotate(sgl_x_axis,0.8f);

    /*********** Render image seen from camera2 to viewport 1 ********/

   	sgl_render(viewport1, camera1, TRUE);


	frame++;

}

void Finish()
{
	if(!finished)
	{
		/**************** Close down the display device in an orderly fashion **************/
		FreeAllBMPTextures ();

		sgl_delete_device(logicalDevice);	
		finished=1;
	}

}	  

					   

/*--------------------------- End of File --------------------------------*/

