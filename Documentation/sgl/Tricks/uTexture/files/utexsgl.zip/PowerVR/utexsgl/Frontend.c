/*
// FRONTEND.C
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <windows.h>
#include <mmsystem.h> 

#include "ddraw.h"
#include "sgl.h"


#include "config.h"
#include "frontend.h"
#include "resource.h"
#include "microtex.h"


#define NAME "MicroTexturing"
#define TITLE "MicroTex using DirectDraw"

/*
// ============================================================================
// 									GLOBALS
// ============================================================================
*/

GLOBALVARS 			globalVars;
static HINSTANCE  	hInst;
static HWND  		hWnd;
BOOL				bActive;
DWORD 				LastError;
BOOL 				bInfo=0;
sgl_versions*		versions;
sgl_win_versions*	w32versions;
BOOL				bQuit=FALSE;
int					nStrictLocks;
BOOL				bDisplayFPS=FALSE;
float				vx,vy,xpos,ypos;

static char * szCmdLine;
static char delimiters[] = " ,\t\n";
static char *token;
static char szTmp[80];
static int xsize = 0;
static int ysize = 0;
static int pixsize = 0;

/* Callback prototype */
int sgl_2d_callback(P_CALLBACK_SURFACE_PARAMS lpSurfaceInfo);
int eor_callback();

/******************************************************************************
 * WinMain()
 *****************************************************************************/
int PASCAL WinMain ( HANDLE hInstance,
					 HANDLE hPrevInstance,
					 LPSTR  lpszCmdParam,
					 int    nCmdShow )
{
	static char szAppName[] = "SGLFrontEnd";
	HWND        hwnd;
	MSG         msg;
	WNDCLASS    wndclass;
	HMENU       hMenu;
	LOGBRUSH    brush;
	int			iret;
	int			loopcount;
	int			i;

	/* Detect command line params, look for display size */
	szCmdLine = GetCommandLine();

	/* Establish string and get the first token: */
	token = strtok (szCmdLine, delimiters);

	while (token != NULL) /* While there are tokens in the command line */
	{
		/* Look for integers on the command line */
		if (sscanf(token, "%d", &i) == 1)
		{
			/* Assign the fist integer to x, the second to y */
			if (xsize == 0)
			{
				xsize = i;
				sprintf (szTmp, "X size = %d\n", xsize);
				OutputDebugString (szTmp);
			}
			else
			{
				if (ysize == 0)
				{
					ysize = i;
					sprintf (szTmp, "Y size = %d\n", ysize);
					OutputDebugString (szTmp);
				}
				else
				{
					if (pixsize == 0)
					{
						pixsize = i;
						sprintf (szTmp, "pixel size = %d\n", pixsize);
						OutputDebugString (szTmp);
					}
				}
			}
		}

		/* Get next token: */
		token = strtok (NULL, delimiters);
	}

	if (ysize == 0 || xsize == 0)
	{
		xsize = 640;
		ysize = 480;
	}
	
	if (pixsize == 0)
	{
		pixsize = 16;
	}
	
	/* Get Version info */
	versions = sgl_get_versions();
	w32versions = sgl_get_win_versions();

	/* setup inital values */
	hInst = hInstance;

	brush.lbStyle = BS_SOLID;
	brush.lbColor = PALETTEINDEX(DEFAULT_KEY_COLOUR);

	/* set the key value for overlay */
	globalVars.hBrush    = CreateBrushIndirect(&brush);
	globalVars.keyColour = DEFAULT_KEY_COLOUR;
	

	/*
	// =========================
	// WINDOWS APPLICATION STUFF
	// =========================
	*/
	if (!hPrevInstance)
	{
		wndclass.style = 0 /*CS_HREDRAW | CS_VREDRAW*/;
	    wndclass.lpfnWndProc = WndProc;
	    wndclass.cbClsExtra = 0;
	    wndclass.cbWndExtra = 0;
	    wndclass.hInstance = hInstance;
	    wndclass.hIcon = LoadIcon( hInstance, IDI_APPLICATION );
	    wndclass.hCursor = LoadCursor( NULL, IDC_ARROW );
	    wndclass.hbrBackground = NULL;
	    wndclass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	    wndclass.lpszClassName = NAME;
		RegisterClass (&wndclass);
	}

	hMenu = LoadMenu(hInstance,MAKEINTRESOURCE(IDR_MENU1));

    hwnd = CreateWindowEx(WS_EX_TOPMOST,
				    NAME,
				    TITLE,
				    WS_POPUP|WS_VISIBLE,
				    0, 0,
				    GetSystemMetrics( SM_CXSCREEN ),
				    GetSystemMetrics( SM_CYSCREEN ),
				    NULL,
				    hMenu,
				    hInstance,
				    NULL );

	if (hwnd == NULL)
	{
		LastError = GetLastError();
		return FALSE;
	}

	Sleep(200);

	sgl_get_ini_int (&nStrictLocks, 0, "Default","StrictLocks");

	/* Put sgl into direct draw mode */
	iret =  sgl_use_ddraw_mode (hwnd, &sgl_2d_callback);
	if (iret !=	sgl_no_err)
	{
		ShowWindow(hwnd,SW_HIDE);
		MessageBox(NULL,"ERROR : sgl_use_ddraw_mode failed","microtex",MB_OK);
		DestroyWindow(hwnd);
		return FALSE;
	}

	/*
	   Set up the SGL scene
	*/
	vx=0.2f;
	vy=-0.3f;
	xpos=0.0f;
	ypos=240.0f;

	iret = SetupScene(hwnd, xsize, ysize, pixsize);

	if (iret !=	sgl_no_err)
	{
		if (iret == ERR_CREATE_SCREEN_DEVICE)
		{
			MessageBox(NULL,"sgl_create_screen_device\n\nERROR : Graphics device does not support required direct draw mode","tower4.exe",MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
		}
		
		if (iret == ERR_CREATE_VIEWPORT)
		{
			MessageBox(NULL,"sgl_create_viewport\n\nERROR : Graphics device does not support required direct draw mode","tower4.exe",MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
		}

		DestroyWindow(hwnd);
		return FALSE;
	}


	bActive = TRUE;

	if (nStrictLocks)
	{
		loopcount = 100;

		/*
			Do normal message loop for a while to
			allow GDI to draw the window
		*/
		while (loopcount--)
	    {
	      	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	        {
	            if (!GetMessage( &msg, NULL, 0, 0 ))
	            {
	                return msg.wParam;
	            }

	            TranslateMessage(&msg); 
	            DispatchMessage(&msg);
	        }
	    }

		/* Do main message loop inside the callback */
		iret = sgl_use_eor_callback(&eor_callback);

		while (!bQuit)
		{
		   	NextFrame();
		}

		Sleep(100);
		Finish();
	}
	else
	{
		/* Strict locking is off, so use normal message loop */
		while (1)
	    {
	      	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	        {

	            if (!GetMessage( &msg, NULL, 0, 0 ))
	            {
					Finish();
					break;
	                /* return msg.wParam; */
	            }

	            TranslateMessage(&msg); 
	            DispatchMessage(&msg);
	        }
	        else if (bActive)
	        {
				xpos=xpos+vx;
				ypos=ypos+vy;
				if(ypos<=9.0f)
				{
					ypos=9.0f;
					vy=0.0f;
				}
				if(ypos>255.0f)
				{
					ypos=255.0f;
					vy=0.0f;
				}

	            NextFrame();
	        }
			else
			{
				WaitMessage();
			}
	    }
	}

	return 0;
}

/*
	End of render callback.
	As soon as the buffer is unlocked then Windows can process
	it's message loop.
	If this were not done here then Windows would wait for the Direct
	Draw unlock before updating it's display; and we wan't to remove
	all wait states !
	
*/
int eor_callback()
{
	MSG         msg;

	while(1)
	{
	  	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ))
	    {
	        if (!GetMessage( &msg, NULL, 0, 0 ))
	        {
				/* Application closing down */
				bQuit = TRUE;

				/* Prevent sgl from rendering */
	            return 1;
	        }

	        TranslateMessage(&msg); 
	        DispatchMessage(&msg);
	    }

		Sleep(10); /* Allow the mouse some time to move */

		if (bActive)
		{
			break; /* If active then continue to render */	
		}
	}

	return 0; /* Continue with sgl_render */

}/*eor_callback*/



/*
	2d callback, called during sgl_render
	just before frame becomes visible
*/
int sgl_2d_callback(P_CALLBACK_SURFACE_PARAMS lpSurfaceInfo)
{
    HDC                 hdc;
    HRESULT             hr = FALSE;
	char				pszTmp [120];
	int					nYPos;
	int					nGap;
	DWORD				dwNowTime;
	DWORD				dwRunTime;
	float				fFrameRate;

	static int			count = 0;
	static BOOL			bInitStartTime=TRUE;
	static DWORD		dwStartTime;

	dwNowTime = timeGetTime();

	if (bInitStartTime)
	{
		dwStartTime = dwNowTime;
		bInitStartTime = FALSE;
	}

	dwRunTime = dwNowTime - dwStartTime;

	if (dwRunTime)
	{
		fFrameRate 	= ((float)count * 1000.0f) / (float) dwRunTime;
	}
	else
	{
	 	fFrameRate 	= 0.0f;
	}

	if (lpSurfaceInfo->p3DSurfaceObject != NULL)
	{
		if (IDirectDrawSurface_GetDC(lpSurfaceInfo->p3DSurfaceObject, &hdc) == DD_OK)
	    {
			 SetBkMode(hdc, TRANSPARENT);
		     SetBkColor( hdc, RGB( 0, 0, 255 ) );
		     SetTextColor( hdc, RGB( 255, 255, 0 ) );

			 if (bDisplayFPS)
			 {
			 	sprintf(pszTmp, "Frame %06d,  %.1f FPS  MicroTexturing PowerSGL Example (c) VideoLogic Ltd", count, fFrameRate);
			 }
			 else
			 {
			 	sprintf(pszTmp, "MicroTexturing PowerSGL Example                       press F12 to exit");
			 }

	     	 TextOut( hdc, 50, 10, pszTmp, lstrlen(pszTmp) );

			 if (bInfo)
			 {
			 	nYPos = 100;
				nGap = 20;

			 	sprintf(pszTmp, "SGL DLL Version = %s", versions->library);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "SGL API Version = %s", versions->required_header);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "SGL VXD Version = %s", w32versions->sgl_vxd_rev);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "SGLWin32 API Version = %s", w32versions->required_sglwin32_header);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "PCI Bridge Vendor ID = %s", w32versions->pci_bridge_vendor_id);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "PCI Bridge Device ID = %s", w32versions->pci_bridge_device_id);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "PCI Bridge Revision = %s", w32versions->pci_bridge_rev);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "PCI Bridge IRQ = %s", w32versions->pci_bridge_irq);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "PCI Bridge IO Base = %s", w32versions->pci_bridge_io_base);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "TSP Revision = %s", w32versions->tsp_rev);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "TSP Memory = %s (MB)", w32versions->tsp_mem_size);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

			 	sprintf(pszTmp, "ISP Revision = %s", w32versions->isp_rev);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

				sprintf(pszTmp, "ypos = %f", ypos);
	     	 	TextOut( hdc, 50, nYPos, pszTmp, lstrlen(pszTmp) );
				nYPos+=nGap;

				if (w32versions->build_info[0])
				{
				 	sprintf (pszTmp, "SGL Build info : %s", w32versions->build_info);
		     	 	TextOut (hdc, 50, nYPos, pszTmp, lstrlen(pszTmp));
					nYPos+=nGap;
				}
			 }

			 count++;
		     IDirectDrawSurface_ReleaseDC(lpSurfaceInfo->p3DSurfaceObject,hdc);

			 hr = TRUE;
	    }
	}

    return 0;
}




/*
// =======
// WndProc
// =======
*/
long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam)
{

	hWnd = hwnd;

	switch (message)
	{
	    case WM_ACTIVATEAPP:
		{
	        bActive = (BOOL)wParam;
	        break;
		}
		
		case WM_CREATE:
		{
			return 0;
		}

		case WM_DESTROY:
		{
			bQuit = TRUE;
			/* Finish(); */
			PostQuitMessage (0);
			return 0;
		}

	    case WM_KEYDOWN:
		{
	        switch(wParam)
	        {
				/* Arrow Keys to accelerate in x,y direction */
				case VK_LEFT:
				{
					vx = (vx - 0.1f);
					break;
				}
				case VK_RIGHT:
				{
					vx = (vx + 0.1f);
					break;
				}
				case VK_UP:
				{
					vy = (vy + 0.1f);
					break;
				}
				case VK_DOWN:
				{
					vy = (vy - 0.1f);
					break;
				}
  
				/* f12 to quit */
		        case VK_F12:
				{
					bActive = FALSE;/* This interlock fixed the hanging bug !!!! */

					/* Wait for main message loop to see bActive going low */
					Sleep(100);
							
		            PostMessage(hWnd, WM_CLOSE, 0, 0);
		            break;
				}

				/* f1 for info */
		        case VK_F1:
				{
					/* Get Version/Status info again */
					versions = sgl_get_versions();
					w32versions = sgl_get_win_versions();

					/* Display version info in 2d callback */
					bInfo = !bInfo;
		            break;
				}

				/* f2 for FPS */
		        case VK_F2:
				{
					/* Display FPS in 2d callback */
					bDisplayFPS = !bDisplayFPS;
		            break;
				}
	        }
	        break;
		}
	}

	return DefWindowProc (hwnd, message, wParam, lParam);
}



/* EOF */
