/*==========================================================================
 *
 *  Copyright (C) 1995, 1996 Microsoft Corporation. All Rights Reserved.
 *
 *  File: imfog.c
 *
 ***************************************************************************/

#include <math.h>
#include <d3d.h>
#include "d3ddemo.h"

static D3DEXECUTEDATA d3dExData;
static LPDIRECT3DEXECUTEBUFFER lpD3DExBuf;
LPDIRECT3DMATERIAL lpBmat, lpMat1;

#define NUM_VERTICES  36
#define NUM_TRIANGLES 12
#define OFFSETX       0.0
#define OFFSETY       0.0
#define CLIP_MODE     D3DEXECUTE_CLIPPED

#define D3DTRY(x) if (FAILED(x)) goto generic_error

// STATE_DATA_FLOAT size: 8 (sizeof D3DSTATE)
#define STATE_DATA_FLOAT(type, arg, ptr) \
    ((LPD3DSTATE) ptr)->drstRenderStateType = (D3DRENDERSTATETYPE)type; \
    (float)((LPD3DSTATE) ptr)->dwArg[0] = arg;\
    ptr = (void *)(((LPD3DSTATE) ptr) + 1)


void
OverrideDefaults(Defaults* defaults)
{
    lstrcpy(defaults->Name, "Immediate Mode Fog Example");
    defaults->rs.bPerspCorrect = FALSE;
    defaults->bResizingDisabled = TRUE;
}

BOOL
RenderScene(LPDIRECT3DDEVICE lpDev, LPDIRECT3DVIEWPORT lpView,
            LPD3DRECT lpExtent)
{
    /*
     * Execute the instruction buffer
     */
    if (lpDev->lpVtbl->BeginScene(lpDev) != D3D_OK)
        return FALSE;
    if (lpDev->lpVtbl->Execute(lpDev, lpD3DExBuf,
                               lpView, CLIP_MODE) != D3D_OK)
        return FALSE;
    if (lpDev->lpVtbl->EndScene(lpDev) != D3D_OK)
        return FALSE;
    if (lpD3DExBuf->lpVtbl->GetExecuteData(lpD3DExBuf, &d3dExData) != D3D_OK)
        return FALSE;
    *lpExtent = d3dExData.dsStatus.drExtent;
    return TRUE;
     
   
}

void
ReleaseScene(void)
{
    return;
}

void
ReleaseView(LPDIRECT3DVIEWPORT lpView)
{
    lpView;
    RELEASE(lpD3DExBuf);
    RELEASE(lpMat1);
    RELEASE(lpBmat);
}

BOOL
InitScene(void)
{
    return TRUE;
}

BOOL
InitViewImmediate(LPDIRECTDRAW lpDD, LPDIRECT3D lpD3D, LPDIRECT3DDEVICE lpDev,
				  LPDIRECT3DVIEWPORT lpView, int NumTextures,
				  LPD3DTEXTUREHANDLE TextureHandle)
{
    LPVOID lpBufStart, lpInsStart, lpPointer;
    D3DEXECUTEBUFFERDESC debDesc;
    size_t size;
    D3DTLVERTEX src_v[NUM_VERTICES];
    int t[8][3] = {
        0, 1, 2,
    };
    D3DMATERIAL bmat, mat;
    D3DMATERIALHANDLE hBmat, hMat1;

    if (lpD3D->lpVtbl->CreateMaterial(lpD3D, &lpBmat, NULL) != D3D_OK) {
        return FALSE;
    }
    memset(&bmat, 0, sizeof(D3DMATERIAL));
    bmat.dwSize = sizeof(D3DMATERIAL);
    bmat.diffuse.r = (D3DVALUE)1.0;
    bmat.diffuse.g = (D3DVALUE)1.0;
    bmat.diffuse.b = (D3DVALUE)1.0;
    bmat.ambient.r = (D3DVALUE)1.0;
    bmat.ambient.g = (D3DVALUE)1.0;
    bmat.ambient.b = (D3DVALUE)1.0;
	bmat.hTexture = TextureHandle[0];


    bmat.dwRampSize = 1;
    lpBmat->lpVtbl->SetMaterial(lpBmat, &bmat);
    lpBmat->lpVtbl->GetHandle(lpBmat, lpDev, &hBmat);
    /*lpView->lpVtbl->SetBackground(lpView, hBmat);*/

    if (lpD3D->lpVtbl->CreateMaterial(lpD3D, &lpMat1, NULL) != D3D_OK) {
        return FALSE;
    }
    memset(&mat, 0, sizeof(D3DMATERIAL));
    mat.dwSize = sizeof(D3DMATERIAL);
    mat.diffuse.r = (D3DVALUE)1.0;
    mat.diffuse.g = (D3DVALUE)1.0;
    mat.diffuse.b = (D3DVALUE)1.0;
    mat.ambient.r = (D3DVALUE)1.0;
    mat.ambient.g = (D3DVALUE)1.0;
    mat.ambient.b = (D3DVALUE)1.0;
#define SPECULAR
#ifdef SPECULAR
    mat.specular.r = (D3DVALUE)1.0;
    mat.specular.g = (D3DVALUE)1.0;
    mat.specular.b = (D3DVALUE)1.0;
    mat.power = (float)40.0;
#else
    mat.specular.r = (D3DVALUE)0.0;
    mat.specular.g = (D3DVALUE)0.0;
    mat.specular.b = (D3DVALUE)0.0;
    mat.power = (float)0.0;
#endif    
    
    mat.hTexture = TextureHandle[1];
	mat.dwRampSize = 16;
    lpMat1->lpVtbl->SetMaterial(lpMat1, &mat);
    lpMat1->lpVtbl->GetHandle(lpMat1, lpDev, &hMat1);
    /*
     * Setup vertices
     */
    memset(&src_v[0], 0, sizeof(D3DVERTEX) * NUM_VERTICES);
	src_v[0].sx = D3DVAL(30.0+OFFSETX);
    src_v[0].sy = D3DVAL(160.0+OFFSETY);
    src_v[0].sz = D3DVAL(1.0);
    src_v[0].rhw = D3DVAL(1.0);
    src_v[0].color = RGBA_MAKE(255,255,255, 255);
    src_v[0].specular = RGB_MAKE(0, 0, 0);

    src_v[1].sx = D3DVAL(30.0+OFFSETX);
    src_v[1].sy = D3DVAL(60.0+OFFSETY);
    src_v[1].sz = D3DVAL(1.0);
    src_v[1].rhw = D3DVAL(1.0);
    src_v[1].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[1].specular = RGB_MAKE(0, 0, 0);

    src_v[2].sx = D3DVAL(80.0+OFFSETX);
    src_v[2].sy = D3DVAL(60.0+OFFSETY);
    src_v[2].sz = D3DVAL(1.0);
    src_v[2].rhw = D3DVAL(1.0);
    src_v[2].color = RGBA_MAKE(255,255,255, 255);
    src_v[2].specular = RGB_MAKE(0, 0, 0);

    src_v[3].sx = D3DVAL(30.0+OFFSETX);
    src_v[3].sy = D3DVAL(160.0+OFFSETY);
    src_v[3].sz = D3DVAL(1.0);
    src_v[3].rhw = D3DVAL(1.0);
    src_v[3].color = RGBA_MAKE(255,255,255, 255);
    src_v[3].specular = RGB_MAKE(0, 0, 0);

    src_v[4].sx = D3DVAL(80.0+OFFSETX);
    src_v[4].sy = D3DVAL(60.0+OFFSETY);
    src_v[4].sz = D3DVAL(1.0);
    src_v[4].rhw = D3DVAL(1.0);
    src_v[4].color = RGBA_MAKE(255,255,255, 255);
    src_v[4].specular = RGB_MAKE(0, 0, 0);

    src_v[5].sx = D3DVAL(80.0+OFFSETX);
    src_v[5].sy = D3DVAL(160.0+OFFSETY);
    src_v[5].sz = D3DVAL(1.0);
    src_v[5].rhw = D3DVAL(1.0);
    src_v[5].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[5].specular = RGB_MAKE(0, 0, 0);


	src_v[6].sx = D3DVAL(80.0+OFFSETX);
    src_v[6].sy = D3DVAL(160.0+OFFSETY);
    src_v[6].sz = D3DVAL(0.8);
    src_v[6].rhw = D3DVAL(0.8);
    src_v[6].color = RGBA_MAKE(255,255,255, 255);
    src_v[6].specular = RGB_MAKE(0, 0, 0);

    src_v[7].sx = D3DVAL(80.0+OFFSETX);
    src_v[7].sy = D3DVAL(60.0+OFFSETY);
    src_v[7].sz = D3DVAL(0.8);
    src_v[7].rhw = D3DVAL(0.8);
    src_v[7].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[7].specular = RGB_MAKE(0, 0, 0);

    src_v[8].sx = D3DVAL(130.0+OFFSETX);
    src_v[8].sy = D3DVAL(60.0+OFFSETY);
    src_v[8].sz = D3DVAL(0.8);
    src_v[8].rhw = D3DVAL(0.8);
    src_v[8].color = RGBA_MAKE(255,255,255, 255);
    src_v[8].specular = RGB_MAKE(0, 0, 0);
  
    src_v[9].sx = D3DVAL(80.0+OFFSETX);
    src_v[9].sy = D3DVAL(160.0+OFFSETY);
    src_v[9].sz = D3DVAL(0.8);
    src_v[9].rhw = D3DVAL(0.8);
    src_v[9].color = RGBA_MAKE(255,255,255, 255);
    src_v[9].specular = RGB_MAKE(0, 0, 0);

	src_v[10].sx = D3DVAL(130.0+OFFSETX);
    src_v[10].sy = D3DVAL(60.0+OFFSETY);
    src_v[10].sz = D3DVAL(0.8);
    src_v[10].rhw = D3DVAL(0.8);
    src_v[10].color = RGBA_MAKE(255,255,255, 255);
    src_v[10].specular = RGB_MAKE(0, 0, 0);

    src_v[11].sx = D3DVAL(130.0+OFFSETX);
    src_v[11].sy = D3DVAL(160.0+OFFSETY);
    src_v[11].sz = D3DVAL(0.8);
    src_v[11].rhw = D3DVAL(0.8);
    src_v[11].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[11].specular = RGB_MAKE(0, 0, 0);

    src_v[12].sx = D3DVAL(130.0+OFFSETX);
    src_v[12].sy = D3DVAL(160.0+OFFSETY);
    src_v[12].sz = D3DVAL(0.6);
    src_v[12].rhw = D3DVAL(0.6);
    src_v[12].color = RGBA_MAKE(255,255,255, 255);
    src_v[12].specular = RGB_MAKE(0, 0, 0);

	src_v[13].sx = D3DVAL(130.0+OFFSETX);
    src_v[13].sy = D3DVAL(60.0+OFFSETY);
    src_v[13].sz = D3DVAL(0.6);
    src_v[13].rhw = D3DVAL(0.6);
    src_v[13].color = RGBA_MAKE(255,255,255, 255);
    src_v[13].specular = RGB_MAKE(0, 0, 0);

    src_v[14].sx = D3DVAL(180.0+OFFSETX);
    src_v[14].sy = D3DVAL(60.0+OFFSETY);
    src_v[14].sz = D3DVAL(0.6);
    src_v[14].rhw = D3DVAL(0.6);
    src_v[14].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[14].specular = RGB_MAKE(0, 0, 0);

    src_v[15].sx = D3DVAL(130.0+OFFSETX);
    src_v[15].sy = D3DVAL(160.0+OFFSETY);
    src_v[15].sz = D3DVAL(0.6);
    src_v[15].rhw = D3DVAL(0.6);
    src_v[15].color = RGBA_MAKE(255,255,255, 255);
    src_v[15].specular = RGB_MAKE(0, 0, 0);

	src_v[16].sx = D3DVAL(180.0+OFFSETX);
    src_v[16].sy = D3DVAL(60.0+OFFSETY);
    src_v[16].sz = D3DVAL(0.6);
    src_v[16].rhw = D3DVAL(0.6);
    src_v[16].color = RGBA_MAKE(255,255,255, 255);
    src_v[16].specular = RGB_MAKE(0, 0, 0);

    src_v[17].sx = D3DVAL(180.0+OFFSETX);
    src_v[17].sy = D3DVAL(160.0+OFFSETY);
    src_v[17].sz = D3DVAL(0.6);
    src_v[17].rhw = D3DVAL(0.6);
    src_v[17].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[17].specular = RGB_MAKE(0, 0, 0);

	src_v[18].sx = D3DVAL(180.0+OFFSETX);
    src_v[18].sy = D3DVAL(160.0+OFFSETY);
    src_v[18].sz = D3DVAL(0.4);
    src_v[18].rhw = D3DVAL(0.4);
    src_v[18].color = RGBA_MAKE(255,255,255, 255);
    src_v[18].specular = RGB_MAKE(0, 0, 0);

    src_v[19].sx = D3DVAL(180.0+OFFSETX);
    src_v[19].sy = D3DVAL(60.0+OFFSETY);
    src_v[19].sz = D3DVAL(0.4);
    src_v[19].rhw = D3DVAL(0.4);
    src_v[19].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[19].specular = RGB_MAKE(0, 0, 0);

    src_v[20].sx = D3DVAL(230.0+OFFSETX);
    src_v[20].sy = D3DVAL(60.0+OFFSETY);
    src_v[20].sz = D3DVAL(0.4);
    src_v[20].rhw = D3DVAL(0.4);
    src_v[20].color = RGBA_MAKE(255,255,255, 255);
    src_v[20].specular = RGB_MAKE(0, 0, 0);

    src_v[21].sx = D3DVAL(180.0+OFFSETX);
    src_v[21].sy = D3DVAL(160.0+OFFSETY);
    src_v[21].sz = D3DVAL(0.4);
    src_v[21].rhw = D3DVAL(0.4);
    src_v[21].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[21].specular = RGB_MAKE(0, 0, 0);

    src_v[22].sx = D3DVAL(230.0+OFFSETX);
    src_v[22].sy = D3DVAL(60.0+OFFSETY);
    src_v[22].sz = D3DVAL(0.4);
    src_v[22].rhw = D3DVAL(0.4);
    src_v[22].color = RGBA_MAKE(255,255,255, 255);
    src_v[22].specular = RGB_MAKE(0, 0, 0);

	src_v[23].sx = D3DVAL(230.0+OFFSETX);
    src_v[23].sy = D3DVAL(160.0+OFFSETY);
    src_v[23].sz = D3DVAL(0.4);
    src_v[23].rhw = D3DVAL(0.4);
    src_v[23].color = RGBA_MAKE(255,255,255, 255);
    src_v[23].specular = RGB_MAKE(0, 0, 0);

    src_v[24].sx = D3DVAL(230.0+OFFSETX);
    src_v[24].sy = D3DVAL(160.0+OFFSETY);
    src_v[24].sz = D3DVAL(0.2);
    src_v[24].rhw = D3DVAL(0.2);
    src_v[24].color = RGBA_MAKE(255,255,255, 255);
    src_v[24].specular = RGB_MAKE(0, 0, 0);

	src_v[25].sx = D3DVAL(230.0+OFFSETX);
    src_v[25].sy = D3DVAL(60.0+OFFSETY);
    src_v[25].sz = D3DVAL(0.2);
    src_v[25].rhw = D3DVAL(0.2);
    src_v[25].color = RGBA_MAKE(255,255,255, 255);
    src_v[25].specular = RGB_MAKE(0, 0, 0);

    src_v[26].sx = D3DVAL(280.0+OFFSETX);
    src_v[26].sy = D3DVAL(60.0+OFFSETY);
    src_v[26].sz = D3DVAL(0.2);
    src_v[26].rhw = D3DVAL(0.2);
    src_v[26].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[26].specular = RGB_MAKE(0, 0, 0);


	src_v[27].sx = D3DVAL(230.0+OFFSETX);
    src_v[27].sy = D3DVAL(160.0+OFFSETY);
    src_v[27].sz = D3DVAL(0.2);
    src_v[27].rhw = D3DVAL(0.2);
    src_v[27].color = RGBA_MAKE(255,255,255, 255);
    src_v[27].specular = RGB_MAKE(0, 0, 0);

    src_v[28].sx = D3DVAL(280.0+OFFSETX);
    src_v[28].sy = D3DVAL(60.0+OFFSETY);
    src_v[28].sz = D3DVAL(0.2);
    src_v[28].rhw = D3DVAL(0.2);
    src_v[28].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[28].specular = RGB_MAKE(0, 0, 0);

    src_v[29].sx = D3DVAL(280.0+OFFSETX);
    src_v[29].sy = D3DVAL(160.0+OFFSETY);
    src_v[29].sz = D3DVAL(0.2);
    src_v[29].rhw = D3DVAL(0.2);
    src_v[29].color = RGBA_MAKE(255,255,255, 255);
    src_v[29].specular = RGB_MAKE(0, 0, 0);


    src_v[30].sx = D3DVAL(280.0+OFFSETX);
    src_v[30].sy = D3DVAL(160.0+OFFSETY);
    src_v[30].sz = D3DVAL(0.0000);
    src_v[30].rhw = D3DVAL(0.0000);
    src_v[30].color = RGBA_MAKE(255,255,255, 255);
    src_v[30].specular = RGB_MAKE(0, 0, 0);

	src_v[31].sx = D3DVAL(280.0+OFFSETX);
    src_v[31].sy = D3DVAL(60.0+OFFSETY);
    src_v[31].sz = D3DVAL(0.0000);
    src_v[31].rhw = D3DVAL(0.0000);
    src_v[31].color = RGBA_MAKE(255,255,255, 255);
    src_v[31].specular = RGB_MAKE(0, 0, 0);

    src_v[32].sx = D3DVAL(290.0+OFFSETX);
    src_v[32].sy = D3DVAL(60.0+OFFSETY);
    src_v[32].sz = D3DVAL(0.0000);
    src_v[32].rhw = D3DVAL(0.0000);
    src_v[32].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[32].specular = RGB_MAKE(0, 0, 0);


	src_v[33].sx = D3DVAL(280.0+OFFSETX);
    src_v[33].sy = D3DVAL(160.0+OFFSETY);
    src_v[33].sz = D3DVAL(0.0000);
    src_v[33].rhw = D3DVAL(0.0000);
    src_v[33].color = RGBA_MAKE(255,255,255, 255);
    src_v[33].specular = RGB_MAKE(0, 0, 0);

    src_v[34].sx = D3DVAL(290.0+OFFSETX);
    src_v[34].sy = D3DVAL(60.0+OFFSETY);
    src_v[34].sz = D3DVAL(0.0000);
    src_v[34].rhw = D3DVAL(0.0000);
    src_v[34].color = RGBA_MAKE(255, 255, 255, 255);
    src_v[34].specular = RGB_MAKE(0, 0, 0);

    src_v[35].sx = D3DVAL(290.0+OFFSETX);
    src_v[35].sy = D3DVAL(160.0+OFFSETY);
    src_v[35].sz = D3DVAL(0.0000);
    src_v[35].rhw = D3DVAL(0.0000);
    src_v[35].color = RGBA_MAKE(255,255,255, 255);
    src_v[35].specular = RGB_MAKE(0, 0, 0);


    /*
     * Create an execute buffer
     */
    size = sizeof(D3DVERTEX) * NUM_VERTICES;    
    size += sizeof(D3DINSTRUCTION) * 5;
    size += sizeof(D3DSTATE) * 2;
    size += sizeof(D3DPROCESSVERTICES);
    size += sizeof(D3DTRIANGLE) * NUM_TRIANGLES;
    memset(&debDesc, 0, sizeof(D3DEXECUTEBUFFERDESC));
    debDesc.dwSize = sizeof(D3DEXECUTEBUFFERDESC);
    debDesc.dwFlags = D3DDEB_BUFSIZE;
    debDesc.dwBufferSize = size;
    if (lpDev->lpVtbl->CreateExecuteBuffer(lpDev, &debDesc, &lpD3DExBuf,
                                           NULL) != D3D_OK) {
        return FALSE;
    }
    if (lpD3DExBuf->lpVtbl->Lock(lpD3DExBuf, &debDesc) != D3D_OK) {
        return FALSE;
    }
    lpBufStart = debDesc.lpData;
    memset(lpBufStart, 0, size);
    lpPointer = lpBufStart;

    /*
     * Copy vertices to execute buffer
     */
    VERTEX_DATA(&src_v[0], NUM_VERTICES, lpPointer);
    /*
     * Setup instructions in execute buffer
     */
    lpInsStart = lpPointer;
    OP_STATE_LIGHT(1, lpPointer);
        STATE_DATA(D3DLIGHTSTATE_MATERIAL, hMat1, lpPointer);
    OP_PROCESS_VERTICES(1, lpPointer);
        PROCESSVERTICES_DATA(D3DPROCESSVERTICES_COPY |
                             D3DPROCESSVERTICES_UPDATEEXTENTS, 0, NUM_VERTICES, lpPointer);
    OP_STATE_RENDER(1, lpPointer);
/*        STATE_DATA(D3DRENDERSTATE_TEXTUREHANDLE, TextureHandle[1], lpPointer);*/
        STATE_DATA(D3DRENDERSTATE_SHADEMODE, D3DSHADE_FLAT, lpPointer);
/*		 STATE_DATA(D3DRENDERSTATE_FOGENABLE, TRUE, lpPointer);
		STATE_DATA(D3DRENDERSTATE_FOGCOLOR, 0xffff0000, lpPointer);
	    STATE_DATA(D3DRENDERSTATE_FOGTABLEMODE, 1, lpPointer);
		STATE_DATA_FLOAT(D3DRENDERSTATE_FOGTABLEDENSITY, 0.75f, lpPointer);*/
		
		
   		
             

    /*
     * Make sure that the triangle data (not OP) will be QWORD aligned
     */
    if (QWORD_ALIGNED(lpPointer)) {
        OP_NOP(lpPointer);
    }
    OP_TRIANGLE_LIST(NUM_TRIANGLES, lpPointer);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 0;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 1;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 2;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_START;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
	    ((LPD3DTRIANGLE)lpPointer)->v1 = 3;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 4;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 5;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_EVEN;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 6;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 7;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 8;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_ODD;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
	    ((LPD3DTRIANGLE)lpPointer)->v1 = 9;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 10;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 11;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_EVEN;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 12;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 13;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 14;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_ODD;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
	    ((LPD3DTRIANGLE)lpPointer)->v1 = 15;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 16;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 17;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_EVEN;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 18;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 19;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 20;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_ODD;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
	    ((LPD3DTRIANGLE)lpPointer)->v1 = 21;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 22;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 23;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_EVEN;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 24;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 25;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 26;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_EVEN;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 27;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 28;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 29;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_EVEN;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 30;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 31;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 32;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_ODD;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);
        ((LPD3DTRIANGLE)lpPointer)->v1 = 33;
        ((LPD3DTRIANGLE)lpPointer)->v2 = 34;
        ((LPD3DTRIANGLE)lpPointer)->v3 = 35;
        ((LPD3DTRIANGLE)lpPointer)->wFlags = D3DTRIFLAG_EDGEENABLETRIANGLE & D3DTRIFLAG_ODD;
        lpPointer = ((char*)lpPointer) + sizeof(D3DTRIANGLE);

    OP_EXIT(lpPointer);
    /*
     * Setup the execute data
     */
    lpD3DExBuf->lpVtbl->Unlock(lpD3DExBuf);
    memset(&d3dExData, 0, sizeof(D3DEXECUTEDATA));
    d3dExData.dwSize = sizeof(D3DEXECUTEDATA);
    d3dExData.dwVertexCount = NUM_VERTICES;
    d3dExData.dwInstructionOffset = (ULONG) ((char *)lpInsStart - (char *)lpBufStart);
    d3dExData.dwInstructionLength = (ULONG) ((char *)lpPointer - (char *)lpInsStart);
    lpD3DExBuf->lpVtbl->SetExecuteData(lpD3DExBuf, &d3dExData);


    return TRUE;
}





