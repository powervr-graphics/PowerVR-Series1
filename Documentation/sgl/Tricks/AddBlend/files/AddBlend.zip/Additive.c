/*-----------------------------------------------------------------------------
   Name   : Additive Blend demo
   Author : Carlos Sarria inproved by David Gallardo -=<Kalisto>=-            
   Date   : Dec 1997
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/
#include <math.h>
#include "ddraw.h"
#include "sgl.h"
#include "frontend.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */
#pragma warning (disable : 4056)

#define	MAX(a,b)	((a)>(b) ? (a) : (b))
#define OPAQU  SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR
#define TRANS  SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR | SGLTT_GLOBALTRANS;

#define PI	3.142f

int Device, frame=0, finished = 0;
int	TexBackgrnd, TexForegrnd, TexAlpha;

SGLCONTEXT SGLContext;

float Added = 0.0f;

int TransVal = 255;

#define RGBColour(r, g, b) ((sgl_uint32) (((r) << 16) | ((g) << 8) | (b)))

void SetupContext    (void);
void SetupTextures   (void);
void Plane           (float PosX, float PosY, float PosZ, int Texture);

int  AdditiveAlpha   (char *BMPFile, sgl_bool MipMap, sgl_bool Dither);

/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
   
	Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	
	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

	SetupTextures (); 
	SetupContext  ();

    sgl_qual_texture_filter (sgl_tf_bilinear);

    SetCursor (NULL);   /* This hides the pointer */

	frame = 0;

	return 0;
}

/*------------------------------------------------------------------------------------------*/
void NextFrame()
{

 sgltri_startofframe (&SGLContext);

     /* Global Translucent value (CURSOR keys) */
     SGLContext.u32GlobalTrans = TransVal;    

	 /* Background */
   	 SGLContext.u32Flags = OPAQU;
     Plane (170, 60, 10, TexBackgrnd);

	 /* Additive blending with saturation */
	 SGLContext.u32Flags = TRANS;
	 Plane (170, 60,  9, TexAlpha);

   sgltri_render   (&SGLContext);

    frame++;
}
/*-------------------------------------------------------------------------------------------*/					   
void Finish()
{
	if(!finished){
		FreeAllBMPTextures ();
		sgl_delete_device(Device);	
		finished=1;
	}
}
/*------------------------------------------------------------------------------------*/
void SetupTextures (void)
{
	TexBackgrnd  = LoadBMPTexture ("backgrnd.bmp", FALSE, TRUE, FALSE);
	TexAlpha     = AdditiveAlpha  ("additive.bmp", TRUE, FALSE);

	/* Try with this one */
	/* TexAlpha = TransAdditiveAlpha ("additive.bmp", TRUE, FALSE); */
}
/*------------------------------------------------------------------------------------*/
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 10;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = OPAQU;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = FALSE;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.u32GlobalTrans       = 128;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*----------------------------------------------------------------------------------------------------*/
void Plane (float PosX, float PosY, float PosZ, int Texture)
{
 float Size = 300;
 SGLVERTEX Plane[4];
 int PlaneF[4] = { 0,1,2,3 };
 
 
     Plane[0].fX		= PosX;
	 Plane[0].fY		= PosY;
	 Plane[0].fInvW		= 1.0f/PosZ;
	 Plane[0].u32Colour = 0xFFFFFF;
	 Plane[0].fUOverW   = 0.0f;
     Plane[0].fVOverW   = 1.0f; 
            

	 Plane[1].fX		= PosX+Size;
	 Plane[1].fY		= PosY;
	 Plane[1].fInvW		= 1.0f/PosZ;
	 Plane[1].u32Colour = 0xFFFFFF;
	 Plane[1].fUOverW   = 1.0f;
     Plane[1].fVOverW   = 1.0f; 

	 Plane[2].fX		= PosX+Size;
	 Plane[2].fY		= PosY+Size;
	 Plane[2].fInvW		= 1.0f/PosZ;
	 Plane[2].u32Colour = 0xFFFFFF;
	 Plane[2].fUOverW   = 1.0f;
     Plane[2].fVOverW   = 0.0f; 

	 Plane[3].fX		= PosX;
	 Plane[3].fY		= PosY+Size;
	 Plane[3].fInvW		= 1.0f/PosZ;
	 Plane[3].u32Colour = 0xFFFFFF;
	 Plane[3].fUOverW   = 0.0f;
     Plane[3].fVOverW   = 0.0f; 

	 SGLContext.nTextureName   = Texture;
    
	 sgltri_quads (&SGLContext, 1, (int(*)[4])PlaneF, Plane);

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   AdditiveAlpha                                                  */ 
/*  Inputs          :   BMPFile, MipMap, Dither                                        */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Texture ID                                                     */
/*  Globals Used    :   None                                                           */
/*  Description     :   This routine builds a alpha map calculating the intensity      */
/*                      of the RGB values in the original BMP file.                    */
/*  Carlos note     :   David has done a great work here !!!                           */
/*-------------------------------------------------------------------------------------*/
int AdditiveAlpha (char *BMPFile, sgl_bool MipMap, sgl_bool Dither)
{
register i, j;
int rMap, SizeX, SizeY, nPixel=0;
sgl_intermediate_map TempMap;
sgl_map_sizes MapSize = 0;

	 TempMap =  ConvertBMPtoSGL (BMPFile, FALSE);

     SizeX = TempMap.x_dim;
	 SizeY = TempMap.y_dim;

	 for (j=0;j<SizeY;j++)
	 {
	    for(i=0;i<SizeX;i++)
			{
				float	r,g,b,max;
				r=(float)(TempMap.pixels+nPixel)->red;
				g=(float)(TempMap.pixels+nPixel)->green;
				b=(float)(TempMap.pixels+nPixel)->blue;
				max=MAX(r,g);
				max=MAX(b,max);

				if(max>8.f)
				{
					r/=max;
					g/=max;
					b/=max;
				}
				else
				{
					max=r=g=b=0.f;
				}

				(TempMap.pixels+nPixel)->red=r*255.f;
				(TempMap.pixels+nPixel)->green=g*255.f;
				(TempMap.pixels+nPixel)->blue=b*255.f;
				(TempMap.pixels+nPixel)->alpha=~(unsigned char)(max);	             

				nPixel++;
			}
	}
    
	switch (SizeX & 0x0001E0)
	{
	   case 32:  MapSize = sgl_map_32x32;   break;
	   case 64:  MapSize = sgl_map_64x64;   break;
	   case 128: MapSize = sgl_map_128x128; break;
	   case 256: MapSize = sgl_map_256x256; break;
	   default:  MapSize = sgl_map_256x256; break;
	}

	if (MipMap) rMap = sgl_create_texture ( sgl_map_trans16_mm, MapSize, TRUE,  Dither, &TempMap,  NULL);
	else        rMap = sgl_create_texture ( sgl_map_trans16,    MapSize, FALSE, Dither, &TempMap,  NULL);

	return rMap;
}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   TransAdditiveAlpha                                             */ 
/*  Inputs          :   BMPFile, MipMap, Dither                                        */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Texture ID                                                     */
/*  Globals Used    :   None                                                           */
/*  Description     :   This routine is the same than AdditiveAlpha but calculates the */
/*                      alpha map from the intensity of the original values.           */
/*                      For some "overlap" effects works fine.                         */ 
/*-------------------------------------------------------------------------------------*/
int TransAdditiveAlpha (char *BMPFile, sgl_bool MipMap, sgl_bool Dither)
{
register i, j;
int rMap, SizeX, SizeY, nPixel=0;
sgl_intermediate_map TempMap;
sgl_map_sizes MapSize = 0;
int AlphaColor;

	 TempMap =  ConvertBMPtoSGL (BMPFile, FALSE);

     SizeX = TempMap.x_dim;
	 SizeY = TempMap.y_dim;

	 for (j=0;j<SizeY;j++)
	 {
	    for(i=0;i<SizeX;i++)
			{
				float	r,g,b,max;
				r=(float)(TempMap.pixels+nPixel)->red;
				g=(float)(TempMap.pixels+nPixel)->green;
				b=(float)(TempMap.pixels+nPixel)->blue;

				AlphaColor = 255-(unsigned char) ((float)r*0.4f + (float)g*0.4f + (float)b*0.2f);
						
				max=MAX(r,g);
				max=MAX(b,max);

				if(max>8.0f)
				{
					r/=max;
					g/=max;
					b/=max;
				}

				else
				{
					max=r=g=b=0.0f;
				}

			           
				(TempMap.pixels+nPixel)->alpha  = AlphaColor;	       

				(TempMap.pixels+nPixel)->red   = r*255.f;
				(TempMap.pixels+nPixel)->green = g*255.f;
				(TempMap.pixels+nPixel)->blue  = b*255.f;
			
				
				nPixel++;
			}
	}
    
	switch (SizeX & 0x0001E0)
	{
	   case 32:  MapSize = sgl_map_32x32;   break;
	   case 64:  MapSize = sgl_map_64x64;   break;
	   case 128: MapSize = sgl_map_128x128; break;
	   case 256: MapSize = sgl_map_256x256; break;
	   default:  MapSize = sgl_map_256x256; break;
	}

	if (MipMap) rMap = sgl_create_texture ( sgl_map_trans16_mm, MapSize, TRUE,  Dither, &TempMap,  NULL);
	else        rMap = sgl_create_texture ( sgl_map_trans16,    MapSize, FALSE, Dither, &TempMap,  NULL);

	return rMap;
}
/*------------------------------------------------------------------------*/
/*--------------------------- End of File --------------------------------*/

