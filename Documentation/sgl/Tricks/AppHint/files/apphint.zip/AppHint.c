/*****************************************************************************
  Name : AppHint.c v1.00
  Date : June 1998
  Platform : ANSI compatible

  * DESCRIPTION:
  This file contains the PVRCreateAppHint function.
  This function is used to set App Hints for PowerVR PCX1 or PCX2 boards.
  

  Email any comments to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/


/************* Includes ***********/
#include <windows.h>
#include "AppHint.h"

									
/***********************************
************** Function ************
***********************************/


/*******************************************************************************
 * Function Name  : PVRCreateAppHint
 * Returns        : TRUE or FALSE
 * Inputs		  : lpExeName, lpValueName, lpValue
 * Description    : Create a key called lpExeName in the PowerVR section of the
 *					registry (HKEY_LOCAL_MACHINE\SOFTWARE\PowerVR\PCX1&2\App hints)
 *					A new string is created at this location (lpValueName) with value
 *					lpValue.
 *					
 *******************************************************************************/
BOOL PVRCreateAppHint(char *lpExeName, char *lpValueName, char *lpValue)
{
	BOOL	bReturnValue=TRUE;
	LONG	nErrorCode=0;
	HKEY	hKey;
	DWORD	dwDispn;
	char	pszPVRAppHintsKey[300];
		
	/* Assign path */
	strcpy(pszPVRAppHintsKey, "SOFTWARE\\PowerVR\\PCX1&2\\App hints\\");
	
	/* Append exe name to create new key */
	strcat(pszPVRAppHintsKey, lpExeName);

	/* First create key and retreive key handle (only retrieve key handle
	   if key already exists */
	nErrorCode=RegCreateKeyEx(HKEY_LOCAL_MACHINE, pszPVRAppHintsKey, 0, "", 
							  REG_OPTION_NON_VOLATILE,
							  KEY_WRITE | KEY_READ,
							  NULL,
							  &hKey,
							  &dwDispn);
	if (nErrorCode!=ERROR_SUCCESS)
	{
		OutputDebugString("Error in RegCreateKeyEx\n");
		bReturnValue=FALSE;
	}
	
	/* Then set a value */
	nErrorCode=RegSetValueEx(hKey,
							 lpValueName,
							 0,
							 REG_SZ,
							 (CONST BYTE *)lpValue,
							 strlen(lpValue)+1);
	if (nErrorCode!=ERROR_SUCCESS)
	{
		OutputDebugString("Error in RegSetValueEx\n");
		bReturnValue=FALSE;
	}

	/* Close key */
	nErrorCode=RegCloseKey(hKey);
	if (nErrorCode!=ERROR_SUCCESS)
	{
		OutputDebugString("Error in RegCloseKey\n");
		bReturnValue=FALSE;
	}

	/* Return status */
	return(bReturnValue);
}


