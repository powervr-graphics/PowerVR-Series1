/*****************************************************************************
  Name : AppHint.h v1.00
  Date : June 1998
  Platform : ANSI compatible

  Header file for AppHint.c.
  

  Email any comments to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/


#ifndef _APPHINT_H_
#define _APPHINT_H_

#ifdef __CPLUSPLUS
extern "C" {
#endif

BOOL	PVRCreateAppHint(char *lpExeName, char *lpValueName, char *lpValue);

#ifdef __CPLUSPLUS
}
#endif

#endif

