/*****************************************************************************
  Name : AppTest.c v1.00
  Date : June 1998
  Platform : ANSI compatible

  * DESCRIPTION:
  Simple program that calls the function PVRCreateAppHint from AppHint.c

  

  Email any comments to nthibieroz@videologic.com

  Copyright : 1998 by VideoLogic Limited. All rights reserved.
******************************************************************************/


/************* Includes ***********/
#include <windows.h>
#include "AppHint.h"


/************* Globals ************/
static MSG			msg;
static HWND			hwnd;
static WNDCLASS		wndclass;
static HINSTANCE	HInst;					/* Windows management variables */


/************* Prototypes ************/
static LRESULT CALLBACK WindowProc( HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam );
int PASCAL				WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow);

									
/***********************************
************** Functions ***********
***********************************/


/*******************************************************************************
 * Function Name  : WindowProc
 * Returns        : LRESULT
 * Inputs		  : hwnd, message, wParam, lParam
 * Global Used    : pMyPowerVRInfo, pMyPowerVRD3DInfo
 * Description    : Callback function for main dialog box window
 *					
 *******************************************************************************/
/* Message processing function */
static LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return DefWindowProc(hwnd, message, wParam, lParam);
}


/*******************************************************************************
 * Function Name  : WinMain
 * Returns        : int
 * Inputs		  : hInstance, hprevInstance, lpCmdLine, nCmdShow
 * Global Used    : wndclass, hwnd, msg
 * Description    : Callback function for main dialog box window
 *					
 *******************************************************************************/
int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    /* Create window class */
	if (!hPrevInstance)
	{
        wndclass.style=0;
        wndclass.lpfnWndProc=(WNDPROC)WindowProc;
        wndclass.cbClsExtra=0;
        wndclass.cbWndExtra=0;
        wndclass.hInstance=hInstance;
        wndclass.hIcon=LoadIcon(NULL, IDI_QUESTION);
        wndclass.hCursor=LoadCursor(NULL, IDC_ARROW);
        wndclass.hbrBackground=GetStockObject(LTGRAY_BRUSH);
        wndclass.lpszMenuName=NULL;
        wndclass.lpszClassName="PowerVR AppHint Class";
        RegisterClass(&wndclass);
    }

	/* Create window */
	hwnd = CreateWindowEx(0, 
						  "PowerVR AppHint Class", 
						  "PowerVR AppHint Creation", 
						  WS_OVERLAPPEDWINDOW, 
						  CW_USEDEFAULT,
						  CW_USEDEFAULT,
						  CW_USEDEFAULT,
						  CW_USEDEFAULT,
                          NULL, 
						  NULL, 
						  hInstance, 
						  NULL );

	/* Test if window has been created */
	if (hwnd==NULL)
	{
		MessageBox(NULL, "Unable to create main Window\n", "PowerVR Detection", MB_ICONERROR | MB_OK);
		exit(0);		/* Exit immediately */
	}

	/* Show and update window */
	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);

	/* Create app hints */
	PVRCreateAppHint("mygame.exe", "Description", "Full name of my game");
	PVRCreateAppHint("mygame.exe", "SglTransSort", "1");
	PVRCreateAppHint("mygame.exe", "DisableNewPassPerTri", "1");

	/* Destroy window */
	DestroyWindow(hwnd);

	/* End of program */
	return msg.wParam;
}


