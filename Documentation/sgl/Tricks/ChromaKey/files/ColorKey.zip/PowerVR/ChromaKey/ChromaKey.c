/*-----------------------------------------------------------------------------
   Name   : ChromaKey demo for SGL-Direct
   Author : Carlos Sarria             
   Date   : Oct 1997
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#include "ddraw.h"
#include "sgl.h"
#include "frontend.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */
#pragma warning (disable : 4056)

#define OPAQU  SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR
#define TRANS  SGLTT_TEXTURE | SGLTT_GOURAUD | SGLTT_BILINEAR | SGLTT_GLOBALTRANS;

#define PI	3.142f

int Device, frame=0, finished = 0;
int	TexBackgrnd, TexAlpha;

SGLCONTEXT SGLContext;

float Added = 0.0f;

int TransVal = 255;

#define RGBColour(r, g, b) ((sgl_uint32) (((r) << 16) | ((g) << 8) | (b)))

void SetupContext  (void);
void SetupTextures (void);
void Plane         (float PosX, float PosY, float PosZ, int Texture);
int  ChromaKeyAlpha ( char *BMPFile, sgl_bool MipMap, sgl_bool Dither, sgl_uint32 Key);

/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
   
	Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	
	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

	SetupTextures (); 
	SetupContext  ();

    sgl_qual_texture_filter (sgl_tf_bilinear);

    SetCursor (NULL);   /* This hides the pointer */

	frame = 0;

	return 0;
}

/*------------------------------------------------------------------------------------------*/
void NextFrame()
{

 sgltri_startofframe (&SGLContext);

     /* Change global translucent pressing CURSOR keys */
     SGLContext.u32GlobalTrans = TransVal;    

	 /* Opaque Background */
   	 SGLContext.u32Flags = OPAQU;
     Plane (170, 60, 10, TexBackgrnd);

	 /* Translucent Foreground */
	 SGLContext.u32Flags = TRANS;
	 Plane (170, 60,  9, TexAlpha);

   sgltri_render   (&SGLContext);

    frame++;
}
/*-------------------------------------------------------------------------------------------*/					   
void Finish()
{
	if(!finished){
		FreeAllBMPTextures ();
		sgl_delete_device(Device);	
		finished=1;
	}
}
/*------------------------------------------------------------------------------------*/
void SetupTextures (void)
{

	TexBackgrnd  = LoadBMPTexture ("backgrnd.bmp", FALSE, TRUE, FALSE);
	TexAlpha = ChromaKeyAlpha ("ChromaKey.bmp", TRUE, FALSE, RGB(255,0,255));
}
/*------------------------------------------------------------------------------------*/
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 10;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = OPAQU;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = FALSE;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.u32GlobalTrans       = 128;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*----------------------------------------------------------------------------------------------------*/
void Plane (float PosX, float PosY, float PosZ, int Texture)
{
 float Size = 300;
 SGLVERTEX Plane[4];
 int PlaneF[4] = { 0,1,2,3 };
 
 
     Plane[0].fX = PosX;
	 Plane[0].fY = PosY;
	 Plane[0].fInvW = 1.0f/PosZ;
	 Plane[0].u32Colour = 0xFFFFFF;
	 Plane[0].fUOverW    =  0.0f;
     Plane[0].fVOverW    =  1.0f; 
            

	 Plane[1].fX = PosX+Size;
	 Plane[1].fY = PosY;
	 Plane[1].fInvW = 1.0f/PosZ;
	 Plane[1].u32Colour = 0xFFFFFF;
	 Plane[1].fUOverW    =  1.0f;
     Plane[1].fVOverW    =  1.0f; 

	 Plane[2].fX = PosX+Size;
	 Plane[2].fY = PosY+Size;
	 Plane[2].fInvW = 1.0f/PosZ;
	 Plane[2].u32Colour = 0xFFFFFF;
	 Plane[2].fUOverW    = 1.0f;
     Plane[2].fVOverW    = 0.0f; 

	 Plane[3].fX = PosX;
	 Plane[3].fY = PosY+Size;
	 Plane[3].fInvW = 1.0f/PosZ;
	 Plane[3].u32Colour = 0xFFFFFF;
	 Plane[3].fUOverW    =  0.0f;
     Plane[3].fVOverW    =  0.0f; 

	 SGLContext.nTextureName   = Texture;
    
	 sgltri_quads (&SGLContext, 1, (int(*)[4])PlaneF, Plane);

}
/*-------------------------------------------------------------------------------------*/
/*  Function Name   :   ChromaKeyAlpha                                                 */ 
/*  Inputs          :   BMPFile, MipMap, Dither, Key                                   */  
/*  Outputs         :   None                                                           */
/*  Returns         :   Texture ID,                                                    */
/*  Globals Used    :   None                                                           */
/*  Description     :   This is a routine for building a translucent map from a opaque */
/*                      BMP using a Chroma Key.                                        */
/*-------------------------------------------------------------------------------------*/
int ChromaKeyAlpha (char *BMPFile, sgl_bool MipMap, sgl_bool Dither, sgl_uint32 Key)
{
register i, j, k;
int rMap, SizeX, SizeY, Red, Green, Blue, nAverage, nPixel=0, nOff[8];
unsigned char AlphaColor;
sgl_intermediate_map TempMap;
sgl_map_sizes MapSize = 0;

     /* Loading the original BMP */
	 TempMap =  ConvertBMPtoSGL (BMPFile, FALSE);

	 /* Setting the alpha chanel to ON or OFF*/
     SizeX = TempMap.x_dim;
	 SizeY = TempMap.y_dim;

	 for (j=0;j<SizeY;j++)
	 {
	    for(i=0;i<SizeX;i++)
			{
			AlphaColor =(*((sgl_uint32 *)(TempMap.pixels+nPixel)) == Key) ? 0xFF:0x00;
			(TempMap.pixels+nPixel++)->alpha = AlphaColor;
			}
	}

	/* Change the original RGB map in order to avoid interpolation with the chroma key.  */
	/* If a pixel is translucent and has no translucent neighbours, its colour is set    */
	/* to the average colour of the surrounding pixels.                                  */  
	nPixel = 0;

	nOff[0] = -SizeX-1;  nOff[1] = -SizeX;  nOff[2] = -SizeX+1;
	nOff[3] = -1;        nOff[4] = 1;
	nOff[5] =  SizeX-1;  nOff[6] =  SizeX;  nOff[7] =  SizeX+1;
   
	for (j=0;j<SizeY;j++)
	{
	    for(i=0;i<SizeX;i++)
		{
			if((TempMap.pixels+nPixel)->alpha == 0) { nPixel++; continue; }

            nAverage = Red = Green = Blue = 0;

			for (k=0; k<8; k++)
			{
				if ((i==0 && (k==0 || k==3 || k==5)) ||
					(j==0 && (k==0 || k==1 || k==2)) ||
					(i==SizeX-1 && (k==2 || k==4 || k==7)) ||
					(j==SizeX-1 && (k==5 || k==6 || k==7))   ) continue;

                if((TempMap.pixels+nPixel+nOff[k])->alpha == 0)
				{
				nAverage++; 
				Red   += (TempMap.pixels+nPixel+nOff[k])->red;
				Green += (TempMap.pixels+nPixel+nOff[k])->green;
				Blue  += (TempMap.pixels+nPixel+nOff[k])->blue;
				}
			}
			if (nAverage)
			{
            (TempMap.pixels+nPixel)->red   = (char) (Red / nAverage);
			(TempMap.pixels+nPixel)->green = (char) (Green / nAverage);
			(TempMap.pixels+nPixel)->blue  = (char) (Blue / nAverage);
			}
			nPixel++;
		}
	}

	switch (SizeX & 0x0001E0)
	{
	   case 32:  MapSize = sgl_map_32x32;   break;
	   case 64:  MapSize = sgl_map_64x64;   break;
	   case 128: MapSize = sgl_map_128x128; break;
	   case 256: MapSize = sgl_map_256x256; break;
	   default:  MapSize = sgl_map_256x256; break;
	}

	if (MipMap) rMap = sgl_create_texture ( sgl_map_trans16_mm, MapSize, TRUE,  Dither, &TempMap,  NULL);
	else        rMap = sgl_create_texture ( sgl_map_trans16,    MapSize, FALSE, Dither, &TempMap,  NULL);

	return rMap;
}
/*------------------------------------------------------------------------*/
/*--------------------------- End of File --------------------------------*/

