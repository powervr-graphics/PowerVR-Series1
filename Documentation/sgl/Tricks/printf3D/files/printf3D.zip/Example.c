/*-----------------------------------------------------------------------------
   Name   : Example.c (Using printf3D function)
   Author : Carlos Sarria             
   Date   : Nov 1997
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/
#include <math.h>
#include <windows.h>

#include "ddraw.h"
#include "sgl.h"

#include "printf3D.h"
#include "frontend.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */

SGLCONTEXT SGLContext;
int Device, Finished = FALSE, TexBackgrnd;

void SetupContext   (void);
void Background     (void);

/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
   
	Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, TRUE);
	
	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

	SetupContext  ();

    sgl_qual_texture_filter (sgl_tf_bilinear);

    SetCursor (NULL);   /* This hides the pointer */

	TexBackgrnd  = LoadBMPTexture ("Backgrnd.bmp", FALSE, FALSE, FALSE);

	return 0;
}

/*------------------------------------------------------------------------------------------*/
void NextFrame()
{
static i, j;
char *Text[] = { "This is a DEMO,",
					 "You can write",
					 "on the screen",
					 "whatever you want.",
					 "Numbers: 0123456789,",
					 "CAPITAL letters,",
					 "small letters,",
					 "and some symbols.",
					 ".,\"-():=",
					 "0123456789",
					 "abcdefghijklm",
					 "nopqrstuvwxyz",
					 "ABCDEFGHIJKLMN",
					 "OPQRSTUVWXYZ",
		              
	};
static Frame = 0;

  sgltri_startofframe (&SGLContext);
 
  printf3D (0, 0, 1, "PowerVR SGL Direct Demo.", &SGLContext);

  j++; if (j>100){ j=0; i++; if (i==14) i=0;}
  
  printf3D (0, 220, sin((float)j*0.0314f)*3.0f, Text[i], &SGLContext);

  Background ();

  sgltri_render   (&SGLContext);

  Frame++;
}
/*-------------------------------------------------------------------------------------------*/					   
void Finish()
{
	if(Finished==FALSE){
		FreeAllBMPTextures ();
		sgl_delete_device(Device);	
		Finished = TRUE;
	}
}

/*------------------------------------------------------------------------------------*/
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 10;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = FALSE;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
	SGLContext.u32GlobalTrans       = 128;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*------------------------------------------------------------------------------*/
void Background (void)
{
 SGLVERTEX Plane[4];
 int Faces[4] = {0,1,2,3};
 

     Plane[0].fX		= 0.0f;
	 Plane[0].fY		= 0.0f;
	 Plane[0].fInvW		= 1/10000.0f;
	 Plane[0].u32Colour = 0xFFFFFFFF;
	 Plane[0].fUOverW   = 0.01f;
     Plane[0].fVOverW   = 0.99f; 
            

	 Plane[1].fX		= 640.0f;
	 Plane[1].fY		= 0.0f;
	 Plane[1].fInvW		= 1/10000.0f;
	 Plane[1].u32Colour = 0xFFFFFFFF;
	 Plane[1].fUOverW   = 0.99f;
     Plane[1].fVOverW   = 0.99f;

	 Plane[2].fX		= 640.0f;
	 Plane[2].fY		= 480.0f;
	 Plane[2].fInvW     = 1/10000.0f;
	 Plane[2].u32Colour = 0xFFFFFFFF;
	 Plane[2].fUOverW   = 0.99f;
     Plane[2].fVOverW   = 0.01f;

	 Plane[3].fX		= 0.0f;
	 Plane[3].fY		= 480.0f;
	 Plane[3].fInvW		= 1/10000.0f;
	 Plane[3].u32Colour	= 0xFFFFFFFF;
	 Plane[3].fUOverW	= 0.99f;
     Plane[3].fVOverW	= 0.01f; 


	 SGLContext.nTextureName = TexBackgrnd;
     SGLContext.u32Flags     =  SGLTT_TEXTURE | SGLTT_BILINEAR ;

	 sgltri_quads (&SGLContext, 1, (int(*)[4]) Faces, Plane);

}
/*------------------------------------------------------------------------*/
/*--------------------------- End of File --------------------------------*/

