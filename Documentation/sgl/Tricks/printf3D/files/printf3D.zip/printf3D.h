/*printf3D.h */

#include "sgl.h"

#ifndef PRINTF_3D
#define PRINTF_3D

#define MAX_LETT      100
#define SCALE_OFFSET  128

void printf3D (float PosX, float PosY, float Size, char *Text, SGLCONTEXT *SGLContext);


#endif

