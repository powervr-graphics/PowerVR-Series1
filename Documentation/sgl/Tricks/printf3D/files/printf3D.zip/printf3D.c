/*--------------------------------------------------------------------*/
/*   Name   : printf3D.c                                              */
/*   Author : Carlos Sarria                                           */
/*   Date   : November 1997                                           */
/*                                                                    */
/*   Copyright : 1997 by VideoLogic Limited. All rights reserved.     */
/*--------------------------------------------------------------------*/

#include "ABCTable.h"
#include "printf3D.h"

#include <malloc.h>

/*--------------------------------------------------------------------*/
/*  Function Name   : printf3D                                        */ 
/*  Inputs          : PosX, PosY, Scale, Text                         */  
/*  Outputs         : None                                            */
/*  Returns         : None                                            */
/*  Globals Used    : ABCTexture, TextSize, TextU, TextV              */
/*                    (from ABCTable.h)                               */
/*  Description     :                                                 */
/*--------------------------------------------------------------------*/
void printf3D (float PosX, float PosY, float Scale, char *Text, SGLCONTEXT *SGLContext)
{
sgl_intermediate_map TempMap;
SGLVERTEX	LettVert[4*MAX_LETT];
int			i = 0, Val,  CVert = 0, FlipU, FlipV, Flags, TexName, NumFaces;
static int	Quad[4*MAX_LETT], TexID = 666; 
float		CurPos = 0, VPos, HPos, UVHPos, UVVPos;
float		TextColor[3] = { 0.0f, 0.0f, 0.0f };
    
    if (Scale<=0) return;

	/* The texture is created here (only once) reading data from ABCTable.h */
    if (TexID == 666) {

        for (i=0; i<4*MAX_LETT; i++) Quad[i]=i;

		TempMap.id[0]='I'; TempMap.id[1]='M'; TempMap.id[2]='A'; TempMap.id[3]='P';
		TempMap.x_dim = 256;
		TempMap.y_dim = 256;
		TempMap.pixels = (sgl_map_pixel *) malloc (4*256*256);

		for (i=0; i<256*256; i++)
		{
			(TempMap.pixels+i)->red   = (char) ((255-ABCTexture[i])*TextColor[0]);
			(TempMap.pixels+i)->green = (char) ((255-ABCTexture[i])*TextColor[1]);
			(TempMap.pixels+i)->blue  = (char) ((255-ABCTexture[i])*TextColor[2]);
			(TempMap.pixels+i)->alpha = ABCTexture[i];
		}

		/* Change sgl_map_trans16 to sgl_map16bit to get a opaque texture */
		TexID = sgl_create_texture (sgl_map_trans16, sgl_map_256x256, FALSE, FALSE, &TempMap, NULL);
	}

      NumFaces = i = CVert = 0;
	  
	  Scale *= SCALE_OFFSET;

      while (TRUE)
	  {
       Val = (int)*(Text+i++);

	   if (Val==0 || i>MAX_LETT) break;

	   if (Val==' ')  {CurPos += TextSize['1']*Scale; continue;}
  
	   VPos   = Scale*(30.0f/255.0f);
	   HPos   = Scale*TextSize[Val];
	   UVHPos = TextSize[Val];
	   UVVPos = (30.0f/255.0f);

	   LettVert[CVert].fX			= PosX+CurPos;
	   LettVert[CVert].fY			= PosY;
	   LettVert[CVert].fInvW		= 1.0f;
	   LettVert[CVert].u32Colour	= 0xFFFFFFFF;
	   LettVert[CVert].fUOverW		= TextU[Val];
	   LettVert[CVert].fVOverW		= TextV[Val];
	   CVert++;

	   LettVert[CVert].fX			= PosX+CurPos+HPos;
	   LettVert[CVert].fY			= PosY;
	   LettVert[CVert].fInvW		= 1.0f;
	   LettVert[CVert].u32Colour	= 0xFFFFFFFF;
	   LettVert[CVert].fUOverW		= TextU[Val]+UVHPos;
	   LettVert[CVert].fVOverW		= TextV[Val];
	   CVert++;

	   LettVert[CVert].fX			= PosX+CurPos+HPos;
	   LettVert[CVert].fY			= PosY+VPos;
	   LettVert[CVert].fInvW		= 1.0f;
	   LettVert[CVert].u32Colour	= 0xFFFFFFFF;
	   LettVert[CVert].fUOverW		= TextU[Val]+UVHPos;
	   LettVert[CVert].fVOverW		= TextV[Val]-UVVPos;
	   CVert++;

	   LettVert[CVert].fX			= PosX+CurPos;
	   LettVert[CVert].fY			= PosY+VPos;
	   LettVert[CVert].fInvW		= 1.0f;
	   LettVert[CVert].u32Colour	= 0xFFFFFFFF;
	   LettVert[CVert].fUOverW		= TextU[Val];
	   LettVert[CVert].fVOverW		= TextV[Val]-UVVPos;
       CVert++;

	   NumFaces++;

       CurPos += TextSize[Val]*Scale;

	  }

	  FlipU   = SGLContext->bFlipU;
	  FlipV   = SGLContext->bFlipV;
	  Flags   = SGLContext->u32Flags;
	  TexName = SGLContext->nTextureName;


	  SGLContext->bFlipU		= FALSE;
	  SGLContext->bFlipV		= FALSE;
	  SGLContext->nTextureName	= TexID;
	  SGLContext->u32Flags		= SGLTT_TEXTURE | SGLTT_BILINEAR ;

	  sgltri_quads (SGLContext, NumFaces, (int (*)[4])Quad, LettVert);

	  SGLContext->bFlipU		= FlipU;
	  SGLContext->bFlipV		= FlipV;
	  SGLContext->u32Flags		= Flags;
	  SGLContext->nTextureName	= TexName;

	   
	   
}

/*---------------------- End Of File -----------------------------------*/