/*-----------------------------------------------------------------------------
   Name   : Test
   Author : Carlos Sarria             
   Date   : Sep 1997
 
   Copyright : 1997 by VideoLogic Limited. All rights reserved.
 -----------------------------------------------------------------------------*/

#include "ddraw.h"
#include "sgl.h"
#include "sglwin.h"

#pragma warning (disable : 4244)  /* Float to Double Conversion Warning */
#pragma warning (disable : 4056)

#define NAMED_ITEM			TRUE
#define UNAMED_ITEM			FALSE

#define PI	3.142f

int Device, frame=0, finished = 0;
int	Texture[2];

SGLCONTEXT SGLContext;

float Added = 0.0f;
/* Added corresponds to the amount by which u is stretched when F2 is pressed.
   It is equal to [ 0.5 x (1/256) ]. 
   The resulting range for u is 0.5x(1/256) to [1 - ( 0.5 x (1/256))].
   This will ensure that no texel information from the opposite side of the texture
   map is sampled in at the texture boundary, resolving the visible-line problem. */


#define RGBColour(r, g, b) ((sgl_uint32) (((r) << 16) | ((g) << 8) | (b)))

void SetupContext  (void);
void SetupTextures (void);
void Test          (void);

/*-------------------------------------------------------------------------------------*/
int SetupScene (void)
{
   
	Device = sgl_create_screen_device (0, 640, 480, sgl_device_16bit, FALSE);
	
	if (Device<0) return ERR_CREATE_SCREEN_DEVICE;

	SetupTextures (); 
	SetupContext  ();
        
	frame = 0;

	return 0;
}

/*------------------------------------------------------------------------------------------*/
void NextFrame()
{

   sgltri_startofframe (&SGLContext);

     Test();

   sgltri_render   (&SGLContext);

    frame++;
}
/*-------------------------------------------------------------------------------------------*/					   
void Finish()
{
	if(!finished){
		FreeAllBMPTextures ();
		sgl_delete_device(Device);	
		finished=1;
	}
}
/*------------------------------------------------------------------------------------*/
void SetupTextures (void)
{
	Texture[0]  = LoadBMPTexture ("Test1.bmp", FALSE, TRUE, FALSE);
	Texture[1]  = LoadBMPTexture ("Test2.bmp", FALSE, TRUE, FALSE);
}
/*------------------------------------------------------------------------------------*/
void SetupContext (void)
{
	SGLContext.bFogOn               = FALSE;
	SGLContext.fFogR                = 0.3f;
	SGLContext.fFogG                = 0.7f;
	SGLContext.fFogB                = 0.7f;
	SGLContext.u32FogDensity        = 10;
	SGLContext.bCullBackfacing      = FALSE;
	SGLContext.u32Flags             = SGLTT_TEXTURE | 0x00040000 | SGLTT_BILINEAR;
	SGLContext.nTextureName         = 0;
    SGLContext.bDoClipping          = TRUE;
    SGLContext.cBackgroundColour[0] = 0.0f;
	SGLContext.cBackgroundColour[1] = 0.0f;
	SGLContext.cBackgroundColour[2] = 0.0f;
	SGLContext.eShadowLightVolMode  = ENABLE_SHADOWS;
	SGLContext.bFlipU               = FALSE;
	SGLContext.bFlipV               = FALSE;
    SGLContext.bDoUVTimesInvW       = TRUE;
    SGLContext.eFilterType          = sgl_tf_bilinear;
}
/*----------------------------------------------------------------------------------------------------*/
void Test (void)
{
 float TPosX = 0, TPosY = 60.0f, Size = 320;
 float PosX,PosY;
 register i;
 SGLVERTEX Plane[4];
 int PlaneF[4] = { 0,1,2,3 };
 
 
	 for(i=0;i<2;i++)
	 {
     
	 PosX = i*Size+TPosX; 
	 PosY = TPosY;

     Plane[0].fX = PosX;
	 Plane[0].fY = PosY;
	 Plane[0].fInvW = 1.0f;
	 Plane[0].u32Colour = 0xFFFFFF;
	 Plane[0].fUOverW    =  0.0f + Added;
     Plane[0].fVOverW    =  1.0f; 
            

	 Plane[1].fX = PosX+Size;
	 Plane[1].fY = PosY;
	 Plane[1].fInvW = 1.0f;
	 Plane[1].u32Colour = 0xFFFFFF;
	 Plane[1].fUOverW    =  1.0f - Added;
     Plane[1].fVOverW    =  1.0f; 

	 Plane[2].fX = PosX+Size;
	 Plane[2].fY = PosY+Size;
	 Plane[2].fInvW = 1.0f;
	 Plane[2].u32Colour = 0xFFFFFF;
	 Plane[2].fUOverW    = 1.0f - Added;
     Plane[2].fVOverW    = 0.0f; ; 

	 Plane[3].fX = PosX;
	 Plane[3].fY = PosY+Size;
	 Plane[3].fInvW = 1.0f;
	 Plane[3].u32Colour = 0xFFFFFF;
	 Plane[3].fUOverW    =  0.0f + Added;
     Plane[3].fVOverW    =  0.0f; 

	 SGLContext.nTextureName   = Texture[i];
     SGLContext.u32Flags       =  SGLTT_TEXTURE | SGLTT_BILINEAR ;

	 sgltri_quads (&SGLContext, 1, (int(*)[4])PlaneF, Plane);
	 }

}
/*------------------------------------------------------------------------*/
/*--------------------------- End of File --------------------------------*/

