/*****************************************************************************
  Name : FRONTEND.C  (Reduced Version)
  Date : February 1997
  Description : 
  Platform : ANSI compatible

  Copyright : 1997 by VideoLogic Limited. All rights reserved.   
******************************************************************************/

#include <windows.h>
#include <mmsystem.h> 

#include "ddraw.h"
#include "sgl.h"

#include "sglwin.h" 

#define X_SIZE 640
#define Y_SIZE 480
#define DPIXEL 16

static HINSTANCE  	hInst;
static HWND  		hWnd;
BOOL				bActive;
DWORD 				LastError;
BOOL 				bInfo=0;
sgl_versions*		versions;
sgl_win_versions*	w32versions;
BOOL				bQuit = FALSE;
int					nStrictLocks;
BOOL				bDisplayFPS = FALSE;

long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam);
int eor_callback();

extern float Added;
/*-------------------------------------------------------------------------------------------*/
int PASCAL WinMain ( HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	static char szAppName[] = "SGLFrontEnd";
	HWND        hwnd;
	MSG         msg;
	WNDCLASS    wndclass;
	int			iret;
	int			loopcount;

	versions = sgl_get_versions();
	w32versions = sgl_get_win_versions();

	hInst = hInstance;

	if (!hPrevInstance)	{
		wndclass.style = CS_HREDRAW | CS_VREDRAW;
	    wndclass.lpfnWndProc = WndProc;
	    wndclass.cbClsExtra = 0;
	    wndclass.cbWndExtra = 0;
	    wndclass.hInstance = hInstance;
	    wndclass.hIcon = LoadIcon( hInstance, IDI_APPLICATION );
	    wndclass.hCursor = LoadCursor( NULL, IDC_ARROW );
	    wndclass.hbrBackground = NULL;
	    wndclass.lpszMenuName = NULL;
	    wndclass.lpszClassName = "SGLClass";
		RegisterClass (&wndclass);
	}



    hwnd = CreateWindowEx(WS_EX_TOPMOST, "SGLClass", NULL, WS_POPUP|WS_VISIBLE, 0, 0, 
		                  GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),
				          NULL, NULL, hInstance, NULL );

	if (hwnd == NULL) {LastError = GetLastError();	return FALSE;}

	Sleep(200);

	nStrictLocks = GetPrivateProfileInt("Default","StrictLocks",0,"sglhw.ini");

	iret =  sgl_use_ddraw_mode (hwnd, NULL); 

	if (iret !=	sgl_no_err){
		ShowWindow(hwnd,SW_HIDE);
		MessageBox (NULL,"ERROR : sgl_use_ddraw_mode failed",NULL,MB_OK);
		DestroyWindow(hwnd);
		return FALSE;
	}
	

	iret = SetupScene (X_SIZE, Y_SIZE, DPIXEL);


	if (iret !=	sgl_no_err)	{
		if (iret == ERR_CREATE_SCREEN_DEVICE)
			MessageBox(NULL,"sgl_create_screen_device\n\nERROR : Graphics device does not support required direct draw mode", NULL, MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
		
		if (iret == ERR_CREATE_VIEWPORT)
			MessageBox(NULL,"sgl_create_viewport\n\nERROR : Graphics device does not support required direct draw mode",NULL, MB_SYSTEMMODAL| MB_ICONSTOP | MB_OK);
		

		DestroyWindow(hwnd);
		return FALSE;
	}


	bActive = TRUE;

	if (nStrictLocks) {
		loopcount = 100;

		while (loopcount--)  {
	      	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE )){

	            if (!GetMessage( &msg, NULL, 0, 0 ))  return msg.wParam;

	            TranslateMessage(&msg); 
	            DispatchMessage(&msg);
	        }
	    }

	
		iret = sgl_use_eor_callback(&eor_callback);

		while (!bQuit) 	NextFrame();

		Sleep(100);
		Finish();
	}

	else{
		while (1){
	      	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE )) {
	            if (!GetMessage( &msg, NULL, 0, 0 )) {Finish(); break;}

	            TranslateMessage(&msg); 
	            DispatchMessage(&msg);
	       }
	        else if (bActive) NextFrame();
			else WaitMessage();
	    }
	}

	return 0;
}
/*------------------------------------------------------------------------------------------*/
int eor_callback()
{
	MSG         msg;

	while(1)
	{
	  	if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE )){
	        if (!GetMessage( &msg, NULL, 0, 0 )) { bQuit = TRUE;  return 1;}

	        TranslateMessage(&msg); 
	        DispatchMessage(&msg);
	    }

		Sleep(10); /* Allow the mouse some time to move */

		if (bActive) break; 
	}

	return 0; 
}
/*-------------------------------------------------------------------------------------------*/
long FAR PASCAL WndProc (HWND hwnd, UINT message, UINT wParam, LONG lParam)
{

	hWnd = hwnd;

	switch (message){

	    case WM_ACTIVATEAPP:
		     bActive = (BOOL)wParam;
             break;
		
		
		case WM_CREATE:
			 return 0;
		
		case WM_DESTROY:
		     bQuit = TRUE;
			 PostQuitMessage (0);
			 return 0;
		
	    case WM_KEYDOWN:
		     switch(wParam){
		
			      case VK_F12:
				  case VK_ESCAPE:
				       bActive = FALSE;
					   Sleep(100);
				       PostMessage(hWnd, WM_CLOSE, 0, 0);
		               break;
                 	  
                  case VK_F2: Added = 1.0f / 512.0f; break;
			 	  case VK_F1:  Added = 0.00f;         break;
				 
			 }
	        break;
	}

	return DefWindowProc (hwnd, message, wParam, lParam);
}
/*-----------------------------------  END OF FILE ---------------------------------------*/
